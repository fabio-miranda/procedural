package skeleton;

import static sity.Parameters.*;
import geom.*;

import java.util.*;

import java.lang.reflect.Field;

import util.CEFPIterator;

import junit.framework.TestCase;

/**
 * A set of tests for analysing the straight skelton. Result has to examined manually, so remove the xx's!
 * 
 * @author people
 * 
 */
public class BonesTest extends TestCase
{
	// shape from hell - lip shape
	public double data1[][] =
	{
	{ 0, 0.5, 1 }, // 0.000001 breaks it
			{ 2, 1, 1 },
			{ 2.5, 0.8, 1 },
			{ 3, 1, 1 },
			{ 5, 0.5, 1 },
			{ 3, 0, 1 },
			{ 2.5, 0.2, 1 },
			{ 2, 0, 1 } };

	// wonkey triangle with split
	public double data2[][] =
	{
	{ 2.5, 0, 1 },
	{ 0, 0, 1 },
	{ 1.25, 1, 1 },
	{ 1.5, 2, 1 },
	{ 1.75, 1.5, 1 },
	{ 2, 2, 1 } };

	// one split trapezoid
	public double data3[][] =
	{
	{ 2.6, 0, 0.1 },
	{ 0, 0, 0.7 },
	{ 1.3, 2, 1.5 },
	{ 1.9, 2.5, 0.3 },
	{ 2.4, 2, 0.8 } };

	// silly speeds
	public double data3a[][] =
	{
	{ 2.6, 0, 1 },
	{ 0, 0, 0.0 },
	{ 1.3, 2, 1.5 },
	{ 1.9, 2.5, 30.3 },
	{ 2.4, 2, 0.8 } };

	// with 0 speeds
	public double data3b[][] =
	{
	{ 2.6, 0, 0.0 },
	{ 0, 0, 0 },
	{ 1.3, 2, 1 },
	{ 1.9, 2.5, 0 },
	{ 2.4, 2, 0 } };

	// one split trapezoid
	public double data4[][] =
	{
	{ 2.5, 0, 1 },
	{ 0, 0, 1 },
	{ 0.5, 2, 1 },
	{ 1.5, 2, 1 },
	{ 1.75, 1.5, 1 },
	{ 2, 2, 2 } };

	// rectangle with split
	public double data5[][] =
	{
	{ 0, -1, 1 },
	{ 0, 2, 1 },
	{ 1, 2, 1 },
	{ 1, 0.55, 1 },
	{ 0.8, 0.5, 1 },
	{ 1, 0.45, 1 },
	{ 1, -1, 1 } };

	// convex version
	public double data5b[][] =
	{
	{ 0, -1, 1 },
	{ 0, 2, 1 },
	{ 1, 2, 1 },
	{ 1.8, 0.5, 1 },
	{ 1, -1, 1 } };

	// normal tripple split shape with slope
	public double data6[][] =
	{
	{ 2.5, 0, 0 },
	{ 0, 0, 1 },
	{ 0.5, 2, 1 },
	{ 0.75, 1.5, 1 },
	{ 1, 2, 1 },
	{ 1.25, 1, 1 },
	{ 1.5, 2, 1 },
	{ 1.75, 1.5, 1 },
	{ 2, 2, 1 } };

	// normal tripple split shape with slope, 3 consecutive vertical edges to split against
	public double data6b[][] =
	{
	{ 2.5, 0, 0 },
	{ 0, 0, 0 },
	{ 0.5, 2, 1 },
	{ 0.75, 1.5, 1 },
	{ 1, 2, 1 },
	{ 1.25, 1, 1 },
	{ 1.5, 2, 1 },
	{ 1.75, 1.5, 1 },
	{ 2, 2, 0 } };

	public double data6c[][] =
	{
	{ 2.5, 0, 0.6 },
	{ 0, 0, 1.6 },
	{ 0.5, 2, 1 },
	{ 0.75, 1.5, 0 },
	{ 1, 2, 0.2 },
	{ 1.25, 1, 0.5 },
	{ 1.5, 2, 0.9 },
	{ 1.75, 1.5, 1.5 },
	{ 2, 2, 1.4 } };

	public double data6d[][] =
	{
	{ 2.5, 0, -0.6 },
	{ 0, 0, 1.6 },
	{ 0.5, 2, 1 },
	{ 0.75, 1.5, 0 },
	{ 1, 2, 0.2 },
	{ 1.25, 1, 0.5 },
	{ 1.5, 2, 0.9 },
	{ 1.75, 1.5, 1.5 },
	{ 2, 2, 1.4 } };

	// half medal with convex bisector simultainiuos intersect public double
	public double data8[][] =
	{
	{ 0.7, 1, 1 },
	{ 0.5, 0.5, 1 },
	{ 1, 0.7, 1 },
	{ 1, -1, 1 },
	{ -1, -1, 1 },
	{ -1, 0.7, 1 },
	{ -0.5, 0.5, 1 },
	{ -0.7, 1, 1 } };

	/*
	 * // four way medal cross public double data7[][] = { { 0.7, 1, 1 }, { 0.5, 0.5, 1 }, { 1, 0.7, 1 }, { 1, -0.7, 1 }, { 0.5, -0.5, 1 }, { 0.7, -1, 1 }, { -0.7, -1, 1 }, { -0.5, -0.5, 1 }, { -1, -0.7, 1 }, { -1, 0.7, 1 }, { -0.5, 0.5, 1 }, { -0.7, 1, 1 } }; // // and without public double data9[][] = { { 0.7, 1, 1 }, { 0.5, 0.5, 1 }, { 1, 0.7, 1 }, { 1, -1.5, 1 }, { -1, -1.5, 1 }, { -1, 0.7, 1 }, { -0.5, 0.5, 1 }, { -0.7, 1, 1 } }; // half medal with wonkeyconvex bisector public double data10[][] = { { 0.7, 1, 1 }, { 0.4, 0.5, 1 }, { 1, 0.7, 1 }, { 1, -1, 1 }, { -1, -1, 1 }, { -1, 0.7, 1 }, { -0.5, 0.5, 1 }, { -0.7, 1, 1 } };
	 */
	// octagon (non regular)
	public double data11[][] =
	{
	{ 1, 0, -1 },
	{ 2, 0, -1 },
	{ 3, 1, -1 },
	{ 3, 2, -1 },
	{ 2, 3, -1 },
	{ 1, 3, -1 },
	{ 0, 2, -1 },
	{ 0, 1, -1 } };

	// camp octagon
	public double data11b[][] =
	{
	{ 1, 0, 1.5 },
	{ 2, 0, 0.2 },
	{ 3, 1, 0.5 },
	{ 3, 2, 1.2 },
	{ 2, 3, 0.8 },
	{ 1, 3, 0.6 },
	{ 0, 2, 0.2 },
	{ 0, 1, 0.6 } };

	// square
	public double data12[][] =
	{
	{ 0, 0, -1 },
	{ 1, 0, -1 },
	{ 1, 1, -1 },
	{ 0, 1, -1 } };

	// regular octagon
	final static double l = 1.0 / (Math.sqrt(2)) + 0.5;

	public double data13[][] =
	{
	{ -0.5, l, 1 },
	{ 0.5, l, 1 },
	{ l, 0.5, 1 },
	{ l, -0.5, 1 },
	{ 0.5, -l, 1 },
	{ -0.5, -l, 1 },
	{ -l, -0.5, 1 },
	{ -l, 0.5, 1 } };

	// splitting triangle
	public double data14[][] =
	{
	{ 0, 0, 1 },
	{ 2, 1, 1 },
	{ 2, 0, 1 },
	{ 1, 0.3, 1 } };

	// hollow roof
	public double data15[][] =
	{
	{ 0, 0, 1 },
	{ 0, 5, 1 },
	{ 1, 5, 1 },
	{ 1, 7, 1 },
	{ 3, 7, 1 },
	{ 3, 5, 1 },
	{ 5, 5, 1 },
	{ 5, 0, 1 } };

	public double data15h[][] =
	{
	{ 2.8, 6.8, -1 },
	{ 1.2, 6.8, -1 },
	{ 1.2, 5, 1 },
	{ 2.8, 5, -1 } };

	// its got a parallel side!
	public double data16[][] =
	{
	{ 63.66387958012386, 17.15010867497409, 1 },
	{ 81.38175431700468, 23.38984193343707, 1 },
	{ 89.61899364675696, 0.0, 1 },
	{ 69.70366172525542, 0.0, 1 },
	{ 40.473393869699514, 0.0, 1 },
	{ 45.946004843243045, 10.910375416511112, 1 } };

	// regular shape fecking it up
	public double data17[][] =
	{
	{ 3.355696305343237, 4.287103878305999, 1 },
	{ 0.31687544100042686, 8.429490606168983, 1 },
	{ 0.0, 13.557198671536128, 1 },
	{ 2.505675695924708, 18.042216994307267, 1 },
	{ 7.038368199576908, 20.460583946627708, 1 },
	{ 15.346768977018286, 19.785446625268023, 1 },
	{ 21.314876728272637, 14.889786956967697, 1 },
	{ 16.18906423559949, 0.8476200400837683, 1 },
	{ 14.518590275076605, 0.0, 1 }, };

	// same as 17, different order
	public double data18[][] =
	{
	{ 0.31687544100042686, 8.429490606168983, 1 },
	{ 0.0, 13.557198671536128, 1 },
	{ 2.505675695924708, 18.042216994307267, 1 },
	{ 7.038368199576908, 20.460583946627708, 1 },
	{ 15.346768977018286, 19.785446625268023, 1 },
	{ 21.314876728272637, 14.889786956967697, 1 },
	{ 16.18906423559949, 0.8476200400837683, 1 },
	{ 14.518590275076605, 0.0, 1 },
	{ 3.355696305343237, 4.287103878305999, 1 }, };

	// circle with adjoining lump....
	public double data19[][] =
	{
	{ 27.395390836165063, 34.80356867620205, 1 },
	{ 14.577598730772394, 18.451306750913915, 1 },
	{ 18.07006565689028, 14.385017341155404, 1 },
	{ 19.248962166069077, 10.790657802637497, 1 },
	{ 18.962618676494145, 7.018758429978348, 1 },
	{ 17.254628388743043, 3.6435567103122963, 1 },
	{ 14.38501734115539, 1.1788965091787702, 1 },
	{ 10.790657802637526, 0.0, 1 },
	{ 7.0187584299783055, 0.2863434895749535, 1 },
	{ 3.643556710312282, 1.994333777326041, 1 },
	{ 1.1788965091787986, 4.863944824913695, 1 },
	{ 0.0, 8.458304363431601, 1 },
	{ 0.28634348957493216, 12.230203736090765, 1 },
	{ 1.994333777326034, 15.605405455756795, 1 },
	{ 4.863944824913688, 18.07006565689032, 1 },
	{ 8.45830436343158, 19.248962166069106, 1 },
	{ 13.803152225866597, 18.843208396689548, 1 },
	{ 19.375358006311558, 38.81234218605742, 1 },
	{ 21.340732153448215, 38.631101194321815, 1 },
	{ 26.48171411641829, 35.90866185384718, 1 }, };

	// circle with adjoining lump....
	public double data20[][] =
	{
	{ 1.994333777326034, 15.605405455756795, 1 },
	{ 4.863944824913688, 18.07006565689032, 1 },
	{ 8.45830436343158, 19.248962166069106, 1 },
	{ 13.803152225866597, 18.843208396689548, 1 },
	{ 19.375358006311558, 38.81234218605742, 1 },
	{ 21.340732153448215, 38.631101194321815, 1 },
	{ 26.48171411641829, 35.90866185384718, 1 },
	{ 27.395390836165063, 34.80356867620205, 1 },
	{ 14.577598730772394, 18.451306750913915, 1 },
	{ 18.07006565689028, 14.385017341155404, 1 },
	{ 19.248962166069077, 10.790657802637497, 1 },
	{ 18.962618676494145, 7.018758429978348, 1 },
	{ 17.254628388743043, 3.6435567103122963, 1 },
	{ 14.38501734115539, 1.1788965091787702, 1 },
	{ 10.790657802637526, 0.0, 1 },
	{ 7.0187584299783055, 0.2863434895749535, 1 },
	{ 3.643556710312282, 1.994333777326041, 1 },
	{ 1.1788965091787986, 4.863944824913695, 1 },
	{ 0.0, 8.458304363431601, 1 },
	{ 0.28634348957493216, 12.230203736090765, 1 }, };

	// uses up the whole heap?!
	public double data21[][] =
	{
	{ 16.516746800649628, 16.74626550099255, 1 },
	{ 18.668853753300453, 11.887495921479541, 1 },
	{ 17.584353479157812, 4.911980047151431, 1 },
	{ 13.202687156379739, 0.0, 1 },
	{ 4.1298629990707525, 2.7771277152068166, 1 },
	{ 0.6960579227958021, 6.832764392794914, 1 },
	{ 0.0, 12.101038259115995, 1 },
	{ 2.2626827030607046, 16.90930958545762, 1 },
	{ 6.765720261108157, 19.730986199327972, 1 },
	{ 12.07943006640528, 19.670205712837515, 1 }, };

	public double data22[][] =
	{
	{ 0.4621502590205182, 9.095080320888144, 1 },
	{ 20.26025784015627, 11.699220475340567, 1 },
	{ 22.38140030334438, 17.94259609647453, 1 },
	{ 31.47981724271638, 13.087865191254338, 1 },
	{ 23.655369428829488, 4.482300165063151, 1 },
	{ 23.38907759867803, 4.672060806018266, 1 },
	{ 4.704413508009246, 0.0, 1 },
	{ 0.0, 5.001849967213303, 1 }, };

	// roof with overhang
	public double data23[][][] =
	{
	{
	{ 0.0, 0.0, 0.0 },
	{ 0.0, 9.600000000000001, 0.0 },
	{ 9.600000000000001, 9.600000000000001, 0.0 },
	{ 9.600000000000001, 0.0, 0.0 }, },
	{
	{ -1.0, -1.0, -1.0 },
	{ 10.600000000000001, -1.0, -1.0 },
	{ 10.600000000000001, 10.600000000000001, -1.0 },
	{ -1.0, 10.600000000000001, -1.0 }, },
	{
	{ -2.0, -2.0, 1.0 },
	{ -2.0, 11.600000000000001, 1.0 },
	{ 11.600000000000001, 11.600000000000001, 1.0 },
	{ 11.600000000000001, -2.0, 1.0 }, }, };

	public double data24[][] =
	{
	{ 42, 3, 1 },
	{ 34, 19, 1 },
	{ 3, 25, 1 },
	{ 53, 55, 1 },
	{ 51, 25, 1 },
	{ 72, 27, 1 } };

	// lol, no it isnt!
	public double convexSplitEvent[][] =
	{
	{ 0, 0, 1 },
	{ -1, 1, 0 },
	{ -2, 0, 0 },
	{ -2, 1.5, 0 },
	{ -0.1, 1.5, 0 },
	{ -0.1, 0.75, 0 },
	{ 0.1, 0.75, 0 },
	{ 0.1, 1.5, 0 },
	{ 2, 1.5, 0 },
	{ 2, 0, 0, },
	{ 1, 1, 1 },
	};
	
	public double convexRealSplitEvent[][][] =
	{
			{
				{0,0,1}, // square
				{0,1,0},
				{1,1,-1},
				{1,0,0},
			},
			{
				{2, 0.5, 0.0}, // triangle
				{3, 1, 0},
				{3, 0, 0.0}
			}
	};

	public void testManual() throws IllegalAccessException
	{
		setupParameters();
		Vector<double[][]> data = new Vector<double[][]>();
		Field[] f = this.getClass().getFields();
		String name = "unkown";
		if (false)
			try
			{
				for (Field a : f)
				{
					name = a.getName(); // needs check just for double[][][] -> different sig
					assertTrue(make((double[][]) a.get(this)));
				}
			}
			catch (Error e)
			{
				e.printStackTrace();
				System.err.println("During test of " + name);
				assertTrue(false);
			}
		else
			assertTrue(make(convexRealSplitEvent));
	}

	public boolean make(double[][] data)
	{
		SheetBuilder sb = demoSheetBuilder();

		for (int i = 0; i < data.length; i++)
		{
			sb.addPoint(data[i][0], data[i][1], 0);
			sb.setPointSpeed(data[i][2]);
		}
		/*
		 * // stuff for hole! sb.newSheet(); data = data15h; for (int i = 0; i < data.length; i++) { //FlatPoint f = new FlatPoint(data[i][0], data[i][1]); //f.setSpeed(data[i][2]); //f.addType(STREET); //spds.add(data[i][2]); sb.addPoint(data[i][0], data[i][1], 0); sb.setPointSpeed(data[i][2]); }
		 */

		Sheaf sheaf = sb.makeSheaf();

		anchor.createPolygon(sheaf.getFace());
		try
		{
			System.err.println("about to enter bones");
			Bones s = new Bones(sheaf, 4., false);
			System.err.println("starting to make woof");
			List<Sheaf> woof = s.getWoof();
			System.err.println("done making woof");
			System.err.println("There are " + woof.size() + " sides to the roof");
			for (Sheaf f : woof)
			{
				Sheet a = f.getMain();
				CEFPIterator cit = a.iterator();
				// while (cit.hasNext()) System.err.println("this sheet's coords "+cit.next().thing);
				anchor.createPolygon(f);
				// System.err.println("************************************");
			}

			anchor.createPolygon(s.getFlatTop());

			sity.Parameters.anchor.nextFrame();
		}
		catch (BonesSaysNoException e)
		{
			System.err.println("got an error:" + e.message);
			return false;
		}
		return true;
	}

	/**
	 * Note same name, but takes double [][][] for a sheaf with holes in it
	 * 
	 * @param data
	 * @return
	 */
	public boolean make(double[][][] data)
	{
		SheetBuilder sb = demoSheetBuilder();

		for (double[][] sh : data)
		{
			for (int i = 0; i < sh.length; i++)
			{
				sb.addPoint(sh[i][0], sh[i][1], 0);
				sb.setPointSpeed(sh[i][2]);
			}
			sb.newSheet();
		}
		Sheaf sheaf = sb.makeSheaf();
		/*
		 * // stuff for hole! sb.newSheet(); data = data15h; for (int i = 0; i < data.length; i++) { //FlatPoint f = new FlatPoint(data[i][0], data[i][1]); //f.setSpeed(data[i][2]); //f.addType(STREET); //spds.add(data[i][2]); sb.addPoint(data[i][0], data[i][1], 0); sb.setPointSpeed(data[i][2]); }
		 */

		anchor.createPolygon(sheaf.getFace());
		try
		{
			System.err.println("about to enter bones");
			Bones s = new Bones(sheaf, false);
			System.err.println("starting to make woof");
			List<Sheaf> woof = s.getWoof();
			System.err.println("done making woof");
			System.err.println("There are " + woof.size() + " sides to the roof");
			for (Sheaf f : woof)
			{
				int count = 0;
				for (Sheet a : f.getSheets())
				{
					CEFPIterator cit = a.iterator();
					while (cit.hasNext())
						System.err.println(count + "this sheet's coords " + cit.next().thing);
					count++;
				}
				System.err.println("************************************");
				anchor.createPolygon(f);

			}
			// sity.Parameters.anchor.nextFrame();
		}
		catch (BonesSaysNoException e)
		{
			System.err.println("got an error:" + e.message);
			return false;
		}
		return true;
	}

}
