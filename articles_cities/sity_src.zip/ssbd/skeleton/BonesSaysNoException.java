package skeleton;

public class BonesSaysNoException extends Exception
{
	String message;
	public BonesSaysNoException(String msg)
	{
		message = "BSN:"+msg;
	}

	public String getMessage()
	{
		return message;
	}

	public String toString()
	{
		return message;
	}

}
