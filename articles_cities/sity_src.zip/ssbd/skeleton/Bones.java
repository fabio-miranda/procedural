package skeleton;

import static geom.DotMath.isNan;
import static geom.Vec2d.pointBetweenPoints;
import static sity.Parameters.*;
import static skyHook.AnchorStatics.*;
import geom.*;

import java.util.*;

import java.awt.Color;

import javax.vecmath.*;

import util.*;

/**
 * Another (3rd) and hopefully final attempt at writing a straight skeleton implementation as the others got tooo complicated.
 * 
 * @author people is who i am...stupid windows login Bones s = new Skeleton(sheaf, Double.MAX_VALUE);
 * 
 * Iterator<Sheaf> shit = s.makeSideSheets(sheaf, 1).iterator();
 * 
 */
public class Bones
{
	Sheaf sheaf = null;

	double bevel = Double.MAX_VALUE;

	// heap of Dots
	private Heap heap = new Heap();

	// all the active points in the skeleton
	private Collection<Dot> puzzle = new LinkedHashSet<Dot>();

	// map from input flatpoints to 3D Dots we work with (for constructing roof at end)
	private Map<FlatPoint, Dot> flatTo3D = new LinkedHashMap<FlatPoint, Dot>();

	private Map<Dot, Dot> ancestors = new LinkedHashMap<Dot, Dot>();

	Dotty dotty;
	
	// the flat top sections of this roof if we are bevling
	private Sheaf flatTop = null;
	
	private double heightScale;


	
	/**
	 * New set of bones
	 * 
	 * @param sheaf
	 *            the sheaf to operate on
	 * @param bevel
	 *            Height at which to perform a bevel
	 */
	public Bones(Sheaf sheaf, Double bevel, boolean flat) throws BonesSaysNoException
	{
		this (sheaf, bevel, flat, 1.0);
		
	}
	
	public Bones(Sheaf sheaf, Double bevel, double heightScale) throws BonesSaysNoException
	{
		this (sheaf, bevel, false, heightScale);
	}

	// never need flat and heightScale
	private Bones(Sheaf sheaf, Double bevel, boolean flat, double heightScale) throws BonesSaysNoException
	{
		this.sheaf = sheaf.removeStraights();
		this.bevel = bevel;
		this.heightScale = heightScale;
		
		setup(flat);
	}
	
	/**
	 * Constructor without beveling
	 * 
	 * @param sheaf
	 *            input shape
	 */
	public Bones(Sheaf sheaf, boolean flat) throws BonesSaysNoException
	{
		this(sheaf, Double.MAX_VALUE, flat);
	}
	
	/**
	 * Creates the inital data structures
	 * 
	 */
	private void setup(boolean flat) throws BonesSaysNoException
	{
		// setup output structure
		dotty = new Dotty(flatTo3D, sheaf);

		// create the data structure
		for (Sheet s : sheaf.getSheets())
		{
			Dot last = null;
			CEFPIterator cit = s.iterator();
			Dot d;
			Toggle done = new Toggle(false);
			// keep going till it says we're done
			while (!done.get())
			{
				d = new Dot(cit, last, done, flatTo3D);
				last = d;
				if (!done.get())
					puzzle.add(d);
			}
		}

		// find bisectors for all points
		for (Dot d : puzzle)
		{
			d.setBisector();
		}

		Side.heap = heap;
		Opposite.heap = heap;

		// find collisions for the first time
		for (Dot d : puzzle)
			findCollisions(d);

		// debugging output
		frameOutput();
		//frameOutput();
		boolean result = false;
		while (heap.hasNext())
		{
			if (result)
				frameOutput();
			Heapable next = heap.next();
			if (next.getHeight() < bevel)
			{
				if (next instanceof Side)
				{
					result = go(Side.class.cast(next));
				}
				else if (next instanceof Opposite)
				{
					result = go(Opposite.class.cast(next));
				}
				//if (result)
				//	System.err.println("just did a " + next.getClass().getSimpleName() + " with height " + next.getHeight() + " at ");
			}
		}
		
		//tidyUpFeckinLittleTriangles();
		// only if not bevelling!:
		if (bevel == Double.MAX_VALUE) tidyUpLeftOvers();
		frameOutput();
		//if bevelling (and havn't tidied up)
		if (bevel != Double.MAX_VALUE) makeFlatTop(flat);
	}

	/**
	 * Dumps current state to an Anchor, really for debugging
	 */
	private void frameOutput()
	{
		if (false)
		{
			anchor.createPolygon(sheaf.getFace());
			outputRoof();
			outputPuzzle();
			anchor.nextFrame();
		}
	}

	/**
	 * Adds the line in, into the map
	 * 
	 * @param a
	 *            the lower point
	 * @param b
	 *            the higher point
	 */
	public void addLine(Dot a, Dot b)
	{
		if (isNan(a.getPoint()) || isNan(b.getPoint()))
			fatalErrorSD(" somethings NaN> from " + a + " to " + b);
		ancestors.put(a, b);
		dotty.putAll(a, b);
		dotty.putAll(b, a);
	}

	public List<Sheaf> getWoof()
	{
		return dotty.getWoof();	
	}
	
	public List<Sheaf> getWoof(boolean flat)
	{
		return dotty.getWoof(flat);
	}
	
	public List<Sheaf> getWoof(double scale)
	{
		return dotty.getWoof(false, scale);
	}

	/**
	 * performs the collision with a side bisector
	 * 
	 * @returns whether we have made changes that need outputting
	 */
	private boolean go(Side side)
	{
		Dot a = side.getA();
		Dot b = side.getB();
		Dot collision = side.getCollision();
		// check all Dots still live
		if (!puzzle.contains(a))
			return false;
		if (!puzzle.contains(b))
			return false;

		//System.err.println("about to do a side at "+collision.getPoint());
		
		// link in new point
		collision.setLastDot(a.getLastDot());
		collision.setNextDot(b.getNextDot());
		collision.getLastDot().setNextDot(collision);
		collision.getNextDot().setLastDot(collision);
		collision.setLastJoin(a.getLastJoin());
		collision.setNextJoin(b.getNextJoin());

		// add to stash of dots & find bisectors, collisions
		addDot(collision);

		// add in the two new lines - going uphill
		addLine(a, collision);
		addLine(b, collision);

		// add dots into the edges that sponsored them
		a.getLastJoin().addDot(collision);
		a.getNextJoin().addDot(collision);
		b.getNextJoin().addDot(collision);

		// remove old dots
		puzzle.remove(a);
		puzzle.remove(b);
		return true;
	}

	private Dot withJoinNextInLoop(Dot collision, Join toFind)
	{
		FlatPoint fp = collision.getPoint();
		for (Dot q : puzzle)
		{
			if (q.getNextJoin() == toFind)
			{
				Dot u = q.getNextDot();

				// this is a check against collision with a split/opposite point
				if (Vec3d.distanceTo(u.getInSpace(), collision.getInSpace()) == 0)
					continue;
				Vector2d qu = new Vector2d(u.getPoint());
				qu.sub(q.getPoint());

				// check for 0 speed, simplifies to a linear problem
				if (toFind.getSpeed() == 0)
				{
					//System.err.println("zamining " + q);
					if (pointBetweenPoints(q.getPoint(), u.getPoint(), fp))
					{
						//System.err.println("tis good");
						return q;
					}
					continue;
				}

				// check point lies inside bisectors of q and u, this is already done before we look at
				if ((Vec2d.onLeftOf(q.getPoint(), q.getBisector(), fp) && Vec2d.onRightOf(u.getPoint(), u.getBisector(), fp) && Vec2d.onRightOf(q.getPoint(), qu, fp)) ||
				(Vec2d.onRightOf(q.getPoint(), q.getBisector(), fp) && Vec2d.onLeftOf(u.getPoint(), u.getBisector(), fp) && Vec2d.onLeftOf(q.getPoint(), qu, fp)))
				{

					// System.err.println("withjoinnextinloop retuning "+q);
					return q;
				}
				
				//System.err.println("wasn't really inside bisectors");
				
				
			}
		}
		//System.err.println("withjoinnextinloop returning null");
		return null;
	}

	/**
	 * performs the collision with an Opposite event
	 * 
	 * @returns whether we have made changes that need outputting
	 */
	private boolean go(Opposite opp)
	{
		Dot a = opp.getA();
		Dot s = opp.getS();
		Dot e = opp.getE();

		// check dots still live
		if (!puzzle.contains(a))
			return false;
		// can still continue if s and e dont exist - may have been split out

		Dot onLeft = opp.getCollision();
		Dot onRight = new Dot(onLeft);
		// traverse this loop to find the dot with next ==
		s = withJoinNextInLoop(onLeft, s.getNextJoin());

		//if (s == null) System.err.println("disguarding "+onLeft+" caus of weithJoinNextInLoop");

		// no dots found that link to edge, edge is closed:
		if (s == null)
			return false;
		// this was a collision with something we split event'd from:
		if (Vec3d.distanceTo(s.getInSpace(), a.getInSpace()) == 0)
			return false;
		
		

		//System.err.println("about to do a opposite at "+onLeft.getPoint());
		
		e = s.getNextDot();

		// remove old dot
		puzzle.remove(a);

		// special weighted case - we are trying to split against ourselves
		if (a == e || a == s)
		{

			a.getLastDot().setNextDot(onLeft);
			onLeft.setLastDot(a.getLastDot());
			a.getNextDot().setLastDot(onLeft);
			onLeft.setNextDot(a.getNextDot());
			a.getLastJoin().addDot(onLeft);
			a.getNextJoin().addDot(onLeft);
			onLeft.setLastJoin(a.getLastJoin());
			onLeft.setNextJoin(a.getNextJoin());
			addDot(onLeft);
			addLine(a, onLeft);
			puzzle.remove(a);
			return true;
		}

		// link in new Left point
		onLeft.setLastDot(s);
		onLeft.setNextDot(a.getNextDot());
		onLeft.setLastJoin(s.getNextJoin());
		onLeft.setNextJoin(a.getNextJoin());
		s.setNextDot(onLeft);
		a.getNextDot().setLastDot(onLeft);

		onRight.setLastDot(a.getLastDot());
		onRight.setNextDot(e);
		onRight.setLastJoin(a.getLastJoin());
		onRight.setNextJoin(e.getLastJoin());
		a.getLastDot().setNextDot(onRight);
		e.setLastDot(onRight);

		// add to stash of dots & find bisectors, collisions
		addDot(onLeft);
		addDot(onRight);

		// add in the two new lines - going uphill
		addLine(a, onLeft);
		addLine(a, onRight);
		addLine(onLeft, onRight);

		// add to list of dots associated with each input edge
		a.getLastJoin().addDot(onRight);
		a.getNextJoin().addDot(onLeft);

		s.getNextJoin().addDot(onLeft);
		s.getNextJoin().addDot(onRight);
		return true;
	}

	/**
	 * Adds the dot & sets up
	 * 
	 * @param in
	 *            a dot with pointers (and surrounding dots) set up correctly
	 */
	public void addDot(Dot in)
	{
		in.setBisector();
		if (in.getBisector() == null)
		{
			fatalErrorSD("null bisector");
		}

		if (in.getNextDot().getNextDot() == in)
		{
			// add in new line in an uphill direction new! hmm...
			if (in.getHeight() < in.getNextDot().getHeight())
				addLine(in, in.getNextDot());
			else
				addLine(in.getNextDot(), in);
			// its a ceiling between two edges... so
			in.getLastJoin().addDot(in);
			in.getNextJoin().addDot(in);

			puzzle.remove(in.getNextDot());
			puzzle.remove(in);
		}
		else
		{
			puzzle.add(in);
			findCollisions(in);
		}
	}

	private void findCollisions(Dot d)
	{
		new Side(d);
		new Side(d.getLastDot());
		for (Dot p : puzzle)
		{
			// p is the first of a pair of dots on an edge
			// dont test against
			if (p != d && p != d.getLastDot() && p != d.getNextDot())
				new Opposite(d, p);
		}
	}

	public void outputRoof()
	{
		dotty.outputRoof();
	}

	
	/**
	 * If anything hasn't merged (for any reason) simply close in the remaining edges.
	 * The shape formed by those point currently in puzzle is discarded...
	 *
	 */
	public void tidyUpLeftOvers()
	{
		for (Dot d: puzzle)
		{
			Dot n = d.getNextDot();
			addLine(d,n);
			//puzzle.remove(d);
		}
	}
	
	/**
	 * This is called after all collisions have been processed. If there are 
	 * any puzzle elements left 
	 *
	 */
	private void tidyUpFeckinLittleTriangles_UNUSED()
	{
		Set<Dot> toDo = new LinkedHashSet<Dot>();
		toDo.addAll(puzzle);
		
		//System.err.println("puzzle size is"+toDo.size());
		
		for (Dot d: puzzle)
		{
			System.err.println("in puzzle "+d);
		}
		
		while (toDo.size() > 0)
		{
			Dot d = toDo.iterator().next();
			Dot n = d.getNextDot();
			
			if (Vec3d.distanceTo(d.getInSpace(), n.getInSpace()) < 10E-13)
			{ // remove next dot and remove it from the list
				System.err.println("merging one at "+d);
				addLine(n,d);
				d.setNextJoin(n.getNextJoin());
				d.getNextJoin().addDot(d);
				Dot after = n.getNextDot();
				d.setNextDot(after);
				after.setLastDot(d);
				toDo.remove(n);
				puzzle.remove(n);
			}
			else // remove this dot
			{
				toDo.remove(d);
			}
			if (d.getNextDot() == d)
			{
				System.err.println("11 pt loop");
				puzzle.remove(d);
				toDo.remove(d);
			}
			// check that we havn't created 2-point loop
			if (d.getNextDot().getNextDot() == d)
			{
				System.err.println("2 pt loop");
				//add the relivant line
				addLine(d, d.getNextDot());
				puzzle.remove(d.getNextDot());
				puzzle.remove(d);
				toDo.remove(d);
				toDo.remove(d.getNextDot());
			}
		}
	}
	
	
	/**
	 * Outputs to the current anchor a representation of the points on the to-be processed list
	 * 
	 */
	public void outputPuzzle()
	{
		for (Dot d : puzzle)
		{
			anchor.setColor(Color.red);
			createArrow(d.getInSpace(), d.getNextDot().getInSpace(), -0.15, 0.15);
			if (false) // two way arrows
			{
				Vector3d h1 = d.getInSpace();
				h1.add(new Vector3d(0, 0.3, 0));
				Vector3d h2 = d.getLastDot().getInSpace();
				h2.add(new Vector3d(0, 0.3, 0));
				createArrow(h1, h2, 0.3, 0.6);
			}

			Vector3d prev = new Vector3d(d.getLastJoin().getFirst().getFlat3DPoint());
			prev.add(new Vector3d(d.getLastJoin().getSecond().getFlat3DPoint()));
			prev.scale(0.5);

			Vector3d next = new Vector3d(d.getNextJoin().getFirst().getFlat3DPoint());
			next.add(new Vector3d(d.getNextJoin().getSecond().getFlat3DPoint()));
			next.scale(0.5);

			anchor.setColor(Color.green);
			createArrow(d.getFlat3DPoint(), prev, 0.3, 0.4);
			createArrow(d.getFlat3DPoint(), next, 0.3, 0.4);

			anchor.setColor(Color.blue);
			Vector3d b = new Vector3d(d.get3dBisector());
			b.add(d.getInSpace());
			createArrow(d.getInSpace(), b, 0.05, 0.15);
		}
		//int count = 0;
		/*for (Heapable h : heap.q)
		{
			count++;
			if (h instanceof Side)
			{
				Side s = Side.class.cast(h);
				anchor.setColor(Color.orange);
				createCube(s.getLocation(), 0.007 * count);
			}
			else if (h instanceof Opposite)
			{
				Opposite o = Opposite.class.cast(h);
				anchor.setColor(Color.pink);
				createCube(o.getLocation(), 0.007 * count);
				createArrow(o.getA().getFlat3DPoint(), o.getCollision().getFlat3DPoint(), 0, 0.1);
				anchor.setColor(Color.magenta);
				createArrow(o.getS().getFlat3DPoint(), o.getCollision().getFlat3DPoint(), 0, 0.01);
				anchor.setColor(Color.cyan);
				createArrow(o.getE().getFlat3DPoint(), o.getCollision().getFlat3DPoint(), 0, 0.01);
			}
		}*/
	}
	
	public Sheaf getFlatTop()
	{
		return flatTop;
	}
	//should always run this if we bevel!: should run a different version if we want flat output...
		
	
	// the mapping of input points to output points
	private Map<FlatPoint, FlatPoint> inputToFlat = new LinkedHashMap<FlatPoint,FlatPoint>();
	
	public Map<FlatPoint, FlatPoint> getIO()
	{
		return inputToFlat;
	}
	
	/**
	 * After running to a certain height we have a list of remaining points. We need to get them all up to the same height. There will be no more collisions
	 * 
	 * @param ref
	 * @return
	 */
	private Sheaf makeFlatTop(boolean flat)
	{
		// move all points in current list up to level bevel
		bevel();
		frameOutput();
		
		SheetBuilder sb = new SheetBuilder(sheaf);
		
		//System.err.println("first point during flat top is "+puzzle.iterator().next().getPoint());
		//System.err.println("make flat top using matrix "+sheaf.getTransform());
		
		//System.err.println("looking for flat top now");
		while (puzzle.size() > 0)
		{
			// lol, only way to get something (anything) out of a set without knowing its name
			Iterator<Dot> it = puzzle.iterator();
			Dot start = it.next();
			Dot last = start;
			Dot current = start.getNextDot();
			
			// a map from input points to output points
			Map<Dot,Vertex> allV = new LinkedHashMap<Dot,Vertex>();
			Vertex vertex;
			
			if (! flat)
				vertex=sb.addPoint(start.getPoint().x, start.getPoint().y, start.getHeight()*heightScale);
			else
				vertex=sb.addPoint(start.getPoint().x, start.getPoint().y, 0);
			
			//System.err.println("bones * puttin "+start.getNextJoin().getFirst()+" to "+vertex);
			allV.put(start.getNextJoin().getFirst(),vertex);
			
			for (EdgeType e: start.getNextJoin().getTypes()) sb.setPointType(e);
			
			addLine(start.getLastDot(),start);
			start.setTop(); // mark dot as belonging to flatTop
			puzzle.remove(start);
			 
			
			int count = 0;
			
			// follow start around until back at start
			while (current != start)
			{
				count++;
				if (count > 100) break; // reliability code
				//broken
				if (!flat)
					vertex = sb.addPoint(current.getPoint().x, current.getPoint().y, current.getHeight()*heightScale);
				else
					vertex = sb.addPoint(current.getPoint().x, current.getPoint().y, 0);
				for (EdgeType e: current.getNextJoin().getTypes()) sb.setPointType(e);
				
				//System.err.println("bones puttin "+current.getNextJoin().getFirst()+" to "+vertex);
				allV.put(current.getNextJoin().getFirst(),vertex);
				
				addLine(last, current);
				current.setTop(); // mark dot as belonging to flatTop
				puzzle.remove(current);
				last = current;
				current = current.getNextDot();
			}
			
			sb.newSheet();
			
			for (Dot d: allV.keySet())
			{
				inputToFlat.put(d.getPoint(), sb.getFlatPoint(allV.get(d)));
			}
		}
		flatTop = sb.makeSheaf();
		frameOutput();
		//System.err.println("done wtih flat top now");
		return flatTop;
	}

	/**
	 * Run through all the points in the puzzle, letting them continue along their
	 * bisectors until they get to bevel height. Doesn't add lines between the tops!
	 * 
	 */
	private void bevel()
	{
		Collection<Dot> toRemove = new LinkedHashSet<Dot>();
		Collection<Dot> toPut    = new LinkedHashSet<Dot>();
		for (Dot d: puzzle)
		{
			// projected flat distance bisector must travel to be at bevel

			double distLeft;
			if (d.getBisectorSpeed() != 0)
				distLeft = (bevel-d.getHeight())*d.getBisectorSpeed();
			else // dont forget vertical walls
				distLeft = 0;
			
			Vector2d toAdd = new Vector2d(d.getBisector());
			//System.err.println("one "+toAdd);
			if (toAdd.lengthSquared() != 0) toAdd.normalize();
			//System.err.println("two "+toAdd);
			toAdd.scale(distLeft);
			//System.err.println("distance left is "+toAdd+" dL : "+distLeft);
			FlatPoint topF = new FlatPoint(d.getPoint().x+toAdd.x, d.getPoint().y+toAdd.y);
			// copy d
			Dot top = new Dot(d);
			// move top
			top.setPoint(topF);
			// link top in
			top.getLastDot().setNextDot(top);
			top.getNextDot().setLastDot(top);
			top.setHeight(bevel);
			d.getLastJoin().addDot(top);
			d.getNextJoin().addDot(top);
			addLine(d,top);
			// remove d and add top
			toRemove.add(d);
			toPut.add(top);
			// add in old point to previous and next walls
		}
		// keep puzzle up to date
		for (Dot d: toRemove)
			puzzle.remove(d);
		for (Dot d: toPut)
			puzzle.add(d);
		
	}

	public void outputJoins()
	{
		/*
		 * double count = 0; for (Dot d: dotty.getJoins().keySet()) { Vector3d start = new Vector3d(d.getPoint().x,0,d.getPoint().y); Dot e = dotty.getJoins().get(d); Vector3d end = new Vector3d(e.getPoint().x,0,e.getPoint().y); anchor.setColor(Color.pink); createArrow(start,end, count, count+0.2); count = count +0.05; }
		 */
	}
	
	/**
	 * Right! - (sponsored by green and blacks) this method returns a list of sheafs
	 * of the projection of the roof panels onto the base plane for all non-0 speed
	 * sides merged into one sheaf...
	 * 
	 * This means merging each side until we get to a 0-length edge ....
	 * 
	 * algorithm is:
	 * 
	 * @return
	 */
	public Sheaf getGutter()
	{
		// must be flat!, and must have bevelled for this to make any sense!:
		return dotty.makeGutter();
	}
	
}
