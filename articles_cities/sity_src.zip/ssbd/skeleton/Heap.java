package skeleton;

import java.util.*;

/**
 * Another Queue class
 * @author people
 *
 */
public class Heap
{
	PriorityQueue<Heapable> q;

	public Heap()
	{
		q = new PriorityQueue<Heapable>();
	}
	
	public void add(Heapable in)
	{
		q.add(in);
	}

	/**
	 * empty queue
	 * 
	 */
	public void empty()
	{
		while (!q.isEmpty())
			q.poll();
	}

	public boolean hasNext()
	{
		return !q.isEmpty();
	}

	public int size()
	{
		return q.size();
	}
	
	public Iterator<Heapable> iterator()
	{
		return q.iterator();
	}
	
	public Heapable next()
	{
		return q.poll();
	}
}
