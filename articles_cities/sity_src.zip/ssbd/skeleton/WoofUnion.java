package skeleton;

import geom.*;

import java.util.*;

import javax.vecmath.Vector3d;

import util.*;
import cloud.*;

/**
 * A panel is a side of a woof, here we merge them together as they are specified clockwise dot by dot by powers beyond our comprehension.
 * 
 * @author people
 * 
 */
public class WoofUnion
{
	// things are added to seen after we move onto the next panel
	Map<Vector3d, DotToList> seen = new LinkedHashMap<Vector3d, DotToList>();

	List<CE<Dot>> thisPanel = new ArrayList<CE<Dot>>();

	CE<Dot> first = null;

	CE<Dot> last = null;

	CE<Dot> anyFirst = null;
	
	public WoofUnion()
	{
		//System.err.println("CREATING NEW");
		newPanel();
	}

	/**
	 * Does tge reak oric
	 * 
	 */
	public void newPanel()
	{
		//System.err.println("new panel___________________________");
		if (first != null) // seen something before, we have to connect old last to first & process!
		{
			first.previous = last;
			last.next = first;

			 //CircularIterator<Dot> cit = new CircularIterator<Dot>(first);
			 //while (cit.hasNext())
			 //System.err.println("after processing list is "+cit.next());

			List<Integer> tags = new ArrayList<Integer>();
			
			for (CE<Dot> c : thisPanel)
				tagEntersAndExits(c, tags);
			
			//for (Integer i: tags) System.err.println("tag is"+i);
			
			assert(tags.size() == thisPanel.size());
			Iterator<Integer> tagIt = tags.iterator();
			// now connect up with connecting stuff
			for (CE<Dot> c : thisPanel)
				connectUp(c, tagIt.next());
		}
		// reset all variables
		first = null;
		last = null;
		thisPanel = new ArrayList<CE<Dot>>();
	}

	public void addCell(Cell cell)
	{
		newPanel();
		for (Wall w: cell.getWall())
		{
			Dot d = new Dot(w.getStart(cell));
			d.setHeight(0);
			addDot(d);
		}
	}
	
	/**
	 * Adds a dot, just adds to list to process, we dont do anything until the above newPanel() is called...
	 * First dot added is assumed to be on the exterior of the shape...
	 * @param in
	 */
	public void addDot(Dot d)
	{
		Dot in = new Dot(d.getPoint()); // something strange going on here, 
		in.setHeight(d.getHeight());// if we dont copy the dot we get corruption problems...
		if (d.isBottom()) in.setBottom(true);
		if (d.getTop()) in.setTop();
		
		if (last == null || !in.getInSpace().equals(last.thing.getInSpace()))
		{
		//System.err.println("adding in"+in.getPoint()+" at height "+in.getHeight());
		//System.err.println("hash is "+in.getInSpace().hashCode());
		CE<Dot> dot = new CE<Dot>(in);
		dot.previous = last;
		if (last != null)
			last.next = dot;
		dot.next = null;
		thisPanel.add(dot);
		last = dot;
		if (first == null)
			first = dot;
		if (anyFirst == null)
			anyFirst = dot;
		}
	}

	public Sheaf getSheaf(Sheaf ref)
	{
		newPanel();
		SheetBuilder sb = new SheetBuilder(ref);
		// idea is that we traverse over all the dots by following first pointers and
		// removing them from the hash of points till the hash of points is empty...
		while (seen.keySet().size() > 0)
		{
			Vector3d d;
			if (anyFirst != null) // the first must be a point on the outside so the normal is normal
			{
				d = anyFirst.thing.getInSpace();
				//System.err.println("any first is "+d);
				//System.err.println("any first is "+d.hashCode());
				//dumpSeen();
				assert(seen.containsKey(d));
				anyFirst = null;
			}
			else d = seen.keySet().iterator().next();
			DotToList dtl = seen.get(d);
			CE<Dot> first = dtl.getList();
			CircularIterator<Dot> ci = new CircularIterator<Dot>(first);
			// remove all linked dots from the hash of dots
			while (ci.hasNext())
			{
				CE<Dot> ce = ci.getCurrent();
				Dot next = ce.next.thing;
				Dot traversed = ci.next();
				//System.err.println("WoofUnion getSheaf adding " + traversed.getFlat3DPoint());
				sb.addPoint(traversed, true, 1.0); // true = flat!
				// now add some meta data...
				if (next.isBottom() && traversed.isBottom())
					sb.setPointType(EdgeType.OUTSIDE_GUTTER);
				else if (next.getTop() && traversed.getTop())
					sb.setPointType(EdgeType.INSIDE_GUTTER);
				else
					sb.setPointType(EdgeType.EDGE_GUTTER);
				
				seen.remove(traversed.getInSpace());
			}
		    //System.err.println("moving to next sheet");
			sb.newSheet();
		}
		return sb.makeSheaf();
	}

	/**
	 * debug
	 * 
	 */
	private void dumpSeen()
	{
		for (Vector3d d : seen.keySet())
		{
			System.err.println(" seen contains " + d);
			System.err.println(" seen contains " + d.hashCode());
			//System.err.println(" seen contains " + seen.get(d).getList());
		}
	}

	private int nextSameMask = 0x1;
	private int lastSameMask = 0x2;
	
	public void tagEntersAndExits(CE<Dot> c, List<Integer> out)
	{
		Vector3d d = c.thing.getInSpace();
		int val = 0;
		if (seen.containsKey(d))
		{
			DotToList found = seen.get(d);
			CE<Dot> fDot = found.getList();
			boolean nextSame = false; // relative to us, c
			boolean lastSame = false;
			
			
			

			//System.err.println("c.next is "+c.next.thing.getPoint());
			//System.err.println("fDot.previous is "+fDot.previous.thing.getPoint());
			//System.err.println("c.previous is "+c.previous.thing.getPoint());
			//System.err.println("fDot.next is "+fDot.next.thing.getPoint());
			// was not .getPoint and == not equals (SHouLD BE 3D?)
			if (c.next.thing.getPoint().equals(fDot.previous.thing.getPoint()))
			{
				//System.err.println("is samed");
				nextSame = true;
			}
			
			if (c.previous.thing.getPoint().equals(fDot.next.thing.getPoint()))
			{
				//System.err.println("last is samed");
				lastSame = true;
			}
			
			//System.err.println("doneded");
			if (nextSame) val += nextSameMask;
			if (lastSame) val += lastSameMask;
		}
		out.add(val);
	}
	
	

	/**
	 * Adds this dot in to the list. assumes fully connected CE...
	 * 
	 * @param c
	 */
	public void connectUp(CE<Dot> c, int tag)
	{
		Vector3d d = c.thing.getInSpace();
		// dumpSeen();
		//System.err.println("looking for " + d);
		if (seen.containsKey(d))
		{
			//System.err.println("seen " + d + " before !");
			DotToList found = seen.get(d);
			CE<Dot> fDot = found.getList();
			boolean nextSame = false; // relative to us, c
			boolean lastSame = false;
			if ((tag & nextSameMask) == nextSameMask) nextSame = true;
			if ((tag & lastSameMask) == lastSameMask) lastSame = true;
			
			if (nextSame && lastSame)
			{
				//System.err.println("double point, removing");
				// in the middle of a list, remove this point from bother lists as well
				// as the list of final dots.
				if (fDot.next != null)     fDot.next.previous = fDot.previous;
				if (fDot.previous != null) fDot.previous.next = fDot.next;
				c.next.previous = c.previous;
				c.previous.next = c.next;
				// remove from hash
				DotToList res = seen.remove(fDot.thing.getInSpace());
				assert(res != null);
				//System.err.println("removing "+fDot.thing);
			}
			else if (lastSame) // && !nextSame
			{
				//System.err.println("leaving.....");
				// now leaving a shape and either heading to another or a new point
				CE<Dot> next;
				DotToList dtt = seen.get(c.next.thing.getInSpace());
				if (dtt == null)
				{
					next = c.next;
					//System.err.println("next is null");
				}
				else
				{
					next = dtt.getList();
					//System.err.println("taking next to be " + next);
				}
				
				if (next.previous != null) next.previous.next = null;
				next.previous = fDot;
				if (fDot.next != null) fDot.next.previous = null;
				fDot.next = next;
			}
			else if (nextSame) // && !lastSame
			{
				//System.err.println("entering.....");
				// entering a section of shared boundary with another shape
				CE<Dot> last;
				DotToList dtt = seen.get(c.previous.thing.getInSpace());
				if (dtt == null)
					last = c.previous;
				else
					last = dtt.getList();

				
				if (last.next != null) last.next.previous = null;
				last.next = fDot;
				if (fDot.previous != null) fDot.previous.next = null; // cut thread pointing here
				fDot.previous = last;
			}
		}
		else
		// unseen dot, just add to hash of dots
		{
			//System.err.println("adding dot to hash" + d.hashCode());
			seen.put(d, new DotToList(c));
		}
	}
}
