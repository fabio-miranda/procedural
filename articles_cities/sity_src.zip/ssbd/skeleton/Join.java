package skeleton;

import geom.EdgeType;

import java.util.*;

/**
 * The join between the dots, (the edges)
 * @author people
 *
 */
public class Join
{

	private List<EdgeType> types = new Vector<EdgeType>();
	private Dot first, second;
	private double speed;
	private Set<Dot> dots = new LinkedHashSet<Dot>();

	protected List<Dot>leftUp    = null;
	protected List<Dot>rightDown = null;
	protected List<Dot>topAcross = null;
	
	
	public Join(Dot one, Dot two, List<EdgeType> type, Double speeed)
	{
		first = one;
		second = two;
		types = type;
		speed = speeed;
	}

	public String toString()
	{
		String o = "from: ";
		if (first != null && first.getPoint() != null) o = o.concat(first.getPoint().toString());
		if (second != null && second.getPoint() != null) o = o.concat(" to "+second.getPoint().toString());
		return o;
	}
	
	public Dot getFirst()
	{
		return first;
	}

	public void setFirst(Dot first)
	{
		this.first = first;
	}

	public Dot getSecond()
	{
		return second;
	}

	public void setSecond(Dot second)
	{
		this.second = second;
	}

	public List<EdgeType> getTypes()
	{
		return types;
	}

	public void setTypes(List<EdgeType> types)
	{
		this.types = types;
	}
	
	public boolean hasType(EdgeType in)
	{
		return types.contains(in);
	}

	public double getSpeed()
	{
		return speed;
	}

	public void setSpeed(double speed)
	{
		this.speed = speed;
	}
	
	public void addDot(Dot in)
	{
		dots.add(in);
	}
	
	public Set<Dot> getDots()
	{
		return dots;
	}
	
	/**
	 * Sets up more complex dot cache for gutter
	 *
	 */
	public void setUpLists()
	{
		leftUp    = new ArrayList<Dot>();
		rightDown = new ArrayList<Dot>();
		topAcross = new ArrayList<Dot>();
	}
}
