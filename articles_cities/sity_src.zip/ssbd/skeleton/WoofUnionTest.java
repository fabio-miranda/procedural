package skeleton;

import geom.*;

import java.util.*;

import javax.vecmath.Matrix4d;

import junit.framework.TestCase;
import util.*;

public class WoofUnionTest extends TestCase
{
	public void xxtestWoofUnion()
	{
		double[][] data = { { 0, 0 }, { 0, 1 }, { 1, 1 }, { 1, 0 }, };

		List<Dot> dots = new ArrayList<Dot>();
		for (double[] d : data)
		{
			Dot dot = new Dot(new FlatPoint(d[0], d[1]));
			dots.add(dot);
		}

		WoofUnion u = new WoofUnion();
		u.newPanel();

		for (Dot d : dots)
		{
			u.addDot(d);
		}

		Matrix4d m = new Matrix4d();
		m.setIdentity();
		Sheaf ref = new Sheaf(m);

		Sheaf list = u.getSheaf(ref);

		assertFalse(list == null);
		assertTrue(list.getSheets().size() == 1);
		CEFP first = list.getSheets().get(0).getFirst();
		assertTrue(list.getSheets().get(0).size() == 4);
		CEFPIterator cit = new CEFPIterator(first);
		while (cit.hasNext())
		{
			System.err.println("tis outputtting " + cit.next().thing);
		}
	}

	public void testWoofUnionWithTwo()
	{
		double[][] data = { { 0, 0 }, { 0, 1 }, { 1, 1 }, { 1, 0 }, { 2, 1 }, { 2, 0 }, };

		int[][] lists = { { 0, 1, 2, 3 }, { 3, 2, 4, 5 }, };

		WoofUnion u = new WoofUnion();

		// make all the Dots first
		List<Dot> dots = new ArrayList<Dot>();
		for (double[] d : data)
		{
			Dot dot = new Dot(new FlatPoint(d[0], d[1]));
			dots.add(dot);
		}

		// now traverse the list in the specified orders
		for (int[] ints : lists)
		{
			for (int i : ints)
			{
				u.addDot(dots.get(i));
			}

			u.newPanel();
		}

		Matrix4d m = new Matrix4d();
		m.setIdentity();
		Sheaf ref = new Sheaf(m);

		Sheaf list = u.getSheaf(ref);
		int count = 0;

		//assertTrue(list.getSheets().size() == 1);
		Sheet sg = list.getMain();
		//assertTrue(sg.size() == 6);

		for (Sheet s : list.getSheets())
		{
			CEFP first = s.getFirst();
			CEFPIterator cit = new CEFPIterator(first);
			while (cit.hasNext())
			{
				System.err.println(count + ") tis outputtting " + cit.next().thing);
			}
			count++;
		}
	}

	public void xxtestWoofUnionWithPointTo()
	{
		double[][] data = { { 0.1, 0.1 }, { 0, 1 }, { 1, 1 }, { 1, 0 }, { 2, 1 }, { 2, 0 }, { 0.9, 0.5 }, };

		int[][] lists = { { 0, 1, 2, 6, 3 }, { 3, 6, 2, 4, 5 }, };

		WoofUnion u = new WoofUnion();

		// make all the Dots first
		List<Dot> dots = new ArrayList<Dot>();
		for (double[] d : data)
		{
			Dot dot = new Dot(new FlatPoint(d[0], d[1]));
			dots.add(dot);
		}

		// now traverse the list in the specified orders
		for (int[] ints : lists)
		{

			for (int i : ints)
			{
				u.addDot(dots.get(i));
			}

			u.newPanel();
		}

		Matrix4d m = new Matrix4d();
		m.setIdentity();
		Sheaf ref = new Sheaf(m);

		Sheaf list = u.getSheaf(ref);
		int count = 0;

		assertTrue(list.getSheets().size() == 1);
		Sheet sg = list.getMain();
		assertTrue(sg.size() == 6);

		for (Sheet s : list.getSheets())
		{
			CEFP first = s.getFirst();
			CEFPIterator cit = new CEFPIterator(first);
			while (cit.hasNext())
			{
				System.err.println(count + ") tis outputtting " + cit.next().thing);
			}
			count++;
		}
	}

	public void xxtestWoofUnionWithLoop()
	{
		double[][] data = { { 0, 0 }, { 0, 1 }, { 1, 1 }, { 1, 0 }, { 0.5, 10. }, };

		int[][] lists = { { 3, 2, 1, 0, 4 }, { 3, 0, 1, 2 }, };

		WoofUnion u = new WoofUnion();

		// make all the Dots first
		List<Dot> dots = new ArrayList<Dot>();
		for (double[] d : data)
		{
			Dot dot = new Dot(new FlatPoint(d[0], d[1]));
			dots.add(dot);
		}

		// now traverse the list in the specified orders
		for (int[] ints : lists)
		{

			for (int i : ints)
			{
				u.addDot(dots.get(i));
			}

			u.newPanel();
		}

		Matrix4d m = new Matrix4d();
		m.setIdentity();
		Sheaf ref = new Sheaf(m);

		Sheaf list = u.getSheaf(ref);
		int count = 0;

		assertTrue(list.getSheets().size() == 1);
		Sheet sg = list.getMain();
		assertTrue(sg.size() == 3);

		for (Sheet s : list.getSheets())
		{
			CEFP first = s.getFirst();
			CEFPIterator cit = new CEFPIterator(first);
			while (cit.hasNext())
			{
				System.err.println(count + ") tis outputtting " + cit.next().thing);
			}
			count++;
		}
	}

	/**
	 * As above but with non null flat top
	 * 
	 */
	public void xxtestWoofUnionWithTrueLoop()
	{
		double[][] data = { { 0, 0 }, { 0, 1 }, { 1, 1 }, { 1, 0 }, { 0.5, 10. }, { 0.5, 1.5 } };

		int[][] lists = { { 3, 2, 5, 1, 0, 4 }, { 3, 0, 1, 2 }, };

		WoofUnion u = new WoofUnion();

		// make all the Dots first
		List<Dot> dots = new ArrayList<Dot>();
		for (double[] d : data)
		{
			Dot dot = new Dot(new FlatPoint(d[0], d[1]));
			dots.add(dot);
		}

		// now traverse the list in the specified orders
		for (int[] ints : lists)
		{

			for (int i : ints)
			{
				u.addDot(dots.get(i));
			}

			u.newPanel();
		}

		Matrix4d m = new Matrix4d();
		m.setIdentity();
		Sheaf ref = new Sheaf(m);

		Sheaf list = u.getSheaf(ref);
		int count = 0;

		assertTrue(list.getSheets().size() == 2);
		Sheet sg = list.getSheets().get(0);
		assertTrue(sg.size() == 3);
		sg = list.getSheets().get(1);
		assertTrue(sg.size() == 3);

		for (Sheet s : list.getSheets())
		{
			CEFP first = s.getFirst();
			CEFPIterator cit = new CEFPIterator(first);
			while (cit.hasNext())
			{
				System.err.println(count + ") tis outputtting " + cit.next().thing);
			}
			count++;
		}
	}

	public void xxtestNastyCase()
	{
		double[][] data = { // hmm... it works here, why does it stop later?
		{ 10.38270765034028, 25.794954281630524, 0.0 }, // 0
				{ 10.574144419391699, 25.46236516276737, 0.07547933986050405 }, { 8.135469891587945, 23.90634058573822, 0.9278871463897851 }, { 7.219407852257069, 24.114102202309205, 1.0 }, { 2.88106219861967, 26.188674999029303, 1.0 }, { -2.220446049250313E-16, 30.759907415236682, 0.0 }, // 5

				{ 10.83868799927696, 21.233040003689535, 0.0 }, // 6
				{ 8.135469891587945, 23.90634058573822, 0.9278871463897851 }, // (2)
				{ 10.574144419391699, 25.46236516276737, 0.07547933986050405 }, // (1)
				{ 10.795906390804108, 25.077091116225148, 0.0 }, // 9

				{ -1.7763568394002505E-15, 21.23304000368953, 0.0 }, // 10
				{ 2.8810621986196696, 24.114102202309205, 1.0 }, { 7.219407852257069, 24.114102202309205, 1.0 }, // (3)
				{ 8.135469891587945, 23.90634058573822, 0.9278871463897851 }, // (2)
				{ 10.83868799927696, 21.233040003689535, 0.0 }, // (6) 14
		};

		int[][] lists = { { 0, 1, 2, 3, 4, 5 }, { 6, 2, 1, 9 }, { 10, 11, 3, 2, 6 }, };

		WoofUnion u = new WoofUnion();

		// make all the Dots first
		List<Dot> dots = new ArrayList<Dot>();
		for (double[] d : data)
		{
			Dot dot = new Dot(new FlatPoint(d[0], d[1]));
			dot.setHeight(d[2]);
			dots.add(dot);
		}

		// now traverse the list in the specified orders
		for (int[] ints : lists)
		{

			for (int i : ints)
			{
				u.addDot(dots.get(i));
			}

			u.newPanel();
		}

		Matrix4d m = new Matrix4d();
		m.setIdentity();
		Sheaf ref = new Sheaf(m);

		Sheaf list = u.getSheaf(ref);
		int count = 0;

		/*
		 * assertTrue(list.getSheets().size() == 2); Sheet sg = list.getSheets().get(0); assertTrue(sg.size() == 3); sg = list.getSheets().get(1); assertTrue(sg.size() == 3);
		 */

		for (Sheet s : list.getSheets())
		{
			CEFP first = s.getFirst();
			CEFPIterator cit = new CEFPIterator(first);
			while (cit.hasNext())
			{
				System.err.println(count + ") tis outputtting " + cit.next().thing);
			}
			count++;
		}
	}

	public void xxtestWTF()
	{
		double[][] data = { { 10.8, 10.8 }, { 10.8, 0.0 }, { 0.0, 0.0 }, { 0.0, 10.8 } };

		List<Dot> dots = new ArrayList<Dot>();
		for (double[] d : data)
		{
			Dot dot = new Dot(new FlatPoint(d[0], d[1]));
			dots.add(dot);
		}

		WoofUnion u = new WoofUnion();
		u.newPanel();

		for (Dot d : dots)
		{
			u.addDot(d);
		}

		Matrix4d m = new Matrix4d();
		m.setIdentity();
		Sheaf ref = new Sheaf(m);

		Sheaf list = u.getSheaf(ref);

		assertFalse(list == null);
		assertTrue(list.getSheets().size() == 1);
		CEFP first = list.getSheets().get(0).getFirst();
		assertTrue(list.getSheets().get(0).size() == 4);
		CEFPIterator cit = new CEFPIterator(first);
		while (cit.hasNext())
		{
			System.err.println("tis outputtting " + cit.next().thing);
		}
	}

}
