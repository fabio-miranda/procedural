package skeleton;

import static geom.DotMath.intersectDots;

import java.util.Collection;

import javax.vecmath.Vector2d;

/**
 * A class that finds out the height at which the specified dot hits the dot after it
 * 
 * @author people
 * 
 */
public class Side extends Heapable
{
	private double height;

	private Dot collision;

	public static Heap heap;

	private Dot a, b;

	public Side(Dot d)
	{
		a = d;
		b = d.getNextDot();
		Dot collision = intersectDots(a, b);
		if (collision == null)
		{
			return;
		}

		// stop collisions at base with coincident bisectors
		// if (geom.Vec3d.distanceTo(collision.getInSpace(), a.getInSpace()) == 0) return;
		//if (geom.Vec3d.distanceTo(collision.getInSpace(), a.getInSpace()) == 0)
		//	System.err.println("foobar");
		if (geom.Vec3d.distanceTo(collision.getInSpace(), a.getInSpace()) == 0)
			return;
		this.collision = collision;
		height = collision.getHeight();
		heap.add(this);
	}

	public Vector2d getLocation()
	{
		return collision.getPoint();
	}

	public double getHeight()
	{
		return height;
	}

	public Dot getCollision()
	{
		return collision;
	}

	public void setHeight(double height)
	{
		this.height = height;
	}

	public Dot getA()
	{
		return a;
	}

	public Dot getB()
	{
		return b;
	}
}
