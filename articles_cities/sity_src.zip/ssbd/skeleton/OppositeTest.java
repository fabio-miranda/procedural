package skeleton;

import static skeleton.Opposite.*;
import javax.vecmath.Vector2d;
import geom.FlatPoint;
import junit.framework.TestCase;

public class OppositeTest extends TestCase
{
	
	// note that y is up
	double data[][] =
	{
			
			// firing along x
			{1,0, -1,0, 0,0.5, 0,0, 0,-0.5, 0,0,  0, 1, 0},
			{1,0, 1,0, 0,0.5, 0,0, 0,-0.5, 0,0,  69, 69, 69},
			{1,0.49, -1,0, 0,0.5, 0,0, 0,-0.5, 0,0,  0, 1, 0.49},
			//{1,0.5, -1,0, 0,0.5, 0,0, 0,-0.5, 0,0,  0, 1, 0.5}, waiting for boundary collisions
			//{1,-0.5, -1,0, 0,0.5, 0,0, 0,-0.5, 0,0,  0,1, -0.5},
			{1,-0.49, -1,0, 0,0.5, 0,0, 0,-0.5, 0,0,  0,1,  -0.49},
			{-1,0, 1,0, 0,0.5, 0,0, 0,-0.5, 0,0,  0, 1, 0},
			{-1,0, 0,0, 0,0.5, 0,0, 0,-0.5, 0,0,  69, 69, 69},
			{-1,0, 0.0001,0, 0,0.5, 0,0, 0,-0.5, 0,0,  0,10000,0},
			
			// firing along y
			{0,10, 0,-1,  1,0, 0,0, -1,0, 0,0,  0, 10, 0},
			{0,-10, 0,1,  1,0, 0,0, -1,0, 0,0,  0, 10, 0},
			{-10,-10, 1,1,  1,0, 0,0, -1,0, 0,0,  0, 10, 0},
			{1,1, -1,-1,  1,0, 0,0, -1,0, 0,0,  0, 1, 0},
			
			// off the top of triangles
			//{1,0, -1,0, 0,1, 0,-1, 0,0, 0,1,  0, 1, 0},
			{1,0.5, -0.1,0, 0,1, 0,0, 0,0, 0,0,  0, 10, 0.5},
			{1,0.5, -1.99999, 0, 0,1, 0,-1, 0,0, 0,1,  69,69,69},
			{1,0.5, -2.000001, 0, 0,1, 0,-1, 0,0, 0,1,  0, 0.5, 0.5},
			
			// 'under triangles' - should hit when we have edge detection?
			{-10,10, 0,0, 1,1, -1,-1, -1,-1, 1, 1,  69,69,69},
			
			// not around the origin
			{0,-3,1,0,   3,0,0,0,   3,-4,0,0,   3,3,-3},
			
			// problem cases - is this a borderline case? YES IT IS! WOOOO!
			// shown on the rectangle with a single slit
			{1,-1, -1, 1, 1.0,0.55, -1.0,  0.7807764064044149, 0.8, 0.5, -4.123105625617661, -5.551115123125783E-16, 69,69,69 },
			{1, 2, -0.999,-1, 0.8, 0.5, -4.123105625617661, -5.551115123125783E-16, 1.0,0.45, -1.0, -0.7807764064044151,  69,69,69},
			
			// on the line, this works and t is the same for both
			//{1,-1.5, -1, 1, 1.0,0.05, -1.0,  0.7807764064044149, 0.8, 0.0, -4.123105625617661, -5.551115123125783E-16, 69,69,69},
			//{1, 1.5, -1,-1, 0.8, 0.0, -4.123105625617661, -5.551115123125783E-16, 1.0,-0.05, -1.0, -0.7807764064044151,  69,69,69},
			
			/*
			// so if all coordinates are positive the collision fails
			{1,0, -1, 1, 1.0,1.55, -1.0,  0.7807764064044149, 0.8, 1.5, -4.123105625617661, -5.551115123125783E-16, 69,69,69},
			{1,3, -1,-1, 0.8, 1.5, -4.123105625617661, -5.551115123125783E-16, 1.0,1.45, -1.0, -0.7807764064044151,  69,69,69},
			
			// and if they are all negative along y it also fails
			{1,-3, -1, 1, 1.0,-1.55, -1.0,  0.7807764064044149, 0.8, -1.5, -4.123105625617661, -5.551115123125783E-16, 69,69,69 },
			{1, 0, -1,-1, 0.8, -1.5, -4.123105625617661, -5.551115123125783E-16, 1.0,-1.45, -1.0, -0.7807764064044151,  69,69,69 },
			*/
			};
	
	
	public void testIntersect() throws Exception
	{
		int count = 0;
		for(double[] q: data)
		{
			Dot a = new Dot(new FlatPoint(q[0],q[1]));
			a.setBisector(q[2],q[3]);
			Dot s = new Dot (new FlatPoint(q[4],q[5]));
			s.setBisector(new Vector2d(q[6],q[7]));
			Dot e = new Dot (new FlatPoint(q[8],q[9]));
			e.setBisector(new Vector2d(q[10],q[11]));
			
			Dot res = intersectDotQuad(a,s,e);
			closeTo(res, q[12],q[13],q[14], count);
			System.err.println(res);
			count++;
		}
	}
	
	private void closeTo(Dot res, double x, double y, double z, int count)
	{
		if (x == 69 && y == 69 && res == null)
		{
			return; //good
		}
		if (res == null)
		{
			assertFalse(""+count+" its not null: "+res,true); //bad
		}
		
		
		double xr = res.getPoint().x - x;
		double yr = res.getPoint().y - z;
		double zr = res.getHeight() - y;

		double dist = Math.sqrt(xr*xr+yr*yr+zr*zr) ;
		assertTrue(""+count+" is wrong is "+res+" should be "+x+","+y+","+z,dist < 0.000001); 
	}
}
