package skeleton;

import static sity.Parameters.anchor;
import static skyHook.AnchorStatics.*;
import geom.*;

import java.util.*;

import java.awt.Color;

import sity.Parameters;
import util.*;

/**
 * The structure that stores the output of a bones instance running
 * 
 * @author people
 * 
 */
public class Dotty
{

	// map of all output lines from lower point to higher point
	private Map<Dot, List<Dot>> joins = new LinkedHashMap<Dot, List<Dot>>();

	// map setup of input flatpoints to the dots we've created
	private Map<FlatPoint, Dot> flatTo3D;

	// the list of input flatpoints.
	private Sheaf sheaf;

	// tolerance for merging end points, could decrease to 10E-10 if large regular shapes wont tesselate
	private static final double END_TOL = 10E-14;

	public Dotty(Map<FlatPoint, Dot> f, Sheaf s)
	{
		flatTo3D = f;
		sheaf = s;
	}

	public void putAll(Dot a, Dot b)
	{
		if (joins.get(a) == null)
		{
			ArrayList<Dot> al = new ArrayList<Dot>();
			al.add(b);
			joins.put(a, al);
		}
		else
		{
			joins.get(a).add(b);
		}
	}

	/**
	 * Creates a 3d roof
	 * 
	 * @return a list of the surfaces defining the roof
	 */
	public List<Sheaf> getWoof()
	{
		return getWoof(false,1.0);
	}
	
	public List<Sheaf>getWoof(boolean flat)
	{
		return getWoof(flat,1.0);
	}

	/**
	 * private Map<FlatPoint,Dot>flatTo3D = new HashMap<FlatPoint,Dot>(); Create side roof panels:
	 * 
	 * @param referebce
	 *            the reference plane the input was defined on (and all heights were relative too!
	 * @return the list faces output
	 */

	public List<Sheaf> getWoof(boolean flat, double scale)
	{
		List<Sheaf> out = new ArrayList<Sheaf>();

		Iterator<Sheet> shit = sheaf.getSheets().iterator();

		// for all sheets in the Sheaf (eg holes, extremities etc...)
		while (shit.hasNext())
		{
			Sheet sheet = shit.next();
			CEFPIterator cit = sheet.iterator();
			while (cit.hasNext())
			{
				// one and two are our start points, we follow them up until they meet
				CEFP tmp = cit.nextCircular();
				FlatPoint one = tmp.thing;
				FlatPoint two = tmp.next.thing;

				// Dot right = flatTo3D.get(one); assert(right != null);
				Dot left = flatTo3D.get(two);
				assert (left != null);
				Dot right = flatTo3D.get(one);
				assert (right != null);

				Join j = right.getNextJoin();
				Set<Dot> dots = j.getDots();
				// dots.add(left);
				dots.add(right);

				SheetBuilder sb = new SheetBuilder(sheaf);

				Dot last = null;
				Dot current = left;
				sb.addPoint(current, flat, scale);
				boolean seenBevel = false;
				//System.err.println("dotty processing "+(current.getPoint().getTypes()));
				 //System.err.println("**********"+left.getPoint()+"<><>"+right.getPoint());
				// for (Dot d: dots)
				// System.err.println(">>>"+d.getPoint());
				
				int count = 0;
				
				while (current != right)
				{
					count++;
					if (count > 100) break; // ""reliability code""
					// System.err.println("starting at"+current);
					List<Dot> choices = joins.get(current);
					if (choices != null)
					{
						for (Dot k : choices)
						{
							// System.err.println("choice of "+k);
							if (k != last)
							{
								// System.err.println("ok not last");
								if (dots.contains(k))
								{
									// System.err.println("i chose "+current);
									if (Vec3d.distanceTo(current.getInSpace(), k.getInSpace()) != 0)
									{
										sb.addPoint(k, flat, scale);
										//System.err.println("dotty processing "+(k.getPoint().getTypes()));
										// now mark as top if necessary
										//System.err.println("><><> " +k.getTop());
										//if (last != null) System.err.println("<><>< " +last.getTop());
										if (!seenBevel && k.getTop())
										{
											sb.setPointType(EdgeType.BEVELTOP);
											// count every other one as we may have multiple tops
											seenBevel = ! seenBevel; 
										}
									}

									// k is the next step
									last = current;
									current = k;
									break;
								}
							}
						}
						// System.err.println("****************************");
					}
					else
					{
						Parameters.fatalErrorSD("point found with no entries in join");
					}
				}
				// current now = right, so tag with bases's metaData
				for (EdgeType e : one.getTypes())
					sb.setPointType(e);

				// sb.addPoint(right);
				Sheaf sheafOut = sb.makeSheaf();
				// will return null if no valid triangles
				if (sheafOut != null)
					out.add(sheafOut);

				// System.err.println("points are " + j.getDots());

			}
		}
		return out;
		/*
		 * Iterator<Sheet> shit = sheaf.getSheets().iterator(); // for all sheets in the Sheaf (eg holes, extremities etc...) while (shit.hasNext()) { Sheet sheet = shit.next(); CEFPIterator cit = sheet.iterator(); while (cit.hasNext()) { // one and two are our start points, we follow them up until they meet CEFP tmp = cit.nextCircular(); FlatPoint one = tmp.thing; FlatPoint two = tmp.next.thing;
		 * 
		 * Dot right = flatTo3D.get(one); assert(right != null); Dot left = flatTo3D.get(two); assert(left != null); // setup the output structures SheetBuilder sb = new SheetBuilder(reference); // list of right hand side points ArrayList<Dot> RHS = new ArrayList<Dot>();
		 * 
		 * boolean tieBreak = false; // while we havn't reached the same point while (left != right) { System.err.println("left : "+left.getPoint()); System.err.println("right: "+right.getPoint()); // if one is higher than the other, move it up until it is if (left.getHeight() < right.getHeight() || tieBreak) { System.err.println("right is top"); // if we're not already at the top climb up one! FlatPoint f = left.getPoint(); if (joinsL.containsKey(left)) { sb.addPoint(f.x, f.y, left.getHeight()); left = joinsL.get(left); System.err.println("left set to "+left); } // reset flag tieBreak = false; } else if(left.getHeight() > right.getHeight()) { System.err.println("left is top"); if (joinsR.containsKey(right)) { RHS.add(right); right = joinsR.get(right); System.err.println("right set to "+right); } } else if (left.getHeight() == right.getHeight()) { System.err.println("tiebreak"); if (left.getPoint().distanceTo(right.getPoint()) < END_TOL) { break; //break while loop } else { tieBreak = true; // move the left side up one } } } // add the top point in RHS.add(right); // now reverse the right hand side and add it in (it includes the base dot) Collections.reverse(RHS); for (Dot d: RHS) { FlatPoint f = d.getPoint(); System.err.println(f+ "++- "+left.getHeight()); sb.addPoint(f.x,f.y,d.getHeight()); } // add the done sheet to the output list & we're done out.add(sb.makeSheaf()); } } System.err.println("********************************"); return out;
		 */
	}

	/**
	 * Another version of the above that just prepairs the joins for a gutter...
	 * 
	 * @param flat
	 * @return
	 */

	public Sheaf makeGutter()
	{
		Iterator<Sheet> shit = sheaf.getSheets().iterator();

		WoofUnion woofUnion = new WoofUnion();

		// for all sheets in the Sheaf (eg holes, extremities etc...)
		while (shit.hasNext())
		{
			Sheet sheet = shit.next();
			CEFPIterator cit = sheet.iterator();
			while (cit.hasNext())
			{
				// one and two are our start points, we follow them up until they meet
				CEFP tmp = cit.nextCircular();
				//System.err.println(">>"+tmp.thing);
				FlatPoint one = tmp.thing;
				FlatPoint two = tmp.next.thing;

				// Dot right = flatTo3D.get(one); assert(right != null);
				Dot left = flatTo3D.get(two);
				assert (left != null);
				Dot right = flatTo3D.get(one);
				assert (right != null);

				Join j = right.getNextJoin();
				if (one.ofType(EdgeType.GUTTER))
				{
					//System.err.println("Starting off here "+left.getPoint());
					Set<Dot> dots = j.getDots();

					dots.add(right);

					Dot last = null;
					Dot current = left;

					woofUnion.addDot(current);

					// System.err.println("**********"+left.getPoint()+"<><>"+right.getPoint());
					// for (Dot d: dots)
					// System.err.println(">>>"+d.getPoint());

					while (current != right)
					{
						// System.err.println("starting at"+current);
						List<Dot> choices = joins.get(current);
						if (choices != null)
						{
							for (Dot k : choices)
							{
								// System.err.println("choice of "+k);
								if (k != last)
								{
									// System.err.println("ok not last");
									if (dots.contains(k))
									{
										woofUnion.addDot(k);
										// k is the next step
										last = current;
										current = k;
										break;
									}
								}
							}
							// System.err.println("****************************");
						}
						else
						{
							Parameters.fatalErrorSD("point found with no entries in join");
						}
					}
					woofUnion.newPanel();
				}
			}
		}
		return woofUnion.getSheaf(sheaf);
	}

	protected void outputRoof()
	{
		for (Dot q : joins.keySet())
		{
			List<Dot> d = joins.get(q);
			if (q != null)
			{
				for (Dot p : d)
				{
					anchor.setColor(Color.yellow);
					createArrow(q.getInSpace(), p.getInSpace(), -0.1, 0.1);
				}
			}
		}
	}

}
