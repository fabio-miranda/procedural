package skeleton;

import geom.*;

import java.util.Map;

import javax.vecmath.*;

import util.*;

/**
 * Unfortunatley I ran out of ideas and called this spot, because point was being used elsewhere
 * 
 * @author people
 * 
 */
public class Dot
{
	private FlatPoint point;

	private Join nextJoin;

	private Join lastJoin;

	private boolean processed = false;

	private Vector2d bisector;

	private Dot nextDot, lastDot;
	
	private double height = 0;

	private static Dot firstDot = null;
	
	// is the size of this bisector infinite?
	private boolean isInfinite = false;

	// is this dot part of the roof?
	private boolean top = false;
	
	private boolean bottom = false;
	
	/**
	 * Constructor ONLY USED FOR TESTING
	 * @param in
	 */
	public Dot(FlatPoint in)
	{
		point = in;
	}
	
	public Dot(FlatPoint in, double h)
	{
		point = in;
		this.height = h;
	}
	
	/**
	 * constructor that uses a list iterator to find its neighborus
	 * 
	 * @param lit
	 *            "param last the last dot processd
	 * @param done
	 *            are we ready to quit yet?
	 */
	public Dot(CEFPIterator lit, Dot last, Toggle done, Map<FlatPoint,Dot> flatTo3D)
	{
		if (lit.hasNext())
		{
			this.bottom = true;
			this.point = lit.next().get();
			this.nextDot = null; // just for clarity
			
			// add to map of input points to dots 
			flatTo3D.put(point,this);
			
			if (last == null)
			{
				firstDot = this;
			}
			else
			{
				this.lastDot = last;
				lastDot.nextDot = this;
				
				Join e = new Join(last, this,
						last.getPoint().getType(),
				//		Math.random());
				last.getPoint().getSpeed()); 
				
				this.setLastJoin(e);
				last.setNextJoin(e);
			}
		}
		else
		{
			// must ignore points iff lit == null
			last.nextDot = firstDot;
			firstDot.lastDot = last;
			
			Join e = new Join(last, firstDot,
					last.getPoint().getType(),
					//Math.random());
					last.getPoint().getSpeed()); 
			
			last.setNextJoin(e);
			firstDot.setLastJoin(e);
			
			done.set(true);
		}
	}

	public Dot(Dot in)
	{
		super();
		this.point = new FlatPoint(in.point);
		this.nextDot = in.nextDot; // delme_on no new problems: these two changed from nextJoing!
		this.lastDot = in.lastDot;
		if (in.bisector != null) this.bisector = new Vector2d(in.bisector);
		this.processed = in.processed;
		this.height = in.height;
		this.nextJoin = in.nextJoin;
		this.lastJoin = in.lastJoin;
	}

	public Vector2d getBisector()
	{
		return bisector;
	}
	
	public double getBisectorSpeed()
	{
		return bisector.length();
	}

	public void setBisector()
	{
		assert (!(lastJoin == null || nextJoin == null)) : "setBisector needs both edges";
		
		bisector = DotMath.bisectorAngleOf(lastJoin, nextJoin, this);
		
		//bisector = 		 shrink(lastDot.getPoint(), getPoint(), nextDot.getPoint(),
		//		getLastJoin().getSpeed(), getNextJoin().getSpeed());
	}
	
	/**
	 * Only really for debugging purposes
	 * 
	 * @param x
	 * @param y
	 */
	public void setBisector(double x, double y)
	{
		bisector = new Vector2d(x,y);
	}
	
	public void setBisector(Vector2d in)
	{
		bisector = in;
	}

	public Join getNextJoin()
	{
		return nextJoin;
	}

	public void setNextJoin(Join leftJoin)
	{
		this.nextJoin = leftJoin;
	}

	public FlatPoint getPoint()
	{
		return point;
	}
	
	/**
	 * Projects this dot onto a plane at y = 0;
	 * @return
	 */
	public Vector3d getFlat3DPoint()
	{
		return new Vector3d(point.x, 0, point.y);
	}
	
	public Vector3d getInSpace()
	{
		return new Vector3d(point.x, height, point.y);
	}
	
	/**
	 * 3d representation of the bisector (from origin)
	 * @return
	 */
	public Vector3d get3dBisector()
	{
		return new Vector3d(bisector.x,1, bisector.y);
	}

	public void setPoint(FlatPoint point)
	{
		this.point = point;
	}

	public boolean isProcessed()
	{
		return processed;
	}

	public void setProcessed(boolean processed)
	{
		this.processed = processed;
	}

	public Join getLastJoin()
	{
		return lastJoin;
	}

	public void setLastJoin(Join rightJoin)
	{
		this.lastJoin = rightJoin;
	}

	public String toString()
	{
		String out = "dot " + point +" h:"+height;// + "\n  bisec" + bisector;
		if (lastDot != null)
			out = out.concat("\n from " + lastDot.getPoint());
		if (nextDot != null)
			out = out.concat("\n to " + nextDot.getPoint());
		return (out);
	}

	public double getHeight()
	{
		return height;
	}

	public void setHeight(double height)
	{
		this.height = height;
	}

	public Dot getLastDot()
	{
		return lastDot;
	}

	public void setLastDot(Dot lastDot)
	{
		this.lastDot = lastDot;
	}

	public Dot getNextDot()
	{
		return nextDot;
	}

	public void setNextDot(Dot nextDot)
	{
		this.nextDot = nextDot;
	}

	public boolean isInfinite()
	{
		return isInfinite;
	}

	public void setInfinite(boolean isInfinite)
	{
		this.isInfinite = isInfinite;
	}
	
	/**
	 * marks this point as being part of the flat-top
	 *
	 */
	public void setTop()
	{
		top = true;
	}
	/**
	 *is this point part of the flat-top?
	 *
	 */
	public boolean getTop()
	{
		return top;
	}

	public boolean isBottom()
	{
		return bottom;
	}

	public void setBottom(boolean bottom)
	{
		this.bottom = bottom;
	}
}
