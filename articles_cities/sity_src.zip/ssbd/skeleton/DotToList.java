package skeleton;


import util.CE;

public class DotToList
{
	private CE<Dot> list;

	public DotToList(CE<Dot> first)
	{
		list = first;
	}

	public void add(CE<Dot> in, CE<Dot> after)
	{
		after.addAfterMe(in); 
	}
	
	/**
	 * This is assumed to be the start point!
	 * @return
	 */
	public CE<Dot> getList()
	{
		return list;
	}


}
