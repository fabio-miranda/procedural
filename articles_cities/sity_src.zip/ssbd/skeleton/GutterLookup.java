package skeleton;

import java.util.*;

import util.CE;

public class GutterLookup
{
	private Map<Dot, DotToList> hash = new LinkedHashMap<Dot, DotToList>();
	
	// do we still need current?
	private DotToList current;
	private DotToList start;
	// S - start connection (or just main start), O - outer
	private CE<Dot> lastS;
	private CE<Dot> lastO;
	private CE<Dot> startS;
	private CE<Dot> startO;
	
	private Set<CE<Dot>>starts = new LinkedHashSet<CE<Dot>>();
	private Set<DotToList>seen;
	
	
	public GutterLookup()
	{
		newShape();
	}
	
	/**
	 * this returns the dot before the specified dot if we've seen it before
	 * else returns null
	 * 
	 * @param in
	 * @return
	 */
	public Dot seenDot(Dot in)
	{
		return null;
	}
	
	public Set<CE<Dot>> getStarts()
	{
		return starts;
	}
	
	/**
	 * Starting a new traversal of a woof panel
	 *
	 */
	public void newShape()
	{
		if (current != null) // if we've run already
		{
			// add startO to list
			for (Dot d: hash.keySet()) // linear in no of dots processed so far - could be just in this cycle?
			{
				DotToList dtl = hash.get(d);
				if (seen.contains(dtl))
				{
					hash.put(d,start); // overwrite value with last start location
				}
			}
			starts.add(start.getList());
		}
		current = null;
		start   = null;
		seen    = new LinkedHashSet<DotToList>();
		lastS   = null;
		lastO   = null;
		startS  = null;
		startO  = null;
	}
	
	/**
	 * add this dot in, assumed to follow from last dot, unless newShape has been called!
	 * 
	 * If the dot is already in the list then we merge two lists the implied one after the
	 * current one. The end of the implied one is joined to the start of the current. The whole
	 * thing becomes the new current.
	 * 
	 * @param toAdd
	 */
	public void addDot(Dot toAdd)
	{
		CE<Dot> a ;
		DotToList h = hash.get(toAdd);
		if (h == null)
		{
			// add to the list
			a = new CE<Dot>(toAdd);  // construct the circular element
			if (lastS == null)
			{
				// create one point linked to itself
				start = current = new DotToList(a);
				seen.add(start);
				lastS = lastO = startO = startS = a;
			}
			else
			{
				current.add(a,lastO);
				lastO = lastS = a;
			}
			// add to hash
			hash.put(toAdd, current);
		}
		else
		{
			seen.add(h);
			a = h.getList().findElement(toAdd);
			assert(a != null);
			if (lastS == null)
			{
				lastO = startO = a;
				lastS = startS = a.clone();
				startS.next     = startO;
				startO.previous = startS;
				
				start = current = h;
			}
			else
			{
				// this is the complicated bit
				CE<Dot> first = a.clone();
				CE<Dot> second = a;
				
				// first is linked to start
				first.next = startS;
				startS.previous = first;
				
				// second is linked to lastS(-tart go'er)
				second.previous = startO;
				startO.next     = second;
				
				// last pair of points
				lastS = first;
				lastO = second;
				
				//
			}
		}
	}
}
