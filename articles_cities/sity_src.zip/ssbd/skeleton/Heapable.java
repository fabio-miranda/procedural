package skeleton;

import static sity.Parameters.fatalErrorSD;

import java.util.Collection;

import sity.Parameters;

public abstract class Heapable implements Comparable
{
	public int compareTo(Object arg0)
	{
		if (!(arg0 instanceof Heapable))
		{
			Parameters.fatalErrorSD("Only heapable here please");
			return 0;
		}

		Heapable other = Heapable.class.cast(arg0);

		double height = getHeight() - other.getHeight();

		if (height < 0)
		{
			return -1;
		}
		else if (height == 0)
		{
			// in a tiebreak choose a edgeevent!
			/*if (this instanceof EdgeEvent && in instanceof SplitEvent)
				return -1;
			else if (this instanceof SplitEvent && in instanceof EdgeEvent)
				return 1;*/
			return 0;
		}
		else
			return 1;
	}

	public abstract double getHeight();
	
	//public abstract void go(Collection<Dot> d);

}
