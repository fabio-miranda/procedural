package skeleton;

import static sity.Parameters.*;
import static geom.DotMath.intersectDots;
import static geom.Vec2d.pointIn;
import static geom.Vec3d.*;
import geom.*;

import java.util.*;

import javax.vecmath.*;

/**
 * A class that finds out the height (if any) of this dot's 3D bisector intersecting with any quads formed
 * 
 * @author people
 * 
 */
public class Opposite extends Heapable
{
	private double height;

	// where the event happens
	private Dot collision;

	// bones' queue
	public static Heap heap;

	// starting quad
	private Dot a;

	// start and end Dots of quad
	private Dot s, e;
	
	// says it all really, size of 'infinite' quads....  
	private static final double HUGE_NUMBER = 10E10;
	
	public Opposite(Dot d, Dot s)
	{
		a = d;
		Join edge = s.getNextJoin();
		s     = edge.getFirst();
		Dot e = edge.getSecond();
		Dot collision = intersectDotQuad(a, s, e);

		// the distanceTo test is required to ensure that we are not intersecting the newly
		// formed bisector of that the last split event created
		if (collision != null && Vec3d.distanceTo(a.getInSpace(),collision.getInSpace()) > 10E-14)
		{
			this.s = s;
			this.e = e;
			this.collision = collision;
			height = collision.getHeight();
			heap.add(this);
		}
	}
	
	/**
	 * Here's the science! concetrate! The bisector of a is tested herein for
	 * collision with the quad defined by the bisectors of s(tart) and e(end).
	 * 
	 * The quad may not be finite. It lies on the plane of dots s & e shared side.
	 * It is bounded by the line s-e, and the bisectors of s and e projected from their
	 * given locations.
	 * 
	 * Being un original, this whole thing is based on the jordan curve algorithm
	 * Mr. Chalmers dictated (from ray tracing).
	 * 
	 * Note: this class assumes Y-up (Maya convention) coordinate system for
	 * 2d - 3d transforms
	 * 
	 * @param a point being tested
	 * @param s the start/right hand base point of the quad
	 * @param e the end/left hand base point of the quad
	 * @return upon finding nother colliding bisectors a null is given, 
	 */
	public static Dot intersectDotQuad(Dot a, Dot s, Dot e)
	{
		// if any is infinite, this isn't really valid
		//if (a.isInfinite() || s.isInfinite() || e.isInfinite()) return null;
		
		//find the equation of the line
		Vector3d rayOrigin = a.getInSpace();
		Vector3d rayDirection = a.get3dBisector();
		rayDirection.normalize();
		
		//find the coordinates of the quad
		List<Vertex> allV = new ArrayList<Vertex>();
		allV.add(new Vertex(s.getInSpace()));
		allV.add(new Vertex(e.getInSpace()));
		// find top points, only 1 if they intersect
		Dot collision = intersectDots(s,e);
		if (collision == null)
		{
			// add two infinite points
			Vector3d ex =e.get3dBisector();ex.normalize();ex.scale(HUGE_NUMBER);
			ex.add(e.getInSpace());
			Vector3d sx =s.get3dBisector();sx.normalize();sx.scale(HUGE_NUMBER);
			sx.add(s.getInSpace());
			allV.add(new Vertex(ex));
			allV.add(new Vertex(sx));
		}
		else // add one point at the collision
		{
			allV.add(new Vertex(collision.getInSpace()));
		}
		
		Tuple4d planeEqn = findPlane(allV);
		if (planeEqn == null) // triangle too skinny to be a plane with any intersections
		{
			//if (Vec3d.distanceTo(collision.getInSpace(),s.getInSpace()
			// if you get here, the polygons got a 0 length edge in it, or 0 degrees between poly segs!
			/*for (Vertex v: allV) System.err.println(")()()( "+v);
			System.err.println("start is "+s);
			System.err.println("end is "+e);
			System.err.println("end.next is "+e.getNextDot());
			fatalErrorSD("zero length edge"+e.getPoint()+".."+s.getPoint()+" >> "+a.getPoint());*/
			return null;
		}
		
		// check ray hits quad (math from blue graphics book)
		Vector3d planeNormal = new Vector3d(planeEqn.x,planeEqn.y,planeEqn.z);
		
		
		double vD = Vec3d.dot(planeNormal,rayDirection);
		if (vD == 0) return null; // line parallel to plane
		// problem starts somwhere here?
		double vO = -(Vec3d.dot(planeNormal, rayOrigin)+planeEqn.w);
		
		double t=vO/vD;
		
		if (t < 0) return null; // plane is behind ray
		
		//intersection point is ri!
		Vector3d ri = new Vector3d(
				rayOrigin.x+rayDirection.x*t,
				rayOrigin.y+rayDirection.y*t,
				rayOrigin.z+rayDirection.z*t);
		
		// convert plane coordinate and collision point to UV space		
		double x = planeEqn.x;
		double y = planeEqn.y;
		double z = planeEqn.z;
		
		ThreeToTwo ttt = new ThreeToTwo(x,y,z);
		List<FlatPoint> lfp = ttt.toFlatVertex(allV);
		
		FlatPoint intersect = ttt.toFlat(ri);

		//do intersect test
		boolean result = pointIn(intersect, lfp);
		
		if (!result) return null;
		
		// return new dot at intersection point
		Dot out = new Dot (new FlatPoint(ri.x,ri.z));
		out.setHeight(ri.y);
		return out;
	}

	public Vector2d getLocation()
	{
		return collision.getPoint();
	}

	public double getHeight()
	{
		return height;
	}

	public Dot getCollision()
	{
		return collision;
	}

	public void setHeight(double height)
	{
		this.height = height;
	}

	public Dot getA()
	{
		return a;
	}

	public Dot getE()
	{
		return e;
	}

	public Dot getS()
	{
		return s;
	}
}
