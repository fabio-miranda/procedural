package skeleton;

import static sity.Parameters.*;
import geom.*;

import java.util.*;

import java.lang.reflect.Field;

import junit.framework.TestCase;
import util.*;

public class BonesGutterTest extends TestCase
{
	// regular octagon	
	final static double l = 1.0/(Math.sqrt(2))+0.5; 
	//public double data13[][] = {{-0.5,l,1},{0.5,l,1},{l,0.5,1},{l,-0.5,1},{0.5,-l,1},{-0.5,-l,1},{-l,-0.5,1},{-l,0.5,1}};
	public double data13[][] = {{0,0,1},{0.5,1,1},{1,0,1}};

	public void testManual() throws IllegalAccessException
	{
		setupParameters();
		Vector<double[][]> data = new Vector<double[][]>();
		Field[] f = this.getClass().getFields();
		String name = "unkown";
		if (true)
		try
		{
			for (Field a: f) 
				{
					name = a.getName();
					assertTrue(make((double[][])a.get(this)));
				}
		}
		catch (Error e)
		{
			e.printStackTrace();
			System.err.println("During test of " +name);
			assertTrue(false);
		}
		else
			assertTrue(make(data13));
	}

	public boolean make(double[][] data)
	{
		SheetBuilder sb = demoSheetBuilder();

		Random random = new Random();
		
		for (int i = 0; i < data.length; i++)
		{
			sb.addPoint(data[i][0], data[i][1], 0);
			sb.setPointSpeed(data[i][2]);
			//if (random.nextDouble() < 0.5) 
			sb.setPointType(EdgeType.GUTTER);
		}
		/*
		 // stuff for hole!
		  sb.newSheet();
		data = data15h;
		for (int i = 0; i < data.length; i++)
		{
			//FlatPoint f = new FlatPoint(data[i][0], data[i][1]);
			//f.setSpeed(data[i][2]);
			//f.addType(STREET);
			//spds.add(data[i][2]);
			sb.addPoint(data[i][0], data[i][1], 0);
			sb.setPointSpeed(data[i][2]);
		}*/
		
		
		Sheaf sheaf = sb.makeSheaf();

		anchor.createPolygon(sheaf.getFace());
		try
		{
			Bones s = new Bones(sheaf, 0.1, true);
			
			List<Sheaf> woof = s.getWoof();
			for (Sheaf f: woof)
			{
				Sheet a = f.getMain();
				CEFPIterator cit = a.iterator();
				while (cit.hasNext()) 
				{
					CEFP c = cit.next();
					System.err.println("this sheet's coord "+c.thing);
					System.err.println("this sheet's types "+c.thing.getTypes());
				}
				anchor.createPolygon(f);
				//System.err.println("************************************");
			}
			sity.Parameters.anchor.nextFrame();
			Sheaf gutter = s.getGutter();
			anchor.createPolygon(gutter);
			int count = 0;
			if (true)
			for (Sheet ss: gutter.getSheets())
			{
				CEFPIterator cit = new CEFPIterator(ss.getFirst());
				while (cit.hasNext())
				{
					CEFP cc = cit.next();
					System.err.println("sheet"+count+" has value "+ cc);
					for (EdgeType e: cc.thing.getTypes()) System.err.print(e+",");
					System.err.println();
				}
				count++;
			}
			
			
		}
		catch (BonesSaysNoException e)
		{
			System.err.println("got an error:"+e.message);
			return false;
		}
		return true;
	}

	
}
