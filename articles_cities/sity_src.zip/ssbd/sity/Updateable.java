package sity;

public interface Updateable
{
	public void doUpdate();
	public boolean isDisposed();
}
