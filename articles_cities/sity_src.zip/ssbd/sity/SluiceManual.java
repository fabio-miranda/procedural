package sity;

import static sity.Parameters.*;

import java.util.*;
import java.util.List;

import java.awt.*;
import java.awt.event.*;
import java.io.Serializable;

import javax.swing.*;
import javax.swing.event.ChangeEvent;

import com.jme.math.Vector3f;

/**
 * Represents the values atached to the output of a waterfall that are
 * determined by the user
 * 
 * @author people
 * 
 */
public class SluiceManual extends Sluice implements Updateable, Serializable
{
	protected List<Flow> leadsTo = new ArrayList<Flow>();

	// the internal value we keep the values normalised to!
	protected final static double NORMALISE = 100;

	// offset is the graphical opffset of this sluice from the waterfall above
	private Vector3f offset = new Vector3f(0f, 0f, 0f);

	/**
	 * Creates a new sluice
	 * 
	 * @param w
	 *            waterfallType - the supertype that any connected class must
	 *            implement
	 * @param n
	 *            name - the type of plug name eg "neighbour wall"
	 * @param i
	 *            min count for structured waterfall
	 * @param a
	 *            max count for a valid
	 * @param p
	 *            the probability of this sluice
	 */
	public SluiceManual(Class w, String n, Waterfall m)
	{
		super(w, n, m);
		m.addSluice(this);
	}

	/**
	 * New Sluice manual from existing sluice
	 * 
	 * @param s
	 *            the sluice type of the output
	 * @param p
	 *            the probability of this sluice
	 */
	public SluiceManual(Sluice s, Waterfall m)
	{
		super(s.getClass(), s.getName(), m);
	}

	/**
	 * Checks we are not already going to this waterfall!
	 * 
	 * @param s
	 *            the waterfall to check
	 * @return true if we go here!
	 */
	public boolean goesTo(Waterfall s)
	{
		if (s == null)
			return false;
		for (Flow f : leadsTo)
		{
			if (f.getTo() == s)
				return true;
		}
		return false;
	}

	protected List<Flow> getLeadsTo()
	{
		return leadsTo;
	}

	protected Flow getOutput(int i)
	{
		return leadsTo.get(i);
	}

	/**
	 * Called when a gui move is detected by the waterfall and then here we
	 * deligate it out to all the adjoining flows
	 */
	public void moved()
	{
		for (Flow f : leadsTo)
			f.moved();
	}

	/**
	 * Uses a cumulatve method to find the next waterfall to be instanced
	 * 
	 * @return
	 */
	public Waterfall getNextToFreeze(Random random)
	{
		// return null if we have no connections - default action is
		// determined by parent...
		if (leadsTo.size() == 0)
			return null;

		Iterator<Flow> it = leadsTo.iterator();
		double denominator = 0;
		while (it.hasNext())
		{
			Flow pair = it.next();
			denominator += pair.getProbablity();
		}
		it = leadsTo.iterator();
		double ran = random.nextDouble();
		ran *= denominator;
		double accum = 0;
		while (it.hasNext())
		{
			Flow pair = it.next();
			accum += pair.getProbablity();
			if (ran < accum)
			{
				return pair.getTo();
			}
		}
		error("Didn't find a match in SluiceManual.getNext");
		return leadsTo.get(0).getTo();
	}

	/**
	 * Adds the specified waterfall as a possible outcome of flowing this way
	 * 
	 * @param in
	 *            the waterfall to add (the associated freezer should implment
	 *            the specified NOISE)
	 * @param prob
	 *            the chance of this outcome being chosen (cumulatative
	 *            probability over all other
	 */
	public void addWaterfall(Waterfall in, double prob)
	{
		if (noiseType.isAssignableFrom(in.getFreezer()))
		{
			Flow flow = new Flow(me, in, prob, this);
			addFlow(flow);
			// and the opposite!
			in.addUpStream(flow);
		} else
		{
			fatalErrorSD("attempt to add an invalid waterfall to " + name);
		}
	}

	/**
	 * As above but Creates a new waterfall with probability 1.0
	 * 
	 * @param in
	 *            the waterfall to add to this sluice
	 */
	public void addWaterfall(Waterfall in)
	{
		addWaterfall(in, NORMALISE / leadsTo.size());
	}

	/**
	 * Just adds as a new flow, assuming other waterfall links delt with
	 * elsewhere
	 * 
	 * @param f
	 */
	public void addFlow(Flow f)
	{
		leadsTo.add(f);
		normaliseProbabilities(NORMALISE);
	}

	/**
	 * Removes the link to the specified waterfall
	 * 
	 * @param in
	 *            the waterfall to remove from this sluice
	 */
	public void removeFlow(Waterfall in)
	{
		// find the flow corresponding Flow
		for (Flow f : leadsTo)
			if (f.getTo() == in)
			{
				removeFlow(f);
				return;
			}
		errorSD("Asked to remove a non existant waterfall!?");
	}

	public void removeFlow(Flow togo)
	{
		//togo.getTo().removeUpStream(togo);
		leadsTo.remove(togo);
		normaliseProbabilities(NORMALISE);
	}
	
	/**
	 * Called when we are disposing of the above waterfall
	 */
	public void removeAll()
	{
		while (!leadsTo.isEmpty())
		{
			leadsTo.get(0).remove();
		}
	}

	/**
	 * Normalises the probs to some specified value without changing their
	 * proportions
	 * 
	 * @param b
	 *            the value that all probs should sum to
	 */
	public void normaliseProbabilities(double b)
	{
		double total = 0;
		for (Flow d : leadsTo)
		{
			total += d.getProbablity();
		}
		if (total == 0)
		{
			for (Flow d : leadsTo) d.setProbability(1);
			total += 1;
		}
		for (Flow d : leadsTo)
		{
			d.setProbability(new Double(d.getProbablity() * b / total));
		}
		if (leadsTo.size() == 1)
		{
			leadsTo.get(0).setProbability(NORMALISE);
		} else if (leadsTo.size() == 0)
		{
			// ...
		}

	}

	// references for the gui
    private transient ArrayList<JSlider> sliders;
    private transient Map<JComponent, Flow> highlighters;
    private transient Map<JButton, Flow> killers;
    private transient JPanel panel;
    private transient Popup popup;
    
	transient EventDispatch eventDispatch = new EventDispatch();
	
	/**
	 * Creates the panel that specifies the weightings of each 
	 * waterfall below this sluice
	 * @return the panel
	 */
	public Component getPanel()
	{
		sliders = new ArrayList<JSlider>();
		killers = new HashMap<JButton, Flow>();
		highlighters = new HashMap<JComponent, Flow>();
		panel = null;

		double total = 0;
		double max = Double.MIN_VALUE;
		for (Flow d : leadsTo)
		{
			total += d.getProbablity();
			max = Math.max(max, d.getProbablity());
		}

		panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = leadsTo.size();
		panel.add(new JLabel(getName()),c);
		c.gridwidth = 1;
		ToolTipManager.sharedInstance().setInitialDelay(0);
		int count = 0; //column counter
		for (Flow d : leadsTo)
		{
			JSlider js = new JSlider(JSlider.VERTICAL, 0, 100, (new Long(Math
					.round(d.getProbablity() / total))).intValue());
			
			js.addChangeListener(eventDispatch);
			js.addMouseListener(eventDispatch);
			js.setToolTipText("set probability of "+d.getTo().getName());
			JButton kill = new JButton("x");//+d.getTo().getName());
			kill.setBackground(colour(d.getTo().getColour()));
			kill.setToolTipText("remove link to "+d.getTo().getName());
			kill.addActionListener(eventDispatch);
			kill.addMouseListener(eventDispatch);
			killers.put(kill,d);
			highlighters.put(js,d);
			highlighters.put(kill,d);
			
			sliders.add(js);
			
			c.gridx=count;
			c.gridy=1;
			panel.add(js,c);
			c.gridy=2;
			panel.add(kill,c);
			count++;
		}

		updateValues();
		return panel;
	}

	/**
	 * Synchronises leadsTo to sliders
	 * 
	 */
	public void updateValues()
	{
		int count = 0;
		for (JSlider s : sliders)
		{

			s.setValue(new Long(Math.round(leadsTo.get(count).getProbablity()))
					.intValue());
			count++;
		}
	}

	public Vector3f getOffset()
	{
		return offset;
	}

	public void setOffset(Vector3f offset)
	{
		this.offset = offset;
	}

	public void setPopup(Popup pop)
	{
		popup = pop;
		popup.setUpdate(this);
	}
	
	public boolean isDisposed()
	{
		fatalErrorSD("Never ment to get here!");
		return false;
	}
	
	/**
	 * This must be called from the render thread because
	 * were about to make gl state changes!
	 *
	 */
	public void doUpdate()
	{
		MouseEvent event;
		if (eventDispatch == null) return;
		while ((event = eventDispatch.getMouseEvent()) != null)
		{
			switch (event.getID())
			{
			case MouseEvent.MOUSE_DRAGGED:
				break;
			case MouseEvent.MOUSE_PRESSED:
				break;
			case MouseEvent.MOUSE_RELEASED:
				break;
			case MouseEvent.MOUSE_WHEEL:
				break;
			case MouseEvent.MOUSE_MOVED:
				break;
			case MouseEvent.MOUSE_ENTERED:
				mouseEnteredUpdate(event);
				break;
			case MouseEvent.MOUSE_EXITED:
				mouseExitedUpdate(event);
				break;
			}
		}
		ActionEvent action;
		while ((action = eventDispatch.getActionEvent()) != null)
		{
			switch (action.getID())
			{
			case ActionEvent.ACTION_PERFORMED:
				actionPerformedUpdate(action);
				break;
				
			}
		}
		ChangeEvent change;
		while ((change= eventDispatch.getChangeEvent()) != null)
		{
			stateChangedUpdate(change);
		}
		
	}

	public void stateChangedUpdate(ChangeEvent e)
	{
		int count = 0;
		for (JSlider s : sliders)
		{
			if (e.getSource() == s)
			{ // event from s
				double prob = s.getValue();
				leadsTo.get(count).setProbability(new Double(prob));
				normaliseProbabilities(NORMALISE);
				updateValues();
				return;
			}
			count++;
		}
	}

	/**
	 * Only called by the buttons, who must kill the relevant flow
	 */
	public void actionPerformedUpdate(ActionEvent e)
	{
		JButton b = JButton.class.cast(e.getSource());
		Flow flow = killers.get(b);
		flow.remove();
		popup.dispose();
		b.setEnabled(false);
	}
	
	public void mouseEnteredUpdate(MouseEvent e)
	{
		highlighters.get(e.getSource()).setHighlighted(true);
	}

	public void mouseExitedUpdate(MouseEvent e)
	{
		highlighters.get(e.getSource()).setHighlighted(false);
	}
}
