/*
 * Copyright (c) 2003-2006 jMonkeyEngine
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * * Neither the name of 'jMonkeyEngine' nor the names of its contributors 
 *   may be used to endorse or promote products derived from this software 
 *   without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package sity;

import static sity.Parameters.fps;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import com.jme.system.DisplaySystem;
import com.jmex.awt.JMECanvas;

/**
 * 
 * This class is copied from the JMESwingTest example of how to create a JMonkey
 * component. Will be heavily modified!
 * 
 * <code>JMESwingTest</code> is a test demoing the JMEComponent and
 * HeadlessDelegate integration classes allowing jME generated graphics to be
 * displayed in  AWT/Swing interface.
 * 
 * Note the Repaint thread and how you grab a canvas and add an implementor to
 * it.
 * 
 * @author Joshua Slack
 * @version $Id: Balloon.java,v 1.14 2006/07/25 17:14:40 tk1748 Exp $
 */

public class Balloon extends JFrame implements Poppable
{

	public String openButton = "Open Waterfall";
	public String closeButton = "Close Waterfall";
	
	//int width = 640, height = 480;
	int width = 800, height = 600;

	Waterfall rootFall = null;
	
	// our render thread
	MonkeyThread thread = null;
	// Swing frame
	// private SwingFrame frame;

	public Balloon(Waterfall n)
	{
		// center the frame
		setLocation(450,00);
		// show frame
		setVisible(true);
		setResizable(false);
		rootFall = n;
		addKeyListener(Sity.self);
		Parameters.setIcon(this);
		
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				dispose();
			}
		});

		init();
		pack();

		thread = new MonkeyThread(comp);		
		thread.start();

	}

	/**
	 * What we do when we die
	 */
	public void pop()
	{
		impl.onQuit();
		Parameters.balloon = null;
		Sity.self.update();
		setVisible(false);
		thread.stopMonkeyingAround();
		// dont think we need these two, but theres a memory leak somewhere...
		thread = null;
		impl = null;
		dispose();
	}

	private static final long serialVersionUID = 1L;

	JPanel contentPane;

	JPanel mainPanel = new JPanel();

	public Canvas comp = null;

	JPanel spPanel = new JPanel();

	BalloonMonkey impl;

	// Component initialization
	private void init()
	{
		contentPane = (JPanel) getContentPane();
		contentPane.setLayout(new BorderLayout());

		//mainPanel.setLayout(new GridBagLayout());

		setTitle("Sity - waterfall view");

		// -------------GL STUFF------------------

		// make the canvas:
		comp = DisplaySystem.getDisplaySystem("lwjgl").createCanvas(width,
				height);
						
		// add a listener... if window is resized, we can do something about it.
		comp.addComponentListener(new ComponentAdapter()
		{
			public void componentResized(ComponentEvent ce)
			{
				doResize();
			}
		});

		// Important! Here is where we add the guts to the panel:
		impl = new BalloonMonkey(width, height, rootFall, this);
		comp.addKeyListener(Sity.self);
		comp.addKeyListener(impl.getEventDispatch());
		this.addKeyListener(impl.getEventDispatch());
		
		((JMECanvas) comp).setImplementor(impl);

		// -----------END OF GL STUFF-------------

		//mainPanel.add(spPanel, new GridBagConstraints(0, 5, 1, 1, 1.0, 1.0,
		//		GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(
		//				5, 5, 0, 5), 0, 0));
		comp.setBounds(0,0,width, height);
		//comp.setSize(width,height);
		contentPane.add(comp, BorderLayout.CENTER);
}

	/*protected void setSide(Component comp)
	{
		spPanel.removeAll();
		spPanel.add(comp);
	}*/
	
	/**
	 * Should never resize, too complicated to reconcile JME and AWT TLAs!
	 *
	 */
	protected void doResize()
	{
		impl.resizeCanvas(comp.getWidth(), comp.getHeight());
		//impl.resizeCanvas(width, height);
	}

	// Overridden so we can exit when window is closed
	protected void processWindowEvent(WindowEvent e)
	{
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING)
		{
			pop(); // just close the window, nothing else!
		}
	}
	
	protected Canvas getCanvas()
	{
		return comp;
	}

	public BalloonMonkey getMonkey()
	{
		return impl;
	}
}