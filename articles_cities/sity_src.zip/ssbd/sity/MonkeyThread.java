package sity;

import static sity.Parameters.fps;

import java.awt.Canvas;

public class MonkeyThread extends Thread
{

	private boolean go = true;
	private Canvas comp = null;
	
	public MonkeyThread(Canvas in)
	{
		setDaemon(true);
		comp = in;
	}
	
	public void run()
	{
		while (go)
		{
			comp.repaint();
			try
			{
				// only for windows where yield() doesn't yield enough!
				sleep(1000/fps);
			}
			catch (InterruptedException e)
			{
				continue;
			}
			yield();
		}
	}
	
	public void stopMonkeyingAround()
	{
		go = false;
	}
}
