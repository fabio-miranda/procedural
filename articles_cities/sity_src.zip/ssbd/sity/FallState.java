package sity;

import geom.Sheaf;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.Random;

import ssbd.FREEZER;

/**
 * The state of a waterfall when it is run : - used for extracting the input
 * values
 * 
 * @author tomkelly
 * 
 */
public class FallState
{
	Sheaf sheaf;

	List<FREEZER> parents;

	Waterfall waterfall;

	Random random;
	
	FREEZER freezer;

	public FallState(Sheaf sheaf, List<FREEZER> parents, Waterfall waterfall,
			Random random, FREEZER freezer)
	{
		this.sheaf = sheaf;
		this.parents = parents;
		this.waterfall = waterfall;
		// not sure about this
		this.random = (Random)clone(random);
	}

	public static Object clone(Object o) 
	{
		try
		{
		ByteArrayOutputStream b = new ByteArrayOutputStream();
		ObjectOutputStream out = new ObjectOutputStream(b);
		out.writeObject(o);
		out.close();
		ByteArrayInputStream bi = new ByteArrayInputStream(b.toByteArray());
		ObjectInputStream in = new ObjectInputStream(bi);
		Object no = in.readObject();
		return no;
		}
		catch (Exception e)
		{
			return null;
		}
	}

	public List<FREEZER> getParents()
	{
		return parents;
	}

	public void setParents(List<FREEZER> parents)
	{
		this.parents = parents;
	}

	public Random getRandom()
	{
		return random;
	}

	public void setRandom(Random random)
	{
		this.random = random;
	}

	public Sheaf getSheaf()
	{
		return sheaf;
	}

	public void setSheaf(Sheaf sheaf)
	{
		this.sheaf = sheaf;
	}

	public Waterfall getWaterfall()
	{
		return waterfall;
	}

	public void setWaterfall(Waterfall waterfall)
	{
		this.waterfall = waterfall;
	}

	public FREEZER getFreezer()
	{
		return freezer;
	}

	public void setFreezer(FREEZER freezer)
	{
		this.freezer = freezer;
	}

}
