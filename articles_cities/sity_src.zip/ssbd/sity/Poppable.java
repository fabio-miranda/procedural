package sity;

public interface Poppable
{
	/**
	 * Things which are opened then closed by a button
	 */
	public String openButton = "create thing";
	public String closeButton = "dispose thing";
	public void pop();
}
