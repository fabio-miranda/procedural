package sity;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Popup extends JFrame implements MouseListener, MouseMotionListener, Updateable
{
	// do we close when the mouse leaves?
	boolean clicked = false;

	// have we been disposed of?
	boolean disposed = false;
	
	private static Popup last = null;
	
	public Popup(Component c)
	{
		setup(c);
	}

	/**
	 * dummy constructor for Palette when we need to construct the popup
	 * construct the component then do setup!
	 *
	 */
	protected Popup()
	{
	}
	
	public Popup(Image i)
	{
		this(new Viewer(i));
	}
	
	public Popup(Component c, int locX, int locY)
	{
		setup(c);
		setLocation(locX, locY);
	}
	
	public void setup(Component c)
	{
		if (last != null) last.dispose();
		add(c);
		Parameters.setIcon(this);
		setTitle("Sity option");
		addMouseListener(this);
		//setUndecorated(true);
		setResizable(false);
		pack();
		setVisible(true);
		if (c.getHeight() <= 10)
		{
			dispose();
		}
		last = this;
	}

	public static void goAway()
	{
		if (last != null)
			last.dispose();
	}

	public void mouseClicked(MouseEvent e)
	{
		// TODO Auto-generated method stub
		// clicked = true;
	}

	public void mouseEntered(MouseEvent e)
	{
		
	}

	public void mouseExited(MouseEvent e)
	{
		// TODO Auto-generated method stub
		/*if (!clicked)
		{
			System.err.println(getBounds());
			if (getBounds().contains(e.getPoint()))
				dispose();
		}*/
	}

	public void mousePressed(MouseEvent e)
	{
		// TODO Auto-generated method stub

	}

	public void mouseReleased(MouseEvent e)
	{
		// TODO Auto-generated method stub

	}

	public void mouseDragged(MouseEvent e)
	{
		// TODO Auto-generated method stub

	}

	private Updateable update = null;
	
	public void doUpdate()
	{
		if (update != null) update.doUpdate();
	}
	
	public void mouseMoved(MouseEvent e)
	{
		
	}
	
	/**
	 * do our own dispose action!
	 */
	public final void dispose()
	{
		disposed = true;
		onDispose();
		super.dispose();
	}
	
	/**
	 * Gets called when the window is destroyed, overridden elsewhere
	 *
	 */
	public void onDispose()
	{
		
	}

	public Updateable getUpdate()
	{
		return update;
	}

	public void setUpdate(Updateable update)
	{
		this.update = update;
	}
	
	public boolean isDisposed()
	{
		return disposed;
	}
}
