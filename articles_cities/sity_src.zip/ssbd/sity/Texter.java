package sity;

import java.io.InputStream;
import java.net.URL;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Vector;
 
import com.jme.image.Texture;
import com.jme.math.Vector2f;
import com.jme.math.Vector3f;
import com.jme.scene.TriMesh;
import com.jme.scene.state.AlphaState;
import com.jme.scene.state.RenderState;
import com.jme.scene.state.TextureState;
import com.jme.system.DisplaySystem;
import com.jme.util.TextureManager;
import com.jme.util.geom.BufferUtils;
 
/**
 * Created on Oct 25, 2004
 * 
 * @author zen
 */
public class Texter extends TriMesh {
 
    public static final String fontLocation = "data/fonts/";
 
    public static final String defaultFont = "Vrinda";
 
    public static final int LEFT = 0;
 
    public static final int RIGHT = 1;
 
    public static final int CENTER = 2;
 
    public class Font {
        public float[] widths; // in range 0..1
 
        public TextureState ts;
 
        public String name;
 
        public Font(String fontname) {
 
            name = fontname;
            // construct texture
            ts = DisplaySystem.getDisplaySystem().getRenderer()
                    .createTextureState();
            /** The texture is loaded from fontLocation */
            ts.setTexture(TextureManager.loadTexture(Font.class.getClassLoader().getResource(fontLocation
                    + fontname + ".png"), Texture.MM_LINEAR, Texture.FM_LINEAR, 1.0f,
                    true));
            ts.setEnabled(true);
 
            // and load the width data
            URL file = Font.class.getClassLoader().getResource(fontLocation + fontname + ".dat");
            widths = new float[256];
            try {
                InputStream is = file.openStream();
                // ugh.. NEED ELEGANT WAY TO KNOW TEXTURE SIZE
                for (int i = 0; i < 256; ++i)
                    widths[i] = ((float) is.read()) / 512;
            } catch (Exception e) {
                // fill with a default width
                for (int i = 0; i < 256; ++i)
                    widths[i] = 10f / 256;
            }
        }
    }
 
    public static Vector fonts = new Vector();
 
    float width = 0;
 
    float height = 0;
 
    int alignment = LEFT;
 
    String text = null;
 
    /**
     * @return Returns the height.
     */
    public float getHeight() {
        return height;
    }
 
    /**
     * @return Returns the width.
     */
    public float getWidth() {
        return width;
    }
 
    Font font = null;
 
    public Texter(String name, String text) {
        this(name, defaultFont, text);
    }
 
    public Texter(String name, String face, String text) {
        super(name);
 
        // try to locate font face
        font = null;
        for (int i = 0; i < fonts.size(); ++i) {
            Font f = (Font) fonts.get(i);
            if (f.name.equals(face)) {
                font = f;
                break;
            }
        }
        if (font == null) {
            font = new Font(face);
            fonts.add(font);
        }
 
        setRenderState(font.ts);
        setTextureCombineMode(TextureState.REPLACE);
 
        AlphaState blend = DisplaySystem.getDisplaySystem().getRenderer()
                .createAlphaState();
        blend.setEnabled(true);
        blend.setBlendEnabled(true);
        blend.setSrcFunction(AlphaState.SB_SRC_ALPHA);
        blend.setDstFunction(AlphaState.DB_ONE_MINUS_SRC_ALPHA);
        setRenderState(blend);
 
        setText(text);
    }
 
    public void setText(String text) {
        // Characters are recreated at a size of 1. Use setLocalScale to set the
        // "font size".
        // Textures are assumed to contain a 16x16 grid of characters
 
        FloatBuffer verts = BufferUtils.createVector3Buffer(4*text.length());
        FloatBuffer texcoords = BufferUtils.createVector2Buffer(4*text.length());
        IntBuffer indicies = BufferUtils.createIntBuffer(6*text.length());
 
        // get the dimensions of the text
        width = 0;
        for (int i = 0; i < text.length(); ++i) {
            width += 16 * font.widths[text.charAt(i)];
        }
        height = 1; // always.
 
        float x = 0;
        float y = 0;
        switch (alignment) {
        case LEFT:
            x = 0;
            y = -height / 2;
            break;
        case RIGHT:
            x = -width;
            y = -height / 2;
            break;
        case CENTER:
            x = -width / 2;
            y = -height / 2;
            break;
        }
        float h = 15f / 256;
 
        for (int i = 0; i < text.length(); ++i) {
            char loop = text.charAt(i);
            loop -= 32;
 
            float cx = (loop % 16) / 16.0f;
            float cy = (loop / 16) / 16.0f;
            int base = i * 4;
            float w = font.widths[loop];
 
            // bottom left
            BufferUtils.setInBuffer(new Vector2f(cx, 1 - cy - h), texcoords, base);
            BufferUtils.setInBuffer(new Vector3f(x + 0, y + 0, 0), verts, base);
            // bottom right
            BufferUtils.setInBuffer(new Vector2f(cx + w, 1 - cy - h), texcoords, base+1);
            BufferUtils.setInBuffer(new Vector3f(x + (w * 16), y + 0, 0), verts, base+1);
            // top right
            BufferUtils.setInBuffer(new Vector2f(cx + w, 1 - cy), texcoords, base+2);
            BufferUtils.setInBuffer(new Vector3f(x + (w * 16), y + 1, 0), verts, base+2);
            // top left
            BufferUtils.setInBuffer(new Vector2f(cx, 1 - cy), texcoords, base+3);
            BufferUtils.setInBuffer(new Vector3f(x + 0, y + 1, 0), verts, base+3);
 
            // indicies for a quad, lower right triangle
            indicies.put(i*6+0, base);
            indicies.put(i*6+1, base+1);
            indicies.put(i*6+2, base+2);
            // indicies for a quad, upper left triangle
            indicies.put(i*6+3, base+2);
            indicies.put(i*6+4, base+3);
            indicies.put(i*6+5, base);
 
            // advance caret
            x += w * 16;
        }
        reconstruct(verts, null, null, texcoords, indicies);
 
        this.text = text;
    }
 
    /**
     * @return Returns the alignment.
     */
    public int getAlignment() {
        return alignment;
    }
 
    /**
     * @param alignment
     *            The alignment to set.
     */
    public void setAlignment(int alignment) {
        this.alignment = alignment;
        if (text != null)
            setText(text);
    }
 
    public static RenderState getFontRenderState(String name) {
        // try to locate font face
        Font font = null;
        for (int i = 0; i < fonts.size(); ++i) {
            Font f = (Font) fonts.get(i);
            if (f.name.equals(name)) {
                font = f;
                break;
            }
        }
        if (font == null) {
            return null;
        }
        return font.ts;
    }
}
