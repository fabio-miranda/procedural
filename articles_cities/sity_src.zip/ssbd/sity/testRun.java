package sity;

import junit.framework.TestCase;
import skyHook.DoNothingAnchor;
import ssbd.*;

/**
 * Just for running a freese and doing speed profiling....
 * @author people
 *
 */
public class testRun extends TestCase
{
	public void testSpeed() throws Exception
	{
		Parameters.anchor = new DoNothingAnchor();
		for (int i = 0; i < 20; i++)
		{
		Root start = Sity.demodata();
		FREEZER_Root.bigFreeze(start);
		}
	}
}
