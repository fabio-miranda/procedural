package sity;

import static sity.Parameters.*;

import java.io.Serializable;

import ssbd.*;

/** Represents an output plug from a waterfall, values that may not be changed by
 *  the user. 
 * 
 * @author people
 *
 */
public class Sluice implements Serializable
{
	protected Class noiseType;
	protected String name;
	protected Waterfall me;
	/**
	 * 
	 * @param w waterfallType - the supertype that any connected class must implement
	 * @param n name - the type of plug name eg "neighbour wall" 
	 */
	protected Sluice(Class w, String na, Waterfall me)
	{
		if (w.isInterface() && NOISE_Core.class.isAssignableFrom(w))
		{
			noiseType = w;
		}
		else
		{
			System.err.println(w.isInterface());
			System.err.println(NOISE_Core.class.isAssignableFrom(w));
			fatalError("Attempt to assign a non-noise type of type of "+w.getSimpleName()+" to a new sluice");
		}
		name = na;
		this.me = me;
	}

	public String getName()
	{
		return name;
	}

	protected void setName(String name)
	{
		this.name = name;
	}

	protected Class getType()
	{
		return noiseType;
	}

	protected void setWaterfallType(Class type)
	{
		this.noiseType = type;
	}
	
	
	
}
