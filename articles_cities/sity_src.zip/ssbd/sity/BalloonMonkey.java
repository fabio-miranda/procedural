package sity;

import static sity.Parameters.*;
import static sity.Waterfall.*;

import java.util.*;
import java.util.List;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

import ssbd.Root;

import com.jme.bounding.BoundingBox;
import com.jme.image.Texture;
import com.jme.input.InputHandler;
import com.jme.intersection.*;
import com.jme.math.*;
import com.jme.renderer.*;
import com.jme.scene.*;
import com.jme.scene.batch.GeomBatch;
import com.jme.scene.shape.*;
import com.jme.scene.state.*;
import com.jme.system.DisplaySystem;
import com.jme.util.TextureManager;
import com.jmex.awt.JMECanvasImplementor;

/**
 * This is SimpleCanvasImpl with a bit of BaseSimple game for features. Handles all the JME interface and awt events. Hence is total mess.
 * 
 * <code>SimpleCanvasImpl</code>
 * 
 * @author Joshua Slack
 * @version $Id: BalloonMonkey.java,v 1.23 2006/08/02 23:48:05 tk1748 Exp $
 */

public class BalloonMonkey extends JMECanvasImplementor
{

	// Items for scene
	protected Node rootNode;

	protected com.jme.util.Timer timer;

	protected float tpf;

	protected Camera cam;

	Vector3f loc = new Vector3f(8.0f, -8.0f, 20.0f); // camera location at start

	//private float camHeight = loc.z;

	protected DisplaySystem display;

	protected int width, height;

	protected InputHandler input;

	// tied in unknown ways to the screen resolution!
	private static final int SCROLL_SPEED = 600;

	private Map<GeomBatch, Waterfall> geometryToWaterfall = new Hashtable<GeomBatch, Waterfall>();

	private Map<GeomBatch, Waterfall> geometryToInPlug = new Hashtable<GeomBatch, Waterfall>();

	private Map<GeomBatch, SluiceManual> geometryToOutPlug = new Hashtable<GeomBatch, SluiceManual>();

	private Waterfall source = null;

	private Balloon balloon = null;

	/**
	 * Variables for the gui
	 */
	private int downX, downY; // last position the mouse was clicked down

	private GeomBatch selected = null;

	private static EventDispatch eventDispatch = new EventDispatch();

	private static Set<Texture>textures = new LinkedHashSet<Texture>();
	
	// list of awt components to be updated
	private List<Updateable> toUpdate = new LinkedList<Updateable>();
	
	/**
	 * This class should be subclasses - not directly instantiated.
	 * 
	 * @param width
	 *            canvas width
	 * @param height
	 *            canvas height
	 */
	protected BalloonMonkey(int width, int height, Waterfall s, Balloon b)
	{
		this.width = width;
		this.height = height;
		source = s;
		balloon = b;
		eventDispatch = new EventDispatch();
		balloon.getCanvas().addMouseListener(eventDispatch);
		balloon.getCanvas().addMouseMotionListener(eventDispatch);
		balloon.getCanvas().addMouseWheelListener(eventDispatch);
		balloon.getCanvas().addKeyListener(eventDispatch);
	}

	public void doSetup()
	{

		display = Parameters.getDisplay();
		renderer = Parameters.getRenderer();
		/**
		 * Create a camera specific to the DisplaySystem that works with the width and height
		 */
		// cam = renderer.createCamera(width, height);
		cam = display.getRenderer().createCamera(width, height);

		/** Set up how our camera sees. */
		cam.setFrustumPerspective(45.0f, (float) width / (float) height, 1, 1000);

		Vector3f left = new Vector3f(-1.0f, 0.0f, 0.0f);
		Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f);
		Vector3f dir = new Vector3f(0.0f, 0f, -1.0f);
		/** Move our camera to a correct place and orientation. */
		cam.setFrame(loc, left, up, dir);
		/** Signal that we've changed our camera's location/frustum. */
		cam.update();
		/** Assign the camera to this renderer. */
		renderer.setCamera(cam);

		/** Set a black background. */
		renderer.setBackgroundColor(ColorRGBA.black);

		display.getRenderer().setCamera(cam);

		/** Get a high resolution timer for FPS updates. */
		timer = com.jme.util.Timer.getTimer();

		/** Create rootNode */
		rootNode = new Node("rootNode");

		/**
		 * Create a ZBuffer to display pixels closest to the camera above farther ones.
		 */
		ZBufferState buf = renderer.createZBufferState();
		buf.setEnabled(true);
		buf.setFunction(ZBufferState.CF_LEQUAL);

		rootNode.setRenderState(buf);

		simpleSetup();
		createWaterfalls();
		/**
		 * Update geometric and rendering information for both the rootNode and fpsNode.
		 */
		rootNode.updateGeometricState(0.0f, true);
		rootNode.updateRenderState();

		setup = true;
	}

	/**
	 * Create the waterfall meshes :)
	 * 
	 */
	private void createWaterfalls()
	{
		seenWaterfalls = new LinkedHashSet<Waterfall>();
		// add them to the graph
		addWaterfalls(source);
	}


	// list of waterfalls seen to stop horrible recursion
	private static Set<Waterfall> seenWaterfalls;
	
	private void addWaterfalls(Waterfall todo)
	{
		for (SluiceManual sm : todo.downStream)
			for (Flow wp : sm.leadsTo)
			{
				// over all connected waterfalls
				Waterfall w = wp.getTo();
				if (!seenWaterfalls.contains(w))
				{
					seenWaterfalls.add(w);
					addWaterfalls(w);
				}
			}
		createMesh(todo);
		return;
	}

	
	protected static void doFallLocate(Waterfall source)
	{
		// we do it twice to allow the flows to catch up....
		seenWaterfalls = new HashSet<Waterfall>();
		fallLocate(0f, source, 0f);
		seenWaterfalls = new HashSet<Waterfall>();
		fallLocate(0f, source, 0f);
	}
	
	
	/**
	 * recursive doofit to locate all waterfalls according to their sizes
	 * 
	 * @return
	 */
	private static  float fallLocate(float sizeToLeft, Waterfall todo, float depth)
	{
		float sizeUnder = 0; // size to left under this waterfall
		boolean leaf = true;
		for (SluiceManual sm : todo.downStream)
			for (Flow wp : sm.leadsTo)
			{
				// over all connected waterfalls
				leaf = false;
				Waterfall w = wp.getTo();
				if (!seenWaterfalls.contains(w))
				{
					seenWaterfalls.add(w);

					sizeUnder += fallLocate((float) sizeUnder + sizeToLeft, w, depth + Y_SPACE + todo.getSize().y);
				}
			}
		if (leaf)
		{
			sizeUnder += todo.getSize().x + X_SPACE + X_SPACE;
		}
		todo.setLocation(new Vector2f(sizeToLeft + X_SPACE + todo.getSize().x / 2 + (float) sizeUnder / 2, -depth));

		return sizeUnder;
	}

	/**
	 * Create the mesh for a waterfall and add it to the hash corresponding Geometries to Waterfalls
	 * 
	 */

	protected void createMesh(Waterfall todo)
	{
		Node node = new Node();
		// waterfall box
		// real location on screen
		Vector3f location2 = new Vector3f(todo.getLocation().x, todo.getLocation().y, 0);
		// offset from real location!
		Vector3f location = new Vector3f(0, 0, 0);
		Geometry geom = new Box(todo.getClass().getSimpleName(), location, todo.getSize().x / 2, todo.getSize().y / 2, 0);

		Quad q = new Quad("Quad", 3f, 0.5f);
		node.attachChild(geom);
		node.setLocalTranslation(location2);

		BufferedImage buffer = new BufferedImage(128, 64, BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = buffer.createGraphics();
		g.setFont(new Font(null, Font.PLAIN, 20));
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 128, 64);
		g.setColor(Color.BLACK);
		g.drawString(todo.getName(), 10, 20);

		Image image = Toolkit.getDefaultToolkit().createImage(buffer.getSource());

		Texture t = TextureManager.loadTexture(image, com.jme.image.Texture.MM_LINEAR, com.jme.image.Texture.FM_LINEAR, true);

		TextureState ts = display.getRenderer().createTextureState();
		ts.setEnabled(true);
		ts.setTexture(t);
		geom.setRenderState(ts);
		todo.setText(q);
		todo.setNode(node);

		Vector3f start = new Vector3f(location);

		// upstream plugs
		if (!(todo instanceof Root))
		{
			location.y += todo.getSize().y / 2 + PLUG_SIZE / 2;
			Geometry topPlug = new Box(todo.getClass().getSimpleName() + "plug x", location, PLUG_SIZE / 2, PLUG_SIZE / 2, 0f);
			location.x += -todo.getSize().x / 2 + PLUG_SPACING + PLUG_SIZE / 2;
			// geom.addBatch(topPlug.getBatch(0));
			node.attachChild(topPlug);
			topPlug.setModelBound(new BoundingBox());
			topPlug.updateModelBound();
			topPlug.setSolidColor(colourFromNoise(todo.getNoise()));
			location.y -= todo.getSize().y + PLUG_SIZE;
			geometryToInPlug.put(topPlug.getBatch(0), todo);

		}
		else
		{
			// for the root
			location.y -= todo.getSize().y / 2 + PLUG_SIZE / 2;
		}
		// now downstream plugs
		for (SluiceManual sm : todo.downStream)
		{
			Geometry plug = new Box(todo.getClass().getSimpleName() + "plug x", location, PLUG_SIZE / 2, PLUG_SIZE / 2, 0f);
			// specify location of plug in fulutre
			sm.setOffset(location.subtract(start).subtract(new Vector3f(0, PLUG_SIZE / 2, 0)));
			// add the flows for all the elements of the graph
			for (Flow p : sm.leadsTo)
				p.graphInitalise(rootNode);
			location.x += PLUG_SIZE + PLUG_SPACING;
			// geom.addBatch(plug.getBatch(0));
			node.attachChild(plug);

			buffer = new BufferedImage(64, 64, BufferedImage.TYPE_4BYTE_ABGR);
			g = buffer.createGraphics();
			Font font = new Font(null, Font.PLAIN, 20);
			g.setFont(font);
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, 64, 64);
			g.setColor(Color.BLACK);

			g.drawString(sm.getName(), 3, 20);

			image = Toolkit.getDefaultToolkit().createImage(buffer.getSource());

			t = TextureManager.loadTexture(image, com.jme.image.Texture.MM_LINEAR, com.jme.image.Texture.FM_LINEAR, true);

			ts = display.getRenderer().createTextureState();
			ts.setEnabled(true);
			ts.setTexture(t);
			plug.setRenderState(ts);

			plug.setModelBound(new BoundingBox());
			plug.updateModelBound();
			plug.setSolidColor(colourFromNoise(sm.getType()));
			geometryToOutPlug.put(plug.getBatch(0), sm);
		}

		geom.setModelBound(new BoundingBox());
		geom.updateModelBound();
		// Give the sphere random colors
		geom.setSolidColor(todo.getColour());
		rootNode.attachChild(node);
		geometryToWaterfall.put(geom.getBatch(0), todo);
		todo.setBatch(geom.getBatch(0));
		rootNode.updateGeometricState(0.0f, true);
		rootNode.updateRenderState();
	}


	// from baseSimpleGame
	protected void cameraParallel()
	{
		cam.setParallelProjection(true);
		float aspect = (float) display.getWidth() / display.getHeight();
		cam.setFrustum(-100, 1000, -50 * aspect, 50 * aspect, -50, 50);
		cam.update();
	}

	public void doUpdate()
	{
		timer.update();
		/** Update tpf to time per frame according to the Timer. */
		tpf = timer.getTimePerFrame();

		simpleUpdate();
		doMouseUpdate();
		rootNode.updateGeometricState(tpf, true);
		// go through all registered updaters...

		
		Iterator<Updateable> it = toUpdate.iterator();
		ArrayList<Updateable> toRemove = new ArrayList<Updateable>();
		while (it.hasNext())
		{
			Updateable u = it.next();
			if (u.isDisposed())
			{
				toRemove.add(u);
			}
			// always do update - in case action on dispose()
			u.doUpdate();

		}
		for (Updateable r : toRemove)
		{
			toUpdate.remove(r);
		}
		for (Waterfall w : geometryToWaterfall.values())
		{
			w.doUpdate(this);
		}
	}

	public void doRender()
	{
		renderer.clearBuffers();
		renderer.draw(rootNode);
		simpleRender();
		renderer.displayBackBuffer();
	}

	public void simpleSetup()
	{
		/*
		 * Sphere s = new Sphere("My sphere", 10, 10, 1f); // Do bounds for the sphere, but we'll use a BoundingBox this time s.setModelBound(new BoundingBox()); s.updateModelBound(); // Give the sphere random colors s.setRandomColors(); rootNode.attachChild(s);
		 */
	}

	public void simpleUpdate()
	{
		timer.update();
		tpf = timer.getTimePerFrame();
		// input.update( tpf );
	}

	public void simpleRender()
	{
	}

	public Camera getCamera()
	{
		return cam;
	}

	/**
	 * Trial and error correlation between AWT coordinate system and JME!
	 * 
	 * @return
	 */
	protected float getInterfaceFactor()
	{
		return SCROLL_SPEED / cam.getLocation().z;
	}

	GeomBatch geomSelected = null;
/**
 * Called from sity to selectt he current waterfall...
 * @param in
 */
	protected void selectFall(Waterfall in)
	{
		GeomBatch gb = in.getBatch();
		// need to find geombatch from waterfall
		deselectAll();
		gb.setSolidColor(HIGHLIGHT);
		geomSelected = gb;
	}
	
	private void select(GeomBatch gb)
	{
		if (gb != null && geometryToWaterfall.containsKey(gb))
		{
			Sity.self.setCurrentFall(geometryToWaterfall.get(gb));
		}
	}

	private void deselectAll()
	{
		if (geomSelected != null)
			geomSelected.setSolidColor(geometryToWaterfall.get(geomSelected).getColour());
	}

	/**
	 * Gets called from the main thread to dispatch accumulated AWT events
	 */
	private void doMouseUpdate()
	{

		MouseEvent event;
		while ((event = eventDispatch.getMouseEvent()) != null)
		{
			switch (event.getID())
			{
			case MouseEvent.MOUSE_DRAGGED:
				mouseDraggedUpdate(event);
				break;
			case MouseEvent.MOUSE_PRESSED:
				mousePressedUpdate(event);
				break;
			case MouseEvent.MOUSE_RELEASED:
				mouseReleasedUpdate(event);
				break;
			case MouseEvent.MOUSE_WHEEL:
				break;
			case MouseEvent.MOUSE_MOVED:
				break;
			case MouseEvent.MOUSE_ENTERED:
				mouseEnteredUpdate(event);
			case MouseEvent.MOUSE_EXITED:
				mouseExitUpdate(event);
				break;
			}
		}
		MouseWheelEvent wheel;
		while ((wheel = eventDispatch.getMouseWheelEvent()) != null)
		{
			mouseWheelUpdate(wheel);
		}
		KeyEvent key;
		while ((key = eventDispatch.getKeyEvent()) != null)
		{
			switch (key.getID())
			{
			case KeyEvent.KEY_RELEASED:
				keyRelease(key);
				break;
			}
		}

	}
	
	/**
	 * Key release handler delegated through eventDispatch
	 * @param e
	 */
	private void keyRelease(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_R)
		{
			doFallLocate(source);
		}
	}

	/**
	 * Takes a mouse event and finds the object to select (or none!)
	 * 
	 * @param e
	 *            the mouse event with the locations
	 */
	private void processClick(MouseEvent e)
	{
		// jME voodoo to make it work (trial and error)
		display.setRenderer(renderer);
		DisplaySystem.updateStates(renderer);
		// Assign the camera to this renderer.
		renderer.setCamera(cam);
		
		PickResults pr; // should do in init?
		pr = new TrianglePickResults();

		Vector2f screenPos = new Vector2f();
		// Get the position that the mouse is pointing to
		screenPos.set(e.getPoint().x, e.getPoint().y);
		// flip the x coordinate!

		screenPos.y = display.getHeight() - screenPos.y;
		// Get the world location of that X,Y value
		Vector3f worldCoords = display.getWorldCoordinates(screenPos, 0);
		// Create a ray starting from the camera, and
		// going in the direction of the mouse's location
		Ray mouseRay = new Ray(cam.getLocation(), worldCoords.subtractLocal(cam.getLocation()));
		// Does the mouse's ray intersect the box's world bounds?
		pr.clear();
		rootNode.findPick(mouseRay, pr);
		if (pr.getNumber() != 0)
		{
			// for (int i = 0; i < pr.getNumber(); i++)
			// {
			// pr.getPickData(i).getTargetMesh().setRandomColors();
			// }

			selected = pr.getPickData(0).getTargetMesh();
		}
		else
		// person has clicked on the background!
		{
			selected = null;
		}
	}

	public void mouseDraggedUpdate(MouseEvent e)
	{
		float xMov = ((float) e.getPoint().x - (float) downX) / getInterfaceFactor();
		float yMov = ((float) e.getPoint().y - (float) downY) / getInterfaceFactor();

		if (newFlow != null)
		{
			// we are in flow making mode!
			Vector3f v = new Vector3f(xMov, -yMov, 0);
			newFlow.findPoints(newFlow.b.add(v));
			newFlow.updateCurve();
		}
		else if (selected == null) // move the camrea
		{
			// if the main window has seen the down event
			if (seenDown)
			{
				loc.x -= xMov;
				loc.y += yMov;
				cam.setLocation(loc);
				cam.update();
			}
		}
		else if (geometryToWaterfall.containsKey(selected))// move the
		// waterfall
		{
			Waterfall fall = geometryToWaterfall.get(selected);
			fall.setLocation(new Vector2f(fall.getLocation2().x + xMov, fall.getLocation2().y - yMov));
			
		}
		else if (geometryToOutPlug.containsKey(selected))
		{

		}
		else
		// move the object?!
		{
			/*if (geometryToWaterfall.containsKey(selected))
			{
				Vector3f res = selected.getParentGeom().getLocalTranslation();
				res.x += xMov;
				res.y -= yMov;
				selected.getParentGeom().setLocalTranslation(res);
			}*/
		}
		// reset scroll amount
		downX = e.getPoint().x;
		downY = e.getPoint().y;
	}

	Flow newFlow = null;

	// did this balloonMonkey witness the mouse going down
	boolean seenDown = false;

	public void mousePressedUpdate(MouseEvent e)
	{
		processClick(e);
		if (selected != null)
		{
			select(selected);
			if (geometryToWaterfall.containsKey(selected))
			{
				// nothing to do yet - display palette?
				// System.err.println("waterfall");
				//Sity.self.setPanel(geometryToWaterfall.get(selected).getGUI()); - now done in Sity
			}
			else if (geometryToInPlug.containsKey(selected))
			{
				// inplugs dont do anything
				// System.err.println("inplug");
			}
			else if (geometryToOutPlug.containsKey(selected))
			{
				// System.err.println("outplug");
				// someone is clicking from an output sluice!
				SluiceManual sm = geometryToOutPlug.get(selected);
				newFlow = new Flow(sm.me, null, 1, sm);
				newFlow.linkInitalise(sm.me.getLocation().add(sm.getOffset()), rootNode);
			}
		}

		seenDown = true;

		downX = e.getPoint().x;
		downY = e.getPoint().y;
	}

	/**
	 * Contains most of the logic for creating and destroying links between waterfalls
	 * 
	 * @param e
	 *            the triggering mouse release
	 */
	public void mouseReleasedUpdate(MouseEvent e)
	{
		seenDown = false;
		processClick(e);
		if (newFlow != null)
		{
			// we are dropping a flow!
			// if on an output - ignore, input/waterfall - create link,
			// background - bring up the pallete
			if (selected == null)
			{

				// downX = e.getPoint().x;
				// downY = e.getPoint().y;
				// create a waterfall!
				Palette p = new Palette(balloon.getX() + e.getX(), balloon.getY() + e.getY(), newFlow, this, e);
				toUpdate.add(p);
				// downX = e.getPoint().x;
				// downY = e.getPoint().y;

			}
			else if ((geometryToWaterfall.containsKey(selected) && !(geometryToWaterfall.get(selected) instanceof Root)) || geometryToInPlug.containsKey(selected))
			{
				// add flow only if a flow doesn't already exist
				Waterfall toFall;
				if (geometryToWaterfall.containsKey(selected))
				{
					toFall = geometryToWaterfall.get(selected);
				}
				else
				{
					toFall = geometryToInPlug.get(selected);
				}
				if ((!newFlow.getSluice().goesTo(toFall)) && newFlow.getSluice().getType() == toFall.getNoise())
				{
					newFlow.setProbability();
					toFall.addUpStream(newFlow);
					newFlow.setTo(toFall);
					newFlow.getSluice().addFlow(newFlow);
				}
				else
				{

					// no duplicate links, ignore!
					rootNode.detachChild(newFlow.getCurve());
					if (newFlow.getSluice().getType() != toFall.getNoise())
					{
						error("you can only connect sluices of the same colour!");
					}
					else
					{
						error("no more than one link between a sluice and inflow pair!");
					}

				}
			}
			else if (geometryToOutPlug.containsKey(selected))
			{
				// makes no sense and may not have been a drag, just
				// a plug release
				rootNode.detachChild(newFlow.getCurve());
				outPlugClick(e);
			}
			else
			{
				// delete flow - only really used when someone tries to wire the
				// root waterfall
				rootNode.detachChild(newFlow.getCurve());
			}

			newFlow = null;
		}
		else
		// if we're not making lines links:
		{
			if (selected != null)
			{
				select(selected);
				if (geometryToWaterfall.containsKey(selected))
				{

				}
				else if (geometryToInPlug.containsKey(selected))
				{

				}
				else if (geometryToOutPlug.containsKey(selected))
				{
					outPlugClick(e);
				}
			}
		}
	}

	private void mouseEnteredUpdate(MouseEvent e)
	{
		Popup.goAway();
	}

	/**
	 * dragging the waterfall to the edge of the screen deletes it!
	 * 
	 * @param e
	 */
	private void mouseExitUpdate(MouseEvent e)
	{
		if (selected != null && eventDispatch.isMouseDown())
			if (geometryToWaterfall.containsKey(selected))
			{
				Waterfall togo = geometryToWaterfall.get(selected);
				// delete all links
				if (!(togo instanceof Root))
				{
					deleteWaterfall(togo);
				}
				else
				{
					error("You may not delete the root!");
				}
			}
	}

	/**
	 * This is what to call to remove all links from the waterfall and remove it from scenegraph
	 * 
	 * @param togo
	 */
	public void deleteWaterfall(Waterfall togo)
	{
		togo.disconnectAll();
		if (geometryToWaterfall.containsValue(togo))
		{
			if (selected != null)
				geometryToWaterfall.remove(selected);
			// make unselectable
			togo.node.removeFromParent();
			selected = null;
			geomSelected = null;
		}
	}

	private void mouseWheelUpdate(MouseWheelEvent e)
	{
		Vector3f pos = cam.getLocation();
		pos.z += (float) e.getUnitsToScroll() * pos.z / MOUSE_WHEEL_DIVIDER;
		pos.z = Math.max(pos.z, 5);
		pos.z = Math.min(pos.z, 50);
		cam.setLocation(pos);
	}

	private void outPlugClick(MouseEvent e)
	{
		Component p = geometryToOutPlug.get(selected).getPanel();
		Popup pop = new Popup(p, balloon.getX() + e.getX(), balloon.getY() + e.getY());
		toUpdate.add(pop);
		geometryToOutPlug.get(selected).setPopup(pop);
	}

	public EventDispatch getEventDispatch()
	{
		return eventDispatch;
	}
	
	/**
	 * Tidy up resources....
	 *
	 */
	protected void onQuit()
	{
		renderer.setCamera(null);
		
		ListIterator<Spatial> lit = rootNode.getChildren().listIterator(); 
		while (lit.hasNext()) lit.next(); lit.remove();
		
		rootNode.removeFromParent();
		
		// the might be to blame for inter-display reactions? (also in MagicWindowMonkey)
		display.getDisplaySystem().close();
		display.getRenderer().clearVBOCache();
		display.close();

		renderer.clearQueue();
		renderer.clearVBOCache();

		for (Texture t: textures)TextureManager.releaseTexture(t);
		TextureManager.clearCache();
		
		eventDispatch = null;
		geometryToWaterfall = null;
		geometryToInPlug = null;
		geometryToOutPlug = null;
		toUpdate = null;
	}
	
}
