package sity;

import java.awt.*;
import java.net.*;

/**
 * Little class to wrap an image to a compent
 * 
 * @author tk1748
 * 
 */
class Viewer extends Component
{
	private Image image;

	public Viewer(Image fileName)
	{
		setup(fileName);
	}

	public Viewer(URL in)
	{
		try
		{
			Image m = (Toolkit.getDefaultToolkit()).getImage(in);
			setup(m);
		}
		catch (Exception e)
		{
			Parameters.error("file " + in + " not found");
		}
	}

	public Viewer(String in)
	{
		try
		{
			Image m = (Toolkit.getDefaultToolkit()).getImage(this.getClass().getResource(in));
			setup(m);
		}
		catch (Exception e)
		{
			Parameters.error("file " + in + " not found");
		}

	}

	private void setup(Image fileName)
	{
		image = fileName;

		// Create a media tracker to wait for the image
		MediaTracker tracker = new MediaTracker(this);

		// Tell the media tracker to watch the image
		tracker.addImage(image, 0);

		// Wait for the image to be loaded
		try
		{
			tracker.waitForAll();
		}
		catch (Exception ignore)
		{
		}

		//setSize(new Dimension(getWidth() - 1, getHeight() - 1));
		setPreferredSize(new Dimension(image.getWidth(null)/2, image.getHeight(null)/2));
	}

	public void paint(Graphics graphics)
	{
		Graphics g = graphics;
		// graphics.drawImage(image, 0, 0, null);
		// Get the width of the image
		int width = image.getWidth(this);

		g.drawImage(image, 0, 0, getWidth(), getHeight(), this);

	}
}
