package sity;

import java.io.Serializable;
import java.nio.FloatBuffer;

import com.jme.curve.BezierCurve;
import com.jme.math.Vector3f;
import com.jme.renderer.ColorRGBA;
import com.jme.scene.Node;
import com.jme.util.geom.BufferUtils;

/**
 * A representation of a link between two waterfalls
 * 
 * @author tk1748
 * 
 */
public class Flow implements Serializable
{
	private Waterfall from;

	private SluiceManual sluice;

	private Waterfall to;

	private double probablity;

	private BezierCurve curve = null;

	private static float BENDYNESS = 1f;

	private static float BEND_HEIGHT = 1f;
	
	private transient Node root;
	
	private boolean highlight = false;

	public Flow(Waterfall from, Waterfall to, double probablity,
			SluiceManual sluice)
	{
		this.from = from;
		this.probablity = probablity;
		this.sluice = sluice;
		this.to = to;
	}

	// bezier points (non live)
	Vector3f a, b, a2, b2;

	/**
	 * Called when we are put into the graph the first time!
	 */
	public BezierCurve graphInitalise(Node n)
	{
		findPoints(null);
		createFall(n);
		return curve;
	}
	
	/**
	 * Similarly for a flow with an unconnected downstream (being connected)
	 * @return
	 */
	public BezierCurve linkInitalise(Vector3f location, Node n)
	{
		findPoints(location);
		createFall(n);
		return curve;
	}

	/**
	 * Called to update the curve data points, then call updateCurve()!
	 * @param to
	 */
	public void findPoints(Vector3f pointTo)
	{
		if (pointTo == null) pointTo = to.getLocation().add(0,to.getSize().y/2+Waterfall.PLUG_SIZE,0);
		a = sluice.getOffset().add(from.getLocation());
		b = pointTo;
		b2 = new Vector3f(b);
		b2 = b2.add(0, BENDYNESS, BEND_HEIGHT);
		a2 = new Vector3f(a);
		a2 = a2.add(0, -BENDYNESS, BEND_HEIGHT);
	}

	/**
	 * Creates the new curve for this object
	 * @param root the node that we will be attached, to and we will remove ourselves from
	 * later
	 * @return the curve ready
	 */
	protected void createFall(Node r)
	{
		
		root = r;
		
		Vector3f[] points = new Vector3f[4];
		points[0] = a;
		points[1] = a2;
		points[2] = b2;
		points[3] = b;

		curve = new BezierCurve("Curve", points);
		curve.setIsCollidable(true);
		ColorRGBA[] colors = new ColorRGBA[4];
		colors[0] = new ColorRGBA(1, 0, 0, 1);
		colors[1] = new ColorRGBA(1, 0, 0, 1);
		colors[2] = new ColorRGBA(1, 0, 0, 1);
		colors[3] = new ColorRGBA(1, 0, 0, 1);
		curve.setColorBuffer(0, BufferUtils.createFloatBuffer(colors));

		updateCurve();
		root.attachChild(curve);
	}

	/**
	 * Change keypoints on curve and flip buffer
	 * to display!
	 *
	 */
	protected void updateCurve()
	{
		if (curve != null) //before we start the gui
		{
		FloatBuffer fb = curve.getVertexBuffer(0);
		fb.position(0);
		fb.put(a.x);
		fb.put(a.y);
		fb.put(a.z);
		fb.put(a2.x);
		fb.put(a2.y);
		fb.put(a2.z);
		fb.put(b2.x);
		fb.put(b2.y);
		fb.put(b2.z);
		fb.put(b.x);
		fb.put(b.y);
		fb.put(b.z);
		fb.flip();
		
		FloatBuffer cb = curve.getColorBuffer(0);
		cb.position(0); // lol, dunno why colour needs this but fb doesnt!
		
		ColorRGBA start;
		if (highlight)
		{
			start = ColorRGBA.red;
		}
		else
		{
			start =new ColorRGBA((float)(probablity/SluiceManual.NORMALISE),(float)(probablity/SluiceManual.NORMALISE),1f,1f); 
			//Parameters.colourFromNoise(sluice.getType());
		}

		//start
		cb.put(start.r);
		cb.put(start.g);
		cb.put(start.b);
		cb.put(start.a);
		
		ColorRGBA mid = start; 
		//middle
		cb.put(mid.r);
		cb.put(mid.g);
		cb.put(mid.b);
		cb.put(mid.a);

		//end
		ColorRGBA end = start;
		if (to != null) end = mid;//Parameters.colourFromNoise(to.getNoise());
		cb.put(end.r);
		cb.put(end.g);
		cb.put(end.b);
		
		cb.put(1.0f);// doesn't show!
		cb.put(end.r);
		cb.put(end.g);
		cb.put(end.b);
		cb.put(1.0f);
		
		
		cb.flip();
		}
	}
	
	/**
	 * Highlights this flow
	 * @param in
	 */
	public void setHighlighted(boolean in)
	{
		highlight = in;
		updateCurve();
	}
	
	/**
	 * Called when the gui requests that this link is removed 
	 * Removes from before and after waterfalls too!
	 */
	public void remove()
	{
		sluice.removeFlow(this);
		to.removeUpStream(this);
		root.detachChild(curve);
	}
	

	/**
	 * Called when someone movesfrom one of the adjoining waterfalls in the GUI
	 */
	public void moved()
	{
		if (curve != null)
		{
			findPoints(null); // null to go with defaults!
			updateCurve();
		}
	}

	public BezierCurve getCurve()
	{
		return curve;
	}
	
	public Waterfall getFrom()
	{
		return from;
	}

	public void setFrom(Waterfall from)
	{
		this.from = from;
	}

	public double getProbablity()
	{
		return probablity;
	}
	
	/**
	 * Sets the probability to the averge of other
	 * flows in the sluice and normalise them
	 *
	 */
	public void setProbability()
	{
		probablity = SluiceManual.NORMALISE/sluice.leadsTo.size();
		sluice.normaliseProbabilities(SluiceManual.NORMALISE);
		updateCurve();
	}

	public void setProbability(double probablity)
	{
		this.probablity = probablity;
		updateCurve();
	}

	public SluiceManual getSluice()
	{
		return sluice;
	}

	public void setSluice(SluiceManual sluice)
	{
		this.sluice = sluice;
	}

	public Waterfall getTo()
	{
		return to;
	}

	public void setTo(Waterfall to)
	{
		this.to = to;
		moved();
	}

}
