package sity;

import static sity.Parameters.*;

import java.util.*;
import java.util.List;

import java.lang.reflect.*;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.io.*;
import java.net.*;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;

import ssbd.*;

import com.jme.math.Vector2f;
import com.jme.scene.Node;

/**
 * List of all Waterfalls
 * 
 * @author people
 * 
 */
public class Palette extends Popup implements Updateable
{
	// just a marker/dummy for no assigned result
	Waterfall NONE = new Root(null);

	Waterfall result = NONE;

	Flow flow = null;

	BalloonMonkey bm = null;

	Node rootNode = null;

	MouseEvent e = null;

	EventDispatch eventDispatch = new EventDispatch();

	JList toSelect = null;

	/**
	 * 
	 * @param x
	 *            position on screen of palette
	 * @param y
	 *            position on screen of palette
	 * @param ourLink
	 *            the flow that we are created with
	 * @param r
	 *            the root node to make changes to
	 */
	public Palette(int x, int y, Flow ourLink, BalloonMonkey b, MouseEvent m)
	{
		super();
		flow = ourLink;
		bm = b;
		rootNode = b.rootNode;
		e = m;

		List<Class<Waterfall>> list = null;
		try
		{
			list = getClassesForPackage(waterfallPackage);
		}
		catch (ClassNotFoundException e)
		{
			error("package " + waterfallPackage + " not found");
		}

		Vector<String> names = new Vector<String>();

		//System.err.println("\n looking for: "+ourLink.getSluice().getType());
		
		toSelect = new JList(names);
		// fall all classes in ssbd
		for (Class c : list)
		{
			Class[] interfaces = c.getInterfaces();
			//System.err.println("for class " + c.getSimpleName());
			// fall all interfaces that class has
			for (Class i : interfaces)
			{
				//System.err.println("  interfaces include " + i.getSimpleName());
				// if the interface is a noise, but the class isin't another nosie,
				if (NOISE_Core.class.isAssignableFrom(i) && !c.getSimpleName().startsWith("NOISE"))
				{
					//System.err.println("...1" + i);
					// and if that type is the same as our sluice
					if (i == flow.getSluice().getType())
					{
						//System.err.println("...2");
						// and if that type isn a root or main freezer
						if (!(c == FREEZER.class || c == FREEZER_Root.class))
						{
							//System.err.println("...3 :)");
							names.add(c.getSimpleName().replaceFirst("FREEZER_", ""));
							continue;
						}
					}
				}
			}

		}

		toSelect.addListSelectionListener(eventDispatch);
		JScrollPane jsp = new JScrollPane(toSelect);
		jsp.setToolTipText("select Waterfall to add");
		jsp.setPreferredSize(new Dimension(150, 300));

		setLayout(new BorderLayout());

		setup(jsp);
		setSize(150, 300);
		setLocation(x, y);
	}

	/**
	 * Called when the window is disposed() TO UPDATE THREAD!?
	 */
	public void onDispose()
	{
		result = null;
	}

	/**
	 * Check to see if a decision has been made, if so set to dispose then add the waterfall. Called from the Render thread!
	 */
	public void doUpdate()
	{
		ListSelectionEvent action;
		while ((action = eventDispatch.getListEvent()) != null)
		{
			listUpdate(action);
		}

		if (result != NONE)
		{
			addFall();
			// only addFall once now!
			result = NONE;
			dispose();
		}
	}

	/**
	 * Someones clicked on the list! Reflection code from java.sun.com
	 * 
	 * @param e
	 */
	private void listUpdate(ListSelectionEvent e)
	{
		String toMake = String.class.cast(Parameters.waterfallPackage + "." + toSelect.getSelectedValue());

		Class[] intArgsClass = new Class[] { Waterfall.class };
		Object[] intArgs = new Object[] { flow.getFrom() };
		Constructor intArgsConstructor;

		Class classToMake;
		Waterfall fall;
		try
		{
			classToMake = Class.forName(toMake);
			intArgsConstructor = classToMake.getConstructor(intArgsClass);
			fall = (Waterfall) intArgsConstructor.newInstance(intArgs);
			result = fall;
		}
		catch (ClassNotFoundException f)
		{
			error(f.toString());
		}
		catch (NoSuchMethodException f)
		{
			error(f.toString());
		}
		catch (InstantiationException f)
		{
			error(f.toString());
		}
		catch (IllegalAccessException f)
		{
			error(f.toString());
		}
		catch (IllegalArgumentException f)
		{
			error(f.toString());
		}
		catch (InvocationTargetException f)
		{
			error(f.toString());
		}
	}

	/**
	 * Gets run twice if you add a waterfall..bit shoddy design
	 * 
	 */
	private void addFall()
	{

		if (result == null)
		{
			if (flow.getTo() == null)
				rootNode.detachChild(flow.getCurve());
		}
		else if (result == NONE)
		{
			fatalErrorSD("Should never reach here, should only addFall when decision to action made");
		}
		else
		{
			Vector2f newLoc = new Vector2f(e.getX() / bm.getInterfaceFactor() + bm.cam.getLocation().x - bm.width / (2 * bm.getInterfaceFactor()), -e.getY() / bm.getInterfaceFactor() + bm.cam.getLocation().y + bm.height / (2 * bm.getInterfaceFactor()));
			result.setLocation(newLoc);// newFlow.getFrom().getLocation2().add(new Vector2f(0,-Waterfall.FALL_Y*2)));
			// System.err.println(e.getX()+">>>"+e.getY());
			bm.createMesh(result);

			flow.setProbability();
			result.addUpStream(flow);
			flow.setTo(result);
			flow.getSluice().addFlow(flow);
		}
	}

	/**
	 * returns a list of waterfalls available to the system
	 * 
	 * @param parent
	 *            the parent of this waterfall (for type info)
	 * @return returns the waterfall selected, or null for none selected
	 */
	public Waterfall getWaterfall(Waterfall parent)
	{
		try
		{
			Thread.currentThread().sleep(10000);
		}
		catch (Exception e)
		{

		}
		return new Plot(parent);
	}

	/**
	 * from http://forum.java.sun.com/thread.jspa?threadID=341935&start=15 to find the name of all the classes we want :)
	 * 
	 * @param pckgname
	 *            name of package to find
	 * @return the list of classes in the package
	 * @throws ClassNotFoundException
	 */
	public static List<Class<Waterfall>> getClassesForPackage(String pckgname) throws ClassNotFoundException
	{
		// This will hold a list of directories matching the pckgname. There may be more than one if a package is split over multiple jars/paths
		ArrayList<File> directories = new ArrayList<File>();
		try
		{
			ClassLoader cld = Thread.currentThread().getContextClassLoader();
			if (cld == null)
			{
				throw new ClassNotFoundException("Can't get class loader.");
			}
			String path = pckgname.replace('.', '/');
			// Ask for all resources for the path
			Enumeration<URL> resources = cld.getResources(path);
			while (resources.hasMoreElements())
			{
				directories.add(new File(URLDecoder.decode(resources.nextElement().getPath(), "UTF-8")));
			}
		}
		catch (NullPointerException x)
		{
			throw new ClassNotFoundException(pckgname + " does not appear to be a valid package (Null pointer exception)");
		}
		catch (UnsupportedEncodingException encex)
		{
			throw new ClassNotFoundException(pckgname + " does not appear to be a valid package (Unsupported encoding)");
		}
		catch (IOException ioex)
		{
			throw new ClassNotFoundException("IOException was thrown when trying to get all resources for " + pckgname);
		}

		ArrayList<Class<Waterfall>> classes = new ArrayList<Class<Waterfall>>();
		// For every directory identified capture all the .class files
		for (File directory : directories)
		{
			if (directory.exists())
			{
				// Get the list of the files contained in the package
				String[] files = directory.list();
				for (String file : files)
				{
					// we are only interested in .class files
					if (file.endsWith(".class"))
					{
						// removes the .class extension
						classes.add((Class<Waterfall>) Class.forName(pckgname + '.' + file.substring(0, file.length() - 6)));
					}
				}
			}
			else
			{
				throw new ClassNotFoundException(pckgname + " (" + directory.getPath() + ") does not appear to be a valid package");
			}
		}
		return classes;
	}
}
