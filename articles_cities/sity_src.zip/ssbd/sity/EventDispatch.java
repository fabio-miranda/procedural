package sity;

import java.util.*;

import java.awt.event.*;

import javax.swing.event.*;

/**
 * Synchronised inter-thread event adaptor. Allows swing/awt events to be queued up and then retrieved one at a time from inside the correct thred. Kinda a mess, could be seperated out, but not really required....
 * 
 * @author people
 * 
 */
public class EventDispatch implements MouseMotionListener, MouseListener, ChangeListener, ActionListener, MouseWheelListener, ListSelectionListener, KeyListener

{
	private List<MouseEvent> mouseEvents = new LinkedList<MouseEvent>();

	private List<ChangeEvent> changeEvents = new LinkedList<ChangeEvent>();

	private List<ActionEvent> actionEvents = new LinkedList<ActionEvent>();
	
	private List<MouseWheelEvent> mouseWheelEvents = new LinkedList<MouseWheelEvent>();
	
	private List<ListSelectionEvent> listEvents = new LinkedList<ListSelectionEvent>();

	private List<KeyEvent> keyEvents = new LinkedList<KeyEvent>();
	
	private boolean mouseDown;
	
	private synchronized void addMouseEvent(MouseEvent e)
	{
		mouseEvents.add(e);
	}

	public synchronized MouseEvent getMouseEvent()
	{
		if (!mouseEvents.isEmpty())
			return mouseEvents.remove(0);
		return null;
	}

	private synchronized void addChangeEvent(ChangeEvent e)
	{
		changeEvents.add(e);
	}

	public synchronized ChangeEvent getChangeEvent()
	{
		if (!changeEvents.isEmpty())
			return changeEvents.remove(0);
		return null;
	}

	private synchronized void addActionEvent(ActionEvent e)
	{
		actionEvents.add(e);
	}

	public synchronized ActionEvent getActionEvent()
	{
		if (!actionEvents.isEmpty())
			return actionEvents.remove(0);
		return null;
	}
	

	private synchronized void addMouseWheelEvent(MouseWheelEvent e)
	{
		mouseWheelEvents.add(e);
	}

	public synchronized MouseWheelEvent getMouseWheelEvent()
	{
		if (!mouseWheelEvents.isEmpty())
			return mouseWheelEvents.remove(0);
		return null;
	}
	

	private synchronized void addListEvent(ListSelectionEvent e)
	{
		listEvents.add(e);
	}

	public synchronized ListSelectionEvent getListEvent()
	{
		if (!listEvents.isEmpty())
			return listEvents.remove(0);
		return null;
	}

	public synchronized void addKeyEvent(KeyEvent e)
	{
		keyEvents.add(e);
	}
	
	public synchronized KeyEvent getKeyEvent()
	{
		if (!keyEvents.isEmpty())
			return keyEvents.remove(0);
		return null;
	}
	
	public void mouseMoved(MouseEvent e)
	{
		addMouseEvent(e);
	}

	public void mouseClicked(MouseEvent e)
	{
		addMouseEvent(e);
	}

	public void mouseEntered(MouseEvent e)
	{
		addMouseEvent(e);
	}

	public void mouseExited(MouseEvent e)
	{
		addMouseEvent(e);
	}

	public void mouseDragged(MouseEvent arg0)
	{
		addMouseEvent(arg0);
	}

	public void mousePressed(MouseEvent arg0)
	{
		mouseDown = true;
		addMouseEvent(arg0);
	}

	public void mouseReleased(MouseEvent arg0)
	{
		mouseDown = false;
		addMouseEvent(arg0);
	}

	public void stateChanged(ChangeEvent arg0)
	{
		addChangeEvent(arg0);
	}

	public void actionPerformed(ActionEvent arg0)
	{
		addActionEvent(arg0);
	}

	public void mouseWheelMoved(MouseWheelEvent arg0)
	{
		addMouseWheelEvent(arg0);
	}

	public void valueChanged(ListSelectionEvent arg0)
	{
		addListEvent(arg0);
	}

	public boolean isMouseDown()
	{
		return mouseDown;
	}

	public void keyPressed(KeyEvent arg0)
	{
		addKeyEvent(arg0);
	}

	public void keyReleased(KeyEvent arg0)
	{
		addKeyEvent(arg0);
	}

	public void keyTyped(KeyEvent arg0)
	{
		addKeyEvent(arg0);
	}
}
