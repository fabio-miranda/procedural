package sity;

import static sity.Parameters.fatalErrorSD;
import geom.*;

import java.util.*;
import java.util.List;

import java.awt.*;
import java.awt.event.*;

import javax.vecmath.*;

import skyHook.*;
import ssbd.*;

import com.jme.bounding.BoundingBox;
import com.jme.input.*;
import com.jme.intersection.*;
import com.jme.light.PointLight;
import com.jme.math.*;
import com.jme.math.Vector2f;
import com.jme.math.Vector3f;
import com.jme.renderer.*;
import com.jme.renderer.lwjgl.LWJGLRenderer;
import com.jme.scene.*;
import com.jme.scene.batch.GeomBatch;
import com.jme.scene.state.*;
import com.jme.system.DisplaySystem;
import com.jme.util.geom.BufferUtils;
import com.jmex.awt.*;
import com.jmex.awt.input.*;

/**
 * This is SimpleCanvasImpl with a bit of BaseSimple game for features. Handles all the JME interface and awt events. Hence is total mess.
 * 
 * <code>SimpleCanvasImpl</code>
 * 
 * @author Joshua Slack
 * @version $Id: MagicWindowMonkey.java,v 1.15 2006/08/06 19:04:38 tk1748 Exp $
 */

public class MagicWindowMonkey extends JMECanvasImplementor implements Anchor
{

	// Items for scene
	protected Node rootNode;

	protected com.jme.util.Timer timer;

	protected float tpf;

	protected Camera cam;

	Vector3f loc = new Vector3f(10.0f, 1.5f, 0.0f); // camera location at start

	protected DisplaySystem display;

	protected int width, height;

	protected InputHandler input;

	private Root root = null;
	
	private Waterfall source = null;

	private MagicWindow magicWindow = null;

	protected EventDispatch eventDispatch = new EventDispatch();

	// list of awt components to be updated
	private List<Updateable> toUpdate = new LinkedList<Updateable>();

	// a flag from teh AWT to JME threads to say erase and rewind
	private boolean doRefresh = false;
	
	private Canvas canvas;

	// if true monkey display has more speed, but is not selectable
	private final static boolean noSelect = true;
	
	/**
	 * This class should be subclasses - not directly instantiated.
	 * 
	 * @param width
	 *            canvas width
	 * @param height
	 *            canvas height
	 */
	protected MagicWindowMonkey(int width, int height, Waterfall s, Root root, MagicWindow b, Canvas c)
	{
		this.width = width;
		this.height = height;
		this.root = root;
		canvas = c;
		source = s;
		magicWindow = b;
		// eventDispatch = new EventDispatch();
		magicWindow.getCanvas().addMouseListener(eventDispatch);
		magicWindow.getCanvas().addMouseMotionListener(eventDispatch);
		magicWindow.getCanvas().addMouseWheelListener(eventDispatch);
		//magicWindow.getCanvas().addKeyListener(eventDispatch);
	}

	public void doSetup()
	{
		display = DisplaySystem.getDisplaySystem();//= Parameters.getDisplay();
		//renderer = Parameters.getRenderer();
		
		renderer = new LWJGLRenderer(800, 600);
		renderer.setHeadless(true);
		display.setRenderer(renderer);
		DisplaySystem.updateStates(renderer);
		// Create a camera specific to the DisplaySystem that works with the width and height

		cam = renderer.createCamera(width, height);

		// Set up how our camera sees.
		cam.setFrustumPerspective(45.0f, (float) width / (float) height, 1, 1000);

		Vector3f left = new Vector3f(1.0f, 0.0f, 0.0f);
		Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f);
		Vector3f dir = new Vector3f(0.0f, 0f, 1.0f);

		// Move our camera to a correct place and orientation.
		cam.setFrame(loc, left, up, dir);
		
		// Signal that we've changed our camera's location/frustum.
		// cameraPerspective();
		//cameraParallel();
		
		cam.update();


		// Assign the camera to this renderer.
		renderer.setCamera(cam);

		renderer.setBackgroundColor(new ColorRGBA(0.1f, 0.2f, 0.6f, 1.0f));

		// Get a high resolution timer for FPS updates.
		timer = com.jme.util.Timer.getTimer();

		// Create rootNode
		rootNode = new Node("rootNode");

		// Create a ZBuffer to display pixels closest to the camera above farther ones.

		ZBufferState buf = renderer.createZBufferState();
		buf.setEnabled(true);
		buf.setFunction(ZBufferState.CF_LEQUAL);
		// cameraPerspective();
		rootNode.setRenderState(buf);
		
		input = new KeyboardLookHandler(cam, 50f, 3f);
		//input.
		((JMECanvas) canvas).setUpdateInput(true);

		KeyListener kl = (KeyListener) KeyInput.get();

		canvas.addKeyListener(kl);
		magicWindow.addKeyListener(kl);

		((AWTMouseInput) MouseInput.get()).setEnabled(true);
		((AWTMouseInput) MouseInput.get()).setDragOnly(false);
		((AWTMouseInput) MouseInput.get()).setRelativeDelta(canvas);

		canvas.addMouseListener(eventDispatch);
		
		setFocusListener();
		input.setEnabled(true);

		lightState = renderer.createLightState();
		assert(lightState != null);

		simpleSetup();
		
		setup = true;
	}

	private void setFocusListener()
	{
		canvas.addFocusListener(new FocusListener()
		{
			public void focusGained(FocusEvent arg0)
			{
				((AWTKeyInput) KeyInput.get()).setEnabled(true);
				((AWTMouseInput) MouseInput.get()).setEnabled(true);
				input.setEnabled(true);
				//mouseLook = true;
			}

			public void focusLost(FocusEvent arg0)
			{
				((AWTKeyInput) KeyInput.get()).setEnabled(false);
				((AWTMouseInput) MouseInput.get()).setEnabled(false);
				input.update(0);
				input.setEnabled(false);
				//mouseLook = false;
			}
		});
	}

	// from baseSimpleGame
	protected void cameraPerspective()
	{
		cam.setFrustumPerspective(45.0f, (float) display.getWidth() / (float) display.getHeight(), 1, 1000);
		cam.setParallelProjection(false);
		cam.update();
	}

	protected void cameraParallel()
	{
		cam.setParallelProjection(true);
		float aspect = (float) display.getWidth() / display.getHeight();
		cam.setFrustum(-100, 1000, -50 * aspect, 50 * aspect, -50, 50);
		cam.update();
	}

	public void doUpdate()
	{

		/** Update tpf to time per frame according to the Timer. */

		timer.update();
		tpf = timer.getTimePerFrame();
		cam.update();

		simpleUpdate();
		doMouseUpdate();
		rootNode.updateGeometricState(tpf, true);
		// go through all registered updaters...

		Iterator<Updateable> it = toUpdate.iterator();
		ArrayList<Updateable> toRemove = new ArrayList<Updateable>();
		while (it.hasNext())
		{
			Updateable u = it.next();
			if (u.isDisposed())
			{
				toRemove.add(u);
			}
			// always do update - in case action on dispose()
			u.doUpdate();

		}
		for (Updateable r : toRemove)
		{
			toUpdate.remove(r);
		}
		// has anyone requested a change in whats displayed?
		if (doRefresh)
		{
			doRefresh = false;
			emptySity();
			createSity();
		}
	}
	
	/** called to change whats being displayed. 
	 *  this may be a root waterfall, but may end up being something else.
	 *  Called from swing thread...so massage it in!
	 * @param in
	 */
	public void setWaterfall(Waterfall in)
	{
		doRefresh = true;
		source = in;
	}

	public void doRender()
	{
		renderer.clearBuffers();
		renderer.draw(rootNode);
		simpleRender();
		renderer.displayBackBuffer();
	}

	private void createSity()
	{
		createSity(this, false);
	}
	
	/**
	 * Evaluate our tree
	 * @param resetRandom - reset the random of the found instance? will create
	 * new building!
	 *
	 */
	private void createSity(Anchor anchor, boolean resetRandom)
	{
		Anchor oldAnchor = Parameters.anchor;
		Parameters.anchor = anchor;
		newFile();
		if (source instanceof Root)
		{
			if (resetRandom)
			{
				int seed = Parameters.uberRandom.nextInt();
				Parameters.message(" have reset root random to "+seed);
				((Root)source).VAR_random_seed.value = seed;
			}
			FREEZER_Root.bigFreeze(Root.class.cast(source));
		}
		else
		{
			// search for the 
			Parameters.message("searching for waterfall instance...");
			// may need to repeat this line, switching randoms till found?
			FallState fs = FREEZER_Root.findFallState(source, root);
			if (fs == null)
			{
				Parameters.error("no instance of that waterfall found");
			}
			else
			{
				Parameters.message("Have reset objects random");
				if (resetRandom) fs.setRandom(new Random(Parameters.uberRandom.nextLong()));
				FREEZER_Root.freezeFromState(fs);
			}
		}
		
		// show it
		rootNode.updateGeometricState(0.0f, true);
		rootNode.updateRenderState();
		
		// put the anchor back the way it was
		Parameters.anchor = oldAnchor;
	}
	
	public void simpleSetup()
	{
		createSity();
		allDone();

		/*Sphere s = new Sphere("My sphere", 10, 10, 1f);
		// Do bounds for the sphere, but we'll use a BoundingBox this time
		s.setModelBound(new BoundingBox());
		s.updateModelBound(); // Give the sphere random colors 
		s.setRandomColors();
		rootNode.attachChild(s);*/
	}

	public void simpleUpdate()
	{
		timer.update();
		tpf = timer.getTimePerFrame();
		// very important line....
	    input.update( tpf );
	}

	public void simpleRender()
	{
	}

	public Camera getCamera()
	{
		return cam;
	}

	private void doMouseUpdate()
	{

		MouseEvent event;
		while ((event = eventDispatch.getMouseEvent()) != null)
		{
			switch (event.getID())
			{
			case MouseEvent.MOUSE_DRAGGED:
				mouseDraggedUpdate(event);
				break;
			case MouseEvent.MOUSE_PRESSED:
				mousePressedUpdate(event);
				break;
			case MouseEvent.MOUSE_RELEASED:
				mouseReleasedUpdate(event);
				break;
			case MouseEvent.MOUSE_WHEEL:
				break;
			case MouseEvent.MOUSE_MOVED:
				mouseMovedUpdate(event);
				break;
			case MouseEvent.MOUSE_ENTERED:
				mouseEnteredUpdate(event);
			case MouseEvent.MOUSE_EXITED:
				mouseExitUpdate(event);
				break;
			}
		}
		MouseWheelEvent wheel;
		while ((wheel = eventDispatch.getMouseWheelEvent()) != null)
		{
			mouseWheelUpdate(wheel);
		}
		KeyEvent key;
		while ((key = eventDispatch.getKeyEvent()) != null)
		{
			switch (key.getID())
			{
			case KeyEvent.KEY_RELEASED:
				keyRelease(key);
				break;
			}
		}

	}
	
	private void mouseMovedUpdate(MouseEvent e)
	{
		//magicWindow.fixMouse();
	}
	
	/**
	 * removes all data from jME buffer
	 *
	 */
	private void emptySity()
	{
		
		//rootNode = new Node("rootNode");

		// Create a ZBuffer to display pixels closest to the camera above farther ones.

		/*ZBufferState buf = renderer.createZBufferState();
		buf.setEnabled(true);
		buf.setFunction(ZBufferState.CF_LEQUAL);
		// cameraPerspective();
		rootNode.setRenderState(buf);
		
		simpleSetup();*/

		if (rootNode.getChildren() == null) return;
		ListIterator<Spatial> lit = rootNode.getChildren().listIterator();
		while (lit.hasNext())
		{
			Spatial s = lit.next();
			if (s instanceof Geometry) lit.remove();
		}
		// could just do this:!
		//rootNode.detachAllChildren();	
	}

	/**
	 * Key release handler delegated through eventDispatch
	 * 
	 * @param e
	 */
	private void keyRelease(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_SPACE)
		{
			emptySity();
			// create sity and tell to reset random seed!
			createSity(this, true);
		}
		else if (e.getKeyCode() == KeyEvent.VK_ENTER)
		{
			// dump to maya!
			MayaSkyHook sh = new MayaSkyHook();
			Anchor a = new MayaAnchor(sh);
			createSity(a,false);
		}
		else if (e.getKeyCode() == KeyEvent.VK_O)
		{
			// dump to ovj
			Anchor a = new ObjAnchor();
			a.newFile();
			createSity(a,false);
		}
	}

	
	
	/**
	 * Takes a mouse event and finds the object to select (or none!)
	 * 
	 * @param e
	 *            the mouse event with the locations
	 */
	private void processClick(MouseEvent e)
	{
		// jME voodoo to make it work (read: trial and error)
		display.setRenderer(renderer);
		DisplaySystem.updateStates(renderer);
		// Assign the camera to this renderer.
		renderer.setCamera(cam);
		
		PickResults pr; // should do in init?
		pr = new TrianglePickResults();
		pr.setCheckDistance(true);
		Vector2f screenPos = new Vector2f();
		// Get the position that the mouse is pointing to
		screenPos.set(e.getPoint().x, e.getPoint().y);
		// flip the x coordinate!

		screenPos.y = display.getHeight() - screenPos.y;
		// Get the world location of that X,Y value
		Vector3f worldCoords = display.getWorldCoordinates(screenPos, 0);
		// Create a ray starting from the camera, and
		// going in the direction of the mouse's location
		Ray mouseRay = new Ray(cam.getLocation(), worldCoords.subtractLocal(cam.getLocation()));
		// Does the mouse's ray intersect the box's world bounds?
		pr.clear();
		rootNode.findPick(mouseRay, pr);
		if (pr.getNumber() != 0)
		{
			// for (int i = 0; i < pr.getNumber(); i++)
			// {
			// pr.getPickData(i).getTargetMesh().setRandomColors();
			// }
		//	for (int i = 0; i < pr.getNumber(); i++)
			Waterfall selected = geomToWaterfall.get((pr.getPickData(0).getTargetMesh()));
			if (selected  != null)
			{
				Sity.self.setCurrentFall(selected);
			}
			
			//selected = pr.getPickData(0).getTargetMesh();
		}
		else
		// person has clicked on the background!
		{
			// = null;
		}
	}

	public void mouseDraggedUpdate(MouseEvent e)
	{

	}

	public void mousePressedUpdate(MouseEvent e)
	{

	}

	/**
	 * Contains most of the logic for creating and destroying links between waterfalls
	 * 
	 * @param e
	 *            the triggering mouse release
	 */
	public void mouseReleasedUpdate(MouseEvent e)
	{
		processClick(e);
	}

	private void mouseEnteredUpdate(MouseEvent e)
	{

	}

	/**
	 * dragging the waterfall to the edge of the screen deletes it!
	 * 
	 * @param e
	 */
	private void mouseExitUpdate(MouseEvent e)
	{

	}

	/**
	 * This is what to call to remove all links from the waterfall and remove it from scenegraph
	 * 
	 * @param togo
	 */
	public void deleteWaterfall(Waterfall togo)
	{

	}

	private void mouseWheelUpdate(MouseWheelEvent e)
	{

	}

	/***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************
	 * Anchor related stuff *
	 **************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/

	private int xSize = 500, ySize = 500;

	private ArrayList<Vector3f> vertices, normals;

	private ArrayList<ColorRGBA> colours;

	private ArrayList<Vector2f> texCoords;

	private ArrayList<Integer> indexes;

	// default or current colors
	private float red = 0.5f, green = 0.5f, blue = 0.9f;

	private LightState lightState;

	Map <GeomBatch, Waterfall> geomToWaterfall;// = new HashMap<GeomBatch, Waterfall>(); now set in newFile
	
	
	public void setColor(Color in)
	{
		red = in.getRed();
		green = in.getGreen();
		blue = in.getBlue();
	}

	public void newFile()
	{
		geomToWaterfall = new HashMap<GeomBatch, Waterfall>();
		newObject();
		// lightState = display.getRenderer().createLightState();
		// lightState.setEnabled( true );
		// rootNode.setRenderState( lightState );
	}
	
	private void newObject()
	{
		vertices = new ArrayList<Vector3f>();
		normals = new ArrayList<Vector3f>();
		colours = new ArrayList<ColorRGBA>();
		texCoords = new ArrayList<Vector2f>();
		indexes = new ArrayList<Integer>();
	}
	
	private static int count = 0;
	
	private void addObject()
	{
		int[] indexArray = new int[indexes.size()];
		int count = 0;
		Iterator<Integer> it = indexes.iterator();
		while (it.hasNext())
		{
			indexArray[count] = it.next();
			count++;
		}

		TriMesh m = new TriMesh("House"+(count++));
		// Feed the information to the TriMesh
		m.reconstruct(
				BufferUtils.createFloatBuffer((Vector3f[]) vertices.toArray(new Vector3f[0])), 
				BufferUtils.createFloatBuffer((Vector3f[]) normals.toArray(new Vector3f[0])), 
				BufferUtils.createFloatBuffer((ColorRGBA[]) colours.toArray(new ColorRGBA[0])), 
				BufferUtils.createFloatBuffer((Vector2f[]) texCoords.toArray(new Vector2f[0])), 
				BufferUtils.createIntBuffer(indexArray));
		
		// Create a bounds
		m.setModelBound(new BoundingBox());
		m.updateModelBound();
		geomToWaterfall.put(m.getBatch(0), FREEZER.getRunTimeFreezer());

		// Attach the mesh to my scene graph
		rootNode.attachChild(m);
	}

	public void createPolygon(Sheaf in)
	{
		if (in != null) createPolygon(in.getFace());
	}
	
	public void createPolygon(Face face)
	{
		if (face.size() != 3)
		{
			fatalErrorSD("Monkey say only three vertices at a time");
		}
		for (Vertex v: face.getVertices())
		{
			if (Double.isNaN(v.getX()) ||
					Double.isNaN(v.getY()) ||
					Double.isNaN(v.getZ())
					)
			{
				Parameters.error("Monkey can't output NaN coord");
				// should be this!: fatalErrorSD("Monkey can't output NaN coord!\n"+face);
			}
		}

		Iterator<Vertex> it = face.getIter();
		Vertex one = it.next();
		Vertex two = it.next();
		Vertex three = it.next();
		// Vertex four = new Vertex(twp);

		Vector3d a = one.sub(two);
		Vector3d b = two.sub(three);
		a.cross(a, b);
		a.normalize();
		it = face.getIter();

		while (it.hasNext())
		{
			Vertex v = it.next();
			vertices.add(new Vector3f((float) v.getX(), (float) v.getY(), (float) v.getZ()));
			colours.add(new ColorRGBA(red, green, blue, 1.0f));
			normals.add(new Vector3f((float) a.x, (float) a.y, (float) a.z));
			texCoords.add(new Vector2f(0f, 0f));
			indexes.add(vertices.size() - 1);
		}
	}
	
	public void createPolygon(List<Face> faeces)
	{
		// clear buffers - if we want selecteable faces
		if (!noSelect) newObject();
		Iterator<Face> it = faeces.iterator();
		while (it.hasNext())
			createPolygon(it.next());
		// add to graph!
		if (!noSelect) addObject(); 
		//System.err.println("create polygons ordered");
	}

	public void texture()
	{
		// nothing to do here for now
	}

	/**
	 * One time setup first time window is created!
	 */
	public void allDone()
	{
		if (noSelect) addObject(); // if we dont want selectable faces (but want speed)
		if (noSelect) newObject();
		
		MaterialState ms = renderer.createMaterialState();
		ms.setAmbient(new ColorRGBA(0.3f, 0.3f, 0.2f, 0.0f));

		ms.setDiffuse(ColorRGBA.white);
		ms.setShininess(1f);
		ms.setEnabled(true);
		rootNode.setRenderState(ms);

		// add the lighting
	    doLighting();
		
		// Let us see the per vertex colors
		//System.err.println("Firing up JME");
		// setDialogBehaviour(SimpleGame.FIRSTRUN_OR_NOCONFIGFILE_SHOW_PROPS_DIALOG);// ALWAYS_SHOW_PROPS_DIALOG);//
	}

	/**
	 * default light set
	 *
	 */
	private void doLighting()
	{
		// Detach all the default lights made by SimpleGame
		//lightState.detachAll();

		PointLight l = new PointLight();
		// Give it a location
		l.setLocation(new Vector3f(10, 10, 5));
		// Make it a red light
		l.setDiffuse(ColorRGBA.white);
		// Enable it
		l.setEnabled(true);

		PointLight l2 = new PointLight();
		// Give it a location
		l2.setLocation(new Vector3f(-10, -10, 5));
		// Make it a red light
		l2.setDiffuse(ColorRGBA.pink);
		// Enable it
		l2.setEnabled(true);

		// Create a LightState to put my light in
		LightState ls = renderer.createLightState();
		// Attach the light
		ls.attach(l);
		ls.attach(l2);
		rootNode.setRenderState(ls);

		/**
		 * SPHERE - delete me when it all works
		 
		Sphere s = new Sphere("My sphere", 10, 10, 1f);
		// Do bounds for the sphere, but we'll use a BoundingBox this time
		s.setModelBound(new BoundingBox());
		s.updateModelBound();
		// Give the sphere random colors
		s.setRandomColors();
		rootNode.attachChild(s);*/

	}

	public void nextFrame()
	{
		Parameters.errorSD("nextFrame not implmented in monkeyanchor");
	}
	
	protected void onQuit()
	{
		newObject();
		geomToWaterfall = null;
		toUpdate = null;
		ListIterator<Spatial> lit = rootNode.getChildren().listIterator(); 
		while (lit.hasNext()) lit.next(); lit.remove();
		display.close();

		renderer.setCamera(null);		
		rootNode.removeFromParent();
			
			// the might be to blame for inter-display reactions? (also in MagicWindowMonkey)
		display.getDisplaySystem().close();
		display.getRenderer().clearVBOCache();
		display.close();

		renderer.clearQueue();
		renderer.clearVBOCache();

		eventDispatch = null;
		toUpdate = null;
	}
}
