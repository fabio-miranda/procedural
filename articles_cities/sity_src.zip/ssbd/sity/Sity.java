package sity;

import static sity.Parameters.*;
import geom.FlatPoint;

import java.util.*;
import java.util.List;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

import javax.swing.*;
import javax.vecmath.*;

import skyHook.ObjAnchor;
import ssbd.*;
import util.*;

import com.jme.input.*;
import com.jme.util.LoggingSystem;

/**
 * Executive 'run' class - sets up the gui and the rest of it.
 * 
 * Class must be compiled to link in JME stuff and use the line "-Djava.library.path=../jme/lib/"
 * 
 * @author people
 * 
 */
public class Sity extends JFrame implements KeyListener, ActionListener
{
	private ArrayList<Poppable> pops;

	public Waterfall currentFall = null;

	private Root rootFall = null;

	public static Sity self;

	private JButton previewB;

	private JButton balloonB;

	private JPanel panel;

	private JScrollPane scroll;
	
	private JButton toObj;

	private GridBagConstraints c = new GridBagConstraints();

	private JButton save,load;
	
	public Sity()
	{
		// turn of jme logging - we might want this sometime tho!
		LoggingSystem.getLoggingSystem().loggerOn(false);
		
		try // jME voodoo to set AWT as the default input command
		{
			MouseInput.setProvider(InputSystem.INPUT_SYSTEM_AWT);
			KeyInput.setProvider(InputSystem.INPUT_SYSTEM_AWT);
		}
		catch (Exception e)
		{
			System.err.println("couldnt find AWT handler"+e);
			System.exit(3);
		}
		
		setLook(UIManager.getSystemLookAndFeelClassName());
		previewB = new JButton("xxx");
		balloonB = new JButton("xxx");
		panel = new JPanel();
		scroll = new JScrollPane(panel);

		setTitle("Sity");
		//setSize(300, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// setLayout(new GridBagLayout());
		setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));

		JPanel buttons = new JPanel();
		buttons.setLayout(new GridLayout(0,1));
		buttons.setMaximumSize(new Dimension(2000,50));
		buttons.add(balloonB);
		buttons.add(previewB);
		toObj = new JButton("Dump to .obj file");
		toObj.addActionListener(this);
		buttons.add(toObj);
		JPanel saveLoad = new JPanel();
		saveLoad.setLayout(new GridLayout(1,0));
		save = new JButton("save...");
		load = new JButton("load...");
		saveLoad.add(save);
		saveLoad.add(load);
		save.addActionListener(this);
		load.addActionListener(this);
		buttons.add(saveLoad);
		// previewB.setEnabled(false);

		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 1;
		c.weighty = 1;
		c.gridwidth = 1;

		// panel.setPreferredSize(new Dimension(200,200));
		// add(splashScreen(),c);
		// panel.setLayout(new GridLayout(1,1));

		setPanel(getSplashScreen());
		panel.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		// scroll.setLayout(new ScrollPaneLayout());
		add(buttons);
		add(scroll);
		c.gridwidth = 1;

		previewB.addActionListener(this);
		balloonB.addActionListener(this);
		addKeyListener(this);
		balloonB.addKeyListener(this); // hmm ugly but it'll do
		previewB.addKeyListener(this);
		save.addKeyListener(this);
		load.addKeyListener(this);
		toObj.addKeyListener(this);

		self = this;

		currentFall = rootFall = demodata();

		Parameters.setIcon(this);

		update();
		pack();
		setVisible(true);
	}

	/**
	 * creates the spash screen
	 * 
	 * @return
	 */
	public static Component getSplashScreen()
	{
		return new Viewer("/media/logoBig.jpg");
	}

	public static void main(String[] args)
	{
		new Sity();
	}

	public void keyPressed(KeyEvent e)
	{
	}

	public void keyReleased(KeyEvent e)
	{
		char c = Character.toLowerCase(e.getKeyChar());
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
			System.exit(0);
		switch (c)
		{
		case 'x':
		case 'q':
			System.exit(0);
			break;
		}
	}

	public void keyTyped(KeyEvent e)
	{
	}

	/**
	 * From http://java.sun.com/docs/books/tutorial/uiswing/learn/example-1dot4/SwingApplication.java
	 * 
	 * @param lookAndFeel
	 *            the name of the look and feel to use
	 */
	private void setLook(String lookAndFeel)
	{
		try
		{
			UIManager.setLookAndFeel(lookAndFeel);
		}
		catch (ClassNotFoundException e)
		{
			System.err.println("Couldn't find class for specified look and feel:" + lookAndFeel);
			System.err.println("Did you include the L&F library in the class path?");
			System.err.println("Using the default look and feel.");
		}
		catch (UnsupportedLookAndFeelException e)
		{
			System.err.println("Can't use the specified look and feel (" + lookAndFeel + ") on this platform.");
			System.err.println("Using the default look and feel.");
		}
		catch (Exception e)
		{
			System.err.println("Couldn't get specified look and feel (" + lookAndFeel + "), for some reason.");
			System.err.println("Using the default look and feel.");
			e.printStackTrace();
		}
	}

	/**
	 * Called on a state (of anything) c //private JButton previewB = new JButton("xxx"); //private JButton balloonB = new JButton("xxx");hange!
	 * 
	 */
	public void update()
	{
		if (magicWindow == null)
		{
			previewB.setText("Show preview");
		}
		else
		{
			previewB.setText("Hide preview");
		}

		if (balloon == null)
		{
			balloonB.setText("Show waterfalls");
		}
		else
		{
			balloonB.setText("Hide waterfall");
		}
	}

	// where the file dialog starts off at
	String fileStart = ".";
	
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == previewB)
		{
			if (magicWindow == null)
			{
				magicWindow = new MagicWindow(rootFall, rootFall); // shall be currentFall in future?
			}
			else
			{
				magicWindow.pop();
			}
		}
		else if (e.getSource() == balloonB)
		{
			if (balloon == null)
			{
				balloon = new Balloon(rootFall);
			}
			else
			{
				balloon.pop();
			}
		}
		// dump to obj button
		else if (e.getSource() == toObj)
		{
			anchor = new ObjAnchor();
			anchor.newFile();
			FREEZER_Root.bigFreeze(Root.class.cast(rootFall));
		}
		// serialization code to load and save:
		else if (e.getSource() == save)
		{
			FileDialog fileDialog = new FileDialog(this,"Select file to save into", FileDialog.SAVE);
			fileDialog.setVisible(true);
			if (fileDialog.getDirectory() == null) return;
			String location = fileDialog.getDirectory()+fileDialog.getFile();
			try
			{
				ObjectOutput out  = new ObjectOutputStream(new FileOutputStream(location));
				out.writeObject(rootFall);
				out.close();
			}
			catch (IOException f)
			{
				Parameters.message("error writing to "+location);
				f.printStackTrace();
				return;
			}
			Parameters.message("sucess writing to "+location);
		}
		else if (e.getSource() == load)
		{
			FileDialog fileDialog = new FileDialog(this,"Select file to save into", FileDialog.LOAD);
			fileDialog.setVisible(true);
			String location = fileDialog.getDirectory()+fileDialog.getFile();
			if (fileDialog.getDirectory() == null) return;
			// tidy up so its all re-loaded next time!
			if (balloon != null) balloon.pop();
			if (magicWindow != null) magicWindow.pop();
			setPanel(getSplashScreen());
			try
			{
		        // Serialize to a byte array
             
                File file = new File(location);
                ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
                // Deserialize the object
                rootFall = (Root) in.readObject();
                in.close();
            
                doneWaterfalls = new HashSet<Waterfall>(); 
		        restoreWaterfalls(rootFall);
			}
            catch (ClassNotFoundException g)
            {
                Parameters.message("CNF error reading from "+location);
                g.printStackTrace();
                return;
            }
			catch (IOException f)
			{
                Parameters.message("IO error reading from "+location);
				f.printStackTrace();
				return;
			}
			Parameters.message("sucess reading from "+location);
		}
		update();
	}

    private Set<Waterfall> doneWaterfalls;
    
    /**
     * Recurse through serialized objects to reset unknown fields
     * @param in
     */
    private void restoreWaterfalls(Waterfall in)
    {
       in.fromDisk();
       for (SluiceManual s : in.downStream)
       {
         for (Flow f: s.getLeadsTo())
         {
           Waterfall w = f.getTo();
           if (doneWaterfalls.contains(w))
           {
             // nothing
           }
           else
           {
             doneWaterfalls.add(w);
             restoreWaterfalls(w);
           }
         }
       }
    }
    
	public static Root demodata()
	{
		//setupParameters();
		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(0, 0, 0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));
		fp.add(new FlatPoint(1, 1));
		fp.add(new FlatPoint(0, 1));
		// sheet is now a unit sqare in the 1st quadrant clockwise manner!
		// Sheaf s2 = new Sheaf(fp, mat);

		Root root = new Root(null);
		
		CityPlanner cp = new CityPlanner(root);
		root.cityPlanner.addWaterfall(cp);

		Hood hood = new Hood(cp);
		cp.hood.addWaterfall(hood);

		DotGrid planDot = new DotGrid(cp);
		cp.points.addWaterfall(planDot);
		// default values...messy but it works
		planDot.VAR_height = new ProbInt(1,100,0,1);
		planDot.VAR_width  = new ProbInt(2,100,0,3);
		planDot.VAR_dotStyle.choices.select(1);
		
		Block block = new Block(hood);
		hood.block.addWaterfall(block);
		
		// two sets of street layout hoodickies
		/*Dot hoodDot1 = new Dot(hood);
		hood.points.addWaterfall(hoodDot1);
		hoodDot1.VAR_dotStyle.choices.select(1);
		hoodDot1.VAR_height = new ProbDouble(0,100, 1,20);
		hoodDot1.VAR_width = new ProbDouble(0,100, 1,5);*/
		
		Dot hoodDot2 = new Dot(hood);
		hood.points.addWaterfall(hoodDot2);
		hoodDot2.VAR_dotStyle.choices.select(2);
		hoodDot2.VAR_height = new ProbDouble(0,100, 1,20);
		hoodDot2.VAR_width = new ProbDouble(0,100, 1,50);
		
		Street street = new Street(block);
		block.streets.addWaterfall(street);
		
		Plot plot = new Plot(block);
		block.plot.addWaterfall(plot, 1.00);

		Fence fence = new Fence(plot);
		plot.sideFence.addWaterfall(fence);
		
		Fence fence2 = new Fence(plot);
		plot.frontFence.addWaterfall(fence2);
		fence2.VAR_fenceHeight = new  ProbDouble(0.1,1000, 0.2,0.5);
		
		
		FloorPlan floorPlan = new FloorPlan(plot);
		plot.floorPlan.addWaterfall(floorPlan);
		
		StraightWall sw = new StraightWall(floorPlan);
		floorPlan.back .addWaterfall(sw);
		//floorPlan.front.addWaterfall(sw);
		floorPlan.side .addWaterfall(sw);
		
		SlopeWall slope = new SlopeWall(floorPlan);
		floorPlan.front.addWaterfall(slope);
		
		OverHang oh = new OverHang(floorPlan);
		floorPlan.onTop.addWaterfall(oh);
		
		SlopeInRoof sr = new SlopeInRoof(oh);
		oh.gables.addWaterfall(sr);
		oh.other.addWaterfall(sr);
		
		/*SimpleRoof roof = new SimpleRoof(floorPlan);
		floorPlan.roof.addWaterfall(roof, 1.0);
		roof.nextRoof.addWaterfall(roof, 1.0);

		WallsFromFloor wff = new WallsFromFloor(floorPlan);
		floorPlan.wallMaker.addWaterfall(wff);

		
		Wall wall = new Wall(wff);
		wff.wall.addWaterfall(wall);*/

		// locate all the waterfalls on the screen
		BalloonMonkey.doFallLocate(root);
		
		return root;
	}

	/**
	 * Allows other classes to put their options here!
	 * 
	 * @param p
	 */
	public void setPanel(Component p)
	{
		panel.removeAll();
		panel.add(p, c);
		pack();
	}

	public Waterfall getCurrentFall()
	{
		return currentFall;
	}

	/**
	 * Called to change which waterfall is selected - used from prieview window too!
	 * @param currentFall
	 */
	public void setCurrentFall(Waterfall currentFall)
	{
		setPanel(currentFall.getGUI());
		// highlight if balloon is active
		if (Parameters.balloon != null) balloon.getMonkey().selectFall(currentFall);
		this.currentFall = currentFall;
	}

	public Root getRootFall()
	{
		return rootFall;
	}

}
