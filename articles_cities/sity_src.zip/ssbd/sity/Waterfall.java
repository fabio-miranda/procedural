package sity;

import static sity.Parameters.error;
import static sity.Parameters.fatalErrorSD;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.io.Serializable;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ssbd.Root;
import util.GUIiser;

import com.jme.math.Vector2f;
import com.jme.math.Vector3f;
import com.jme.renderer.ColorRGBA;
import com.jme.scene.Node;
import com.jme.scene.Spatial;
import com.jme.scene.batch.GeomBatch;

public abstract class Waterfall implements Serializable
{                
	// display constants
	protected static final float PLUG_SIZE = 0.4f;

	protected static final float PLUG_SPACING = 0.2f;

	protected static final float FALL_MIN_X = 1.5f;

	protected static final float FALL_Y = 1f;

	// waterfall default spacings in balloon view
	protected static final float X_SPACE = 1f;

	protected static final float Y_SPACE = 2f;

	protected static final ColorRGBA HIGHLIGHT = ColorRGBA.yellow;

	// location, size & colour in waterfall view
	private Vector2f location = new Vector2f(0, 0);

	private Vector2f size = new Vector2f(FALL_MIN_X, FALL_Y);

	private ColorRGBA colour;

	protected transient Spatial text = null;

	public transient Node node;
	 
	private transient GeomBatch batch;
	
	// the output plugs of teh waterfall
	protected List<SluiceManual> downStream = new ArrayList<SluiceManual>();

	private String name;

	private List<Flow> upStream = new ArrayList<Flow>();

	private Class freezer = null; // pointer to class responsible for

	// instaniasing this waterfall
	private Class noise = null;
	
	
	// random only used here for colours?
	private transient static final Random random = Parameters.uberRandom;
	

	/**
	 * 
	 * @param up
	 *            the upstream waterfall
	 * @param l
	 *            the generator for this type of waterful (eventually a distribution?)
	 * @param f
	 *            the face that was input into this waterfall
	 */
	public Waterfall(Waterfall up)
	{
		// upStream = up;
		freezer = findFreezer();
		name = this.getClass().getSimpleName();
		float r = random.nextFloat() / 2;
		float g = random.nextFloat() / 2 + 0.5f;
		float b = random.nextFloat() / 2 + 0.5f;
		if (this instanceof Root)
		{
			r = 1f;
			g = 1f;
			b = 1f;
		}
		colour = new ColorRGBA(r, g, b, 1.0f);
	}

	/**
	 * Adds a sluice to this waterfall. It is important that the sluices are added in the order that they are to be evaluated!
	 * 
	 * @param in
	 *            the sluice to add
	 */
	public void addSluice(SluiceManual in)
	{
		downStream.add(in);
		float width = downStream.size() * (PLUG_SIZE + PLUG_SPACING) + PLUG_SPACING;
		if (width < FALL_MIN_X)
			width = FALL_MIN_X;
		size = new Vector2f(width, FALL_Y);
	}

	/**
	 * 
	 */
	public Class getFreezer()
	{
		return freezer;
	}

	/**
	 * Returns the next downstream waterfall as specified.
	 * 
	 * @param a
	 *            the deterministic plug/sluice that is requested
	 * @param b
	 *            the stochastic choice to return
	 * @return
	 */
	protected Waterfall getDownStream(int a, int b)
	{
		return downStream.get(a).getLeadsTo().get(b).getTo();
	}

	/**
	 * Finds the class that freezes the particular waterfall
	 * 
	 * @return the freezer with the name of this class starting with "FREEZER_"
	 */
	private Class findFreezer()
	{
		String n = this.getClass().getName();
		n = n.substring(0, n.lastIndexOf('.') + 1) + "FREEZER_" + n.substring(n.lastIndexOf('.') + 1, n.length());
		try
		{
			// System.err.println(this.getClass().getSimpleName()+" = "+Class.forName(n));
			Class out = Class.forName(n);
			Class[] types = out.getInterfaces();

			for (Class t : types)
			{
				String name = t.getSimpleName();
				if (name.startsWith("NOISE"))
				{
					if (noise != null)
					{
						fatalErrorSD("Cant do multiple noises till this bit of code is fixed!");
					}
					// if (noise == null || noise.isAssignableFrom(t))
					noise = t;
				}
			}
			return out;
		}
		catch (ClassNotFoundException e)
		{
			error("While looking for freezer " + n + " it could not be found");
			return null;
		}
	}

	public ColorRGBA getColour()
	{
		return colour;
	}

	public void setColour(ColorRGBA colour)
	{
		this.colour = colour;
	}

	public Vector2f getLocation2()
	{
		return location;
	}

	public Vector3f getLocation()
	{
		return new Vector3f(location.x, location.y, 0);
	}

	/**
	 * Called when we are moved in the GUI, cascade to adjoining links
	 * 
	 * @param location
	 */
	public void setLocation(Vector2f location)
	{
		for (Flow f : upStream)
			f.moved();
		for (SluiceManual s : downStream)
			s.moved();

		this.location = location;
		
		// if we're on screen
		if (node != null)
		{
			node.setLocalTranslation(new Vector3f(
					location.x, 
					location.y, 
					0));
		}
	}

	public Vector2f getSize()
	{
		return size;
	}

	public void setSize(Vector2f size)
	{
		this.size = size;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * The upstream is set up by waterfall and sluice when a link is made no need to create!
	 * 
	 * @return
	 */
	protected List<Flow> getUpStream()
	{
		return upStream;
	}

	protected void addUpStream(Flow up)
	{
		upStream.add(up);
	}

	protected void removeUpStream(Flow f)
	{
		upStream.remove(f);
	}

	/**
	 * Theses get and set the text label that must follow the waterfall!
	 * 
	 * @param s
	 */
	public void setText(Spatial s)
	{
		text = s;
	}

	public Spatial getText()
	{
		return text;
	}

	public Node getNode()
	{
		return node;
	}

	public void setNode(Node node)
	{
		this.node = node;
	}

	public Class getNoise()
	{
		return noise;
	}

	public void setNoise(Class noise)
	{
		this.noise = noise;
	}

	public void disconnectAll()
	{

		// links in/upstream
		while (upStream.size() > 0)
		{
			Flow f = upStream.get(0);
			f.remove();
		}
		// links out
		for (SluiceManual s : downStream)
		{
			s.removeAll();
		}

	}

	
	private transient EventDispatch eventDispatch = new EventDispatch();
	
    public void doUpdate(BalloonMonkey state)
	{
		ActionEvent action;
		while ((action = eventDispatch.getActionEvent()) != null)
		{
			actionUpdate(action, state);
		}
	}
    
    /**
     * This is called when we are taken offa disk. Just need to setup any transient fields 
     *
     */
    public void fromDisk()
    {
      eventDispatch = new EventDispatch();
    }
	
	private void actionUpdate(ActionEvent ae,BalloonMonkey state)
	{
		if (ae.getSource() instanceof JButton)
		{
			JButton j = (JButton)ae.getSource();
			if (j.getText().compareTo("x")==0)
			{
				// delete and refresh...
				state.deleteWaterfall(this);
				Sity.self.setPanel(Sity.getSplashScreen());
			}
			else if (j.getText().compareTo("eg")==0)
			{
				// tell waterfall to try to display only from this level
				MagicWindow.setWaterFall(this, Sity.self.getRootFall());
			}
		}
	}
	
	/**
	 * The automagical GUI constructor. Creates a GUI from the over riding waterfall classes features
	 * 
	 * @return
	 */
	public Component getGUI()
	{
		JPanel out = new JPanel();
		
		//out.set
		//out.setMaximumSize(new Dimension(250,2000));
		//out.setPreferredSize(new Dimension(300,2000));
		JPanel title = new JPanel();
		out.setLayout(new BoxLayout(out,BoxLayout.PAGE_AXIS));
		
		JButton kill = new JButton("x");
		kill.addActionListener(eventDispatch);
		JButton eg = new JButton("eg");
		eg.addActionListener(eventDispatch);
		//kill.setMaximumSize(new Dimension(16,16));
		//title.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		title.setBorder(new EmptyBorder(5,5,5,5));
		

		title.setLayout(new BoxLayout(title, BoxLayout.LINE_AXIS));
		title.add(new JLabel(getName()));
		title.add(Box.createHorizontalGlue());
		title.add(eg);
		title.add(kill);
		title.setMaximumSize(new Dimension(2000,30));
		
		out.add(title);
		
		Field[] fields = getClass().getFields();
		List<Field> vars = new ArrayList<Field>();
		// for all variables
		for (Field f : fields)
			// which start with _VAR
			if (f.getName().startsWith("VAR_"))
				vars.add(f);

		for (Field f : vars)
		{
			// default value
			String toolTip = "unknown (sorry)";
			try
			{
				Field hint = this.getClass().getField("DEF_" + f.getName().substring(4, f.getName().length()));
				toolTip = (String)hint.get(this);
			}
			catch (NoSuchFieldException e)
			{
				toolTip = "No definion given for " + f.getName();
			}
			catch (IllegalAccessException e)
			{
				toolTip = error("No access exception when finding description:" + f.getName());
			}
			
			try
			{
			 Object heightValue; 
			 heightValue = f.get(this);
			 GUIiser g = new GUIiser(heightValue, toolTip);
			 out.add(g.getGUI());
			}
			catch (IllegalAccessException e)
			{
				fatalErrorSD("While trying to read value of "+f.getName()+" from "+this.getClass().getSimpleName());
			}
		}

		return out;
	}

	public GeomBatch getBatch()
	{
		return batch;
	}

	public void setBatch(GeomBatch batch)
	{
		this.batch = batch;
	}

}
