package sity;

import static com.jme.renderer.ColorRGBA.*;
import geom.*;

import java.util.*;
import java.util.List;

import java.awt.*;
import java.io.PrintStream;

import javax.swing.JFrame;
import javax.vecmath.*;

import skyHook.*;

import com.jme.renderer.*;
import com.jme.renderer.lwjgl.LWJGLRenderer;
import com.jme.system.DisplaySystem;

/**
 * This is where all the persistant variables live for the entire system. Also has utility classes and suchlike.... (read: a mess)
 * 
 * @author tk1748
 * 
 */
public class Parameters
{

	public static Balloon balloon = null;

	public static MagicWindow magicWindow = null;

	public static int skyHookPort = 2424;

	public static PrintStream MEL = makePrintStream();

	public static MayaSkyHook skyHook;

	public static Anchor anchor;

	public static Random uberRandom = new Random(327136l);

	// fps for 3d windows!
	public static final int fps = 45;

	public static final float MOUSE_WHEEL_DIVIDER = 10;

	// place we look for all waterfalls
	public static final String waterfallPackage = "ssbd";

	public static Sheaf NULL_SHEAF = new Sheaf(new Matrix4d());
	
	private static PrintStream makePrintStream()
	{
		try
		{
			return new PrintStream("output_debug");
		}
		catch (Exception e)
		{
			System.err.println("Unable to set up debug printsream, expect more errors");
		}
		return null;
	}

	public static void setupParameters()
	{
		MayaSkyHook sh = new MayaSkyHook();
		anchor = new MayaAnchor(sh);
		// anchor = new MonkeyAnchor();
		// System.out.println("random is ")
	}

	public static Sheaf nullSheet()
	{
		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(0, 0, 0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));
		fp.add(new FlatPoint(1, 1));
		fp.add(new FlatPoint(0, 1)); // sheet is now a unit sqare in the 1st
		// quadrant
		// clockwise manner!
		Sheaf s2 = new Sheaf(fp, mat);
		return s2;
	}

	public static SheetBuilder demoSheetBuilder()
	{
		return new SheetBuilder(nullSheet());
	}

	/**
	 * Polite notice to user!
	 * @param msg
	 * @return
	 */
	public static String message(String msg)
	{
		System.out.println(msg);
		return msg;
	}
	/**
	 * Displays the specified error mesage in a manner appropriate for the current state of developement!
	 * 
	 * @param msg
	 *            the soul destroying message
	 */
	public static String error(String msg)
	{
		System.err.println(msg);
		return msg;
	}

	/**
	 * Displays the specified error mesage in a manner appropriate for the current state of developement! And dumps the stack!
	 * 
	 * @param msg
	 *            the soul destroying message
	 */
	public static void errorSD(String msg)
	{
		System.err.println(msg);
		Thread.dumpStack();
	}

	/**
	 * Ends program execution with the given error
	 * 
	 * @param msg
	 *            the soul destroying message
	 */
	public static void fatalError(String msg)
	{
		System.err.println(msg);
		System.exit(-1);
	}

	/**
	 * Ends program execution with the given error and a stack dump :)
	 * 
	 * @param msg
	 *            the soul destroying message
	 */
	public static void fatalErrorSD(String msg)
	{
		System.err.println(msg);
		assert (false);
		Thread.dumpStack();
		System.exit(-1);
	}

	private static Class[] dataTypes = null;

	private static String dataTypesS[] = { "Integer", "Double" };

	/**
	 * Initalises Iif not already) the list of classes that a frozen waterfall may use as parameters
	 * 
	 * @return that list o classes
	 */
	public static Class[] getVariables()
	{
		if (dataTypes == null)
		{

			try
			{
				dataTypes = new Class[dataTypesS.length];
				for (int i = 0; i < dataTypesS.length; i++)
				{
					dataTypes[i] = Class.forName(dataTypesS[i]);
				}
			}
			catch (ClassNotFoundException e)
			{
				fatalError("Error trying to initalise dataTypesS!");
			}
		}
		return dataTypes;
	}

	private static Map<Class, ColorRGBA> noiseToColour = new HashMap<Class, ColorRGBA>();

	private static List<ColorRGBA> colours = null;

	public static ColorRGBA colourFromNoise(Class in)
	{
		Random random = uberRandom;
		if (colours == null)
		{
			colours = new ArrayList<ColorRGBA>();
			colours.add(blue);
			colours.add(green);
			colours.add(new ColorRGBA(0.5f, 0.2f, 0.8f, 1.0f));
			colours.add(new ColorRGBA(0.0f, 1f, 1f, 1.0f));
			colours.add(new ColorRGBA(0.5f, 1f, 1f, 1.0f));
			colours.add(new ColorRGBA(0.0f, 1f, 1f, 1.0f));
			colours.add(new ColorRGBA(0.0f, 0.5f, 1f, 1.0f));
			colours.add(new ColorRGBA(0.3f, 0.47f, 1f, 1.0f));
		}

		if (noiseToColour.containsKey(in))
		{
			return noiseToColour.get(in);
		}
		else
		{
			ColorRGBA out;
			if (colours.size() > 0)
			{
				out = colours.remove(0);
			}
			else
			{
				out = new ColorRGBA(random.nextFloat(), random.nextFloat(), random.nextFloat(), 1.0f);
			}
			noiseToColour.put(in, out);
			return out;
		}
	}

	public static ColorRGBA colour(Color c)
	{
		return new ColorRGBA(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha());
	}

	public static Color colour(ColorRGBA c)
	{
		return new Color(c.r, c.g, c.b, c.a);
	}

	/**
	 * sets the frame icons
	 * 
	 * @param in
	 */
	public static void setIcon(JFrame in)
	{
		Image icon = Toolkit.getDefaultToolkit().getImage(Sity.class.getResource("/media/icon.png"));
		in.setIconImage(icon);
	}

	/**
	 * JMe sharing a display window boxes
	 */
	private static DisplaySystem display = null;

	private static Renderer renderer = null;

	/**
	 * Returns a simgi;lar display system for all of Sity
	 * @return
	 */
	public static DisplaySystem getDisplay()
	{
		if (display == null)
		{
			setupDisplay();
		}
		return display;
	}

	/**
	 * This returns the renderer for the first display created, the others
	 * should create their own
	 * @return
	 */
	public static Renderer getRenderer()
	{
		if (renderer == null) setupDisplay();
		return renderer;
	}
	
	/**
	 * Creates a new renderer and display system
	 *
	 */
	private static void setupDisplay()
	{
		display = DisplaySystem.getDisplaySystem();
		renderer = new LWJGLRenderer(800, 600);
		renderer.setHeadless(true);
		display.setRenderer(renderer);
		DisplaySystem.updateStates(renderer);
	}
}
