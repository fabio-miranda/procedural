package junk;

import sity.*;
import ssbd.NOISE_Subdiv;
import util.*;

public class HippedRoof extends Waterfall
{
	public ProbDouble VAR_steepness = new ProbDouble(0.01,Double.MAX_VALUE,0.7,1);
	public String       DEF_steepness = "how steep is the roof edge?";
	
	public MyDouble VAR_minSteep = new MyDouble(0.5);
	public String   DEF_minSteep = "Minimum steepness of the roof";
	
	public SluiceManual nextTop = new SluiceManual(NOISE_Subdiv.class,"What goes on top",this);
	
	public HippedRoof(Waterfall parent)
	{
		super(parent);
	}
}
