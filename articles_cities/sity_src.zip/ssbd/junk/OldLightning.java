package junk;

import static geom.Vec2d.*;
import geom.*;

import java.util.*;

import java.awt.Color;

import javax.vecmath.*;

import cloud.*;

import sity.Parameters;
import skyHook.AnchorStatics;

/**
 * Delme code!
 * @author people
 *
 */
public class OldLightning
{

	PointCloud pointCloud = null;
	

	FlatPoint start, nextPoint;
	Cell nextCell;
	
	/**
	 * inner function that inserts the bisector of me and other into the correct places
	 * @param me
	 * @param other
	 */
	private void gogoOld(Cell me, Cell other)
	{
		// find bisector of current centre and new point
		Pair<Tuple2d, Tuple2d> res = bisectorOfPoints(me.getCentre(), other.getCentre());
		// System.err.println("bisector is at" + res.first() + " angle " + res.second());
		Pair<FlatPoint, FlatPoint> clipped = clip(res, other);
		if (clipped == null)
			Parameters.fatalErrorSD("failed to clip where I expected to clip");

		// if start is null then we have started a new insertion, and we set the flatpoint to return too!
		if (start == null) start = clipped.first();
		
		Wall sharedWall = new Wall(me, other, clipped.first(), clipped.second(), pointCloud);
		System.err.println("shared wall is "+sharedWall);
		
		me.getWall().add(sharedWall);
		// these are relative to me
		Wall startWall = other.getClipTwo();
		Wall endWall = other.getClipOne();

		//Map<FlatPoint, List<Wall>> skin = pointCloud.getSkin();
		
		Wall start = null; // the edge to start on
		if (nextPoint == null) // this is the first one, just start on me's side
			start = other.getClipOne();
		else
		{
		// Find the first wall to process, remembering that
		for (Wall w: other.getWall())
		{
			System.err.println("looking for "+nextPoint+"against "+w.getStart(other));
			if (w.getStart(other) == nextPoint) 
			{
				start = w;
				break;
			}
		}
		}
		assert(start != null);
		
		// now go from this point, adding the edges encountered to me, until startWall
		// then keep all edges to other until end Wall, then add all to me again till back at start...
		// ... and fit sharedWall in somewhere too!
		
		ListIterator<Wall> allWall = other.getWallOn(start).listIterator();
		
		boolean toMe = false; // tag to say current edges are being added to me
		while (allWall.hasNext())
		{
			Wall t = allWall.next();
			System.err.println(" t ish "+t);
			if (t == startWall)
			{
				System.err.println("startwall says " + clipped.first() + " " + clipped.second());
				allWall.add(sharedWall);
				// add the other half of t into skin IS ME RIGHT?
				if (pointCloud.inSkin(t))
				{
					Wall otherHalf = new Wall(null,me, t.getStart(other ),clipped.second(), pointCloud);
					//Wall otherHalf = new Wall(null,me, clipped.second(), t.getEnd(other ), pointCloud);
					pointCloud.addToSkin(otherHalf);
					me.getWall().add(otherHalf);
				}
				t.setStart(clipped.second(), other);
				//t.setEnd(clipped.second(), other);
				toMe= false;

			}
			else if (t == endWall)
			{
				System.err.println("endwall says " + clipped.first() + " " + clipped.second());
				
				if (pointCloud.inSkin(t)) // splitting skin wall
				{
					Wall otherHalf = new Wall(other,me, clipped.first(), t.getEnd(other), pointCloud);
					//Wall otherHalf = new Wall(other,me, t.getStart(other), clipped.first(), pointCloud);
					pointCloud.addToSkin(otherHalf);
					me.getWall().add(otherHalf); // me is needing all skin edges
				}
				t.setEnd(clipped.first(), other);
				//t.setStart(clipped.first(), other);
				toMe = true;
			}
			else if (toMe)
			{
				System.err.println("otherwall says " + clipped.first() + " " + clipped.second());
				if (t.getOther(other) == null) // me is needing all edges
				{
					t.change(other, me);
					me.getWall().add(t);
				}
				// remove it from the old wall, but it stays in the skin
				allWall.remove();
			}
			else //toMe == false
			{
				//t.change(other, me);
				System.err.println("fineWall says ");
				// nothing to do!, edge already in correct cell

			}
		}
		
		// swap point around...!
		FlatPoint tmp = me.getCentre();
		me.setCentre(other.getCentre());
		other.setCentre(tmp);
		
		nextCell = other.getClipOne().getOther(other);
		nextPoint = clipped.second();
	}
	
	public OldLightning(PointCloud in)
	{
		pointCloud = in;
		setup2();
	}
	public void setup2()
	{
		// grab the first cell
		Cell c = pointCloud.getFirstCell();

		List<FlatPoint> pointsToAdd = pointCloud.getPointsClone();
		pointsToAdd.remove(c.getCentre());

		// for each point in the cloud add it to the network
		for (FlatPoint f : pointsToAdd)
		{
			System.err.println("looking for point " + f);
			// first up find the cell that its in
			for (Cell cell : pointCloud.getCells())
			{
				if (geom.Vec2d.pointIn(f, cell.getCorners()))
				{
					c = cell;
					System.err.println("found it");
					continue;
				}
			}
			if (c == null)
			{
				for (Cell ce : pointCloud.getCells())
					ce.show(3);
				Parameters.fatalErrorSD("There is nomatching cell for " + f);
			}

			Map<FlatPoint, Pair<FlatPoint,Cell>> listNull = new LinkedHashMap<FlatPoint, Pair<FlatPoint,Cell>> ();
			
			Cell newCell = new Cell(f);
			Cell result1 = gogo(newCell, c, THAT_WAY, false, listNull );
			//while (result1 != c)
			{
				System.err.println("gogoin with "+newCell+" "+result1);  
				if (result1 != null) // incase above gogo returned null...
					result1 = gogo(newCell, result1, THAT_WAY, false, listNull);
				
				showNull(listNull, 1);
				/*
				while (result1 == null)
				{
					// only works for THAT_WAY
					FlatPoint last = newCell.getWall().get(newCell.getWall().size()-1).getEnd(newCell);
					// find wall section
					System.err.println("going into j with with "+last);
					Pair<FlatPoint,Cell> j = listNull.get(last);
					assert(j!= null);
					// add in wall section
					newCell.getWall().add(new Wall(newCell, null, last, j.first()));
					// continue with next cell
					result1 = j.second();
				}*/
			}

			pointCloud.addCell(newCell);

			double height = 0;
			for (Cell q : pointCloud.getCells())
				q.show(height++);
			c = null;
		}
	}

	private final static int THAT_WAY = 100;

	private final static int OTHER_WAY = 200;

	/**
	 * 
	 * @param me
	 * @param other
	 * @param start
	 * @return the next cell to be processed
	 */
	private Cell gogo(Cell me, Cell other, int addIn, boolean firstTime,
			Map<FlatPoint, Pair<FlatPoint,Cell>>  listNull)
	{
		// find bisector of current centre and new point
		Pair<Tuple2d, Tuple2d> res = bisectorOfPoints(me.getCentre(), other.getCentre());
		// System.err.println("bisector is at" + res.first() + " angle " + res.second());
		Pair<FlatPoint, FlatPoint> clipped = clip(res, other);
		if (clipped == null)
			Parameters.fatalErrorSD("failed to clip where expected");
		// Cell nextCell = other.getClipOne().getOther(other);

		Wall sharedWall = new Wall(me, other, clipped.first(), clipped.second(), pointCloud);

		if (!firstTime) // make no changes first time around
		{

			// add clip to boundry definition - check order
			if (addIn == THAT_WAY)
				me.getWall().add(sharedWall);
			if (addIn == OTHER_WAY)
				me.getWall().add(0, sharedWall);

			// traverse wall
			Wall startWall = other.getClipTwo();
			Wall endWall = other.getClipOne();

			ListIterator<Wall> allWall = other.getWallOn(startWall).listIterator();
			boolean removeRest = true; // tag to bring us to the bit of the curve we care about
			while (allWall.hasNext())
			{
				Wall t = allWall.next();
				if (t == startWall)
				{
					System.err.println("startwall says " + clipped.first() + " " + clipped.second());
					allWall.add(sharedWall);
					nullAdd(t.getOther(other), other, listNull, 
							t.getEnd(other), clipped.second(), addIn);
					t.setEnd(clipped.second(), other);
					
				}
				else if (t == endWall)
				{
					System.err.println("endwall says " + clipped.first() + " " + clipped.second());
					nullAdd(t.getOther(other), other, listNull, 
							clipped.first(), t.getStart(other), addIn);
					t.setStart(clipped.first(), other);
					removeRest = false;
				}
				else if (removeRest)
				{
					System.err.println("otherwall says " + clipped.first() + " " + clipped.second());
					nullAdd(t.getOther(other), other, listNull, 
							t.getEnd(other), t.getStart(other), addIn);
								
					allWall.remove();
				}
				else
				{
					// nothing to do!, edge already in correct cell
				}
			}
		}

		// return next cell to process.
		if (addIn == THAT_WAY)
		{
			return other.getClipOne().getOther(other);
		}
		else if (addIn == OTHER_WAY)
		{
			return other.getClipTwo().getOther(other);
		}
		Parameters.fatalErrorSD("Called with invalid addIn " + addIn);
		return null;
	}
	
	private void showNull( Map<FlatPoint,Pair<FlatPoint,Cell>> listNull, double height)
	{
		for( FlatPoint f: listNull.keySet())
		{
			Vector3d a = new Vector3d(f.x, height, f.y);
			FlatPoint t = listNull.get(f).first();
			Cell c = listNull.get(f).second();
			if (c == null) c= new Cell(new FlatPoint(-1,-1));
			Vector3d b = new Vector3d(t.x, height, t.y);
			Vector3d d = new Vector3d(c.getCentre().x, height, c.getCentre().y);
			Parameters.anchor.setColor(Color.orange);
			AnchorStatics.createArrow(a, b, 0, 0.5);
			Parameters.anchor.setColor(Color.green);
			AnchorStatics.createArrow(a, d, 0, 0.2);
		}
	}
	
	/**
	 * We add this null edge to our data structure of flatpoint -> (flatpoint, cell)
	 * @param next
	 * @param nullList
	 * @param a
	 * @param b
	 * @param listOWall
	 * @param addIn
	 */
	private void nullAdd(Cell next, Cell me, Map<FlatPoint,Pair<FlatPoint,Cell>> listNull, 
			FlatPoint a, FlatPoint b, int addIn)
	{
		List<Wall> listOWall = me.getWall();
		System.err.println("adding from "+a +" to "+b);
		if (next == null)
		{
			Cell nextCell = null;
			// find the next other cell after that with start = a or end = b
			ListIterator<Wall> liw = listOWall.listIterator();
			while (liw.hasNext())
			{
				Wall w = liw.next();
				if (w.getStart(me) == a || w.getEnd(me) == b)
				{
					if (liw.hasNext())
					{
						w = liw.next();
						nextCell = w.getOther(me);
						break;
					}
					else
					{
						nextCell = listOWall.get(0).getOther(me);
						break;
					}
				}
			}
			//assert nextCell != null; // lol, cant assert that it might be null
			assert(b!= null);
			listNull.put(a, new Pair<FlatPoint,Cell>(b, nextCell));
		}
	}

	/**
	 * Creates the network of lines between points
	 * 
	 */
	public void setup()
	{
		// grab the first cell
		Cell c = pointCloud.getFirstCell();

		List<FlatPoint> pointsToAdd = pointCloud.getPointsClone();
		pointsToAdd.remove(c.getCentre());

		// for each point in the cloud add it to the network
		for (FlatPoint f : pointsToAdd)
		{
			System.err.println("looking for point " + f);
			// first up find the cell that its in
			for (Cell cell : pointCloud.getCells())
			{
				if (geom.Vec2d.pointIn(f, cell.getCorners()))
				{
					c = cell;
					System.err.println("found it");
					continue;
				}
			}
			if (c == null)
			{
				for (Cell ce : pointCloud.getCells())
					ce.show(3);
				Parameters.fatalErrorSD("There is nomatching cell for " + f);
			}

			System.err.println("looking at cell " + c + ":" + c.getCentre());
			System.err.println("cell boundariess are " + c.getCorners());

			Cell n = AddTo(f, c);
			// all done, add the new cell
			pointCloud.addCell(n);

			// now walk around from first and second
			List<Cell> toProcess = new ArrayList<Cell>();
			Cell tmp = c.getClipOne().getOther(c);
			toProcess.add(tmp);
			tmp = c.getClipTwo().getOther(c);
			toProcess.add(tmp);

			Set<Cell> processed = new LinkedHashSet<Cell>();
			processed.add(c);

			while (!toProcess.isEmpty())
			{
				Cell process = toProcess.remove(0);
				if (processed.contains(process))
					continue;
				if (process == null)
					continue;
				processed.add(process);
				System.err.println("now splitting pt " + f + " against cell " + process.getCentre());
				// now check cell process against point f
				Cell toMerge = AddTo(f, process);
				pointCloud.addCell(toMerge);

				System.err.println("quitting now");

				double height = 0;
				for (Cell ce : pointCloud.getCells())
				{
					ce.show(height++);
				}
				System.exit(3);
				// tmp = process.getClipOne().getOther(process);
				// toProcess.add(tmp);
				// tmp = process.getClipTwo().getOther(process);
				// toProcess.add(tmp);
			}
			// reset c
			c = null;
		}
		double height = 0;
		for (Cell ce : pointCloud.getCells())
		{
			ce.show(height);
		}
	}

	public Cell AddTo(FlatPoint f, Cell c)
	{
		// find bisector of current centre and new point
		Pair<Tuple2d, Tuple2d> res = bisectorOfPoints(f, c.getCentre());
		// System.err.println("bisector is at" + res.first() + " angle " + res.second());
		Pair<FlatPoint, FlatPoint> clipped = clip(res, c);
		// check the line collided with something
		if (clipped != null)
		{
			// AnchorStatics.createArrow(new Vector3d(clipped.first().x, 0, clipped.first().y), new Vector3d(clipped.second().x, 0, clipped.second().y), 0, 0.5);
			// new Cell we're adding in
			Cell n = new Cell(f);
			// set inital walls, stealing from the cell we collided with
			Wall first = c.getClipOne();
			Wall second = c.getClipTwo();
			System.err.println("first to clip" + first);
			System.err.println("second to clip" + second);

			// direction wrong?
			Wall newWall = new Wall(c, n, clipped.first(), clipped.second(), 1, pointCloud);
			// newWall.
			List<Wall> nWalls = n.getWall();
			List<Wall> cWalls = c.getWallOn(first);
			assert (cWalls.get(0) == first);
			boolean wallToNew = false; // are we changing wall ownership?
			// System.err.println(" first wall is " + first);
			// System.err.println(" second wall is " + second);
			// System.err.println(" new wall is " + newWall);
			ListIterator<Wall> liw = cWalls.listIterator();
			while (liw.hasNext())
			{
				Wall t = liw.next();
				if (wallToNew) // remove wall from c and add to n
				{
					liw.remove();
					t.change(c, n);
					nWalls.add(t);
				}
				else
				{
					if (t == first)
					{
						Wall n2 = new Wall(t.getOther(c), n, t.getStart(c), clipped.first(), 1.0, pointCloud);
						if (t.getOther(c) != null)
						{
							try
							
							{
							t.getOther(c).addWallAfter(n2, t);
							}
							catch (CloudSaysNoException e)
							{
								// dunno, should never run OldLighning....
							}
						}
						t.setStart(clipped.first(), c);
						nWalls.add(n2);
						nWalls.add(newWall);

					}
					else if (t == second)
					{
						Wall n2 = new Wall(t.getOther(c), n, clipped.second(), t.getEnd(c), 1.0, pointCloud);
						if (t.getOther(c) != null)
						{
							t.getOther(c).addWallBefore(n2, t);
						}
						nWalls.add(n2);
						t.setEnd(clipped.second(), c);
						liw.add(newWall);
						wallToNew = true;
					}
				}
			}
			return n;
		}
		else
		{
			double height = 0;
			for (Cell ce : pointCloud.getCells())
			{
				ce.show(height);
				height += 0.3;
			}
			// ...if not clipped somethings wrong
			Parameters.fatalError("Lightening bisector didnt bisect");
			return null;
		}
	}
}
