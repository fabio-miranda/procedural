package junk;

import geom.*;

import java.util.*;


/**
 * Edge of a skeleton
 * @author people
 *
 */
public class Edge
{
	private FlatPoint first;
	private FlatPoint second;
	private double speed;
	private List<EdgeType> types = new Vector<EdgeType>();
	//relative heights of both the edges
	private double firstHeight = 0;
	private double secondHeight = 0;
	
	public Edge(FlatPoint first, double fh, FlatPoint second, double sh, double speed)
	{
		super();
		this.first = first;
		this.second = second;
		this.speed = speed;
		this.firstHeight = fh;
		this.secondHeight = sh;
	}
	
	public Edge(FlatPoint first, double fh, FlatPoint second, double sh, double speed, List<EdgeType> in)
	{
		this(first,fh,second,sh,speed);
		types = in;
	}
	
	/**
	 * Warning! this creates an edge going in the oposite direction
	 * as the given edge, with the same (as in object) type list.
	 */
	public Edge(Edge in)
	{
		super();
		this.first = in.second;
		this.second = in.first;
		this.speed = in.speed;
		this.types = in.getTypes();
		this.secondHeight = in.firstHeight;
		this.firstHeight = in.secondHeight;
	}

	public void addType(EdgeType in)
	{
		types.add(in);
	}
	
	
	public boolean hasType(EdgeType in)
	{
		if (types.contains(in)) return true;
		return false;
	}
	
	public List<EdgeType> getTypes()
	{
		return types;
	}
	
	public FlatPoint getFirst()
	{
		return first;
	}

	public void setFirst(FlatPoint first)
	{
		this.first = first;
	}

	public FlatPoint getSecond()
	{
		return second;
	}

	public void setSecond(FlatPoint second)
	{
		this.second = second;
	}

	public double getSpeed()
	{
		return speed;
	}

	public void setSpeed(double speed)
	{
		this.speed = speed;
	}


	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		Iterator<EdgeType>it = types.iterator();
		while(it.hasNext())
		{ 
				sb.append(" ");
				sb.append(it.next().toString());
		}
		
		return (first +" to " +second+"speed "+speed+ ","+ sb.toString());
	}

	public void setType(List<EdgeType> types)
	{
		this.types = types;
	}

	public double getFirstHeight()
	{
		return firstHeight;
	}

	public double getSecondHeight()
	{
		return secondHeight;
	}

	public void setFirstHeight(double firstHeight)
	{
		this.firstHeight = firstHeight;
	}

	public void setSecondHeight(double secondHeight)
	{
		this.secondHeight = secondHeight;
	}

	public void setTypes(List<EdgeType> types)
	{
		this.types = types;
	}
	
	public double length()
	{
		double flat = first.distanceTo(second);
		double h = firstHeight-secondHeight;
		return Math.sqrt(h*h+flat*flat); 
	}
	
}
