package junk;

import geom.FlatPoint;
import util.CE;

/**
 * Just a wrapper to mark this event as a group of poitners to simplify the slitting process
 * @author people
 *
 */
public class DummySplitEvent extends SplitEvent
{
	public DummySplitEvent(CE<Point>  point, double perpHeight, FlatPoint location, Edge e)
	{
		super(point,perpHeight, location,e);
	}
}
