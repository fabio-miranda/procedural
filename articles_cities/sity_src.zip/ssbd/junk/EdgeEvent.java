package junk;

import geom.FlatPoint;
import skeleton.*;
import util.CE;

/**
 * Type of intersection that happens when two convex/concave bisectors intersect
 * @author people
 *
 */
public class EdgeEvent extends Intersection
{
	private CE<Point>  nextPoint, previousPoint;
	private double maxDist = 0;
	
	public EdgeEvent(CE<Point>  leftPoint, CE<Point>  rightPoint, double perpHeight, FlatPoint location)
	{
		super();
		this.nextPoint = leftPoint;
		this.previousPoint = rightPoint;
		this.perpHeight = perpHeight;
		this.location = location;
		this.maxDist = Math.max(rightPoint.thing.getPoint().distanceTo(location),
				leftPoint.thing.getPoint().distanceTo(location));//+0.0000001; 
	}
	public double maxDist()
	{
		return maxDist;
	}
	
	public CE<Point>  getNextPoint()
	{
		return nextPoint;
	}
	public void setNextPoint(CE<Point>  leftPoint)
	{
		this.nextPoint = leftPoint;
	}

	public CE<Point>  getPreviousPoint()
	{
		return previousPoint;
	}
	public void setPreviousPoint(CE<Point>  rightPoint)
	{
		this.previousPoint = rightPoint;
	}

	/**
	 * Thats a lot of output!
	 */
	public String toString()
	{
		return ("EDGE: height: "+perpHeight+" \nlocation "+
				location+"\n next:"+nextPoint.thing+
				" \n previous :"+previousPoint.thing+"\n maxDist"+maxDist());
	}
}
