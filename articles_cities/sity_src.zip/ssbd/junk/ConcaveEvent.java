package junk;

import geom.FlatPoint;

import java.util.*;

import javax.vecmath.Vector2d;

import skeleton.*;
import util.CircularList;
import static sity.Parameters.*;
/**
 * Represents a collection of Split events that happened at the same time.
 * 
 *It is importatnt to remember that the split events in here still ahve their
 * original heights and intersection points, we dtore the proper locations and
 * height of intersection in this class.
 * 
 * @author people
 * 
 */
public class ConcaveEvent extends Intersection
{

	private SortedSet<SplitEvent> splits = null;
	private static final double TOL = 0.000000001;
	double minDist = 0;
	
	/**
	 * Creates a set ordered by their clockwise position around a central point
	 * @param refence the central point of all collisions
	 */
	public ConcaveEvent(Vector2d reference, double height)
	{
		this.splits = new TreeSet<SplitEvent>(new AngleComparitor(reference));
		this.perpHeight = height;
		location = new FlatPoint(reference);
	}

	public void addEvent(SplitEvent in)
	{
		assert(in.location.distanceTo(location) < TOL);
		Iterator<SplitEvent>sit = splits.iterator();
		double md = Double.MAX_VALUE;
		while (sit.hasNext())
		{
			double dtp = location.distanceTo(sit.next().getPoint().thing.getPoint());
			if (dtp < md) md = dtp;
		}
		minDist = md;
		splits.add(in);
	}
	
	public double maxDist()
	{
		return minDist; // change this to a lower Value!
	}

	public int size()
	{
		return splits.size();
	}
	
	public CircularList<SplitEvent> getSectors()
	{
		System.err.println("concave event says size is "+splits.size());
		return new CircularList<SplitEvent>(splits);
	}
	
	public String toString()
	{
		Iterator<SplitEvent> it = splits.iterator();
		String tmp = "";
		while (it.hasNext())
		{
			SplitEvent t = null;
			tmp +="  \n"+(t = it.next()).getPoint().thing.getPoint() +" @ "+t.getLocation() +" ^ "+t.getPerpHeight();
		}
		return "BUNCH_O_SPLIT"+tmp; 
	}
	
}
