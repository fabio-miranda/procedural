package junk;

import java.util.*;

import junk.*;

public class Queue
{
	PriorityQueue<Intersection> q = new PriorityQueue<Intersection>();

	public void add(Intersection in)
	{
		q.add(in);
	}

	/**
	 * empty queue
	 * 
	 */
	public void empty()
	{
		while (!q.isEmpty())
			q.poll();
	}

	public boolean hasNext()
	{
		return !q.isEmpty();
	}

	public int size()
	{
		return q.size();
	}
	
	public Iterator<Intersection> iterator()
	{
		return q.iterator();
	}

	/**
	 * Run through the list of splitEvents (they are all at the same height) if any of them have the same location return a new ConcaveEvent
	 * 
	 * hmm.. this is an n^2 algorithm as we have to give some leeway for points not being in the same location....
	 * 
	 * @param in
	 */
	private void setUpConcave()
	{
		List<SortedSet<SplitEvent>> list = new Vector<SortedSet<SplitEvent>>();
		Iterator<Intersection> it = vip.iterator();

		// System.err.println("SUP says "+vip.size());
		while (it.hasNext())
		{
			Intersection e = it.next();
			// System.err.println(e);
			if (e instanceof SplitEvent)
			{
				Iterator<SortedSet<SplitEvent>> inner = list.iterator();
				boolean found = false;
				while (inner.hasNext())
				{
					SortedSet<SplitEvent> onePlace = inner.next();
					if (onePlace.first().location.distanceTo(e.location) < 0.00000000000001)
					{
						// System.err.println("added to old list");
						onePlace.add(SplitEvent.class.cast(e));
						found = true;
						break;
					}
				}

				if (!found)
				{
//					remed cause unused // SortedSet<SplitEvent> tmp = new TreeSet<SplitEvent>(new AngleComparitor(SplitEvent.class.cast(e).location));
//					remed cause unused // tmp.add(SplitEvent.class.cast(e));
//					remed cause unused // list.add(tmp);
					// System.err.println("new list made");
				}
			}
		}

		// all the points should now be somewhere in 'list'
		vip = new Vector<Intersection>();
		
		// now list should hold a list containing sets of co-locational
		// splitEvents - we for concaveEvents from them and add them
		// to the priority Q
		Iterator<SortedSet<SplitEvent>> coLoc = list.iterator();
		while (coLoc.hasNext())
		{
			SortedSet<SplitEvent> tmp = coLoc.next();
			if (tmp.size() > 1)
			{
				//vip.add(new ConcaveEvent(tmp));
			}
			// any events we dont use go back onto the queue!
			else
			{
				// maybe for borderlines, they should go back on vip? investigate!
				q.add(tmp.first()); 
			}
		}
	}

	// list of all priority intersections, ones that happen at
	// the same time and must be processed sequentially...
	List<Intersection> vip = new Vector<Intersection>();

	/**
	 * R
	 * 
	 * @return the next intersection. iff we have several split events that all happen at the same time, they should all be run before continuing
	 */
	public Intersection getTop()
	{
		if (vip.size() != 0)
			return (vip.remove(0));

		List<Intersection> edge = new Vector<Intersection>();

		// go through all elements while their height < heigh. store any
		// split events on a priority list, and return the edge events to the normal queue
		Intersection next = q.peek();
		if (next == null)
			return null;
		double height = next.getPerpHeight() + 0.00000001;
		while (next.getPerpHeight() < height)
		{
			if (next instanceof EdgeEvent)
				edge.add(next);
			else if (next instanceof SplitEvent || next instanceof ConcaveEvent)
				vip.add(next);
			else
				assert (false);
			q.poll();
			next = q.peek();
			if (next == null)
				break;
		}

		// add the edge event back in!
		Iterator<Intersection> it = edge.iterator();
		while (it.hasNext())
			q.add(it.next());

		// move any clusters of split events on the vip list to ConcaveEvents in the vip list
		//setUpConcave();

		// if there are still any priorities remaining, return them
		if (vip.size() != 0)
			return (vip.remove(0));

		// otherwise return whats left
		return q.poll();
	}
	

	public Intersection othergetTop()
	{
		return q.poll();
	}

	public String toString()
	{
		Object[] thing = q.toArray();
		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < thing.length; i++)
		{
			sb.append(i + " ****** " + thing[i] + "\n");
		}
		return sb.toString();
	}
}
