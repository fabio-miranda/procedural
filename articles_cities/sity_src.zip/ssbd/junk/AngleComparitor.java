package junk;

import java.util.Comparator;
import static geom.Vec2d.*;
import javax.vecmath.Vector2d;


import util.CE;

/**
 * Provides an ording to ensure that the points collected from a set
 * of convex collisions are presented in clockwise order!
 * @author people
 *
 */
public class AngleComparitor implements Comparator<SplitEvent>
{
	private Vector2d reference = null;
	private static final Vector2d UP = new Vector2d(0,1);
	
	public AngleComparitor(Vector2d in)
	{
		reference = in;
	}
	
	public int compare(final SplitEvent a, final SplitEvent b)
	{
		Vector2d aV = new Vector2d(a.getPoint().thing.getPoint());
		Vector2d bV = new Vector2d(b.getPoint().thing.getPoint());
		aV.sub(reference);
		bV.sub(reference);
		
		double ag = angleBetween(UP,aV);
		double bg = angleBetween(UP,bV);

		double res = ag-bg;
		if (Double.isNaN(res))return -1;
		if (res < 0) return -1;
		if (res > 0) return 1;
		return 0;
	}
}
