package junk;

import static geom.EdgeType.*;
import static geom.Vec2d.*;
import static java.lang.Math.*;
import static sity.Parameters.*;
import geom.*;

import java.util.*;

import javax.vecmath.*;

import skeleton.*;
import util.*;

/**
 * Modified from pseudo code published by Felkel. Constructs the skeleton, second reqire of this without such heavy use of generics. Still unreadable, but less unreadable. One day I'll learn Java is a bad habit.
 * 
 * @author people
 * 
 */
public class Skeleton
{
	// circular list structure of roof base 'gutter' <SLAV>
	// private List<Circle> circles = new Vector<Circle>();

	// original list of edges
	private Sheaf originalLines = null;

	// private CircularList<Point> originalCircle = null;

	// all output Edges a hashmap of vectors
	private Map<FlatPoint, Vector<Edge>> lines = new Hashtable<FlatPoint, Vector<Edge>>();

	// if bevelling this contains the top of the roof
	private Map<FlatPoint, Vector<Edge>> flatTop = new Hashtable<FlatPoint, Vector<Edge>>();;

	// contains the polygons output by this routine
	private List<List<Edge>> allPolys = new Vector<List<Edge>>();

	private double bevel;

	private List<CE<Point>> originalCircle = new Vector<CE<Point>>(3);

	// all current points
	private Set<CE<Point>> allP = new LinkedHashSet<CE<Point>>();

	// master queue of all collisions
	private Queue Q = new Queue();

	/**
	 * Creates a skelteon using the points in the sheaf and their speeds. If any of the speeds are 0 it plays merry hell with the boundary conditions, so ALL SPEEDS == 0 are SET TO 0.0000001-ish
	 * 
	 * @param in
	 * @param distance
	 */
	public Skeleton(Sheaf in, double distance)
	{
		bevel = distance;
		originalLines = in;

		Iterator<Sheet> shit = in.getSheets().iterator();

		while (shit.hasNext())
		{
			Sheet sheet = shit.next();
			CEFP firstC = sheet.getFirst();
			CEFPIterator cit = new CEFPIterator(firstC);
			CEFP last = cit.next();

			//if (last.thing.getSpeed() == 0)
				last.thing.setSpeed(1);

			Point lastP = new Point(last.thing, null, null);
			Point firstP = lastP;

			// keep a list of points added from the sheet
			List<Point> tmpPoints = new Vector<Point>();
			tmpPoints.add(firstP);

			while (cit.hasNext())
			{
				CEFP cefp = cit.next(); // currentfp

				Edge newEdge = new Edge(lastP.getPoint(), 0., cefp.thing, 0., cefp.previous.thing.getSpeed());
				newEdge.setType(last.thing.getType());

				//if (cefp.thing.getSpeed() == 0)
					cefp.thing.setSpeed(1);
				Point currentP = new Point(cefp.thing, null, newEdge);
				tmpPoints.add(currentP);

				// set lasts next edge to us
				lastP.setNextEdge(newEdge);
				lastP = currentP;
				last = cefp;
			}

			Edge finalEdge = new Edge(firstC.previous.thing, 0, firstC.thing, 0, firstC.previous.thing.getSpeed());
			finalEdge.setType(firstC.previous.thing.getType());
			lastP.setNextEdge(finalEdge);
			firstP.setPreviousEdge(finalEdge);

			// create the links between this set of points
			CircularList<Point> clp = new CircularList<Point>(tmpPoints);

			CircularIterator cirit = new CircularIterator(clp);

			// add points to the allP buffer of acive points and store
			// a copy of the other point "for later use"
			while (cirit.hasNext())
			{
				CE<Point> cep = cirit.nextCircular();
				setBisector(cep);
				//System.err.println(">>>->" + cep + cep.thing.getBisector());
				allP.add(cep);

				CE duplicate = new CE<Point>(cep);
				duplicate.thing = new Point(cep.thing);
				originalCircle.add(duplicate);
			}
		}

		// find the initial set of intersection events
		Iterator<CE<Point>> circ = allP.iterator();
		while (circ.hasNext())
		{
			findIntersections(circ.next());
		}

		// set the ball in motion
		partTwo();

		// process list into faces
		//makeFaeces(0, 0); // debugging data
	    makeFaeces2(); // real one!
	}

	/**
	 * Part two from Felkel's notes
	 */
	int itCount = 0;

	public void partTwo()
	{
		double maxHeight = -Double.MAX_VALUE;
		// until the queue is empty!
		while (Q.hasNext())
		{
			itCount++;
			// pop top intersection points
			Intersection top = Q.getTop();

			// ratchet up top processed intersection if necessary
			if (top.getPerpHeight() > maxHeight) maxHeight = top.getPerpHeight();
			
			// System.err.println(q.size() + "top is " + top);
			// check for bevel/framing event
			if (top.getPerpHeight() > bevel)
			{
				Q.empty();
				// if (allP.size() < 3)
				// continue;
				bevelNow(); // remove all elements
				return;
			}
			
			// dispatch edge event to appropriate handler
			if (top instanceof EdgeEvent)
			{
				edgeEvent(EdgeEvent.class.cast(top));
			}
			else if (top instanceof SplitEvent)
			{
				splitEvent(SplitEvent.class.cast(top));
			}
			else if (top instanceof ConcaveEvent)
			{
				ConcaveEvent tmp = ConcaveEvent.class.cast(top);
				splitEvent(tmp);
			}

			// makeFaeces(itCount,3);
			 
			 //anchor.createPolygon(originalLines.getFace());

		}
		if (maxHeight < bevel) bevelNow();
	}

	private void checkP() // can probably delete this!
	{
		Iterator<CE<Point>> it = allP.iterator();
		while (it.hasNext())
		{
			CE<Point> p = it.next();
			assert (p.next != null);
			assert (p.previous != null);
		}
	}

	/**
	 * Performs a split event on the list of events specified. There will always be more than one elmeent in the list as splitEvent(SplitEvent) creates a new circuit of two events from single event (linking it up correctly) and passes it in here)
	 * 
	 * @param start
	 */
	private void splitEvent(final ConcaveEvent concave)
	{
		CircularList<SplitEvent> start = concave.getSectors();
		CircularIterator<SplitEvent> clit = new CircularIterator(start);
		int splitSize = start.size();
		int splitCount = 0;
		
		FlatPoint middle = concave.location;//start.current.thing.getLocation();
		double middleHeight = concave.perpHeight;//start.current.thing.getPerpHeight();

		
		while (splitCount < splitSize)
		{
			splitCount ++;
			SplitEvent top = clit.next();
			// this line will remove the dummy point added! fix it with a nextedge==previousedge check

			//System.err.println("allP: "+allP.contains(top.getPoint())+" ph:"+top.getPerpHeight()+" "+top.getPoint().thing.getPoint());
			if ((!allP.contains(top.getPoint()) && ((!(top instanceof DummySplitEvent)))) || top.getPerpHeight() < 0)
			{
				splitSize--;
				clit.remove();
			}
			// check these points really belong in a set!
			//assert (Math.abs(middleHeight - top.getPerpHeight()) < 0.0000000001);
			//assert (middle.distanceTo(top.getLocation()) < 0.000000001);
		}
		// check we still have a list!
		if (splitSize == 0)
			return;
		if (splitSize == 1)
		{
			splitEvent(start.current());
			return;
		}

		// loop over all the points in the circle applying the same rule...
		clit = new CircularIterator(start);
		int loopCount = 0;
		while (clit.hasNext())
		{
			loopCount++;
			CE<SplitEvent> current = clit.nextCircular();

			//System.err.println("now splitting " + current.thing.getPoint() + " to " + current.thing.getLocation());

			SplitEvent cse = current.thing;

			// these two are the points at the bases of our intersections
			CE<Point> originPrevious = cse.getPoint();
			CE<Point> originNext = current.next.thing.getPoint();

			// now we know its valid, add the line in!
			addLine(new Edge(middle, middleHeight, originPrevious.thing.getPoint(), originPrevious.thing.getHeight(), 0.),lines, true);

			// remove the old point
			// 2e)
			allP.remove(originPrevious);

			// point on 'left' in Felkel's notes
			Point pL = new Point(new FlatPoint(middle), 
					originPrevious.thing.getNextEdge(), 
					originNext.thing.getPreviousEdge()); // and right:
			pL.setHeight(middleHeight);

			CE<Point> leftPoint = new CE<Point>(pL);

			originPrevious.next.previous = leftPoint;
			leftPoint.next = originPrevious.next;

			leftPoint.previous = originNext.previous;
			originNext.previous.next = leftPoint;

			//System.err.println("previous edge is "+leftPoint.thing.getPreviousEdge());
			//System.err.println("next edge is "+leftPoint.thing.getNextEdge());
			// bind pisectors and intersections of new point
			setBisector(leftPoint);
			//System.err.println("new bisector is "+leftPoint.thing.getBisector());
			findIntersections(leftPoint);
			

			if (!checkForTriangles(leftPoint, null, 0))
				; // last two args unused?
			allP.add(leftPoint);
		}
	}

	/**
	 * concave case
	 * 
	 * @param top
	 */
	private void splitEvent(SplitEvent top)
	{
		checkP();
		// toEdge == null checks for a split event on split event event!
		// 2b)
		if ((!allP.contains(top.getPoint())) || top.getPerpHeight() < 0 || top.getEdge() == null)
			return;

		System.err.println("\nnew top " + top);

		// 2d)
		// System.err.println("added lines from "+top.getPoint().thing.getPoint() + " to "+top.getLocation());
		// System.err.println("height is "+top.getPerpHeight()+" "); // find the edge on the other side that corresponds to the one found,
		// because we look over all points if this edge is on anther polygon we wont
		// find it so we abort.

		CE<Point> leftTopSplit = null;
		// System.err.println("left top edge is "+top.getEdge());

		Iterator<CE<Point>> cep = allP.iterator();
		int secCount = 0;
		while (cep.hasNext())
		{
			CE<Point> p = cep.next();
			// check if top.getLocation is between intersectors specified by this edge.
			// "a soecuak case if nyktuoke stokuttubg if tge edge" in felkels words
			Point firstEnd = p.thing;
			Point secondEnd = p.next.thing;

			FlatPoint s = new FlatPoint(secondEnd.getPoint());
			s.sub(firstEnd.getPoint());
			// inside pisectors bit locates the correct subsection if more than one exists
			if (p.thing.getNextEdge() == top.getEdge() && p.next.thing.getPreviousEdge() == top.getEdge())
			{
				//System.err.println(p.thing.getPoint() + " too " + p.next.thing.getPoint());
				//System.err.println(onLeftOf(firstEnd.getPoint(), firstEnd.getBisector(), top.getLocation()) + " " + onRightOf(secondEnd.getPoint(), secondEnd.getBisector(), top.getLocation()) + onRightOf(firstEnd.getPoint(), s, top.getLocation()));
			}

			if (p.thing.getNextEdge() == top.getEdge() && p.next.thing.getPreviousEdge() == top.getEdge() && // new line!
					insideBisectorsOfEqual(firstEnd, secondEnd, top.getLocation(), s))
			{
				secCount++;
				leftTopSplit = p;
			}
		}
		//System.err.println("intersects are" + secCount);
		// the edge is no longer unprocessed!
		if (leftTopSplit == null)
			return;

		// here's the science! concentrate! we create a new split event at the same
		// height and location as our intersect location. The point it references is
		// invented - the same location as the split event, with its edge pointers both
		// set to the edge found above. The points previous and next are set to both
		// ends of that edge.
		Point pL = new Point(new FlatPoint(top.getLocation()), leftTopSplit.thing.getNextEdge(), leftTopSplit.thing.getNextEdge());
		pL.setHeight(top.getPerpHeight());

		CE<Point> dummyPoint = new CE<Point>(pL);
		dummyPoint.previous = leftTopSplit;
		dummyPoint.next = leftTopSplit.next;

		SplitEvent split = new DummySplitEvent(dummyPoint, top.getPerpHeight(), dummyPoint.thing.getPoint(), leftTopSplit.thing.getNextEdge());

		// create a new wrapper - ConcaveEvent to represent this split
		ConcaveEvent ce = new ConcaveEvent(top.getLocation(),top.getPerpHeight());
		ce.addEvent(top);
		ce.addEvent(split);

		// finally process this as a split point propper!
		splitEvent(ce);
	}

	/**
	 * Border condition necesitates checking for very very small (or far away) triangles for side of a split
	 * 
	 * @param p
	 */
	private boolean checkForTriangles(CE<Point> p, FlatPoint intersection, double h)
	{
		if (p.next.next == p)
		{
			addLine(new Edge(p.thing.getPoint(), p.thing.getHeight(), p.next.thing.getPoint(), p.next.thing.getHeight(), 1),lines, true);
			allP.remove(p.next);
			allP.remove(p);
			return true;
		}
		/*
		 * if (p.next.next.next == p) {
		 * 
		 * addLine(new Edge(p.thing.getPoint(), p.thing.getHeight(), intersection, h,1));
		 * 
		 * addLine(new Edge(p.next.thing.getPoint(), p.next.thing.getHeight(), intersection, h,1));
		 * 
		 * addLine(new Edge(p.next.next.thing.getPoint(), p.next.next.thing.getHeight(), intersection, h,1));
		 * 
		 * allP.remove(p.next.next); allP.remove(p.next); allP.remove(p); return true; }
		 */
		return false;
	}

	/**
	 * convex case
	 * 
	 * @param top
	 * @param circle
	 * @param q
	 */
	private void edgeEvent(EdgeEvent top)
	{
		// if they have both been processed already! this should be OR
		// really?
		// also disgard intersections that occur outside our shape...change
		// this
		// if we wwant to grow a skeleton outwards, and dont add them in the
		// first place!
		if ((!allP.contains(top.getNextPoint())) || (!allP.contains(top.getPreviousPoint())) || top.getPerpHeight() < 0)
		{
			return;
		}

		//System.err.println("\nnew top " + top);

		// formula for finding the height from the speed and perpendicular
		// height
		double height = top.getPerpHeight();

		// System.err.println(" new top==>> "+top.g)
		// final triangle is closing - the peak of the roof :)
		if (top.getNextPoint().next.next == top.getPreviousPoint())
		{
			addLine(new Edge(top.getPreviousPoint().thing.getPoint(), top.getPreviousPoint().thing.getHeight(),
			// 0 speed!
					top.getLocation(), height, 0),lines, true);
			addLine(new Edge(top.getNextPoint().thing.getPoint(), top.getNextPoint().thing.getHeight(), top.getLocation(), height, 0),lines, true);
			Edge tmp = new Edge(top.getPreviousPoint().previous.thing.getPoint(), top.getPreviousPoint().previous.thing.getHeight(), top.getLocation(), height, 0);
			// tmp.addType(ROOFLINE);
			addLine(tmp,lines, true);
			// System.err.println("made final part of roof :)");

			allP.remove(top.getNextPoint());
			allP.remove(top.getPreviousPoint());
			allP.remove(top.getPreviousPoint().previous);

			return;
		}
		// output the two new lines
		// System.err.println("adding edge now");
		addLine(new Edge(top.getPreviousPoint().thing.getPoint(), top.getPreviousPoint().thing.getHeight(), top.getLocation(), height, 0),lines, true); // top.getPerpHeight()
		addLine(new Edge(top.getNextPoint().thing.getPoint(), top.getNextPoint().thing.getHeight(), top.getLocation(), height, 0),lines, true); // top.getPerpHeight()
		// mark as processed
		allP.remove(top.getPreviousPoint());
		allP.remove(top.getNextPoint());

		Point point = new Point(top.getLocation(), top.getNextPoint().thing.getNextEdge(), top.getPreviousPoint().thing.getPreviousEdge());
		point.setHeight(height);

		/*
		 * System.err.println("perp height is from below is "+top.getPerpHeight()); double pNext = heightPerpendicular(point.getNextEdge().getFirst(), point.getNextEdge().getSecond(), point.getPoint()); System.err.println("perp height is from next is "+pNext); double pPrev = heightPerpendicular(point.getPreviousEdge().getFirst(), point.getPreviousEdge().getSecond(), point.getPoint()); System.err.println("perp height is from previous is "+pPrev);
		 */

		// insert into circular list, removing the two other that it takes
		// the place of
		CE<Point> newCircle = new CE<Point>(point);

		/*
		 * circle.select(top.getPreviousPoint()); circle.replace(newCircle); circle.select(top.getNextPoint()); circle.remove();
		 */

		top.getPreviousPoint().previous.next = newCircle;
		top.getNextPoint().next.previous = newCircle;
		newCircle.previous = top.getPreviousPoint().previous;
		newCircle.next = top.getNextPoint().next;

		allP.add(newCircle);

		// finally set bisector and calculate collisions with nearby
		// offenders
		setBisector(newCircle);
		//System.err.println("new bisector is " + newCircle.get().getBisector());
		findIntersections(newCircle);
		// find intersections of new point
		//System.err.println("new bisector is now " + newCircle.get().getBisector());

	}

	/**
	 * My procedure to bevel this frame, no need to care about face direction, all taken care of later - just making a graph for now
	 */
	private void bevelNow()
	{
		CE<Point> current = null;
		// FlatPoint lastEdge = null;
		// FlatPoint edgeIntersect = null, firstEdge = null;
		// stop execution of futher collisions by emptying queue
		// run through all points in the current list
		//System.err.println("now bevling");
		Iterator<CE<Point>> cip = allP.iterator();

		while (cip.hasNext())
		{
			current = cip.next();
			setBisector(current);
			Edge one = current.thing.getNextEdge();
			Edge two = current.thing.getPreviousEdge();
			FlatPoint edgeIntersect = intersectEndPoints(one.getFirst(), one.getSecond(), two.getFirst(), two.getSecond());
			Vector2d bisec = new Vector2d(current.thing.getBisector());

			bisec.scale(bevel);
			double height = bevel;
			edgeIntersect.add(bisec);
			Edge f = new Edge(current.thing.getPoint(), current.thing.getHeight(), edgeIntersect, height, 0);
			addLine(f,lines, true);

			// we could cache this lot, but this is not about speed...yet
			Edge three = current.previous.thing.getPreviousEdge();
			FlatPoint edgeIntersect23 = intersectEndPoints(two.getFirst(), two.getSecond(), three.getFirst(), three.getSecond());
			Vector2d bisec23 = new Vector2d(current.previous.thing.getBisector());
			bisec23.scale(bevel);
			edgeIntersect23.add(bisec23);

			// all interior points are at a height of 'bevel'!
			Edge e = new Edge(edgeIntersect, height, edgeIntersect23, height, 0);
			e.addType(BEVELTOP);
			// System.err.println("bevel added "+e+"\n and "+f);
			addLine(e,lines, true);
			addLine(e,flatTop, false); // add to list of lines that for top of roof if bevelled
		}
	}

	/**
	 * 
	 * @return the list of sheafs that comprise the flat tops of the roofs, if they have been bevelled
	 * @param ref the reference sheet that this skeleton was constructed with
	 * @double height the bevel hight specified elsewhere 
	 */
	public List<Sheaf> findFlatTop(Sheaf ref, double height)
	{
		List<Sheaf>output = new Vector<Sheaf>();
		
		List<FlatPoint> sfp = new ArrayList<FlatPoint>(flatTop.keySet());
		
		while (sfp.size() > 0)
		{
			FlatPoint first = sfp.get(0);
			FlatPoint orig = first;
			FlatPoint second = null;
			SheetBuilder sb = new SheetBuilder(ref);
			while (second == null || !second.samePlaceAs(orig))
			{
				if (second != null) first = second;
				Vector<Edge> options = flatTop.get(first);
				if (options.size() != 1)
				{
					fatalErrorSD("Something wrong with the bevelling procedure in findflattop!");
				}
				else
				{
					Edge e = options.get(0);
					sb.addPoint(e.getFirst().x,e.getFirst().y, height);
					second = e.getSecond();
					sfp.remove(e.getFirst());
				}
				
			}
			output.add(sb.makeSheaf());//new Sheaf(sb.makeSheet()));
		}
		return output;
	}

	/**
	 * The edges that make up the sides of the skeleton, if no beveling has taken place then this is the only output.
	 * 
	 * @return
	 */
	public List<List<Edge>> getSides()
	{
		return allPolys;
	}

	/**
	 * Debugging code, outputs the edges as faces instead :) very pretty
	 * 
	 */
	public void makeFaeces(int in, int xOffset)
	{
		Collection<Vector<Edge>> d = lines.values();
		Iterator<Vector<Edge>> vit = d.iterator();
		while (vit.hasNext())
		{
			Iterator<Edge> edit = vit.next().iterator();
			while (edit.hasNext())
			{
				Edge e = edit.next();

				FlatPoint p = new FlatPoint(e.getFirst());
				p.add(new Vector2d(in * xOffset, 0));
				FlatPoint q = new FlatPoint(e.getSecond());
				q.add(new Vector2d(in * xOffset, 0));

				List<Edge> poly = new Vector<Edge>();
				allPolys.add(poly);

				Edge x1 = new Edge(p, 0, q, 0, 0);
				Edge x2 = new Edge(q, 0, p, 1, 0);
				Edge x3 = new Edge(p, 1, p, 0, 0);

				/*
				 * Edge x1 = new Edge(p,0,new FlatPoint(p.x-1, p.y),1,0); Edge x2 = new Edge(new FlatPoint(p.x-1, p.y),1,new FlatPoint(p.x+1, p.y),1,0); Edge x3 = new Edge(new FlatPoint(p.x+1, p.y),1,p,0,0);
				 */
				poly.add(x1);
				poly.add(x2);
				poly.add(x3);
			}
		}
	}

	/**
	 * Now navigate the list of orignal edges and, preserving a clockwise direction, produce a list of faces as output. We search for the smallest interior angle from each vertex.
	 * 
	 */
	public void makeFaeces2()
	{
		Iterator<Sheet> shit = originalLines.getSheets().iterator();

		while (shit.hasNext())
		{
			Sheet sheet = shit.next();
			Iterator<CEFP> it = new CEFPIterator(sheet.getFirst());
			// intiating first point is one step backwards around circum
			FlatPoint first = sheet.getFirst().previous.thing;
			while (it.hasNext())
			{
				CEFP fC = it.next();
				first = fC.thing;
				FlatPoint second = fC.next.thing;
				 //System.err.println("**********************"+first+second);
				FlatPoint lastPoint = null, beforeLast = null;
				List<Edge> poly = new Vector<Edge>();
				allPolys.add(poly);
				Edge tmp = new Edge(first, 0, second, 0, 0, first.getType());
				tmp.addType(REFERENCE); // this is the bottom section
				poly.add(tmp);
				lastPoint = second;
				beforeLast = first;
				int count = 0; // debug var
				// find list of applicable edges from hashtable
				while (lastPoint != first)
				{
					count++;
					if (count > 20)
						assert (false);
					Vector<Edge> v = lines.get(lastPoint);
					 //System.err.println("looking for "+lastPoint);
					if (v == null)
					{
						fatalErrorSD("no joining vertexes found for vertex " + second);
					}
					// find the edge which gives the smallest angle
					Edge best = null;
					double smallest = Double.MAX_VALUE;
					Iterator<Edge> edit = v.iterator();
					while (edit.hasNext())
					{
						Edge e = edit.next();
						// we dont go back from where we came...
						if (e.getSecond().equals(beforeLast))
							continue;
						assert e.getFirst().equals(lastPoint) : "faces in hash are not what where asked for";
						double angle = angleBetween(beforeLast, lastPoint, e.getSecond());
						if (angle > PI)
						{
							angle = 3 * PI - angle;
						}
						else
						{
							angle = PI - angle;
						}
						 //System.err.println("bl:"+ beforeLast + " l:"+ lastPoint +" s:"+e.getSecond());
						 //System.err.println("candidate "+e+"\n "+angle);
						if (angle < smallest)
						{
							smallest = angle;
							best = e;
						}
					}
					 //System.err.println("adding "+best);
					assert (best != null) : " "+first+" "+second;
					poly.add(best);

					lastPoint = best.getSecond();
					beforeLast = best.getFirst();
				}
			}
		}
	}

	/**
	 * Adds the specified line (in both directions....) to the hashtable of all lines
	 * 
	 * @param e1
	 * @param bothWays TODO
	 */
	public void addLine(Edge e1, Map<FlatPoint, Vector<Edge>> map, boolean bothWays)
	{
		// dont accept 0 length lines - sometimes get them thro symmetry
		if (e1.getFirst().equals(e1.getSecond()))
			return;
		// if (e1.getFirst().distanceTo(e1.getSecond()) < 0.00000000000001) return;
		// all added lines are roof edges
		e1.addType(ROOFEDGE);
		Edge e2 = new Edge(e1); // roofline copied to e2 automagically
		Vector<Edge> v = map.get(e1.getFirst());
		if (v == null)
		{
			Vector<Edge> n = new Vector<Edge>();
			map.put(e1.getFirst(), n);
			v = n;
		}
		v.add(e1);
		if (bothWays)
		{
			v = map.get(e2.getFirst());
			if (v == null)
			{
				Vector<Edge> n = new Vector<Edge>();
				map.put(e2.getFirst(), n);
				v = n;
			}
			v.add(e2);
		}
	}

	/**
	 * Sets the bisector vector inside the Point, using the edges specified to locate their intersection...
	 * 
	 * Speed complication is that intersection can happen in front of the end of the next line or behind the start of the previous line, so what we do is find intersection point of two lines subtract previous edge vector to find previous point add next edge vector to find next point
	 * 
	 * @param point
	 */
	private void setBisector(CE<Point> point)
	{

		Triple<FlatPoint, FlatPoint, FlatPoint> res = getPointsForAngle(point);
		FlatPoint previous = res.first();
		FlatPoint intersect = res.second();
		FlatPoint next = res.third();
		Vector2d bisec = shrink_OLD(previous, intersect, next, point.thing.getPreviousEdge().getSpeed(), point.thing.getNextEdge().getSpeed());
	    //System.err.println("bisec edges are "+point.thing.getNextEdge()+" :: "+point.thing.getPreviousEdge());
	    //System.err.println("bisec gpa is "+res);

		if (Double.isInfinite(bisec.x))
		{
			//assert(false);
			// situation where the vector moves back on itself -
			// should be a zero sized vector, but for borderlines, we'll live
			// with very very small.
			Vector2d o = new Vector2d(next);
			o.sub(intersect);
			o.scale(1E7);
			System.err.println("infinite bisector set to "+o);
			bisec = o;
		}

		if (Double.isNaN(bisec.x))
		{
			// this is the case that both the lines are parrallel, and moving against each other
			Vector2d o = new Vector2d(next);
			o.sub(intersect);
			o.scale(1E7);
			bisec = o;
			System.err.println("warning NaN in setBisector - is this perpendiccular?"+o);
			/*
			 * System.err.println("after left we have "); CircularIterator<Point> cit = new CircularIterator<Point>(point); while (cit.hasNext()) { CircularElement<Point> ce = cit.nextCircular(); System.err.println((ce.next.thing)+"\n "+ce.thing+"\n "+ce.previous.thing); System.err.println("\n"); }
			 * 
			 * 
			 * System.err.println("finding bisector at " + point.get().getPoint()); System.err.println("previous " + previous + "\ncurrent " + intersect + "\nnext " + next); System.err.println("speed before " + point.thing.getPreviousEdge().getSpeed()); System.err.println("speed after " + point.thing.getNextEdge().getSpeed()); System.err.println("bisector was " + point.thing.getBisector() + "\n"); assert (false);
			 */
		}
		FlatPoint bisecEnd = new FlatPoint(point.thing.getPoint());
		bisecEnd.add(bisec);
		// if the bisector intersects the base at poitive parameter
		Triple<FlatPoint, Double, Double> baseSec = intersectBetween(point.thing.getPoint(), point.thing.getPreviousEdge().getSecond(), bisecEnd, point.thing.getNextEdge().getFirst(), false);

		// System.err.println("bisec says "+bisec);
		if (baseSec != null && baseSec.second() > 0. && baseSec.third() >= 0 && baseSec.third() <= 1)
		{
			//bisec.negate();
		}
		// copy to the bisector variable
		point.thing.setBisector(bisec);
	}

	private Triple<FlatPoint, FlatPoint, FlatPoint> getPointsForAngle(CE<Point> point)
	{
		return getPointsForAngleEdge(point.thing.getPreviousEdge(), point.thing.getNextEdge(), point);
	}

	/**
	 * Performs a calculation to find the relative intersect points for the specified point and its current edges.
	 */
	private Triple<FlatPoint, FlatPoint, FlatPoint> getPointsForAngleEdge(Edge previousE, Edge nextE, CE<Point> point)
	{

		// Edge previousE = point.thing.getPreviousEdge();
		FlatPoint previous = new FlatPoint(previousE.getSecond());
		previous.sub(previousE.getFirst());

		// previous.negate();

		// Edge nextE = point.thing.getNextEdge();
		FlatPoint next = new FlatPoint(nextE.getSecond());
		next.sub(nextE.getFirst());

		next.add(previous);

		return new Triple<FlatPoint, FlatPoint, FlatPoint>(new FlatPoint(0, 0), previous, next);

		/*
		 * last attempt! //vecotrs involved. //Edge previousE = point.thing.getPreviousEdge(); FlatPoint previous = new FlatPoint(previousE.getFirst()); previous.sub(previousE.getSecond());
		 * 
		 * //previous.negate();
		 * 
		 * //Edge nextE = point.thing.getNextEdge(); FlatPoint next = new FlatPoint(nextE.getSecond()); next.sub(nextE.getFirst());
		 *  // move the second one to the start of the first return new Triple<FlatPoint, FlatPoint, FlatPoint>(previous, new FlatPoint(0,0), next);
		 */

		// move teh
		// FlatPoint intersect = intersectEndPoints(previousE.getFirst(), previousE.getSecond(), nextE.getFirst(), nextE.getSecond());

		// System.err.println("to find intersect"+previousE.getFirst()+ previousE.getSecond()+
		// nextE.getFirst()+ nextE.getSecond());
		// System.err.println("intersection at "+intersect);

		// if (intersect == null && point != null)
		// {
		// lines are parallel, make up something kinda convincing...
		// Vector2d tmp = new Vector2d(nextE.getSecond());
		// tmp.sub(nextE.getFirst());
		// tmp.normalize();
		// tmp.scale((previousE.getSpeed() + nextE.getSpeed()) / 2);
		// System.err.println(" lines are parallel: setting it to "+tmp);
		// point.thing.setBisector(tmp);
		// return new Triple<FlatPoint, FlatPoint, FlatPoint>(previous, intersect, next);
		// intersect = new FlatPoint(previousE.getSecond());
		// }
		// if (previous.distanceTo(intersect) < 0.00001)
		// {
		// move previous point backward
		// Vector2d prev = new Vector2d(previousE.getSecond());
		// prev.sub(previousE.getFirst());
		// previous = new FlatPoint(intersect);
		// previous.sub(prev);
		// }
		// if (next.distanceTo(intersect) < 0.00001)
		// {
		// move previous point backward
		// Vector2d nxt = new Vector2d(nextE.getSecond());
		// nxt.sub(nextE.getFirst());
		// next = new FlatPoint(intersect);
		// next.add(nxt);
		// }
		// return new Triple<FlatPoint, FlatPoint, FlatPoint>(previous, intersect, next);
	}

	/**
	 * Calculates intersection between these two points 1.792
	 * 
	 * @param point
	 */
	private void findEdgeEvent(CE<Point> point, CE<Point> nextPoint)
	{
		Point me = point.thing;
		Point onLeft = nextPoint.thing; // changed from previous?!

		// Triple<FlatPoint,FlatPoint,FlatPoint> res = getPointsForAngle(point);
		FlatPoint collision = intersectInFront(me.getPoint(), onLeft.getPoint(), me.getBisector(), onLeft.getBisector());

		// System.err.println("find edge event of "+point.thing+" against "+nextPoint.thing);

		if (collision == null)
		{
			// System.err.println("no collision here");
			return;
		}
		// System.err.println("point is "+point.thing.getPoint()+" onL "+point.next.thing.getPoint());
		// System.err.println("bisectors are "+me.getBisector()+ " "+onLeft.getBisector());
		// System.err.println("collision i s" +collision);

		// perpendicular height above line between two points!
		Edge heightFrom = point.thing.getNextEdge();
		// assert (heightFrom == nextPoint.thing.getPreviousEdge());
		double pHeight = heightPerpendicular(heightFrom.getFirst(), heightFrom.getSecond(), collision);
		// we have to check two heights to ensure that the collision is valid
		// and not a borderline case of parallel bisectors meeting at an arbitrary location
		// Edge heightFrom2 = point.thing.getPreviousEdge();
		// double pHeight2 = heightPerpendicular(heightFrom2.getFirst(), heightFrom2
		// .getSecond(), collision);
		// if (Math.abs(pHeight - pHeight2) > 0.000001) return;

		// System.err.println("height = "+pHeight+" location "+collision);

		pHeight = pHeight / point.thing.getNextEdge().getSpeed();
		Intersection i = new EdgeEvent(nextPoint, point, pHeight, collision);

		// pHeights < 0 happen outside are shape and we're not interested!
		if (pHeight >= 0)
			Q.add(i);
	}

	/**
	 * Finds splits events and adds them to the priority queue
	 * 
	 * For each line section in the current circle we find the intersection of the bisector with it. This may be outside the edge's vertices...
	 * 
	 * we then fid the midpoint on this line (scaled by relative bisector speeds) and check that it is between the bisectors of the corners of l.
	 * 
	 */
	private void findSplitEvent(CE<Point> in)
	{
		Point me = in.thing;

		/*
		 * System.err.println(in.previous.thing.getPoint() + " " + in.next.thing.getPoint()); System.err.println(originalCircle);
		 */
		CE<Point> a;// = originalCircle.current;

		double bestHeight = Double.MAX_VALUE;
		double bestOther = 69; // debug var
		// double bestOther2 = 69; //debug var
		FlatPoint bestPoint = null;
		Edge bestEdge = null;

		// System.err.println("********** Splitting "+in.thing.getPoint()+" l "+in.thing.getBisector());

		Iterator<CE<Point>> ceit = originalCircle.iterator();

		while (ceit.hasNext())
		{
			a = ceit.next();
			CE<Point> b = a.next; // this is new!
			// find b's bisector

			// dont intersect with lines that will intersect at base of in.thing.getPoint()
			if (a.thing.equals(in.thing) || b.thing.equals(in.thing))
			{
				continue;
			}
			


			// check for intersection with own base points - a possiblity with a double cross.
			//if (a.thing.getNextEdge() == in.thing.getNextEdge() ||
			//		a.thing.getNextEdge() == in.thing.getPreviousEdge())
			//{
			//	continue;
			//}
					
				

			FlatPoint s = new FlatPoint(b.thing.getPoint());
			s.sub(a.thing.getPoint());
			// System.err.println(a.thing.getPoint()+" to "+b.thing.getPoint());

			Vector2d tmp = new Vector2d(in.thing.getPoint());
			tmp.add(in.thing.getBisector());
			Triple<FlatPoint, Double, Double> sect = intersectBetween(in.thing.getPoint(), a.thing.getPoint(), tmp, b.thing.getPoint(), false);
			// borderline case - ignore cases where the intersect doesnt exist between parallel lines

			if (sect == null)
				continue;
			// intersect must be infrom of the point in the direction of the bisector, but
			// may lie on any point on the line ab
			if (sect.second() < 0)
				continue;

			// line from a to b, find intersector with in's bisector
			FlatPoint i = sect.first();

			if (i == null)
				continue;

			// System.err.println("FSE a,b"+a.thing+b.thing);
			// System.err.println("FSE says intersection at"+sect);

			double oAngle = angleBetween(new Vector2d(0, 1), s) - PI / 2;
			FlatPoint oIntersect = intersect(in.thing.getPoint(), a.thing.getPoint(), new Vector2d(sin(oAngle), cos(oAngle)), s);
			// System.err.println(oAngle +" angle is "+new Vector2d(sin(oAngle),cos(oAngle)));
			// System.err.println("oInt "+oIntersect+" point "+in.thing.getPoint() +" other intersect "+i);
			oAngle = PI - angleBetween(oIntersect, in.thing.getPoint(), i);
			// System.err.println("oangle is "+oAngle);

			// find the speed of the opposite line towards concave cave...
			double fromOther = a.thing.getNextEdge().getSpeed() / cos(oAngle);
			double fromThis = in.thing.getBisector().length();

			FlatPoint origin = intersectEndPoints(in.thing.getPreviousEdge().getFirst(), in.thing.getPreviousEdge().getSecond(), in.thing.getNextEdge().getFirst(), in.thing.getNextEdge().getSecond());
			if (origin == null)
			{
				// the two edges are parallel!, origin is intersection between either
				// of the two edges and the line made from the point in question and its
				// bisector
				// System.err.println("Skelton.findSplitEvents is says the edges are parallel!");
				// System.err.println(in.thing.getPreviousEdge());
				// System.err.println(in.thing.getNextEdge());
				tmp = new FlatPoint(in.thing.getPoint());
				tmp.sub(in.thing.getBisector());
				origin = intersect(in.thing.getPreviousEdge().getFirst(), in.thing.getPreviousEdge().getSecond(), in.thing.getPoint(), tmp);
				continue;
			}

			// a check for the point being behind the origin in the case
			// of a backwards facing bisector
			//tmp = new Vector2d(in.thing.getPoint());
			//tmp.add(in.thing.getBisector());
			//if (origin.distanceTo(in.get().getPoint()) < origin.distanceTo(tmp))
			//{
				// continue;
			//}

			// distance from here to
			double total = origin.distanceTo(i);
			// System.err.println("origin "+origin+" intersect "+i);
			// assert(total>0);
			// find centre point
			FlatPoint pnt = new FlatPoint(me.getBisector());
			pnt.normalize();
			// System.err.println("fromThis "+fromThis+" from other "+fromOther+" total "+total);
			pnt.scale(fromThis * total / (fromThis + fromOther));
			FlatPoint l = new FlatPoint(origin);
			l.add(pnt);

			// System.err.println("intersection would be "+l);

			double oldheight = heightPerpendicular(a.thing.getPoint(), b.thing.getPoint(), l) / a.thing.getNextEdge().getSpeed();

			/*
			 * double oldheight2 = heightPerpendicular(in.thing.getNextEdge().getFirst(), in.thing.getNextEdge().getSecond(), l)/ in.thing.getNextEdge().getSpeed();
			 */
			double height = heightPerpendicular(in.thing.getPreviousEdge().getFirst(), in.thing.getPreviousEdge().getSecond(), l) / in.thing.getPreviousEdge().getSpeed();
			
			// System.err.println(onLeftOf(a.thing.getPoint(), a.thing.getBisector(), l));
			// System.err.println(a.thing.getPoint()+" [[]] "+ a.thing.getBisector());

			// System.err.println(""+onRightOf(b.thing.getPoint(), b.thing.getBisector(), l));
			// System.err.println(b.thing.getPoint()+" (()) "+ b.thing.getBisector());

			// System.err.println(onRightOf(a.thing.getPoint(), s, l));

			// System.err.println(a.thing.getPoint()+" <<>> " + s);
			// System.err.println(height < bestHeight) ;

			// if intersect lies between a,b's intersectors, and isn't outside
			// the shape...
			if (insideBisectorsOf(a.thing, b.thing, l, s) && height < bestHeight)
			{
				// System.err.println("????????????? Tis good");
				// point is valid
				bestHeight = height;
				bestOther = oldheight;
				// bestOther2 = oldheight2;
				bestPoint = l;
				bestEdge = a.thing.getNextEdge();
			}
		}
		
		
		//System.err.println("interseciton point is" + bestPoint);
		// System.err.println("oppostite "+bestOther+"\n previous: "+bestHeight);

		//System.err.println("edge is " + bestEdge);

		SplitEvent i;
		if (bestPoint != null) 
		{
			i = new SplitEvent(in, bestHeight, bestPoint, bestEdge);
			//System.err.println("addin split event "+i);
			Q.add(i);
		}
		else
		{
			 i = new SplitEvent(in,Double.MAX_VALUE,null,null);
		}
		// continuation function!
		checkForConcanveIntersections(i);
	}

	/**
	 * This is only expected to run against small numbers of concave pts
	 * so is very unoptimised!
	 * @param in the split event to check
	 */
	private void checkForConcanveIntersections(final SplitEvent in)
	{
		// now we go through all concave pts checking for intersections with any of the other
		//splitEvents therein. If we find one we add it to a ConcaveEvent event if it alread
		// exists else we create a new concave event at the end
		Collection<ConcaveEvent> events = new Vector<ConcaveEvent>();
		List<SplitEvent> splits    = new Vector<SplitEvent>();
		
		// collect existing concave events - we should cache this!
		Iterator<Intersection>iit = Q.iterator();
		while (iit.hasNext())
		{
			Intersection sec = iit.next();
			if (sec instanceof ConcaveEvent) events.add(ConcaveEvent.class.cast(sec));
		}
		
		// search the pts for split events
		Iterator<CE<Point>> it = allP.iterator();
		//System.err.println("now xamininig "+in.getPoint().thing.getPoint());
		while (it.hasNext())
		{
			CE<Point> split = it.next();
			Triple<FlatPoint, FlatPoint, FlatPoint> res = getPointsForAngle(split);
			if (angleBetween(res.first(), res.second(), res.third()) > PI &&
					split!=in.getPoint())
			{
				//System.err.println("aghanst "+split.thing.getPoint());
				// if any of these events bisect this point split event
				// in front of the point, they are added to the relevent concave event if relevant, else
				// they are added to a list of locations to be added at the end
				FlatPoint fp = intersectInFront(split.thing.getPoint(), in.getPoint().thing.getPoint(),
						split.thing.getBisector(), in.getPoint().thing.getBisector());
				// if in front!
				if (fp != null)
				{
					//System.err.println("found one "+split.thing.getPoint()+" and  "+in.getPoint().thing.getPoint()+" @ "+fp);  
					// height is perpendiular height above either points lines
					Edge e = in.getPoint().thing.getNextEdge();
					double h1 = heightPerpendicular(e.getFirst(), e.getSecond(),fp);
					// should be the same on the other!
					Edge e2 = split.thing.getNextEdge();
					double h2 = heightPerpendicular(e2.getFirst(), e2.getSecond(),fp);
					//assert (Math.abs(h-heightPerpendicular(split.thing.getNextEdge().getFirst(),
					//		split.thing.getNextEdge().getSecond(), fp)) < 0.000001): h+" : "+heightPerpendicular(split.thing.getNextEdge().getFirst(),split.thing.getNextEdge().getSecond(), fp);

					//System.err.println("h1"+h1+"h2"+h2);
					if (Math.abs(h1-h2) < 0.000000000001)
					splits.add(new SplitEvent(split,h2,fp,null));
				}
			}
		}
		// now for each intersection found check its already in some 
		Iterator<SplitEvent> sit = splits.iterator();
		List<ConcaveEvent> create = new Vector<ConcaveEvent>();
		while (sit.hasNext())
		{
			SplitEvent against = sit.next();
			Iterator<ConcaveEvent> eit = events.iterator();
			boolean done = false;
			while (eit.hasNext())
			{
				ConcaveEvent ce = eit.next();
				if (ce.location.distanceTo(against.location) < 0.0000000001 && Math.abs(ce.getPerpHeight()-against.perpHeight) < 0.000000001)
				{
					SplitEvent n = new SplitEvent(in.getPoint(),against.perpHeight,against.location,null);
					ce.addEvent(n);
					done = true;
					break;
				}
			}
			if (!done)
			{
				ConcaveEvent ce = new ConcaveEvent(against.location,against.perpHeight);
				ce.addEvent(against);
				SplitEvent n = new SplitEvent(in.getPoint(),against.perpHeight,against.location,null);
				ce.addEvent(n);
				create.add(ce);
			}
		}

		// add all new concave events to the event q
		Iterator<ConcaveEvent>cit = create.iterator();
		while (cit.hasNext())
		{
			ConcaveEvent tmp = cit.next();
			//System.err.println("added to Q");
			Q.add(tmp);
		}
	}
	
	/**
	 * Checks that the specified
	 * 
	 * @param left
	 * @param right
	 * @param l
	 *            the point to check intersections of
	 * @param leftToRight -
	 *            orientation of b from a?
	 * @return
	 */
	private boolean insideBisectorsOf(Point first, Point second, FlatPoint l, Vector2d leftToRight)
	{
		return onLeftOf(first.getPoint(), first.getBisector(), l) && onRightOf(second.getPoint(), second.getBisector(), l) && onRightOf(first.getPoint(), leftToRight, l);
	}
	
	private boolean insideBisectorsOfEqual(Point first, Point second, FlatPoint l, Vector2d leftToRight)
	{
		return onEqualLeftOf(first.getPoint(), first.getBisector(), l) && onEqualRightOf(second.getPoint(), second.getBisector(), l) && onEqualRightOf(first.getPoint(), leftToRight, l);
	}

	/**
	 * looks for edge and split intersections for this point
	 * 
	 * @param point
	 * @param c
	 */
	private void findIntersections(CE<Point> point)
	{
		// catch points that are just pairs
		if (point.next.next == point)
		{ // dont think we need this, but might do us good one day
			// addLine(new Edge(point.thing.getPoint(), point.thing.getHeight(), point.next.thing.getPoint(), point.next.thing.getHeight(), 0));
		}

		Triple<FlatPoint, FlatPoint, FlatPoint> res = getPointsForAngle(point);

		// System.err.println("findIntersections for "+point+" "+angleBetween(res.first(), res.second(), res.third()));
		// System.err.println("bisec: "+point.thing.getBisector());
		// System.err.println(res);
		if (angleBetween(res.first(), res.second(), res.third()) <= PI)
		{ // convex

			// System.err.println("look for convex");
			findEdgeEvent(point, point.next);
			findEdgeEvent(point.previous, point);
		}
		else
		// concave
		{
			// System.err.println("look for concave");
			findSplitEvent(point);

		}
	}

	/**
	 * Prodces a list of sheets for gutter connected edges from the internal data structures.
	 * 
	 * @param in
	 *            the reference sheet
	 * @param steep
	 *            a number saying how raised each sheet should be
	 * @return
	 */
	public List<Sheaf> makeSideSheets(Sheaf in, double steep)
	{
		List<Sheaf> output = new Vector<Sheaf>();// Sheaf(in.getTransform());
		Iterator<List<Edge>> outside = allPolys.iterator();

		while (outside.hasNext())
		{
			Iterator<Edge> it = outside.next().iterator();

			// Point3d other = new Point3d(second.getFirst().x, second.getFirst().y, second.getFirstHeight());
			// List<FlatPoint> togo = new Vector<FlatPoint>();

			SheetBuilder sb = new SheetBuilder(in);
			while (it.hasNext())
			{
				Edge x = it.next();
				if (x.length() > 0.00000000001)
				{
					Point3d e = new Point3d(x.getFirst().x, x.getFirst().y, x.getFirstHeight() * steep);
					sb.addPoint(e.x, e.y, e.z);
				}
			}
			Sheaf sf = sb.makeSheaf();
			if (sf != null)
				output.add(sf);
		}

		return output;
	}
}
