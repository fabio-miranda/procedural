package junk;

import static sity.Parameters.*;
import junk.*;
import geom.FlatPoint;

/**
 * Wrapping class for either edgeevent or splitevent :)
 * @author people
 *
 */
public abstract class Intersection implements Comparable
{
	protected double perpHeight = 0;
	protected FlatPoint location;
	// this is the amount of priority we give to intersections
	// close to their points. Important for annoying borderline cases
	private final static double MIN_FAC = 0.0001;
	
	public FlatPoint getLocation()
	{
		return location;
	}
	public void setLocation(FlatPoint location)
	{
		this.location = location;
	}
	public double getPerpHeight()
	{
		return perpHeight;
	}
	public void setPerpHeight(double perpHeight)
	{
		this.perpHeight = perpHeight;
	}
	
	public abstract double maxDist();
	
	/**
	 * We can just compare by the perpendicular height
	 * @param in
	 * @return
	 */
	public int compareTo(Object in)
	{
		if (perpHeight == -1)
			fatalErrorSD("Comparable not set up in skeleton.Intersection");
		if (in instanceof Intersection)
		{
			Intersection other = Intersection.class.cast(in);
			
			double height = perpHeight-maxDist()*MIN_FAC - (other.getPerpHeight()-other.maxDist()*MIN_FAC);
			
			if (height < 0)
			{
				return -1;
			}
			else if (height == 0)
			{
				// in a tiebreak choose a edgeevent!
				if (this instanceof EdgeEvent && in instanceof SplitEvent)
					return -1;
				else if (this instanceof SplitEvent && in instanceof EdgeEvent)
					return 1;
				
				return 0;
			}
			else return 1;
		}
		else
		{
			// not comparable!
			return 0; 
		}
	}
}
