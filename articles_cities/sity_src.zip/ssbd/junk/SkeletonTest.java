package junk;

import static geom.EdgeType.STREET;
import static sity.Parameters.*;
import geom.*;

import java.util.*;

import junit.framework.TestCase;

/**
 * A set of tests for analysing the straight skelton. Result has to examined manually, so remove the xx's!
 * 
 * @author people
 * 
 */
public class SkeletonTest extends TestCase
{
	// shape from hell - lip shape
	double data1[][] = { { 0, 0.5, 1 }, // 0.000001 breaks it
			{ 2, 1, 1 }, { 2.5, 0.8, 1 }, { 3, 1, 1 }, { 5, 0.5, 1 }, { 3, 0, 1 }, { 2.5, 0.2, 1 }, { 2, 0, 1 } };

	// wonkey triangle with split
	double data2[][] = { { 2.5, 0, 1 }, { 0, 0, 1 }, { 1.25, 1, 1 }, { 1.5, 2, 1 }, { 1.75, 1.5, 1 }, { 2, 2, 1 } };

	// one split trapezoid
	double data3[][] = { { 2.6, 0, 1 }, { 0, 0, 1 }, { 1.5, 2, 1 }, { 1.75, 1.5, 1 }, { 2, 2, 2 } };

	// one split trapezoid
	double data4[][] = { { 2.5, 0, 1 }, { 0, 0, 1 }, { 0.5, 2, 1 }, { 1.5, 2, 1 }, { 1.75, 1.5, 1 }, { 2, 2, 2 } };

	double data5[][] = { { 0, -1, 1 }, { 0, 2, 1 }, { 1, 2, 1 }, { 1, 0.55, 1 }, { 0.8, 0.5, 1 }, { 1, 0.45, 1 }, { 1, -1, 1 } };

	// normal double split shape with slope
	double data6[][] = {{ 2.5, 0, 1 }, { 0, 0, 1 }, { 0.5, 2, 1 }, { 0.75, 1.5, 1 }, { 1, 2, 1 }, { 1.25, 1, 1 }, { 1.5, 2, 1 }, { 1.75, 1.5, 1 }, { 2, 2, 2 } }; 
	
	// four way medal cross
	double data7[][] = {
			{0.7,1,1},{0.5,0.5,1} , {1,0.7,1}, 
			{1, -0.7,1},{0.5,-0.5,1},{0.7,-1,1},
			{-0.7,-1,1},{-0.5,-0.5,1},{-1,-0.7,1},
			{-1,0.7,1},{-0.5,0.5,1},{-0.7,1,1}};
	
	// half medal with convex bisector simultainiuos intersect
	double data8[][] = {
			{0.7,1,1},{0.5,0.5,1} , {1,0.7,1},  {1,-1,1}, {-1,-1,1},
			{-1,0.7,1},{-0.5,0.5,1},{-0.7,1,1}};
	// and without
	double data9[][] = {
			{0.7,1,1},{0.5,0.5,1} , {1,0.7,1},  {1,-1.5,1}, {-1,-1.5,1},
			{-1,0.7,1},{-0.5,0.5,1},{-0.7,1,1}};
	
	// half medal with wonkeyconvex bisector 
	double data10[][] = {
			{0.7,1,1},{0.4,0.5,1} , {1,0.7,1},  {1,-1,1}, {-1,-1,1},
			{-1,0.7,1},{-0.5,0.5,1},{-0.7,1,1}};

	public void testManual()
	{
		Vector<double[][]> data = new Vector<double[][]>();
		data.add(data1);
		data.add(data2);
		data.add(data3);
		data.add(data4);
		data.add(data5);
		data.add(data6);
		data.add(data7);
		data.add(data8);
		data.add(data9);
		Iterator<double[][]> it = data.iterator();
		int count = 0;
		if (false)
			while (it.hasNext())
			{
				count++;
				double[][] thing = it.next();
				try
				{
					make(thing);
				}
				catch (Error e)
				{
					assertFalse("test " + count + " failed ", true);
				}
			}
		else
		{
			try
			{
				make(data4);
			}
			catch (Exception e)
			{
				assertFalse("test " + count + " failed ", true);
			}
		}
	}

	public void make(double[][] data)
	{
		setupParameters();
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		List<Double> spds = new ArrayList<Double>();

		SheetStaticBuilder sb = new SheetStaticBuilder();

		for (int i = 0; i < data.length; i++)
		{
			FlatPoint f = new FlatPoint(data[i][0], data[i][1]);
			f.setSpeed(data[i][2]);
			f.addType(STREET);
			spds.add(data[i][2]);
			sb.addPoint(f);
		}
		Sheaf sheaf = new Sheaf(sb.makeSheet());

		anchor.createPolygon(sheaf.getFace());

		Skeleton s = new Skeleton(sheaf, Double.MAX_VALUE);

		Iterator<Sheaf> shit = s.makeSideSheets(sheaf, 1).iterator();
		while (shit.hasNext())
		{
			Sheaf sf = shit.next();
			assert (sf != null);
			anchor.createPolygon(sf.getFace());
		}

	}

}
