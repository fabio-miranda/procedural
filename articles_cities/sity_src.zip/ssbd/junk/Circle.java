package junk;

import java.util.List;


import util.CircularList;

	
/**
 * List of one circular list and its event priority queue
 * @author people
 *
 */

public class Circle
{
	private CircularList<Point> circle = null;
	private Queue q = null;
	
	public Circle(CircularList<Point> circle, Queue list)
	{
		this.circle = circle;
		this.q = list;
	}
	public CircularList<Point> getCircle()
	{
		return circle;
	}
	public void setCircle(CircularList<Point> circle)
	{
		this.circle = circle;
	}
	public Queue getQueue()
	{
		return q;
	}
	public void setQueue(Queue q)
	{
		this.q = q;
	}
}
