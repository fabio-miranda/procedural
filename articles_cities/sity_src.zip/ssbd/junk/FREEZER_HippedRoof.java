package junk;

import geom.Sheaf;

import java.util.*;

import ssbd.*;

import woof.*;

public class FREEZER_HippedRoof extends FREEZER<HippedRoof> implements NOISE_SheafChange
{
	public double steepness;
	public double minSteep;
	
	public FREEZER_HippedRoof(HippedRoof w, Random r)
	{
		super(w,r);
	}
	
	public void markGables(Sheaf in)
	{
		// do nothing... no gables on a flat roof
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// nothing to do here, just get created!
	}
	
	public String getName()
	{
		return basicName+" I am a very simple roof";
	}

	/**
	 * return the generator for the wall...
	 */
	public WoofFloor getWoofFloor(int storyCount, double storyHeight, WoofBuilder wb)
	{
		return null;// new SlopeRoof(wb,storyHeight*(double)storyCount,0.,0.0,Math.max(steepness, minSteep));
	}
}
