package junk;

import geom.FlatPoint;
import skeleton.*;
import util.CE;

/**
 * Represents the type of colision that happens when a bisector
 * leaving a concave angle collides with the opposite side
 * @author people
 *
 */
public class SplitEvent extends Intersection
{
	private CE<Point>  point;
	private Edge edge = null;
	private double maxDist = 0;
	
	public SplitEvent(CE<Point>  point, double perpHeight, FlatPoint location, Edge e)
	{
		super();
		this.point = point;
		this.perpHeight = perpHeight;
		this.location = location;
		this.edge = e;
		// location and edge may be null if this is just a place holder for
		// concave vertex that doesnt intersect with the other side, but still
		// goes into a ConcaveEvent
		if (location!=null)this.maxDist = point.thing.getPoint().distanceTo(location);
	}

	public double maxDist()
	{
		return maxDist;
	}
	
	public CE<Point> getPoint()
	{
		return point;
	}

	public void setPoint(CE<Point> point)
	{
		this.point = point;
	}

	public Edge getEdge()
	{
		return edge;
	}

	public void setEdge(Edge edge)
	{
		this.edge = edge;
	}
	
	public String toString()
	{
		return ("SPLIT - \npoint "+point.thing.getPoint()+"\n height "+perpHeight+"\n location "+location+"\n edge:"+edge+"\n maxDist"+maxDist());
	}
}
