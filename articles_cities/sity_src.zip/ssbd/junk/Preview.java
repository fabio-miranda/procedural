/*
 * Copyright (c) 2003-2006 jMonkeyEngine
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * * Neither the name of 'jMonkeyEngine' nor the names of its contributors 
 *   may be used to endorse or promote products derived from this software 
 *   without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package junk;

import static sity.Parameters.error;

import java.util.Random;

import sity.Waterfall;
import ssbd.FREEZER_Root;
import ssbd.Root;

/**
 * 
 * This class is copied from the JMESwingTest example of how to create a JMonkey
 * component. Will be heavily modified!
 * 
 * <code>JMESwingTest</code> is a test demoing the JMEComponent and
 * HeadlessDelegate integration classes allowing jME generated graphics to be
 * displayed in  AWT/Swing interface.
 * 
 * Note the Repaint thread and how you grab a canvas and add an implementor to
 * it.
 * 
 * @author Joshua Slack
 * @version $Id: Preview.java,v 1.1 2006/07/17 21:58:17 tk1748 Exp $
 */

public class Preview //extends JFrame implements Poppable
{

	public Preview(Waterfall n)
	{
		//freeze from the root :)
		//if (n instanceof Root)
		// FREEZER_Root.bigFreeze(Root.class.cast(n), new Random());
		//else
		//	error("can only freeze from the root!");
		
	}
	/*
	public void pop()
	{
		Parameters.preview = null;
		Sity.self.update();
		dispose();
	}*/
	
	/*
	int width = 640, height = 480;

	Waterfall rootFall = null;
	
	// Swing frame
	// private SwingFrame frame;

	public Preview(Waterfall n)
	{
		// center the frame
		setLocation(100,100);
		Parameters.setIcon(this);
		// show frame
		setVisible(true);

		rootFall = n;
		
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				dispose();
			}
		});

		init();
		pack();

		// MAKE SURE YOU REPAINT SOMEHOW OR YOU WON'T SEE THE UPDATES...
		new Thread()
		{
			{
				setDaemon(true);
			}

			public void run()
			{
				while (true)
				{
					comp.repaint();
					yield();
				}
			}
		}.start();

	}

	public void pop()
	{
		Parameters.preview = null;
		Sity.self.update();
		dispose();
	}

	private static final long serialVersionUID = 1L;

	JPanel contentPane;

	JPanel mainPanel = new JPanel();

	Canvas comp = null;

	JPanel spPanel = new JPanel();

	JMECanvasImplementor impl;

	// Component initialization
	private void init()
	{
		contentPane = (JPanel) getContentPane();
		contentPane.setLayout(new BorderLayout());

		mainPanel.setLayout(new GridBagLayout());

		setTitle("Sity - preview window");

		// -------------GL STUFF------------------

		// make the canvas:
		comp = DisplaySystem.getDisplaySystem("lwjgl").createCanvas(width,
				height);

		// add a listener... if window is resized, we can do something about it.
		comp.addComponentListener(new ComponentAdapter()
		{
			public void componentResized(ComponentEvent ce)
			{
				doResize();
			}
		});

		// Important! Here is where we add the guts to the panel: // BROKEN!
		impl = new BalloonMonkey(width, height, rootFall, new Balloon(null));
		((JMECanvas) comp).setImplementor(impl);

		// -----------END OF GL STUFF-------------


		spPanel.setLayout(new BorderLayout());
		spPanel.setBounds(0,0,100,600);
		
		mainPanel.add(spPanel);
		contentPane.add(mainPanel, BorderLayout.WEST);
	

		//, new GridBagConstraints(0, 5, 1, 1, 1.0, 1.0,
				//GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(
					//	5, 5, 0, 5), 0, 0));
		comp.setBounds(100, 0, width, height);
		contentPane.add(comp, BorderLayout.EAST);
	}

	protected void doResize()
	{
		//impl.resizeCanvas(comp.getWidth(), comp.getHeight());
		impl.resizeCanvas(width, height);
	}

	// Overridden so we can exit when window is closed
	protected void processWindowEvent(WindowEvent e)
	{
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING)
		{
			pop(); // just close the window, nothing else!
		}
	}*/
}