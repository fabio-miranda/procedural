package junk;

import static geom.EdgeType.*;
import static geom.Vec2d.*;
import static java.lang.Math.*;
import static sity.Parameters.*;

import geom.*;

import java.util.*;

import javax.vecmath.*;

import skeleton.*;
import util.*;

/**
 * Modified from pseudo code published by Felkel. Constructs the skeleton,
 * second reqire of this without such heavy use of generics. Still unreadable,
 * but less unreadable. One day I'll learn Java is a bad habit.
 * 
 * @author people
 * 
 */
public class SkeletonOld
{
	// circular list structure of roof base 'gutter' <SLAV>
	private List<Circle> circles = new Vector<Circle>();

	// original list of edges
	private List<FlatPoint> originalLines = null;

	private CircularList<Point> originalCircle = null;

	// all output Edges a hashmap of vectors
	private Map<FlatPoint, Vector<Edge>> lines = new Hashtable<FlatPoint, Vector<Edge>>();

	// if bevelling this contains the top of the roof
	private List<Edge> flatTop = new Vector<Edge>();

	// contains the polygons output by this routine
	private List<List<Edge>> allPolys = new Vector<List<Edge>>();

	private double bevel;

	
	public SkeletonOld(Sheaf in, double distance)
	{
		
	}
	
	/**
	 * Speeds apply to the first, second...etc... edges!
	 * 
	 * @param fp
	 *            list of points around the edge of the shape to skeleton
	 * @param speeds
	 *            the list of edge speeds.
	 */
	public SkeletonOld(List<FlatPoint> fp, List<Double> speeds, double distance)
	{
		bevel = distance;
		originalLines = fp;
		List<Point> tmpCircle = new Vector<Point>();

		Iterator<FlatPoint> fps = fp.iterator();
		Iterator<Double> speedIt = speeds.iterator();

		FlatPoint lastFp = fps.next();
		Point lastP = new Point(lastFp, null, null);
		tmpCircle.add(lastP);
		Point firstP = lastP;

		// construct a linked list of vertices and edgees edges
		while (fps.hasNext())
		{
			FlatPoint currentFp = fps.next();
			Edge newEdge = new Edge(lastFp, 0, currentFp, 0, speedIt.next());
			newEdge.setType(lastFp.getType());
			Point currentP = new Point(currentFp, null, newEdge);
			tmpCircle.add(currentP);

			// set lasts next edge to us
			lastP.setNextEdge(newEdge);
			lastP = currentP;
			lastFp = currentFp;
		}
		// tidy up first to last
		Edge finalEdge = new Edge(fp.get(fp.size() - 1), 0, fp.get(0), 0,
				speedIt.next());
		finalEdge.setType(fp.get(fp.size() - 1).getType());
		lastP.setNextEdge(finalEdge);
		firstP.setPreviousEdge(finalEdge);

		Circle circle = new Circle(new CircularList<Point>(tmpCircle),
				new Queue());
		circles.add(circle);

		// find the angles leaving the joints in intial circle
		setUpBisectors(circle);

		// store a cache of the original circle
		originalCircle = new CircularList<Point>(tmpCircle);
		setUpBisectors(new Circle(originalCircle, null));

		CircularIterator<Point> cit = circle.getCircle().iterator();
		// add all inital intersections to the priority queue...
		while (cit.hasNext())
		{
			CE<Point> point = cit.nextCircular();
			findIntersections(point, circle.getQueue());
		}

		// set the ball in motion
		partTwo(circle);

		// process list into faces
		//makeFaeces();
		makeFaeces2();
	}

	/**
	 * Part two from Felkel's notes
	 */
	public void partTwo(Circle in)
	{

		
		Queue q = in.getQueue();
		CircularList<Point> circle = in.getCircle();
		// until the queue is empty!
		while (q.hasNext())
		{

			// pop top intersection points
			Intersection top = q.getTop();

			// System.err.println(q.size() + "top is " + top);
			// check for bevel/framing event
			if (top.getPerpHeight() > bevel)
			{
				q.empty();
				if (circle.size() < 3)
					continue;
				bevelNow(circle.current); // remove all elements
				continue;
			}
			
			if (top instanceof EdgeEvent)
			{
				edgeEvent(EdgeEvent.class.cast(top), circle, q);
			}
			else if (top instanceof SplitEvent)
			{
				splitEvent(SplitEvent.class.cast(top), circle, q);
			}
		}
	}

	/**
	 * concave case
	 * 
	 * @param top
	 * @param circle
	 * @param q
	 */
	private void splitEvent(SplitEvent top, CircularList<Point> circle, Queue q)
	{
		// 2b)
		if (top.getPoint().thing.isProcessed() || top.getPerpHeight() < 0)
			return;

		//System.err.println("\nnew top "+top);
		
		// 2c)
		double height = top.getPerpHeight();

		// final triangle is closing - the peak of the roof :)
		if (top.getPoint().next.next.next == top.getPoint())
		{
		/*	This lot should just be a next.next? and ti should just connect the
		 * opposite two sides of the intersected line up with the intersection, then
		 * joint the intersection to its point?*/
			 /*addLine(new Edge(top.getPoint().thing.getPoint(),
			  top.getPoint().thing
			  .getHeight(),  
			  top.getLocation(), height, 0)); 
			 
			 addLine(new Edge(top.getPoint().next.thing.getPoint(),
			  top.getPoint().next.thing.getHeight(),
			  top.getLocation(),height,  0));
			  
			  Edge tmp = new Edge(top.getPoint().previous.thing.getPoint(),
			  top.getPoint().previous.thing.getHeight(), top.getLocation(),
			  height, 0);
			  addLine(tmp);*/
			  // tmp.addType(ROOFLINE); 
			  //
		
			System.err.println("made final part of roof in splitEvent....:)");
			//assert(false);
			top.getPoint().thing.setProcessed(true);
			//top.getPoint().thing.setSplit(true);

			return;
		}
		// 2d)
		addLine(new Edge(top.getPoint().thing.getPoint(), top.getPoint().thing
				.getHeight(), top.getLocation(), top.getPerpHeight(), 0.));
		
		//System.err.println("added lines from "+top.getPoint().thing.getPoint() + " to "+top.getLocation());
		
		// 2e)
		top.getPoint().thing.setProcessed(true);
		//top.getPoint().thing.setSplit(true);
		
		//System.err.println("height is "+top.getPerpHeight()+" ");
				
		
		// point on 'left' in Felkelele's notes
		Point pL = new Point(new FlatPoint(top.getLocation()),
				top.getPoint().thing.getNextEdge(), top.getEdge()); // and
																	// right:
		pL.setHeight(top.getPerpHeight());
		Point pR = new Point(new FlatPoint(top.getLocation()), top.getEdge(),
				top.getPoint().thing.getPreviousEdge());
		pR.setHeight(top.getPerpHeight());
		// split SLAV into two and kkeep one & add another
		CE<Point> leftTopSplit = top.getPoint();
		//System.err.println("left top edge  is "+top.getEdge());

		//System.err.println("left top split edge is "+leftTopSplit.thing.getNextEdge());
		List<Point> leftLoop = new Vector<Point>();
		// find point before insertion
		while (leftTopSplit.thing.getNextEdge() != top.getEdge())
		{
			leftTopSplit = leftTopSplit.next;
			leftLoop.add(leftTopSplit.thing);
			
		}
		leftLoop.add(pL);
		
		// if one big we cam ignofre...?
		if (leftLoop.size()==1)
		{
			q.empty();
			return;// not sure about this
		}
		
		// remove all points from this Circle between top.getPoint.getPrevious
		Circle leftCircle = new Circle(new CircularList<Point>(leftLoop),
				new Queue());

		CircularIterator<Point> cit = leftCircle.getCircle().iterator();
		//System.err.println("first on list is "+leftCircle.getCircle().current.thing.getPoint());
		//setBisector(leftCircle.getCircle().current);
		leftCircle.getCircle().prev();
		setBisector(leftCircle.getCircle().current);
		// add all inital intersections to the priority queue...
		while (cit.hasNext())
		{
			CE<Point> point = cit.nextCircular();
			/*System.err.println(">>>"+point.thing.getPoint());
			System.err.println(" n>"+point.next.thing.getPoint());
			System.err.println(" p>"+point.previous.thing.getPoint());*/
			findIntersections(point, leftCircle.getQueue());
		}

		//System.err.println("Starting on left *******************");
		// recurse in on left loop
		partTwo(leftCircle);

		//System.err.println("Done with left onto right***************");
		
		// now create right loop
		List<Point> rightLoop = new Vector<Point>();
		assert (leftTopSplit.next.thing.getPreviousEdge() == top.getEdge());
		rightLoop.add(pR);

		//System.err.println("adding  "+pR);
		// move onto the other circles points...
		leftTopSplit = leftTopSplit.next;
		while (leftTopSplit != top.getPoint())
		{
			rightLoop.add(leftTopSplit.thing);
			leftTopSplit = leftTopSplit.next;
		}
		// check for the case wehre the is only one point in the other list
		if (rightLoop.size()==1)
			{
				q.empty();
				return;// not sure about this
			}
		// remove all points from this Circle between top.getPoint.getPrevious
		Circle rightCircle = new Circle(new CircularList<Point>(rightLoop),
				new Queue());

		cit = rightCircle.getCircle().iterator();
		//System.err.println(">right>"+rightCircle.getCircle().current().getPoint());
		setBisector(rightCircle.getCircle().current);
//		assert(false);
		// add all inital intersections to the priority queue...
		while (cit.hasNext())
		{
			CE<Point> point = cit.nextCircular();
			//System.err.println(">>>"+point.thing);
			findIntersections(point, rightCircle.getQueue());
		}

		//assert(false);
		partTwo(rightCircle);

		//System.err.println("Done with right***************"+rightLoop.size());
		// empty current queue
		q.empty();
	}

	/**
	 * convex case
	 * 
	 * @param top
	 * @param circle
	 * @param q
	 */
	private void edgeEvent(EdgeEvent top, CircularList<Point> circle, Queue q)
	{
		// if they have both been processed already! this should be OR
		// really?
		// also disgard intersections that occur outside our shape...change
		// this
		// if we wwant to grow a skeleton outwards, and dont add them in the
		// first place!
		if (top.getNextPoint().thing.isProcessed()
				|| top.getPreviousPoint().thing.isProcessed()
				|| top.getPerpHeight() < 0)
		{
			return;
		}


		//System.err.println("\nnew top "+top);
		
		// formula for finding the height from the speed and perpendicular
		// height
		double height = top.getPerpHeight();

		// System.err.println(" new top==>> "+top.g)
		// final triangle is closing - the peak of the roof :)
		if (top.getNextPoint().next.next == top.getPreviousPoint())
		{
			addLine(new Edge(top.getPreviousPoint().thing.getPoint(), top
					.getPreviousPoint().thing.getHeight(),
			// 0 speed!
					top.getLocation(), height, 0));
			addLine(new Edge(top.getNextPoint().thing.getPoint(), top
					.getNextPoint().thing.getHeight(), top.getLocation(),
					height, 0));
			Edge tmp = new Edge(top.getPreviousPoint().previous.thing
					.getPoint(), top.getPreviousPoint().previous.thing
					.getHeight(), top.getLocation(), height, 0);
			// tmp.addType(ROOFLINE);
			addLine(tmp);
			 //System.err.println("made final part of roof :)");

			top.getNextPoint().thing.setProcessed(true);
			top.getPreviousPoint().thing.setProcessed(true);

			return;
		}
		// output the two new lines
		//System.err.println("adding edge now");
		addLine(new Edge(top.getPreviousPoint().thing.getPoint(), top
				.getPreviousPoint().thing.getHeight(), top.getLocation(),
				height, 0)); // top.getPerpHeight()
		addLine(new Edge(top.getNextPoint().thing.getPoint(), top
				.getNextPoint().thing.getHeight(), top.getLocation(), height, 0)); // top.getPerpHeight()
		// mark as processed
		top.getNextPoint().thing.setProcessed(true);
		top.getPreviousPoint().thing.setProcessed(true);
		Point point = new Point(top.getLocation(), top.getNextPoint().thing
				.getNextEdge(), top.getPreviousPoint().thing.getPreviousEdge());
		point.setHeight(height);

		/*
		 * System.err.println("perp height is from below is
		 * "+top.getPerpHeight()); double pNext =
		 * heightPerpendicular(point.getNextEdge().getFirst(),
		 * point.getNextEdge().getSecond(), point.getPoint());
		 * System.err.println("perp height is from next is "+pNext); double
		 * pPrev = heightPerpendicular(point.getPreviousEdge().getFirst(),
		 * point.getPreviousEdge().getSecond(), point.getPoint());
		 * System.err.println("perp height is from previous is "+pPrev);
		 */

		// insert into circular list, removing the two other that it takes
		// the place of
		CE<Point> newCircle = new CE<Point>(point);
		circle.select(top.getPreviousPoint());
		circle.replace(newCircle);
		circle.select(top.getNextPoint());
		circle.remove();

		/*
		 * top.getPreviousPoint().previous.next = newCircle;
		 * top.getNextPoint().next.previous = newCircle; newCircle.previous =
		 * top.getPreviousPoint().previous; newCircle.next =
		 * top.getNextPoint().next;
		 */

		// finally set bisector and calculate collisions with nearby
		// offenders
		setBisector(newCircle);
		//System.err.println("new bisector is "+newCircle.get().getBisector());

		// find intersections of new points
		findIntersections(newCircle, q);

	}

	/**
	 * My procedure to bevel this frame, no need to care about face direction,
	 * all taken care of later - just making a graph for now
	 */
	private void bevelNow(CE<Point> start)
	{
		CE<Point> next = null, current = start;
		FlatPoint lastEdge = null;
		FlatPoint edgeIntersect = null, firstEdge = null;
		// stop execution of futher collisions by emptying queue
		// run through all points in the current list
		while (next != start)
		{
			setBisector(current);
			Edge one = current.thing.getNextEdge();
			Edge two = current.thing.getPreviousEdge();
			edgeIntersect = intersectEndPoints(one.getFirst(), one.getSecond(),
					two.getFirst(), two.getSecond());
			Vector2d bisec = new Vector2d(current.thing.getBisector());
			
			bisec.scale(bevel);
			double height = bevel;
			edgeIntersect.add(bisec);
			addLine(new Edge(current.thing.getPoint(), current.thing.getHeight(), edgeIntersect, height, 0));

			if (lastEdge != null)
			{
				// all interior points are at a height of 'bevel'!
				Edge e = new Edge(lastEdge, height, edgeIntersect, height, 0);
				e.addType(BEVELTOP);
				addLine(e);
				flatTop.add(e);
			}
			else
			{
				firstEdge = edgeIntersect;
			}

			lastEdge = edgeIntersect;
			next = current.next;
			current = next;
		}
		Edge e = new Edge(edgeIntersect, bevel, firstEdge, bevel, 0);
		e.addType(BEVELTOP);
		addLine(e);
		flatTop.add(e);
	}

	/**
	 * Returns the space left at the top of this skelitanisation if bevellin has
	 * taken place
	 * 
	 * @return the list
	 */
	public List<Edge> getFlatTop()
	{
		return flatTop;
	}

	/**
	 * The edges that make up the sides of the skeleton, if no beveling has
	 * taken place then this is the only output.
	 * 
	 * @return
	 */
	public List<List<Edge>> getSides()
	{
		return allPolys;
	}

	/**
	 * Debugging code, outputs the edges as faces instead :) very pretty
	 * 
	 */
	public void makeFaeces()
	{
		Collection<Vector<Edge>> d = lines.values();
		Iterator<Vector<Edge>> vit = d.iterator();
		while (vit.hasNext())
		{
			Iterator<Edge> edit = vit.next().iterator();
			while (edit.hasNext())
			{
				Edge e = edit.next();
				FlatPoint p = e.getFirst();
				FlatPoint q = e.getSecond();
				List<Edge> poly = new Vector<Edge>();
				allPolys.add(poly);

				Edge x1 = new Edge(p, 0, q, 0, 0);
				Edge x2 = new Edge(q, 0, new FlatPoint(p.x + 1, p.y), 1, 0);
				Edge x3 = new Edge(new FlatPoint(p.x, p.y), 1, p, 0, 0);

				/*
				 * Edge x1 = new Edge(p,0,new FlatPoint(p.x-1, p.y),1,0); Edge
				 * x2 = new Edge(new FlatPoint(p.x-1, p.y),1,new
				 * FlatPoint(p.x+1, p.y),1,0); Edge x3 = new Edge(new
				 * FlatPoint(p.x+1, p.y),1,p,0,0);
				 */
				poly.add(x1);
				poly.add(x2);
				poly.add(x3);
			}
		}
	}

	/**
	 * Now navigate the list of orignal edges and, preserving a clockwise
	 * direction, produce a list of faces as output. We search for the smallest
	 * interior angle from each vertex.
	 * 
	 */
	public void makeFaeces2()
	{
		Iterator<FlatPoint> it = originalLines.iterator();
		// intiating first point is one step backwards around circum
		FlatPoint first = originalLines.get(originalLines.size() - 1);
		while (it.hasNext())
		{
			FlatPoint second = it.next();
		    //System.err.println("**********************"+first+second);
			FlatPoint lastPoint = null, beforeLast = null;
			List<Edge> poly = new Vector<Edge>();
			allPolys.add(poly);
			Edge tmp = new Edge(first, 0, second, 0, 0, first.getType());
			tmp.addType(REFERENCE); // this is the bottom section
			poly.add(tmp);
			lastPoint = second;
			beforeLast = first;
			int count = 0; //debug var
			// find list of applicable edges from hashtable
			while (lastPoint != first)
			{
				count++;
				if (count > 20) assert(false);
				Vector<Edge> v = lines.get(lastPoint);
				//System.err.println("looking for "+lastPoint);
				if (v == null)
				{
					fatalErrorSD("no faces found for vertex " + second);
				}
				// find the edge which gives the smallest angle
				Edge best = null;
				double smallest = Double.MAX_VALUE;
				Iterator<Edge> edit = v.iterator();
				while (edit.hasNext())
				{
					Edge e = edit.next();
					// we dont go back from where we came...
					if (e.getSecond().equals(beforeLast))continue;
					assert e.getFirst().equals(lastPoint) : "faces in hash are not what where asked for";
					double angle = angleBetween(beforeLast, lastPoint, e
							.getSecond());
					if (angle > PI)
					{
						angle = 3*PI - angle;
						}
					else
					{
						angle = PI-angle;
					}
					//System.err.println("bl:"+ beforeLast + " l:"+ lastPoint +" s:"+e.getSecond());
					//System.err.println("candidate "+e+"\n   "+angle);
					if (angle < smallest)
					{
						smallest = angle;
						best = e;
					}
				}
				//assert (best != null);
				//System.err.println("adding "+best);
				poly.add(best);

				lastPoint = best.getSecond();
				beforeLast = best.getFirst();
			}
			first = second;
		}
		//System.err.println("outputting "+allPolys.size()+" polygons");
	}

	/**
	 * Adds the specified line (in both directions....) to the hashtable of all
	 * lines
	 * 
	 * @param e1
	 */
	public void addLine(Edge e1)
	{
		// dont accept 0 length lines - sometimes get them thro symmetry
		if (e1.getFirst().equals(e1.getSecond()))return;
		// all added lines are roof edges
		e1.addType(ROOFEDGE);
		Edge e2 = new Edge(e1); // roofline copied to e2 automagically
		Vector<Edge> v = lines.get(e1.getFirst());
		if (v == null)
		{
			Vector<Edge> n = new Vector<Edge>();
			lines.put(e1.getFirst(), n);
			v = n;
		}
		v.add(e1);

		v = lines.get(e2.getFirst());
		if (v == null)
		{
			Vector<Edge> n = new Vector<Edge>();
			lines.put(e2.getFirst(), n);
			v = n;
		}
		v.add(e2);
	}

	/**
	 * Sets the bisector vector inside the Point, using the edges specified to
	 * locate their intersection...
	 * 
	 * Speed complication is that intersection can happen in front of the end of the
	 * next line or behind the start of the previous line, so what we do is
	 * find intersection point of two lines
	 * subtract previous edge vector to find previous point
	 * add next edge vector to find next point
	 * 
	 * @param point
	 */
	private void setBisector(CE<Point> point)
	{

		 Triple<FlatPoint,FlatPoint,FlatPoint> res = getPointsForAngle(point);
		 FlatPoint previous = res.first();
		 FlatPoint intersect= res.second();
		 FlatPoint next = res.third();
		point.thing.setBisector(shrink_OLD(previous, intersect, next, point.thing
				.getPreviousEdge().getSpeed(), point.thing.getNextEdge()
				.getSpeed()));
		
		if (Double.isNaN(point.thing.getBisector().x))
				{
		System.err.println("finding bisector at "+point.get().getPoint());
		System.err.println("previous "+previous +"\ncurrent "+intersect+"\nnext "+next);
		System.err.println("speed before "+point.thing.getPreviousEdge().getSpeed());
		System.err.println("speed after "+point.thing.getNextEdge().getSpeed());
		System.err.println("bisector was "+point.thing.getBisector()+"\n");
		assert(false);
				}
	}

	/**
	 * Performs a calculation to find the relative intersect points for the specified
	 * point and its current edges.
	 */
	private Triple<FlatPoint,FlatPoint,FlatPoint> getPointsForAngle(CE<Point> point)
	{
		
		Edge previousE = point.thing.getPreviousEdge();
		FlatPoint previous = new FlatPoint(previousE.getFirst());

		Edge nextE = point.thing.getNextEdge();
		FlatPoint next = new FlatPoint(nextE.getSecond());

		FlatPoint intersect = intersectEndPoints(previousE.getFirst(),
				previousE.getSecond(), nextE.getFirst(), nextE.getSecond());

		/*System.err.println("to find intersect"+previousE.getFirst()+
				previousE.getSecond()+ nextE.getFirst()+ nextE.getSecond());
		
		System.err.println("intersection at "+intersect);*/
		
		if (intersect == null)
		{
			// lines are parallel, make up something kinda convincing...
			Vector2d tmp = new Vector2d(nextE.getSecond());
			tmp.sub(nextE.getFirst());
			tmp.normalize();
			tmp.scale((previousE.getSpeed()+nextE.getSpeed())/2);
			//System.err.println(" lines are parallel: setting it to "+tmp);
			point.thing.setBisector(tmp);
			return null;
		}
		
			// move previous point backward
			Vector2d prev = new Vector2d(previousE.getSecond());
			prev.sub(previousE.getFirst());
			previous = new FlatPoint(intersect);
			previous.sub(prev);
			
			// move previous point backward
			Vector2d nxt= new Vector2d(nextE.getSecond());
			nxt.sub(nextE.getFirst());
			next = new FlatPoint(intersect);
			next.add(nxt);
			return new Triple<FlatPoint,FlatPoint,FlatPoint>(previous, intersect, next);
	}
	
	/**
	 * Calculates intersection between these two points 1.792
	 * 
	 * @param point
	 */
	private void findEdgeEvent(CE<Point> point,
			CE<Point> nextPoint, Queue q)
	{
		Point me = point.thing;
		Point onLeft = nextPoint.thing; // changed from previous?!

		//Triple<FlatPoint,FlatPoint,FlatPoint> res = getPointsForAngle(point);
		FlatPoint collision = intersectInFront(me.getPoint(), onLeft.getPoint(), me
				.getBisector(), onLeft.getBisector());

		if (collision == null) return;
		//System.err.println("point is "+point.thing.getPoint()+" onL "+point.next.thing.getPoint());
		//System.err.println("bisectors are "+me.getBisector()+ " "+onLeft.getBisector());
		//System.err.println("collision i s" +collision);

		// perpendicular height above line between two points!
		Edge heightFrom = point.thing.getNextEdge();
		// assert (heightFrom == nextPoint.thing.getPreviousEdge());
		double pHeight = heightPerpendicular(heightFrom.getFirst(), heightFrom
				.getSecond(), collision);
		// we have to check two heights to ensure that the collision is valid
		// and not a borderline case of parallel bisectors meeting at an arbitrary location
		//Edge heightFrom2 = point.thing.getPreviousEdge();
		//double pHeight2 = heightPerpendicular(heightFrom2.getFirst(), heightFrom2
				//.getSecond(), collision);
		//if (Math.abs(pHeight - pHeight2) > 0.000001) return;
		
		pHeight = pHeight / point.thing.getNextEdge().getSpeed();
		Intersection i = new EdgeEvent(nextPoint, point, pHeight, collision);

		// pHeights < 0 happen outside are shape and we're not interested!
		if (pHeight >= 0) q.add(i);
	}

	/**
	 * Finds splits events and adds them to the priority queue
	 * 
	 * For each line section in the current circle we find the intersection of
	 * the bisector with it. This may be outside the edge's vertices...
	 * 
	 * we then fid the midpoint on this line (scaled by relative bisector
	 * speeds) and check that it is between the bisectors of the corners of l.
	 * 
	 */
	private void findSplitEvent(CE<Point> in, Queue q)
	{
		Point me = in.thing;

		/*System.err.println(in.previous.thing.getPoint() + " "
				+ in.next.thing.getPoint());
		System.err.println(originalCircle);*/

		CE<Point> first = null;// originalCircle.current;
		CE<Point> a = originalCircle.current;

		double bestHeight = Double.MAX_VALUE;
		double bestOther = 69; //debug var
		double bestOther2 = 69; //debug var
		FlatPoint bestPoint = null;
		Edge bestEdge = null;

		//System.err.println("**********    Splitting "+in.thing.getPoint()+" l "+in.thing.getBisector().length());

		while (a != first)
		{
			CE<Point> b = a.next;
			if (first == null)
				first = originalCircle.current;


			// dont intersect with lines that will intersect at base of in.thing.getPoint()
			if (a.thing.equals(in.thing) || b.thing.equals(in.thing)) 
				{
					a = b;
					continue;
				}
			
			FlatPoint s = new FlatPoint(b.thing.getPoint());
			s.sub(a.thing.getPoint());
			//System.err.println(a.thing.getPoint()+" to "+b.thing.getPoint());
			
			// line from a to b, find intersector with in's bisector
			FlatPoint i = intersect(a.thing.getPoint(), in.thing.getPoint(), s,
					in.thing.getBisector());
			
			double oAngle = angleBetween(new Vector2d(0,1),s)-PI/2;
			FlatPoint oIntersect = intersect(in.thing.getPoint(),a.thing.getPoint(),
					new Vector2d(sin(oAngle),cos(oAngle)), s);
			//System.err.println(oAngle +" angle is "+new Vector2d(sin(oAngle),cos(oAngle)));
			//System.err.println("oInt "+oIntersect+" point "+in.thing.getPoint() +" other intersect "+i);
			oAngle = PI- angleBetween(oIntersect, in.thing.getPoint(), i);
			//System.err.println("oangle is "+oAngle);
			
			// find the speed of the opposite line towards concave cave...
			double fromOther = a.thing.getNextEdge().getSpeed()/cos(oAngle);
			double fromThis = in.thing.getBisector().length();

			/*shrink(in.previous.thing.getPoint(),
					in.thing.getPoint(), in.next.thing.getPoint(),
					in.thing.getPreviousEdge().getSpeed(),
					in.thing.getNextEdge().getSpeed()).length();*/
			
			
			FlatPoint origin =intersectEndPoints(in.thing.getPreviousEdge().getFirst(),
					in.thing.getPreviousEdge().getSecond(), in.thing.getNextEdge().getFirst(),
					in.thing.getNextEdge().getSecond()); 
			if (origin == null)
			{
				// the two edges are parallel!, origin is intersection between either
				// of the two edges and the line made from the point in question and its
				// bisector
				System.err.println("Skelton.findSplitEvents is says the edges are parallel!");
				FlatPoint tmp = new FlatPoint(in.thing.getPoint());
				tmp.sub(in.thing.getBisector());
				origin = intersect(in.thing.getPreviousEdge().getFirst(),
						in.thing.getPreviousEdge().getSecond(), in.thing.getPoint(),tmp);
			}
			
			// distance from here to
			double total = origin.distanceTo(i);
			//System.err.println("origin "+origin+" intersect "+i);
			//assert(total>0);
			// find centre point
			FlatPoint pnt = new FlatPoint(me.getBisector());
			pnt.normalize();
			//System.err.println("fromThis "+fromThis+" from other "+fromOther+" total "+total);
			pnt.scale(fromThis * total / (fromThis + fromOther));
			FlatPoint l = new FlatPoint(origin);
			l.add(pnt);

			//System.err.println("intersection would be "+l);
			
			double oldheight = heightPerpendicular(a.thing.getPoint(), b.thing
					.getPoint(),l)/
					a.thing.getNextEdge().getSpeed();
			
			double oldheight2 = heightPerpendicular(in.thing.getNextEdge().getFirst(),
					in.thing.getNextEdge().getSecond(), l)/
					in.thing.getNextEdge().getSpeed();
			
			double height = heightPerpendicular(in.thing.getPreviousEdge().getFirst(),
					in.thing.getPreviousEdge().getSecond(), l)/
					in.thing.getPreviousEdge().getSpeed();
			
			 //System.err.println(onLeftOf(a.thing.getPoint(), a.thing.getBisector(), l));
			 //System.err.println(a.thing.getPoint()+" [[]] "+ a.thing.getBisector());
			 
			 //System.err.println(""+onRightOf(b.thing.getPoint(), b.thing.getBisector(), l));
			 //System.err.println(b.thing.getPoint()+" (()) "+ b.thing.getBisector());
			 
			 //System.err.println(onRightOf(a.thing.getPoint(), s, l));
			 
			 //System.err.println(a.thing.getPoint()+" <<>> " + s);
			 //System.err.println(height < bestHeight) ;

			// if intersect lies between a,b's intersectors, and isn't outside
			// the shape...
			if (onLeftOf(a.thing.getPoint(), a.thing.getBisector(), l)
					&& onRightOf(b.thing.getPoint(), b.thing.getBisector(), l)
					&& onRightOf(a.thing.getPoint(), s, l)
					&& height < bestHeight) 
			{
				//System.err.println("?????????????   Tis good");
				// point is valid
				bestHeight = height;
				bestOther = oldheight;
				bestOther2 = oldheight2;
				bestPoint = l;
				bestEdge = a.thing.getNextEdge();
			}
			a = b;
		}
	    //System.err.println("interseciton point is"+bestPoint);
	    //System.err.println("oppostite "+bestOther+"\n previous: "+bestHeight+"\n next: "+bestOther2);

		//System.err.println("edge is "+bestEdge);

		assert(!in.thing.getPoint().equals(new FlatPoint(1.7499999999999996, 0.9419264544146251)));
	    assert(bestPoint == null ||Math.abs(bestOther-bestHeight)< 0.000001);
	    
		//assert(false);
		//assert (bestPoint != null);
		if (bestPoint != null)
		{
			Intersection i = new SplitEvent(in, bestHeight, bestPoint, bestEdge);
			//System.err.println("addin "+i);
			q.add(i);
		}
	}

	/**
	 * First caches the bisectors of all points in the points, then calculates
	 * the intersections with the points beore and after and puts them into the
	 * queue.
	 */
	private void setUpBisectors(Circle c)
	{
		CircularList<Point> circle = c.getCircle();
		CircularIterator<Point> it = circle.iterator();

		while (it.hasNext())
		{
			CE<Point> point = it.nextCircular();
			setBisector(point);
		}
		it = circle.iterator();
	}

	/**
	 * looks for edge and split intersections for this point
	 * 
	 * @param point
	 * @param c
	 */
	private void findIntersections(CE<Point> point, Queue q)
	{
		// catch points that are just pairs
		if (point.next.next == point) 
		{ //dont think we need this, but might do us good one day
			addLine(new Edge(point.thing.getPoint(),point.thing.getHeight(),
					point.next.thing.getPoint(),point.next.thing.getHeight(),0));
		}
		
		Triple<FlatPoint,FlatPoint,FlatPoint> res = getPointsForAngle(point);
		
		//System.err.println("findIntersections for "+point);
		if (angleBetween(res.first(), res.second(), res.third()) < PI)
		{ // convex

		 //System.err.println("look for convex");
			findEdgeEvent(point, point.next, q);
			findEdgeEvent(point.previous, point, q);
		}
		else
		// concave
		{
			//System.err.println("look for concave");
			findSplitEvent(point, q);
		}
	}

	/**
	 * Prodces a list of sheets for gutter connected edges from the internal
	 * data structures.
	 * 
	 * @param in
	 *            the reference sheet
	 * @param steep
	 *            a number saying how raised each sheet should be
	 * @return
	 */
	public List<Sheaf> makeSideSheets(Sheaf in, double steep)
	{
		List<Sheaf> output = new Vector<Sheaf>();
		Iterator<List<Edge>> outside = allPolys.iterator();

		while (outside.hasNext())
		{
			Iterator<Edge> it = outside.next().iterator();
			// System.err.println("======================================");
			Edge first = it.next();
			Point3d origin = new Point3d(first.getFirst().x,
					first.getFirst().y, first.getFirstHeight());
			Edge second = it.next();
			Point3d other = new Point3d(second.getFirst().x,
					second.getFirst().y, second.getFirstHeight());
			// List<FlatPoint> togo = new Vector<FlatPoint>();
			while (it.hasNext())
			{
				Edge x = it.next();
				Point3d e = new Point3d(x.getFirst().x, x.getFirst().y, x
						.getFirstHeight());

				SheetBuilder sb = new SheetBuilder(in);
				sb.addPoint(origin.x, origin.y, origin.z);
				sb.addPoint(other.x, other.y, other.z);
				sb.addPoint(e.x, e.y, e.z);// *steep);

				other = e;
				output.add(sb.makeSheaf());
				// Iterator<EdgeType> etit = e.getTypes().iterator();
				// copy edge type data across
				// while (etit.hasNext())
				// sb.setPointType(etit.next());
				// System.err.println("("+e.getFirst().x+","+e.getFirst().y+","+e.getFirstHeight()+"),");
				 }
		}

		return output;
	}

}
