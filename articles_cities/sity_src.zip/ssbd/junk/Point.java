package junk;

import geom.FlatPoint;

import javax.vecmath.Vector2d;



/**
 * point on the skeleton. Left edge is the 'next' edge as we go around clockwise
 * Right is 'previous'
 * @author people
 *
 */
public class Point
{
	private FlatPoint point;
	private Edge nextEdge;
	private Edge previousEdge;
	private boolean processed = false;
	private Vector2d bisector;
	// default height is 0
	private double height = 0;
	
	public Point(FlatPoint point, Edge leftEdge, Edge rightEdge)
	{
		super();
		this.point = point;
		this.nextEdge = leftEdge;
		this.previousEdge = rightEdge;
	}
	public Point(Point in)
	{
		super();
		this.point = new FlatPoint(in.point);
		this.nextEdge = in.nextEdge;
		this.previousEdge = in.previousEdge;
		this.bisector = new Vector2d(in.bisector);
		this.processed = in.processed;
		this.height = in.height;
	}
	
	public Vector2d getBisector()
	{
		return bisector;
	}
	public void setBisector(Vector2d bisector)
	{
		this.bisector = bisector;
	}
	public Edge getNextEdge()
	{
		return nextEdge;
	}
	public void setNextEdge(Edge leftEdge)
	{
		this.nextEdge = leftEdge;
	}
	public FlatPoint getPoint()
	{
		return point;
	}
	public void setPoint(FlatPoint point)
	{
		this.point = point;
	}
	public boolean isProcessed()
	{
		return processed;
	}
	public void setProcessed(boolean processed)
	{
		this.processed = processed;
	}
	public Edge getPreviousEdge()
	{
		return previousEdge;
	}
	public void setPreviousEdge(Edge rightEdge)
	{
		this.previousEdge = rightEdge;
	}

	public String toString()
	{
		return ("point "+point +"bs:"+bisector);/*+" processed "+processed+
				
				" \nleft edge "+nextEdge+
				" \nright edge "+previousEdge+
				" \nbisector "+bisector+"\n");*/
	}
	public double getHeight()
	{
		return height;
	}
	public void setHeight(double height)
	{
		this.height = height;
	}
	
}
