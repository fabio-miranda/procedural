package skyHook;

import static sity.Parameters.*;
import geom.*;

import java.util.*;

import java.awt.Color;

/**
 * A library functions for creating geometry inside of maya using MEL
 * 
 * @author people
 * 
 */
public class MayaAnchor implements Anchor
{
	MayaSkyHook sH = null;

	// current working colour, default = monotone
	private double r = 50, g = 50, b = 50;

	private int frame;

	public MayaAnchor(MayaSkyHook s)
	{
		sH = s;
		newFile();
		sH.sendUp("global proc twakSetVis(string $name, int $time, int $val) {currentTime $time; setAttr ($name+\".visibility\") $val; setKeyframe ($name+\".visibility\");}");
	}

	public void nextFrame()
	{
		// sH.sendUp("select -all;\n");
		// sH.sendUp("performSetKeyframeArgList 1 {\"0\", \"animationList\"};\n");
		// sH.sendUp("setKeyframe \"tri*.translateX\";\n");
		frame++;
		r = 50;
		g = 50;
		b = 50;
		// sH.sendUp("currentTime " + frame + ";\n");
		// sH.sendUp("select -all;\n");
		// sH.sendUp("move -a 500 0 0;\n");
	}

	/**
	 * Does a file->new in Maya
	 */
	public void newFile()
	{
		sH.sendUp("file -f -new;");
		frame = 1;
	}

	int count = 0;

	private void setVis(int t, int frame, boolean visable)
	{
		String vis = "0";
		if (visable)
			vis = "1";
		sH.sendUp("twakSetVis(\"tri" + t + "\", " + frame + " , " + vis + ");");
	}

	public void createPolygon(Sheaf in)
	{
		if (in != null) createPolygon(in.getFace());
	}
	
	/**
	 * Creates an initial triange then adds points to form a polygon bear in mind that this produces a triangulated mesh :)
	 * 
	 * @param face
	 */
public void createPolygon(Face face)
	{
		if (face.size() < 3)
		{
			error("Not enough vertices in face to output");
			return;
		}
		for (Vertex v: face.getVertices())
		{
			if (Double.isNaN(v.getX()) ||
					Double.isNaN(v.getY()) ||
					Double.isNaN(v.getZ())
					)
			{
				errorSD("Maya can't output NaN coord!\n"+face);
			}
		}
		Iterator<Vertex> it = face.getIter();
		count++;
		StringBuffer sb = new StringBuffer("polyCreateFacet -n \"tri" + (count) + "\" ");
		for (int i = 0; i < 3; i++)
		{
			sb.append("-p " + it.next().toMELString());
		}
		sb.append(";");
		// add the first 3 edges
		sH.sendUp(sb.toString());
		sH.sendUp("select -r tri" + (count) + ".vtx[0:2] ;");

		// colour the polygon
		sH.sendUp("polyColorPerVertex -r " + r + " -g " + g + " -b " + b + " -a 1 -cdo;");
		setVis(count,Math.min(frame-1,1),false);
		setVis(count,frame,true);
		setVis(count,frame+1,false);
		
		int count = 2; // the edge that the new face will be attached to
		while (it.hasNext())
		{
			Vertex v = it.next();
			sH.sendUp("polyAppend -ed " + count + " -p " + v.toMELString());
			// colour the polygon
			sH.sendUp("polyColorPerVertex -r " + r + " -g " + g + " -b " + b + " -a 1 -cdo;");
			count += 2;
		}

	}
	public void createPolygon(List<Face> faeces)
	{
		Iterator<Face> it = faeces.iterator();
		while (it.hasNext())
		{
			createPolygon(it.next());
		}
	}

	public void setColor(Color in)
	{
		r = (double) in.getRed() / (double) 255;
		g = (double) in.getGreen() / (double) 255;
		b = (double) in.getBlue() / (double) 255;
	}

	/**
	 * Textures the last object to be made?
	 * 
	 */
	public void texture()
	{

	}

	public void allDone()
	{

	}
}
