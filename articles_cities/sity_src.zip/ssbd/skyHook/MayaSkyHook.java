package skyHook;

import static sity.Parameters.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * This class represents a connection with the mighty maya god in the sky, if
 * you will a skyhook of feindish proportions.<br>
 * <br>
 * Contains methods for sending a MEL string to maya and waiting for the result
 * 
 * @author people
 * 
 */
public class MayaSkyHook
{

	Socket socket = null;

	PrintWriter printWriter = null;

	BufferedReader bufferedReader = null;

	boolean DEBUG = true;
	
	public MayaSkyHook()
	{
		try
		{
			socket = new Socket("localhost", skyHookPort);
			printWriter = new PrintWriter(socket.getOutputStream(), true);
			bufferedReader = new BufferedReader(new InputStreamReader(socket
					.getInputStream()));
		}
		catch (IOException e)
		{
			error("Could not open port to Maya - have you set up maya on port "+skyHookPort+"? ," + e);
		}
	}

	/**
	 * Closes the socket
	 */
	public void crash()
	{
		try
		{
			socket.close();
		}
		catch (IOException e)
		{
			// dont care
		}
	}

	/**
	 * Issues the command to Maya and waits for the result aka: blocking call!
	 * <b>The plan is for this to be blocking - untested<b>
	 */
	public boolean sendUp(String in)
	{
		return sendUp(in, 1);
	}

	/** W
	 * 
	 * @param in the MEL commands to execute
	 * @param count the numer of commands to execute
	 */
	public boolean sendUp(String in, int count)
	{
		String fromMaya = "undefined";

		if (in.length() > 4095) // max length maya allows
			error("String too long - \'" + in + "\'");
		
		if (socket==null || socket.isClosed())
		{
			error("Cant find maya - open it and run the MEL command:\n    commandPort -rnc -eo -n \":2424\";");
			return false;
		}
		
		try
		{
			MEL.println(in);
			printWriter.println(in);
			fromMaya = bufferedReader.readLine();
			fromMaya = removeZeros(fromMaya);
			int result = Integer.parseInt(fromMaya);
			if (result != count)
			{
				//error("Result not as expected when performing: "+in);
				return false;
			}
		}
		catch (IOException e)
		{
			error("Error writing to port" + e);
			return false;
		}
		catch (NumberFormatException e)
		{
			//error("Could not parse maya's reply \"" + e+"\"");
			return false;
		}
		return true;
	}
	
	/** Removes the mysterious 0 characters (not 48's, 0's!)
	 * 
	 * @param in
	 * @return
	 */
	private String removeZeros(String in)
	{
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < in.length(); i++)
		{
			char c = in.charAt(i);
			if (c!= 0)sb.append(c);
		}
		return sb.toString();
	}

	/**
	 * Performs a check to see if the Maya is still responsive
	 * 
	 * @return true if we have a link with Maya, false otherwise
	 */
	public boolean doYouReadMe()
	{
		sendUp("print \"maya, do you copy?\\n\"");
		return printWriter != null;
	}

}
