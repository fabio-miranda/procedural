package skyHook;

import static sity.Parameters.fatalErrorSD;
import geom.*;

import java.util.*;

import java.awt.Color;

import javax.vecmath.Vector3d;

import sity.Parameters;

import com.jme.app.SimpleGame;
import com.jme.bounding.BoundingBox;
import com.jme.light.PointLight;
import com.jme.math.*;
import com.jme.renderer.ColorRGBA;
import com.jme.scene.TriMesh;
import com.jme.scene.shape.Sphere;
import com.jme.scene.state.*;
import com.jme.util.geom.BufferUtils;

/**
 * I gotta start doing pictures for the class names i end up with. This creates
 * objects for the JME/ "JMonkey" Engine. Then displays them in a 'game' when
 * allDone() is called.
 * 
 * @author tk1748
 * 
 */
public class MonkeyAnchor extends SimpleGame implements Anchor
{
	private int xSize = 500, ySize = 500;

	private ArrayList<Vector3f> vertices, normals;

	private ArrayList<ColorRGBA> colours;

	private ArrayList<Vector2f> texCoords;

	private ArrayList<Integer> indexes;

	// default or current colors
	private float red, green, blue;

	public MonkeyAnchor()
	{
		newFile();
	}

	/**
	 * Creates an output data structure for Monkey
	 * 
	 * @param xWidth
	 *            width of window
	 * @param yHeight
	 *            heigh tof window
	 */
	public MonkeyAnchor(int xWidth, int yHeight)
	{
		xSize = xWidth;
		ySize = yHeight;
		newFile();
	}

	public void setColor(Color in)
	{
		
	}
	
	public void newFile()
	{
		vertices = new ArrayList<Vector3f>();
		normals = new ArrayList<Vector3f>();
		colours = new ArrayList<ColorRGBA>();
		texCoords = new ArrayList<Vector2f>();
		indexes = new ArrayList<Integer>();
	}

	public void createPolygon(Sheaf in)
	{
		if (in != null) createPolygon(in.getFace());
	}
	
	public void createPolygon(Face face)
	{
		if (face.size() != 3)
		{
			fatalErrorSD("Monkey say only three vertices at a time");
		}

		Iterator<Vertex> it = face.getIter();
		Vertex one = it.next();
		Vertex two = it.next();
		Vertex three = it.next();
		
		Vector3d a = one.sub(two);
		Vector3d b = two.sub(three);
		a.cross(a, b);
		a.normalize();
		it = face.getIter();
		
		while (it.hasNext())
		{
			Vertex v = it.next();
			vertices.add(new Vector3f((float) v.getX(), (float) v.getY(),
					(float) v.getZ()));
			colours.add(new ColorRGBA(0.8f, 0.8f, 0.8f, 1.0f));
			normals.add(new Vector3f((float) a.x, (float) a.y, (float) a.z));
			texCoords.add(new Vector2f(0f, 0f));
			indexes.add(vertices.size() - 1);
		}
	}

	public void createPolygon(List<Face> faeces)
	{
		Iterator<Face> it = faeces.iterator();
		while (it.hasNext())
			createPolygon(it.next());
	}

	public void texture()
	{
		// TODO Auto-generated method stub
	}

	public void allDone()
	{
		//Parameters.error("Firing up JME");
		setDialogBehaviour(SimpleGame.FIRSTRUN_OR_NOCONFIGFILE_SHOW_PROPS_DIALOG);// ALWAYS_SHOW_PROPS_DIALOG);//
		start();
	}

	/**
	 * JMonkey overide to create a nice simple game
	 */
	public void simpleInitGame()
	{
		display.setTitle("Sity (preview)");

		/**
		 * Convert array of Integer to int?!
		 */
		int[] indexArray = new int[indexes.size()];
		int count = 0;
		Iterator<Integer> it = indexes.iterator();
		while (it.hasNext())
		{
			indexArray[count] = it.next();
			count++;
		}

		TriMesh m = new TriMesh("House");
		// Feed the information to the TriMesh
		m.reconstruct(BufferUtils.createFloatBuffer((Vector3f[]) vertices
				.toArray(new Vector3f[0])), BufferUtils
				.createFloatBuffer((Vector3f[]) normals
						.toArray(new Vector3f[0])), BufferUtils
				.createFloatBuffer((ColorRGBA[]) colours
						.toArray(new ColorRGBA[0])), BufferUtils
				.createFloatBuffer((Vector2f[]) texCoords
						.toArray(new Vector2f[0])), BufferUtils
				.createIntBuffer(indexArray));

		// Create a bounds
		m.setModelBound(new BoundingBox());
		m.updateModelBound();

		MaterialState ms = display.getRenderer().createMaterialState();
		ms.setAmbient(new ColorRGBA(0.3f, 0.3f, 0.2f, 0.0f));

		ms.setDiffuse(ColorRGBA.white);
		ms.setShininess(1f);
		ms.setEnabled(true);
		rootNode.setRenderState(ms);

		doLighting();

		// Attach the mesh to my scene graph
		rootNode.attachChild(m);
		// Let us see the per vertex colors

	}

	private void doLighting()
	{
		// Detach all the default lights made by SimpleGame
		lightState.detachAll();

		PointLight l = new PointLight();
		// Give it a location
		l.setLocation(new Vector3f(10, 10, 5));
		// Make it a red light
		l.setDiffuse(ColorRGBA.white);
		// Enable it
		l.setEnabled(true);
		
		PointLight l2 = new PointLight();
		// Give it a location
		l2.setLocation(new Vector3f(-10, -10, 5));
		// Make it a red light
		l2.setDiffuse(ColorRGBA.pink);
		// Enable it
		l2.setEnabled(true);
		
		// Create a LightState to put my light in
		LightState ls = display.getRenderer().createLightState();
		// Attach the light
		ls.attach(l );
		ls.attach(l2);
		rootNode.setRenderState(ls);
		
		/**
		 * SPHERE - delete me when it all works
		 */
		Sphere s = new Sphere("My sphere", 10, 10, 1f);
		// Do bounds for the sphere, but we'll use a BoundingBox this time
		s.setModelBound(new BoundingBox());
		s.updateModelBound();
		// Give the sphere random colors
		s.setRandomColors();
		rootNode.attachChild(s);
		
	}

	public void nextFrame()
	{
		Parameters.errorSD("nextFrame not implmented in monkeyanchor");
	}
	
}
