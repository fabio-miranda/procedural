package skyHook;

import geom.*;

import java.util.*;
import java.util.List;

import java.awt.*;
import java.io.*;

import sity.Parameters;

/**
 * Really simple anchor that aggregates the points and then outputs the results
 * to a abject file
 * 
 * @author tomkelly
 * 
 */
public class ObjAnchor implements Anchor
{
	String name;

	Set<Triple<Integer, Integer, Integer>> tris;

	Map<Vertex, Integer> vertexToNo;

	List<Vertex> order;

	public void allDone()
	{
		try
		{
			BufferedWriter out = new BufferedWriter(new FileWriter(name));
			for (Vertex v: order)
				out.write("v "+v.x+" "+v.y+" "+v.z+"\n");
			for (Triple<Integer, Integer, Integer> t : tris)
				out.write("f "+(t.first()+1)+" "+(t.second()+1)+" "+(t.third()+1)+"\n");
			out.close();
		}
		catch (IOException e)
		{
			Parameters.message("error writing to file "+name);
		}
	}

	public void createPolygon(Face face)
	{
		List<Vertex> lv = face.getVertices();
		assert (lv.size() <= 3);

		int[] indexes = new int[3];

		Vertex a = lv.get(0);
		Vertex b = lv.get(1);
		Vertex c = lv.get(2);
		
		if (lv.size() == 3 && !a.equals(b) && !b.equals(c) && !a.equals(c))
		{


			int count = 0;
			for (Vertex v : lv)
			{
				if (vertexToNo.containsKey(v))
				{
					indexes[count] = vertexToNo.get(v);
				}
				else
				{
					int number = indexes[count] = order.size(); // size will be next index
					order.add(v);
					vertexToNo.put(v, number);
				}
				count++;
			}
			tris.add(new Triple<Integer, Integer, Integer>(indexes[0], indexes[1], indexes[2]));
		}

	}

	public void createPolygon(List<Face> faeces)
	{
		for (Face f : faeces)
			createPolygon(f);
	}

	public void createPolygon(Sheaf in)
	{
		if (in != null)
			createPolygon(in.getFace());
	}

	public void newFile()
	{
		// reset hashes
		tris = new HashSet<Triple<Integer, Integer, Integer>>();
		vertexToNo = new LinkedHashMap<Vertex, Integer>();
		order = new ArrayList<Vertex>();
		// ask for file name, bootstraping for sity frame
		FileDialog file = new FileDialog(sity.Sity.self, " select output obj file ", FileDialog.SAVE);
		file.setVisible(true);
		name = file.getDirectory() + file.getFile();
	}

	public void nextFrame()
	{
		Parameters.errorSD("Next frame not implemented in " + this.getClass().getSimpleName());
	}

	public void setColor(Color in)
	{
		// nothing to do here!
	}

	public void texture()
	{
		// not implemented!

	}

}
