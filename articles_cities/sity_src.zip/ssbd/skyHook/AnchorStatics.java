package skyHook;

import static sity.Parameters.anchor;
import geom.*;

import java.util.*;

import javax.vecmath.*;

public class AnchorStatics
{
	public static void createCube(Vector2d loc, double w)
	{
		double h = 0.001;
		Vertex v1 = new Vertex(loc.x - w, h, loc.y - w);
		Vertex v2 = new Vertex(loc.x + w, h, loc.y - w);
		Vertex v3 = new Vertex(loc.x + w, h, loc.y + w);
		Vertex v4 = new Vertex(loc.x - w, h, loc.y + w);

		List<Vertex> l = new ArrayList<Vertex>();
		l.add(v1);
		l.add(v2);
		l.add(v3);
		Face f = new Face(l);
		anchor.createPolygon(f);
		l  = new ArrayList<Vertex>();
		l.add(v1);
		l.add(v3);
		l.add(v4);
		f = new Face(l);
		anchor.createPolygon(f);
	}

	public static void createArrow(Vector3d start, Vector3d end, double bottom, double top)
	{
		Vertex v1 = new Vertex(start.x, bottom + start.y, start.z);
		Vertex v2 = new Vertex(start.x, top + start.y, start.z);
		Vertex v3 = new Vertex(end.x, ((bottom + top) / 2) + end.y, end.z);
		List<Vertex> l = new ArrayList<Vertex>();
		l.add(v1);
		l.add(v2);
		l.add(v3);
		Face f = new Face(l);
		anchor.createPolygon(f);
	}
}
