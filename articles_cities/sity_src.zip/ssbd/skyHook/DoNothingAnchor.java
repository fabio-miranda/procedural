package skyHook;

import geom.*;

import java.util.List;

import java.awt.Color;

import sity.Parameters;

/**
 * Does what it says on the tin....
 * @author tomkelly
 *
 */
public class DoNothingAnchor implements Anchor
{

	public void allDone()
	{
		// TODO Auto-generated method stub
		
	}

	public void createPolygon(Face face)
	{
		// TODO Auto-generated method stub
		
	}

	public void createPolygon(List<Face> faeces)
	{
		for (Face f : faeces) createPolygon(f);
		
	}
	
	public void createPolygon(Sheaf in)
	{
		if (in != null) createPolygon(in.getFace());
	}

	public void newFile()
	{
		// TODO Auto-generated method stub
		
	}

	public void nextFrame()
	{
		
	}

	public void setColor(Color in)
	{
		// TODO Auto-generated method stub
		
	}

	public void texture()
	{
		// TODO Auto-generated method stub
		
	}

}
