package skyHook;

import geom.*;
import junit.framework.TestCase;

/** Tests the skyhook
 * 
 * @author people
 *
 */
public class TestOpenConnection extends TestCase
{
	public void testOpenConnection()
    {
		MayaSkyHook sh = new MayaSkyHook();
		assertTrue("connection opened", sh.doYouReadMe());
    }
	
	public void testCustomWrite()
    {
		MayaSkyHook sh = new MayaSkyHook();
		assertTrue("connection opened", sh.sendUp("print \"Uplink established\\n\""));
    }
	
	public void testMakePolygon()
    {
		MayaSkyHook sh = new MayaSkyHook();
		Face f = new Face();
		f.addVertex(new Vertex(0,0,0));
		f.addVertex(new Vertex(0,10,0));
		f.addVertex(new Vertex(0,10,10));
		f.addVertex(new Vertex(0,0,10));
		f.addVertex(new Vertex(10,0,10));
		f.addVertex(new Vertex(10,0,0));
		//f.addVertex(new Vertex(10,0,0));
		//f.addVertex(new Vertex(10,10,0));
		Anchor a = new MayaAnchor(sh);
		a.createPolygon(f);
		assertTrue(true);
    }
	
	
}
