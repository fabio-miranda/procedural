package skyHook;

import geom.*;

import java.util.List;

import java.awt.Color;

public interface Anchor {

	/** Does a file->new in Maya
	 */
	public abstract void newFile();

	/** Creates an initial triange then adds points to form a polygon
	 *  bear in mind that this produces a triangulated mesh :)
	 * 
	 * @param face
	 */
	public abstract void createPolygon(Face face);

	public abstract void createPolygon(List<Face> faeces);
	
	public abstract void createPolygon(Sheaf in);

	/** Textures the last object to be made?
	 * 
	 */
	public abstract void texture();
	
	/**
	 * Called when all polygons have been created and its time to show
	 * the result. Called in FREEZER_Root at the moment!
	 *
	 */
	public abstract void allDone();
	
	public abstract void nextFrame();
	
	/**
	 * Sets colour of all following polygons
	 * @param in
	 */
	public abstract void setColor(Color in);

}