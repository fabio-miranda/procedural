package geom;

import static java.lang.Math.*;
import static sity.Parameters.error;

import javax.vecmath.*;

import skeleton.*;

/**
 * This is an overflow class for Vec2d, for the 3rd rewrite of the skelton system. Carefully this time...
 * 
 * @author people
 * 
 */
public class DotMath
{

	private static double distanceTo(Tuple2d a, Tuple2d b)
	{
		double x = a.x - b.x;
		double y = a.y - b.y;
		return Math.sqrt(x * x + y * y);
	}

	// if a bisector is moving slower than this it gets counted as a point
	private final static double ZERO_BISEC = 0.00000000001; 
	
	/**
	 * Collision of a stationary dot bisector with a non-stationary one
	 * @param point stationary
	 * @param test line to test against
	 * @return null iff test does not intersect with in, position otherwise  
	 */
	private static Dot onLine(Dot point, Dot test)
	{
		FlatPoint line = new FlatPoint(test.getPoint());
		// move dot to origin
		line.sub(point.getPoint());
		// now just need to test if line goes through origin
		line.negate();
		// does bisector go in same direction as line?
		if (line.angle(test.getBisector()) < 0.0000001)
		{
			Dot d = new Dot(point.getPoint());
			// calculate height using moving bisector!			
			d.setHeight(findHeight(point.getPoint(), test));
			return d;
		}
		else
		{
			return null;
		}
		
		
	}
	
	/**
	 * Intersects two dots and their directions, we assume that dot b is
	 * after dot a for calculating heights 
	 * 
	 * @param a first dot
	 * @param b following dot
	 * 
	 * @return
	 */
	public static Dot intersectDots(Dot a, Dot b)
	{
		//if (a.isInfinite() || b.isInfinite()) return null;
		// check for stationary points...
		if (a.getBisectorSpeed() < ZERO_BISEC  && b.getBisectorSpeed() < ZERO_BISEC )
		{
			return null;
		}
		else if (a.getBisectorSpeed() < ZERO_BISEC)
		{
			return onLine(a,b);
			
		}
		else if (b.getBisectorSpeed() < ZERO_BISEC)
		{
			return onLine(b,a);
		}
		
		Vector2d scaleA = new Vector2d(a.getBisector());
		Vector2d scaleB = new Vector2d(b.getBisector());

		scaleA.normalize();
		scaleB.normalize();

		Tuple2d destA = new Vector2d(a.getPoint());
		destA.add(scaleA);
		Tuple2d destB = new Vector2d(b.getPoint());
		destB.add(scaleB);

		Vector2d origA = a.getPoint();
		Vector2d origB = b.getPoint();
		Vector2d directionA = a.getBisector();
		Vector2d directionB = b.getBisector();

		double ua = (destB.x - origB.x) * (origA.y - origB.y) - (destB.y - origB.y) * (origA.x - origB.x);

		double ub = (destA.x - origA.x) * (origA.y - origB.y) - (destA.y - origA.y) * (origA.x - origB.x);

		double den = (destB.y - origB.y) * (destA.x - origA.x) - (destB.x - origB.x) * (destA.y - origA.y);

		// intersection before points!
		if (ua / den < 0 || ub / den < 0)
			return null;

		// lines are parrallel
		if (den == 0)// Math.abs(den) < 0.001)
		{
			//System.err.println("parallel");
			// lines are coincident - do we get here if one isn't moving?
			if (ua < 0.00000001 && ub < 0.00000001)
			{
				//System.err.println(directionA + " <><> " + directionB);
				//System.err.println("Lines are co-incident" + directionA.angle(directionB));

				Vector2d bDir = new Vector2d(origB);
				bDir.sub(origA);
				// gradients are the same, b must be in front of a
				if (bDir.angle(directionA) < 0.0000000001)
				{
					//System.err.println("b is in front of a");
					// now check gradients of direction
					if (directionB.angle(directionA) < 0.00000000001)
					{
					//	System.err.println("AB");
						// both going in the same direction with b in front of a
						return doCoincident(a, b, origA, origB,1,1);
					}
					else
					{
					//	System.err.println("BA");
						// different directions with b in front of a, must mean
						// b going towards a and a towards b
						return doCoincident(a, b, origA, origB,1,-1);
					}
				}
				else
				// b is behind a
				{
					//System.err.println("b is behind a");
					// if b going in same direction as a then intersection
					// is possible
					if (directionB.angle(directionA) < 0.00000001)
					{
						return doCoincident(b, a, origB, origA,1,1);
					}
					else
					{
						//System.err.println("opposite directions");
						// going in opposite directions, no intersection possible
						return null;
					}
				}
			}
			else
			{
				// just parallel
				return null;
			}
		}

		double x = origA.x + (ua / den) * (destA.x - origA.x);
		double y = origA.y + (ua / den) * (destA.y - origA.y);
		
		FlatPoint collision = new FlatPoint(x, y);
		Dot d = new Dot(collision);
		d.setHeight(findHeight(collision, a));

		//System.err.println("DOTMATHa:"+findHeight(collision,a)+" b:"+findHeight(collision, b));
		//assert(Math.abs(findHeight(collision, a)-findHeight(collision, b)) < 0.00000001);
		
		
		return d;
	}
	
	/**
	 * By finding how far along the bisector length we are when
	 * we collide we can determine the. UNTESTED, but works!
	 * @return
	 */
	public static double findHeight(FlatPoint collision, Dot d)
	{
		return collision.distanceTo(d.getPoint())/d.getBisectorSpeed()+d.getHeight();
	}

	/**
	 * Finds the location of a collision. Assumes that b is in front of a's direction
	 * @param a
	 * @param b
	 * @param origA
	 * @param origB
	 * @return null if no collision, a Dot representing the collision otherwise
	 */
	private static Dot doCoincident(Dot a, Dot b, Vector2d origA, Vector2d origB, int aDir, int bDir)
	{
		// note bDot bisector negative:
		Dot aDot = new Dot(new FlatPoint(0, a.getHeight()));
		aDot.setBisector(a.getBisector().length()*aDir, 1);
		Dot bDot = new Dot(new FlatPoint(distanceTo(origA, origB), b.getHeight()));
		bDot.setBisector(b.getBisector().length()*bDir, 1);

		// recursive call...
		Dot result = intersectDots(aDot, bDot);

		//System.err.println("coincident reporting intersect of "+aDot+" & "+bDot);
		//System.err.println("a bisec"+aDot.getBisector());
		//System.err.println("b bisec"+bDot.getBisector());
		//System.err.println("result was "+result);
		
		// if no collision
		if (result == null)
			return null;

		// if collision behind a
		if (result.getPoint().x < 0) return null;
		
		// the result was a point of height result.getPoint().y
		// and of distance from a result.getPoint().x
		FlatPoint out = new FlatPoint(origA);
		FlatPoint outBisec = new FlatPoint(a.getBisector());
		outBisec.normalize();
		outBisec.scale(result.getPoint().x);
		out.add(outBisec);

		Dot output = new Dot(out);
		output.setHeight(result.getPoint().y);
				
		return output;
	}
	
	// length of vector when it should be infinite (you dont get direction with infinite tho!)
	private static final double PAR_SPEED = 10E5;
	
	public static Vector2d bisectorAngleOf(Join first, Join second, Dot toSet)
	{
		// Before/After Start/End
		Vector2d bs = new Vector2d(first .getFirst() .getPoint());
		Vector2d be = new Vector2d(first .getSecond().getPoint());
		Vector2d as = new Vector2d(second.getFirst() .getPoint());
		Vector2d ae = new Vector2d(second.getSecond().getPoint());
		
		bs.sub(be);
		ae.sub(as);
	
		return shrink(bs ,new Vector2d(0,0), ae,first.getSpeed(), second.getSpeed(), toSet);
		//return Vec2d.shrink(first.getFirst().getPoint(), first.getSecond().getPoint(), second.getSecond().getPoint(), first.getSpeed(), second.getSpeed()); 
	}
	
	// speed of infinite bisectors
	public static final double BIG_NUMBER = 10E10;
	
	/**
	 * Rather specialised routine to find the direction of a point shot from the
	 * corner of mitre'd joint. As ever clocwise order of poitns
	 * 
	 * This is my maths and the vector is calculated to be
	 * 
	 * @param before
	 *            point before A
	 * @param current
	 *            point to mitre B
	 * @param after
	 *            point after C
	 * @param beforeSpeed
	 *            speed of line section AB
	 * @param afterSpeed
	 *            speed of line section BC
	 * @return
	 */
	private static Vector2d shrink(Tuple2d before, Tuple2d current,
			Tuple2d after, double beforeSpeed, double afterSpeed, Dot dot)
	{
		// left and right point away from current corner
		assert (current != null);
		Vector2d right = new Vector2d(before);
		Vector2d left  = new Vector2d(after );
		
		right.sub(current);
		left.sub(current);

		// make left and right the same length
		left .normalize();
		right.normalize();
		
		//cache for funny parallel cases below
		Vector2d r2 = new Vector2d(right);
		Vector2d l2 = new Vector2d(left);


		
		//System.err.println("************************************************************");
		//System.err.println(before+ " ;;; "+ current+" ;;; "+after);
		double angle = Vec2d.interiorAngleBetween(before, current,after);

		if (angle == 0)
		{
			// if the lines are on top of another return the out vector, but made big
			right.scale(PAR_SPEED);
			dot.setInfinite(true);
			return new Vector2d(right);
		}
		//double 
		double sinAngle = sin(angle);
		
		
		// multiply by factors
		left.scale(beforeSpeed / sinAngle);
		right.scale(afterSpeed / sinAngle);
		
		// add them together
		left.add(right);
		//System.err.println("anlgle is "+angle);
		// if we are running parallel, need to hack and take average of speeds
		if (left.length() == 0 || angle - Math.PI == 0)
		{
			// stationary point, can just go upwards?
			if (beforeSpeed == 0 && afterSpeed == 0)
			{
				return new Vector2d(0,0);
			}

			// we return a supersonic bisector in left or right direction *proper behavour*
			if (beforeSpeed != afterSpeed)
			{
				right.scale(PAR_SPEED);
				return new Vector2d(right);
			}
			// if both are same speed we can just have a bisector going in the expected direction *hacked behavour*
			right = new Vector2d(before);
			right.sub(current);
			// rotate right by 90 degrees, normalise and scale by zerolength
			double angleBetween = Vec2d.angleBetween(new Vector2d(0, 1), right);
			angleBetween -= PI / 2;
			// construct a vector at anglebetween clockwise from (0,1)
			Vector2d result = new Vector2d(sin(angleBetween), cos(angleBetween));
			// System.err.println("inital "+result);
			// same speed
			result.normalize();
			result.scale(beforeSpeed);
			return result;
			/*// System.err.println("after scaling "+result);
			if (result.length() != 0) 
				{
					error("vec2d, shrink parallel called used <old knight> _wisely_ </old knight>) "+result);
					if (beforeSpeed == afterSpeed)
						return result;
					else if (beforeSpeed < afterSpeed)
					{
						r2.scale(BIG_NUMBER);
						return r2;
					}
					else if (beforeSpeed > afterSpeed)
					{
						l2.scale(BIG_NUMBER);
						return l2;
					}
				}
			return result;*/
		}
		return left;
	}
	
	public static boolean isNan(FlatPoint f)
	{
		return (Double.isNaN(f.x) || Double.isNaN(f.y));
	}
}
