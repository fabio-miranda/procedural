package geom;

import static geom.BooleanType.*;
import static sity.Parameters.*;

import java.util.*;
import java.util.Iterator;

import javax.vecmath.Matrix4d;

import junit.framework.TestCase;
import skeleton.*;

/**
 * test for 2d boolean op, part of Sheaf...
 * 
 * @author people
 * 
 */
public class BooleanTest extends TestCase
{
	public void cctestUnion()
	{
		double data[][] = { { 0, 0.5, 1 }, { 0, 0.6, 1 }, { 1, 0.6, 1 }, { 1, 0.5, 1 } };

		double data2[][] = { { 0.5, 0, 1 }, { 0.5, 2, 1 }, { 0.6, 2, 1 }, { 0.6, 0, 1 } };

		setupParameters();

		SheetStaticBuilder sb = new SheetStaticBuilder();// demoSheetBuilder();
		for (int i = 0; i < data.length; i++)
		{
			sb.addPoint(data[i][0], data[i][1]);
			sb.setPointSpeed(data[i][2]);
		}
		Matrix4d ident = new Matrix4d();
		ident.setIdentity();
		Sheaf out1 = new Sheaf(sb.makeSheet(), ident);

		sb = new SheetStaticBuilder();// demoSheetBuilder();

		for (int i = 0; i < data2.length; i++)
		{
			sb.addPoint(data2[i][0], data2[i][1]);
			sb.setPointSpeed(data2[i][2]);
		}
		Sheaf out2 = new Sheaf(sb.makeSheet(), ident);

		Sheaf res = out1.booleanOp(out2, BooleanType.INTERSECT);

		Sheet m = res.getMain();
		m.dump();
		anchor.createPolygon(res.getFace());
		make(out1);

	}

	public void testIntersect()
	{
		double data[][] = { { 2.5, 0, 1 }, { 0, 0, 1 }, { 0.5, 2, 1 }, { 0.75, 1.5, 1 }, { 1, 2, 1 }, { 1.25, 1, 1 }, { 1.5, 2, 1 }, { 1.75, 1.5, 1 }, { 2, 2, 1 } };

		double data2[][] = { { 0.4, 0.6, 0.2 }, { 1.3, 0.5, 0.2 }, { 0.5, 0.7, 0.2 } };

		setupParameters();

		Random random = new Random();
		
		SheetBuilder sb = demoSheetBuilder();
		for (int i = 0; i < data.length; i++)
		{
			sb.addPoint(data[i][0], data[i][1], 0);
			sb.setPointSpeed(random.nextDouble());//data[i][2]);
		}

		sb.newSheet();

		for (int i = 0; i < data2.length; i++)
		{
			sb.addPoint(data2[i][0], data2[i][1], 0);
			sb.setPointSpeed( data2[i][2]);
		}
		Sheaf output = sb.makeSheaf();

		double data3[][] = { { 0.5, 0.1, 1 }, { 0.5, 2, 1 }, { 0.6, 2, 1 }, { 0.6, 0.1, 1 } };

		SheetStaticBuilder sb3 = new SheetStaticBuilder();// demoSheetBuilder();
		for (int i = 0; i < data3.length; i++)
		{
			sb3.addPoint(data3[i][0], data3[i][1]);
			sb3.setPointSpeed(random.nextDouble());//1);// data3[i][2]);
		}
		Sheaf out1 = new Sheaf(sb3.makeSheet());

		Sheaf res = output.booleanOp(out1, INTERSECT);
		// System.err.println("output has sides "+res.getSheets().size());

		anchor.createPolygon(output.getFace());// res.getFace());
		make(output);
	}

	public void make(Sheaf sheaf)
	{
		try
		{
			Bones s = new Bones(sheaf, Double.MAX_VALUE, false);
			// s.outputPuzzle();
			// s.outputRoof();
			List<Sheaf> woof = s.getWoof();

			anchor.createPolygon(sheaf.getFace());
			 
			for (Sheaf f : woof)
			{
				f.getFace();
				anchor.createPolygon(f.getFace());
			}
		}
		catch (BonesSaysNoException e)
		{

		}
	}

	public void xxtestAnim()
	{

		setupParameters();
		int count = 0;
		//for (double s = -1.05; s < 7; s+= 0.1)
		{
			double s = -1.05;//0.049999999999999795;//-1.05+(12*0.1);
			System.err.println(count+" s is ++++++++++++++++++++++++"+s);
			doIt(s);
			anchor.nextFrame();
			count++;
		}
	}

	private void doIt(double s)
	{
		double data[][] = { { 2.5, 0, 1 }, { 0, 0, s }, { 0.5, 2, 1 }, { 0.75, 1.5, 1 }, { 1, 2, 1 }, { 1.25, 1, 1 }, { 1.5, 2, 1 }, { 1.75, 1.5, 1 }, { 2, 2, 1 } };
		//double data[][] = {
		//		{ 2.5, 0, 1 }, { 0, 0, s }, { 0.5, 2, 1 }, { 2, 2, 1 } };
		double data2[][] = { { 0.4, 0.6, 1 }, { 2.3, 0.5, 1 }, { 0.5, 0.7, 1 } };
		
		SheetBuilder sb = demoSheetBuilder();
		for (int i = 0; i < data.length; i++)
		{
			sb.addPoint(data[i][0], data[i][1], 0);
			sb.setPointSpeed(data[i][2]);
		}

		sb.newSheet();
		
		for (int i = 0; i < data2.length; i++)
		{
			sb.addPoint(data2[i][0], data2[i][1], 0);
			sb.setPointSpeed(1);// data2[i][2]);
		}
		Sheaf output = sb.makeSheaf();
		make(output);
	}

}
