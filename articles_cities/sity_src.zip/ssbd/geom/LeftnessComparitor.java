package geom;

import java.util.Comparator;

import util.CEFP;

/**
 * A comparitor that sorts the points into an order by their x values.
 * @author people
 *
 */
public class LeftnessComparitor implements Comparator<CEFP>
{
	public int compare(CEFP one, CEFP two)
	{
		double res = one.thing.x - two.thing.x;
		if (res > 0) return 1;
		if (res < 0) return -1;
		// a point with same coordsbut different next/previous pointers is
		// not the same as one with different pointers
		res = one.thing.y - two.thing.y;
		if (res > 0) return 1;
		if (res < 0) return -1;
		return one.hashCode() - two.hashCode();
	}
}
