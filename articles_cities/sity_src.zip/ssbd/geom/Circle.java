package geom;

import static geom.Vec2d.*;
import static java.lang.Math.*;

import java.util.*;

import javax.vecmath.Vector2d;

/**
 * Represents a circles and a way of generating discrete lines that
 * form its perimieter
 * 
 * @author people
 *
 */
public class Circle
{
	private FlatPoint middle;
	private double radius;
	
	/**
	 * Constructs a circle from its midpoint and its 
	 * @param mind mid poitns
	 * @param rad radium
	 */
	public Circle(FlatPoint mind, double rad)
	{
		middle = mind;
		radius = rad;
	}
	
	/**
	 * construct a circle from three edge points
	 * @param a the
	 * @param b three
	 * @param c edgepoints
	 */
	public Circle(FlatPoint a, FlatPoint b, FlatPoint c)
	{
		System.err.println(a+" "+b+c);
		Pair<Vector2d, Vector2d> one = findBisector(a,b);
		Pair<Vector2d, Vector2d> two = findBisector(b,c);
		middle = intersect(one.first(), two.first(), one.second(), two.second());
		radius = middle.distanceTo(a);
	}
	
	/**
	 * This finds a list of points, each pair no more that lineLength apart
	 * that will join the points a and b on the circle clockwise along its path
	 *  
	 * @param a first pt
	 * @param b second pt
	 * @param lineLength minimum length of the line
	 * @param lastPoint - is the final flatpoint output?
	 */
	public List<FlatPoint> getClockwiseBetween(FlatPoint a, FlatPoint b, double lineLength, boolean lastPoint)
	{
		Vector2d A = new Vector2d(a);
		A.sub(middle);
		Vector2d B = new Vector2d(b);
		B.sub(middle);
		
		double start = angleBetween(new Vector2d(0, 1),A);
		double end = angleBetween(new Vector2d(0, 1),B);
		
		Vector2d sv = new Vector2d(A);
		Vector2d ev = new Vector2d(B);
				
		// angle between start and end
		double togo = angleBetween(sv,ev);
		
		double circum = 2*PI*radius;
		
		// distnace we will be covering
		double distance = togo*circum/(2*PI);
		
		int numPoints = new Long(Math.round(Math.ceil(distance/lineLength))).intValue();
		numPoints = max(numPoints,2);
		double degEachTime = togo/numPoints;
		
		List<FlatPoint> fp = new Vector<FlatPoint>(2);
				
		// ensure first point is not prone to rounding errors 
		fp.add(a);
		
		
		// for each point
		for (int x = 1; x < numPoints; x++)
		{
			//clockwise from (1,0) angle of new points
			double angle = x*degEachTime+start;
			FlatPoint f = new FlatPoint(radius*sin(angle)+middle.x, radius*cos(angle)+middle.y);
			f.addType(EdgeType.SMOOTH);
			fp.add(f);
		}
		
		// add in last point if required
		if (lastPoint) fp.add(b);
		
		return fp;
	}
	
	/**
	 * finds the perpendicular vector to the vector made between these
	 * two poit
	 * @param one
	 * @param two
	 * @return
	 */
	private Pair<Vector2d, Vector2d>findBisector(FlatPoint one, FlatPoint two)
	{
		Vector2d ab = new Vector2d(two);
		ab.sub(one);
		
		double oAngle = angleBetween(new Vector2d(0, 1), ab) - PI / 2;
		Vector2d perp = new Vector2d(sin(oAngle), cos(oAngle));
		ab.scale(0.5);
		ab.add(one);
		
		return new Pair<Vector2d, Vector2d>(ab,perp);
	}

	public FlatPoint getMiddle()
	{
		return middle;
	}

	public double getRadius()
	{
		return radius;
	}
	
}
