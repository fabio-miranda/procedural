package geom;

import java.util.*;

import javax.vecmath.Matrix4d;

public class SheetStaticBuilder
{
	private List<FlatPoint> fps = null;
	FlatPoint lastFP;
	/**
	 * Constructs a sheet for points to be added to!
	 *
	 */
	public SheetStaticBuilder()
	{
		fps = new Vector<FlatPoint>();
	}
	
	/**
	 * Functions to add to a sheet, when finished call doneAdding to set
	 * up the structure
	 * @param x
	 * @param y
	 */
	public void addPoint(double x, double y)
	{
		lastFP = new FlatPoint(x,y);
		fps.add(lastFP);
	}
	/**
	 * sets speed of last added point
	 * @param in
	 */
	public void setPointSpeed(double in)
	{
		lastFP.setSpeed(in);
	}
	/**
	 * sets last type
	 * @param in
	 */
	public void addType(EdgeType in)
	{
		lastFP.addType(in);
	}
	/**
	 * creates a point BY DIRECTLY REFERENCING the specified flatpoint
	 * @param in
	 */
	public void addPoint(FlatPoint in)
	{
		lastFP = in;
		fps.add(lastFP);
	}
	/**
	 * creates a real sheet from this
	 *
	 */
	public Sheet makeSheet()
	{
		Sheet s = new Sheet(fps);
		fps = null;
		return s;
	}
	
	/**
	 * Creates a sheaf from teh defined sheet at the origin
	 * @return
	 */
	public Sheaf makeSheaf()
	{
		Matrix4d ref = new Matrix4d();
		ref.setIdentity();
		Sheaf out = new Sheaf(ref);
		out.addSheet(makeSheet());
		return out;
	}
}
