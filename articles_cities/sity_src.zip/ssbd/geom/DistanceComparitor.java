package geom;

import java.util.Comparator;

import util.CEFP;

/**
 * A comparitor that sorts the points into an order by their x values.
 * @author people
 *
 */
public class DistanceComparitor implements Comparator<Pair<CEFP,Double>>
{
	private CEFP ref = null;
	
	public DistanceComparitor(CEFP ref)
	{
		this.ref = ref;
	}
	
	public int compare(Pair<CEFP,Double> one, Pair<CEFP,Double> two)
	{
		
		//assert(one.first().thing.equals(one.second().thing));
		//assert(two.first().thing.equals(two.second().thing));
		
		double a = one.first().thing.distanceTo(ref.thing);
		double b = two.first().thing.distanceTo(ref.thing);
		double res = a - b;
		if (res > 0) return 1;
		if (res < 0) return -1;
		// a point with same coordsbut different next/previous pointers is
		// not the same as one with different pointers
		return one.hashCode() - two.hashCode();
	}
}
