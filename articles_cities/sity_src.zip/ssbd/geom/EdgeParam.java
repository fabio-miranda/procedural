package geom;

import cloud.Wall;

public class EdgeParam implements Comparable
{
	private double value;
	private Wall wall;
	private int type;
	
	public final static int MIN = 0;
	public final static int MAX = 1;
	
	public EdgeParam(double value, Wall wall, int val)
	{
		super();
		this.value = value;
		this.wall = wall;
		type = val;
	}
	public double getValue()
	{
		return value;
	}
	public void setValue(double value)
	{
		this.value = value;
	}
	public Wall getWall()
	{
		return wall;
	}
	public void setWall(Wall wall)
	{
		this.wall = wall;
	}
	
	public int compareTo(Object arg0)
	{	
		EdgeParam other = EdgeParam.class.cast(arg0);
		if (other.getValue() < value) return  1;
		if (other.getValue() > value) return -1;
		return 0;
	}
	public int getType()
	{
		return type;
	}
	public void setType(int type)
	{
		this.type = type;
	}
}
