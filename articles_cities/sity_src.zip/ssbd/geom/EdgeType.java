package geom;

/**
 * Meta data tags
 * @author people
 *
 */
public enum EdgeType
{
	/**
	 * REFERENCE - the line that is at the bottom to calculate the next instanced location after
	 * a freeze
	 * UNMOVABLE - indicates to some algorithms that this point is not to be moved
	 * ROOFEDGE - a join between two roof sections
	 * BEVELTOP - top edges marked as this after a bevel-ized straight skeleton
	 * TOP, BOTTOM - at the moment these are just used to tag sides of a window frame
	 * SMOOTH - for a surface that that is domed or arched or sommat
	 * FRONT - decided apon front of a property
	 * INSIDE_GUTTER - inside result from a guttering procedure
	 * OUTSIDE_GUTTER
	 * EDGE_GUTTER - end of a gutter
	 * GUTTER - marks this edge for gutter creation
	 * MY_WALL - say sthat this edge can have a wall on it that just belongs to this plot
	 * SIDE - side wall of a house
	 * GABLED - a wall marked as being a gabled!
	 * TOP_BEVEL_OUTPUT - applied to both the points at the top of a sidepanel of a woof
	 */
	REFERENCE, EXIT, NEIGHBOUR, STREET, UNMOVEABLE, ROOFEDGE,BEVELTOP,INTERSECTED,
	TOP, BOTTOM, SMOOTH, FRONT, INSIDE_GUTTER, OUTSIDE_GUTTER, EDGE_GUTTER, GUTTER,
	MY_WALL, SIDE, GABLED; 
}
