package geom;

import java.util.*;

import java.awt.geom.*;

import javax.vecmath.Vector2d;

import sity.Parameters;
import util.*;

/**
 * A sheaf is a stack of sheets! it may contain several different sheets as a collection
 * (in which case all will be clockwise)
 * or represent a solid surface (with holes defined counter clockwise.)
 * @author people
 *
 */
public class Sheet
{
	CEFP first = null;
	List<SheetType>types = new ArrayList<SheetType>();
	boolean isHole = false;
	int size = 0;
	private Sheaf sheaf = null;

	
	public Sheet(List<FlatPoint> lfp)
	{
		setup(lfp);
	}
	
	public void setup(List<FlatPoint> lfp)
	{
		Iterator<FlatPoint>it = lfp.iterator();
		CEFP previous = first = new CEFP(it.next());
		size = 1;
		while (it.hasNext())
		{
			size++;
			previous.next = new CEFP(it.next());
			previous.next.previous = previous;
			previous = previous.next;
		}
		
		first.previous = previous;
		previous.next = first;
	}
	
	public void setAllSpeeds(double in)
	{
		CEFPIterator it = new CEFPIterator(first);
		while (it.hasNext())
		{
			it.next().thing.setSpeed(in);
		}
	}
	
	/**
	 * Finds the total length of all the line sections in this sheet
	 * @return
	 */
	public double length()
	{
		double total = 0;
		CEFPIterator it = new CEFPIterator(first);
		while (it.hasNext())
		{
			CEFP a = it.next();
			CEFP b = a.previous;
			total+=a.thing.distanceTo(b.thing);
		}
		return total;
	}
	
	/**
	 * Finds a point this far from the start of the sheet in a clockwise direction
	 *
	 */
	public FlatPoint getPointAround(double howFar)
	{
		double total = 0;
		CEFPIterator it = new CEFPIterator(first);
		while (it.hasNext())
		{
			CEFP a = it.next();
			CEFP b = a.previous;
			double oldTotal = total;
			double dist = a.thing.distanceTo(b.thing);
			total+=dist;
			if (total > howFar)
			{
				//we want to go howFar-oldTotal from b to a 
				double aToB = (howFar-oldTotal)/dist;
				
				return new FlatPoint( 
						(1-aToB)*a.thing.x + (aToB)*b.thing.x,
						(1-aToB)*a.thing.y + (aToB)*b.thing.y);
			}
		}
		assert(false);
		return getPointAround(howFar-length());
	}
	
	public void reverse()
	{
		CEFPIterator it = new CEFPIterator(first);
		while (it.hasNext())
		{
			CEFP c = it.next();
			CEFP tmp = c.previous;
			c.previous = c.next;
			c.next = tmp;
		}
		toggleHole();
	}

	/**
	 * returns the first element ofthis sheet
	 * @return
	 */
	public CEFP getFirst()
	{return first;}
	
	/** Returns an iterator over all the points in this shape.
	 * 
	 * @return
	 */
	public Iterator<CEFP> getPoints()
	{
		return new CEFPIterator(first);
	}
	
	public CEFPIterator iterator()
	{
		return new CEFPIterator(first);	
	}

	/**
	 * Add a meta data tag to this sheet eg "window"
	 * @param in
	 */
	public void addType(SheetType in)
	{
		types.add(in);
	}
	
	/**
	 * is this sheet taged with the specified type?
	 * @param in the type to check
	 * @return if this sheet is tagged with that name
	 */
	public boolean hasType(SheetType in)
	{
		return types.contains(in);
	}

	public int size()
	{
		return size;
	}
	/**
	 * does this sheet contain a hole?
	 * @param in
	 * @return
	 */
	public boolean setHole(boolean in)
	{
		isHole = in;
		return isHole;
	}
	
	/**
	 * toggle between being a hole and not - happens automatically when
	 * your reverse the direction of this sheet
	 * @return
	 */
	public boolean toggleHole()
	{
		isHole = !isHole;
		return isHole;
	}
	
	/**
	 * debug function to show the conetents fo this sheet on System.err
	 *
	 */
	public void dump()
	{
		CEFPIterator c = new CEFPIterator(first);
		while (c.hasNext())
		{
			FlatPoint f = c.next().thing;
			System.err.println("Sheet.dump: "+f+" s[eed@ "+f.getSpeed());
		}
		Parameters.fatalErrorSD("arse");
	}
	
	/**
	 * if this were a mole hole, could a mole live here? Is this sheet tagged
	 * as a hole eg: is it specified counterclockwise
	 * @return
	 */
	public boolean isHole()
	{
		return isHole;
	}


	public Sheaf getSheaf()
	{
		return sheaf;
	}


	public void setSheaf(Sheaf sheaf)
	{
		this.sheaf = sheaf;
	}
	
	
	/**
	 * We cache the maximum and minimum extent of this sheet, if
	 * we are asked for any dimension.
	 */
	double xmin = Double.MAX_VALUE,xmax = -Double.MAX_VALUE,
	ymin = Double.MAX_VALUE,ymax = -Double.MAX_VALUE;
	
	private void getMaxDims()
	{
		CEFPIterator cit = new CEFPIterator(first);
		while (cit.hasNext())
		{
			FlatPoint p = cit.next().thing;
			if (p.x > xmax) xmax = p.x;
			if (p.y > ymax) ymax = p.y;
			if (p.x < xmin) xmin = p.x;
			if (p.y < ymin) ymin = p.y;
		}
	}
	
	public double getMaxX()
	{
		if (xmin == Double.MAX_VALUE)
			getMaxDims();
		return xmax;
	}
	public double getMaxY()
	{
		if (xmin == Double.MAX_VALUE)
			getMaxDims();
		return ymax;
	}
	public double getMinX()
	{
		if (xmin == Double.MAX_VALUE)
			getMaxDims();
		return xmin;
	}
	public double getMinY()
	{
		if (xmin == Double.MAX_VALUE)
			getMaxDims();
		return ymin;
	}
	
	/**
	 * scales all poitns in the sheet by
	 * @param x width
	 * @param y height
	 */
	public void scale(double x, double y)
	{
		CEFPIterator cit = new CEFPIterator(first);
		while (cit.hasNext())
		{
			FlatPoint p = cit.next().thing;
			p.x *= x;
			p.y *= y;
		}
	}
	
	/**
	 * moves all the points in this sheet by 
	 */
	public void move(double x, double y)
	{
		CEFPIterator cit = new CEFPIterator(first);
		while (cit.hasNext())
		{
			FlatPoint p = cit.next().thing;
			p.add(new Vector2d(x,y));
		}
	}
	/**
	 * creates a sheet with two points - 0,0 and 1,0
	 * @return the sheet with the line
	 */
	public static Sheet lineBetween01()
	{
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0,0));
		fp.add(new FlatPoint(1,0));
		return new Sheet(fp);
	}
	
	/**
	 * adds all the points in this sheet to the specified list. tags
	 * all poitns apart from the final one with the specified tag
	 * @param in
	 */
	public void addPointsTo(List<FlatPoint> in, EdgeType tag)
	{

		CEFPIterator cit = new CEFPIterator(first);
		FlatPoint last = null;
		while (cit.hasNext())
		{
			size++;
			FlatPoint p = cit.next().thing;
			in.add(new FlatPoint(p));
			
			if (tag != null && last != null) last.addType(tag);
			
			last = p;
		}
	}
	
	/**
	 * Finds the first CEFP in the shortest edge. Yay for brute force!
	 * 
	 * @return shortest edge
	 */
	public CEFP findShortest()
	{
		
		CEFP best = first;
		double dist = Double.MAX_VALUE;
		
		CEFPIterator cit = new CEFPIterator(first);
		FlatPoint last = null;
		while (cit.hasNext())
		{
			CEFP m = cit.next();
			double d = m.thing.distanceTo(m.next.thing);
			if (d < dist)
			{
				dist = d;
				best = m;
			}
		}
		return best;
	}
	
	public void addPointsBackwardsTo(List<FlatPoint> in, EdgeType tag)
	{

		CEFPBackwardsIterator cit = new CEFPBackwardsIterator(first);
		FlatPoint last = null;
		while (cit.hasNext())
		{
			size++;
			FlatPoint p = cit.next().thing;
			in.add(new FlatPoint(p));
			
			if (tag != null && last != null) last.addType(tag);
			
			last = p;
		}
	}
	
	public static double getFuthestFromStreetStartingWith(CEFP s)
	{
		FlatPoint start = s.thing;
		FlatPoint end = s.next.thing;
		
		CEFPIterator cit = new CEFPIterator(s);
		double maxDist = -Double.MAX_VALUE;
		CEFP maxCEFP = s;
		
		while (cit.hasNext())
		{
			CEFP o = cit.next();
			FlatPoint other = o.thing;
			double dist = Math.abs(Vec2d.distanceFromLine(start,end, other));
			if (dist > maxDist) 
			{
				maxDist = dist;
				maxCEFP = o;
			}
		}
		assert maxCEFP != null;
		return maxDist;
	}

}
