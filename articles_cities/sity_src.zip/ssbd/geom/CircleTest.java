package geom;

import java.util.*;

import junit.framework.TestCase;

public class CircleTest extends TestCase
{
	public void testMiddle()
	{
		Circle c= new Circle(new FlatPoint(1,1),1);
		List<FlatPoint> lfp = c.getClockwiseBetween
		(new FlatPoint(0,1), new FlatPoint(1,2),0.1,true);
		assertTrue(lfp.get(0).samePlaceAs(new FlatPoint(0,1)));
		assertTrue(lfp.get(lfp.size()-1).samePlaceAs(new FlatPoint(1,2)));
		Iterator<FlatPoint> it = lfp.iterator();
		FlatPoint last = null;
		while (it.hasNext())
		{
			FlatPoint f = it.next();
			System.err.println(">>=>"+f);
			assertTrue (last == null || last.distanceTo(f) < 0.1);
			last = f;
		}
	}
	
	public void test3Point()
	{
		Circle c= new Circle(new FlatPoint(0.004815273327803071, 1.09801714032956),
				new FlatPoint(0.2928932188134523, 1.7071067811865475),
				new FlatPoint(0.9019828596704395, 1.995184726672197));
		List<FlatPoint> lfp = c.getClockwiseBetween
		(new FlatPoint(0,1), new FlatPoint(1,2),0.1,true);
		assertTrue(c.getMiddle().distanceTo(new FlatPoint(1,1)) < 0.000000001);
		assertTrue(Math.abs(c.getRadius()-1) < 0.000000001);
	}
	
}
