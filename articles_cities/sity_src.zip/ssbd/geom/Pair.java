package geom;

/** Adapted from ibm.com
 * 
 * @author tom
 *
 * @param <A>
 * @param <B>
 */
public class Pair <A,B> {
  private A element1;
  private B element2;
  
  public Pair(A element1, B element2){
      this.element1 = element1;
      this.element2 = element2; 
  }
    
  public void setFirst(A a)
  {
	  element1 = a;
  }
  
  public void setSecond(B b)
  {
	  element2 = b;
  }
  
  public A first(){
      return element1;
  }
  
  public B second(){
      return element2;
  }
  
  public String toString()
  {
	  return "("+element1+","+element2+")";
  }
}
  