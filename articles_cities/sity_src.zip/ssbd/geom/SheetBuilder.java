package geom;

import static geom.EdgeType.REFERENCE;
import static geom.Vec2d.angleBetween;
import static java.lang.Math.*;
import static sity.Parameters.*;

import java.util.*;

import javax.media.j3d.Transform3D;
import javax.vecmath.*;

import sity.Parameters;
import skeleton.Dot;
import util.CEFPIterator;

/**
 *  
 * @author tomkelly
 * 
 */
public class SheetBuilder
{

	protected Matrix4d transform = null;

	protected List<Vertex> data = null;

	private Vertex lastPoint = null;

	// keep a reference to this to remember our plane of reference if another
	// sheet is added
	private Sheaf upstream = null;


	// a map from input points to output points
	private Map<Vertex, FlatPoint> IOList = new LinkedHashMap<Vertex,FlatPoint>();
	
	/**
	 * A new sheet is constructed fromthe sheet higher up the hierarchy, and a list of points <b> in the coordinate space of the upstream node </b>
	 * 
	 * @param in
	 *            the upstream Sheet, or null to assume an empty transform
	 * @param points
	 *            the points specified in <i>the sheetsin's</i> coordinate space.
	 */
	public SheetBuilder(Sheaf in)
	{
		upstream = in;
		setup();
	}

	/**
	 * Functions that get called when we create a new sheet!
	 * 
	 */
	private void setup()
	{
		data = new ArrayList<Vertex>(3);

		if (upstream == null)
		{ // set to a 'null' transform matrix
			transform = new Matrix4d();
			transform.setIdentity();
		}
		else
		{
			transform = new Matrix4d(upstream.getTransform());
		}
	}

	/**
	 * After creation of the sheet use this method to add vertices. The coordinate here is to be noted. I consider the 'across' first(X) followed by up(Z/Y?!) then finally out (away from the previous sheet)
	 * 
	 * @param x
	 *            accross
	 * @param y
	 *            up
	 * @param z
	 *            out
	 */
	public Vertex addPoint(double x, double y, double z)
	{
		if (data == null)
		{
			error("The makeSheet command has already been called, you can't add any more coordinates!");
		}
		lastPoint = new Vertex(x, z, y); // y is out of the system!
		data.add(lastPoint);
		return lastPoint;
	}
	
	public void addPoint(Vector3d in)
	{
		addPoint(in.x, in.y, in.z);
	}
	
	public void addPoint(Dot d, boolean flat, double scale)
	{
		FlatPoint f =  d.getPoint();
		if (!flat)
			addPoint(f.x, f.y, d.getHeight()*scale);
		else
			addPoint(f.x, f.y, 0);
	}

	/**
	 * Adds a type to the last specified
	 * 
	 * @param in
	 *            the type to add to the last addPoint() point!
	 */
	public void setPointType(EdgeType in)
	{
		lastPoint.addType(in);
	}

	/**
	 * Sets the speed
	 * 
	 * @param in
	 *            the speed
	 */
	public void setPointSpeed(double speed)
	{
		lastPoint.setSpeed(speed);
	}

	// where the multiple sheets are accumulated
	private Sheaf sheaf;

	// stores the transformation in our plane, and is only set the first
	// sheet that is created
	private Matrix4d partTwo = null;

	private Matrix4d partOne = null;

	public void newSheet()
	{
		if (data.size() == 0)
			return; // no error msg here!
		if (data.size() < 3)
			error("There are only " + data.size() + " points specified!");
		else
		{
			//System.err.println("using transform: \n"+transform);
			//for (Vertex v: data)
			//	System.err.println("Sheetbuilder start wut "+v.getSpeed());
			// convert the specified points to the global coord system using parents transform
			normalisePoints();
			// find the plane of the incomming points global coord system
			Tuple4d abcd = Vec3d.findPlane(data);
			// if we cant find the plane caus its too small, skip!
			if (abcd != null)
			{
				//System.err.println("Plane is "+abcd+" data size "+data.size());
				List<FlatPoint> lfp;
				if (partOne == null)
				{
					partOne = flattern(abcd);
				}

				if (partTwo == null)
				{
					// IOList changes are overwriten below
					List<FlatPoint> tmp = applyFlatten(data,partOne, null);
					// for concave shapes, the normal may come out 180 degrees off:
					if (Vec2d.findArea(tmp) < 0)
						{
							abcd = Vec3d.findPlane(data, true);
							partOne = flattern(abcd);
							// IOList changes are overwriten below
							tmp = applyFlatten(data,partOne, null);
						}
					partTwo = normalisePlaneLocation(tmp);
				}
				
				//for (Vertex t: data) System.err.println(" p2 befpre flatten locaiton is "+t);
				//List<FlatPoint> tmp = applyFlatten(data,partOne);
				//List<Vertex> tmp2 = applyTransform(tmp, partTwo);
				//for (Vertex t: tmp2) System.err.println(" p2 after flatten locaiton is "+t);
				//for (Vertex t: tmp2) System.err.println(" p2 converted back tis "+ t.multiplyBy(partTwo));
				
				
				//System.err.println("part one is \n"+partOne);
				//System.err.println("part two is \n"+partTwo);
				
				Matrix4d m = new Matrix4d(partTwo);
				m.mul(partOne);
				
				//System.err.println("combined is \n"+m);
				
				// called at the end, these are the values that stay in IO list!
				lfp = applyFlatten(data, m, IOList);
				
				
				// remove all short edges as they may create non-simple polygons which
				// cant be triangulated
				removeShortEdges(lfp, 10E-10);
				
				//for (FlatPoint f: lfp)
				//	System.err.println("stored data is then "+f);

				//for (FlatPoint t: lfp) System.err.println(" reconstituted tis "+ t.multiplyByInverseOf(m));
				
				if (lfp.size() >= 3)
				{
				if (sheaf == null)
					sheaf = new Sheaf(lfp, m);
				else
					sheaf.addSheet(new Sheet(lfp), m);
				}
				else
				{
					Parameters.error("removed a sheet for having < 3 points after removing short edges");
				}
			}
		}
		// reset to take another sheet!
		data = new ArrayList<Vertex>(3);
		lastPoint = null;
		setup();
		// return new Sheaf(lfp, finalMatrix);
	}
	
	public void removeShortEdges(List<FlatPoint> lfp, double tolerance)
	{
		assert(lfp.size() > 0);
		ListIterator<FlatPoint> lit = lfp.listIterator();
		if (! lit.hasNext()) return;
		FlatPoint current = lit.next();
		while (lit.hasNext())
		{
			FlatPoint next = lit.next();
			if (current.distanceTo(next) < tolerance)
			{
				lit.remove(); // remove next;
			}
			else
			{
				current = next;
			}
		}
	}

	public void dump(List<FlatPoint> data)
	{
		Iterator<FlatPoint> it = data.iterator();
		while (it.hasNext())
		{
			System.err.println("dumped:" + it.next());
		}
	}

	/**
	 * Apply a given transform to the list of flatpoints
	 * 
	 * @param in
	 * @param data
	 */
	public void transformPointsBy(Matrix4d in, List<FlatPoint> data)
	{
		Iterator<FlatPoint> it = data.iterator();
		while (it.hasNext())
		{
			FlatPoint fp = it.next();
			fp.multiplyBy(in);
		}
	}

	/**
	 * Once the sheet is constructed calling this routine will do the math to create the sheet object
	 * 
	 * @return The sheet that has just been built.
	 */
	public Sheaf makeSheaf()
	{
		newSheet();
		return sheaf;
	}

	/**
	 * Apply the inverse transfrom to the points to move them into the absolute / 
	 * normalised coordinate system.
	 * 
	 */
	protected void normalisePoints()
	{
		Iterator<Vertex> it = data.iterator();
		Matrix4d mat = new Matrix4d(transform);
		mat.invert();

		while (it.hasNext())
		{
			Vertex v = it.next();
			v.multiplyBy(mat);
		}
	}

	protected Tuple4d findPlane()
	{
		return Vec3d.findPlane(data);
	}

	/**
	 * Finds the cross product between the first three points int the data set and returns the ABC & D values :)
	 * 
	 * @param points
	 * @return
	 */
	protected Tuple4d funnyPlane()
	{
		Tuple4d t = Vec3d.findPlane(data, data.get(2).sub(data.get(1)), data.get(1).sub(data.get(0)));
		//Tuple4d f = Vec3d.findPlane(data, data.get(3).sub(data.get(2)), data.get(2).sub(data.get(1)));
		// Tuple4d g =
		// findPlane(data.get(2).sub(data.get(1)),data.get(1).sub(data.get(0)));
		return t;
	}

	/**
	 * Creates a transform to rotate the specified plane to lie on the XZ axes and applies it to the points and return a list of the 2D points represented
	 * 
	 * @param in
	 *            the normalised plane equation
	 * @return a pair of the new flat points and the 3D transform that was used on them
	 */
	protected Matrix4d flattern(Tuple4d in)
	{
		Matrix4d trans = new Matrix4d();
		trans.setIdentity();

		Vector3d current = new Vector3d(in.x, in.y, in.z);
		Vector3d goal = new Vector3d(0, 1, 0);
		current.normalize();
		goal.normalize();

		Vector3d axis = new Vector3d();
		axis.cross(current, goal);

		// find the angle between the two vectors
		double angle;
		// are parallel
		if (axis.x == 0 && axis.y == 0 && axis.z == 0)
		{
			// shoddy solution to finding unique axis, direction irrelevant
			if (current.x > 0)
			{
				axis.set(-1, 0, 0);
			}
			else
			{
				axis.set(1, 0, 0);
			}
			// parallel axis! eep. Find out whether the same or opposite...
			// they are normalised so this works
			if (current.x == goal.x && current.y == goal.y && current.z == goal.z)
			{
				// same direction no rotation necessary
				angle = 0;
			}
			else
			{
				// must be exactley opposite
				angle = Math.PI;
			}
		}
		else
		{
			Vector3d diff = new Vector3d(goal);
			diff.sub(current); // is this the wrong way around?
			angle = Math.acos((2 - (diff.lengthSquared())) / 2);
		}
		// System.err.println("rotation is around " +axis +" by "+angle);

		// perform the rotation
		Matrix4d rot = new Matrix4d();
		rot.setIdentity();
		rot.setRotation(new AxisAngle4d(axis, angle));

		trans.setTranslation(new Vector3d(0, in.w, 0));
		trans.mul(rot);
		// System.err.println(trans);

		return trans;
	}
	
	/**
	 * prives a map from input points to output points
	 * @param in
	 */
	public FlatPoint getFlatPoint(Vertex in)
	{
		return IOList.get(in);
	}
	
	private static List<FlatPoint> applyFlatten(List<Vertex> in, Matrix4d trans, 
			Map<Vertex, FlatPoint> IOList)
	{
		//for (Vertex f: in) System.err.println("found by applyFlatten as "+f.getSpeed());
		Iterator<Vertex> dp = in.iterator();

		List<FlatPoint> flat = new ArrayList<FlatPoint>();
		while (dp.hasNext())
		{
			// this new
			Vertex origV = dp.next();
			Vertex v = new Vertex(origV);
			v.multiplyBy(trans);
			// check all the points are planar!
			// System.err.println("height is "+v.getY());
			if (Math.abs(v.getY()) > 0.001)
			{
				error("Non planar vertex (" + v + ") submitted for sheet " + Math.abs(v.getY()));
			}
			else
			{
				FlatPoint togo = new FlatPoint(v.getX(), v.getZ());
				togo.setSpeed(v.getSpeed());
				if (IOList != null) IOList.put(origV,togo);
				//System.err.println("putting (in sheetbuilder) "+origV+" to "+togo);
				// add the properties from the 3d to the 2d version
				Iterator<EdgeType> it = v.getTypes();
				while (it.hasNext())
				{
					togo.addType(it.next());
				}
			flat.add(togo);
			}
		}
		return flat;
	}
	
	private static List<Vertex> applyTransform(List<FlatPoint> in, Matrix4d trans)
	{
		List<Vertex> out = new ArrayList<Vertex>();
		for (FlatPoint f: in)
		{
			FlatPoint ff = new FlatPoint(f);
			Point3d v = new Point3d(ff.get3d());
			Transform3D t = new Transform3D();
			t.set(trans);
			t.transform(v);
			out.add(new Vertex(v));
		}
		return out;
	}


	// remembered state for normlaiseplanelocaiton below
	double minX = Double.MAX_VALUE;
	double minY = Double.MAX_VALUE;
	double angle;
	
	/**
	 * Takes the plane in 2D space and constructs a 3D transform to move it 
	 * into the 2D first quadrent, with a sensible up direction. This is tricky 
	 * stuff! Assume that they are in the XZ 3D space and that '2D-up' is Z.
	 * 
	 */
	protected Matrix4d normalisePlaneLocation(List<FlatPoint> points)
	{
		// first deal with rotation. Locate bottom edge vector.
		Iterator<FlatPoint> it = points.iterator();
		Vector2d toStraighten = null;
		while (it.hasNext())
		{
			FlatPoint fp = it.next();
			// System.err.println(fp);
			if (fp.ofType(REFERENCE))
			{
				if (toStraighten != null)
				{
					fatalErrorSD("More than one vertex with REFERENCE tags!");
				}
				// if not the final vertex
				if (it.hasNext())
				{
					FlatPoint next = it.next();
					toStraighten = new Vector2d(fp);
					// System.err.println(">>>"+next);
					toStraighten.sub(next);
					// System.err.println("from "+next+" to "+fp);
					if (next.ofType(REFERENCE))
					{
						fatalErrorSD("More than one vertex with REFERENCE tags!!");
					}
				}
				else
				// final vertex, connects to first
				{
					toStraighten = new Vector2d(fp);
					toStraighten.sub(points.get(0));
				}
			}
		}
		/*
		 * trying to ground (0.0, -2.0) 2D Angle is 1.5707963267948966 now rotating trying to ground null 2D Angle is 0.0 now rotating
		 */
		// System.err.println("trying to ground "+toStraighten);
		Matrix4d rot = new Matrix4d();
		rot.setIdentity();

		// if there was a reference do a rotation, otherwise leave it as is!
		if (toStraighten != null)
		{
			// toStraighten.normalize();
			angle = -angleBetween(new Vector2d(1, 0), toStraighten);
			// angle = angle; // sign change for rotates - they're
			// counterclockwise
			rot.rotY(angle);
		}
		else
		// no preference for a rotation so ignore it
		{
			angle = 0;
		}
		// find min value of each point in Z,X directions

		//System.err.println("2D Angle is "+ angle +" now rotating");

		it = points.iterator();
		// find min at same time as applying rotation!
		while (it.hasNext())
		{
			FlatPoint fp = it.next();
			if (fp.x < minX)
				minX = fp.x;
			if (fp.y < minY)
				minY = fp.y;
		}
		// apply translation to ensure all are just positive
		Matrix4d trans = new Matrix4d();
		trans.setIdentity();
		trans.setTranslation(new Vector3d(-minX, 0, -minY));
		
		Matrix4d out = new Matrix4d(trans);
		out.mul(rot);

		//System.err.println("rotational matrix is \n"+rot);
		//System.err.println("translation matrix is \n"+trans);
		//System.err.println("combined matrix is \n"+out);
		
		// return completed matrix - still untested!
		return out;
	}
	
	/**
	 * Uses the variables angle and  minX,minY calculated above to
	 * apply the same changes to another list of points (I think)
	 *
	 */
	private void normalisePlaneLocationFromState(List<FlatPoint> points)
	{
		Iterator<FlatPoint> it = points.iterator();
		// find min at same time as applying rotation!
		while (it.hasNext())
		{
			FlatPoint fp = it.next();
			double tmpX = fp.x * cos(angle) + fp.y * sin(angle); // this bit here
			// needs to rotate!
			double tmpY = -fp.x * sin(angle) + fp.y * cos(angle);
			// counterclockwise!
			fp.x = tmpX;
			fp.y = tmpY;
		}

		it = points.iterator();
		while (it.hasNext())
		{
			FlatPoint fp = it.next();
			fp.x = fp.x - minX;
			fp.y = fp.y - minY;
		}
	}
	
	/**
	 * Utility to convert from one coordinate space to another, **assuming that
	 * both the transofrms end up in the same 2d coordinate system...
	 * @param target
	 * @param goal
	 */
	public static void convertTo(Sheaf target, Sheaf goal)
	{
		for (Sheet s: target.getSheets())
		{
			List<FlatPoint> lv = new ArrayList<FlatPoint>();
			CEFPIterator cit = s.iterator();
			while (cit.hasNext()) lv.add(cit.next().thing);
			Matrix4d trans = new Matrix4d(target.getTransform());
			trans.invert();
			List<Vertex> points = applyTransform(lv, trans);
			List<FlatPoint> lf = applyFlatten(points,goal.getTransform(),null);
			cit = s.iterator();
			for (FlatPoint f: lf)
			{
				FlatPoint toChange = cit.next().thing;
				toChange.x = f.x;
				toChange.y = f.y;
			}
		}
	}
}
