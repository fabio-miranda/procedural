package geom;

import static java.lang.Math.*;
import static sity.Parameters.*;

import java.util.*;

import javax.vecmath.*;

import util.*;
import cloud.*;

/**
 * Utility class containing a lot of static methods for working in 2D. Aim is not to alter any of the incomming points and vectors!
 * 
 * @author people
 * 
 */
public class Vec2d
{
	/**
	 * cross product
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static double cross(Tuple2d a, Tuple2d b)
	{
		return a.x * b.y - a.y * b.x;
	}

	private static final FlatPoint xAxis = new FlatPoint(1, 0);

	private static final FlatPoint yAxis = new FlatPoint(0, 1);


	public static boolean pointIn(Tuple2d point, Sheaf shape)
	{
		assert(shape.getSheets().size() == 1); // should just or result of all sheets?
		Sheet s = shape.getMain();
		CEFPIterator cit = s.iterator();
		List<FlatPoint> lfp = new ArrayList<FlatPoint>();
		while (cit.hasNext())
			lfp.add(cit.next().thing);

		return pointIn(point, lfp);
	}
	
	private static int getSH(Tuple2d before, Tuple2d current)
	{
		int SH = 666;

		if (current.y < 0)
			SH = -1;
		else if (current.y > 0)
			SH = 1;
		else
		// == 0
		{
			double c = before.y;
			if (c < 0)
			{ // note SH's other way around here
				SH = 1;
			}
			else if (c > 0)
			{
				SH = -1;
			}
			else if (c == 0)
			{ // parallel line, so doesn't really matter
				Vector2d tmp = new Vector2d(current);
				tmp.sub(before);

				if (tmp.dot(xAxis) > 0)
				{ // is this right?
					SH = 1;
				}
				else
				{
					SH = -1;
				}
			}
		}
		return SH;
	}
	
	/**
	 * finds out if a point is with a specified shape. Uses jordan curve so should be suitable for convex shapes too... From graphics course/jordan curve - blue book, see alan chalmers for references. Boundry points are inside!
	 * 
	 * @param point
	 *            the point to find out
	 * @param shape
	 *            the shape to check for membership of
	 */
	public static boolean pointIn(Tuple2d point, List<FlatPoint> shape)
	{
		if (shape.size() <=2) return false; // should return true when point on line?
		List<Vector2d> newPoints = new Vector<Vector2d>();
		ListIterator<FlatPoint> it = shape.listIterator();
		while (it.hasNext())
		{
			Tuple2d fp = it.next();
			Vector2d n = new FlatPoint(fp);
			n.sub(point);
			newPoints.add(n);
		}
		int NC = 0; // number of crossings
		int SH; // sign holder
		int NSH; // next sign holder
		SH = getSH(newPoints.get(newPoints.size() - 2), newPoints.get(newPoints.size() - 1));

		// now count odd and even intersections
		ListIterator<Vector2d>it2 = newPoints.listIterator();
		Tuple2d b = newPoints.get(newPoints.size() - 1);

		while (it2.hasNext())
		{
			Tuple2d a = b;
			b = it2.next();
			
			// this is for Lightning, was not finding points on intersections!
			if (	Math.abs(b.x)< 10E-16 && 
					Math.abs(b.y)< 10E-16) return true;

			// System.err.println("*********************"+a +" to "+b);
			NSH = getSH(a, b);

			// System.err.println("SH "+SH+" NSH"+NSH);
			if (SH != NSH)
			{
				// System.err.println("SH != NSH");
				if (a.x > 0 && b.x > 0)
				{
					NC++;
				}
				else if (a.x == 0 && b.x == 0)
				{

					Vector2d tmp = new Vector2d(b);
					tmp.sub(a);
					// System.err.println("both zero"+tmp.dot(yAxis));
					if (tmp.dot(yAxis) < 0)
					{ // test me
						// System.err.println("both zero, nc plus plus");
						NC++;
					}
				}
				else if (a.x >= 0 || b.x >= 0)
				{
					if (a.x - a.y * (b.x - a.x) / (b.y - a.y) >= -10E-15)
					{
						// System.err.println(" >=0 or plus plus");
						NC++;
					}
				}

			}
			SH = NSH;
			// System.err.println("NC at end is "+NC);
		}

		if (NC % 2 == 1)
			return true;
		return false;
	}

	/**
	 * Returns a random point within the convex shape shape specified by splitting it up into triangles, picking one proportional to its area then finding a random point within the parrellelogram specified by two sides of this trianges. Then we test if its on the wrong side of the parallelogram and flip it if necessary
	 * 
	 * @param in
	 *            a list of points
	 * 
	 */
	public static FlatPoint randomPoint(Sheaf list, Random random)
	{
		// Iterator<FlatPoint> in = list.listIterator();

		List<Double> sizes = new Vector<Double>();
		double totalSize = 0;

		TriIterator it = new TriIterator(list);
		while (it.hasNext())
		{
			it.next();

			double area = abs(cross(it.onRight(), it.onLeft())) / 2;
			sizes.add(area);
			totalSize += area;
		}
		double trigger = random.nextDouble();
		trigger *= totalSize;

		Iterator<Double> di = sizes.iterator();

		it = new TriIterator(list);

		double accum = 0;
		while (it.hasNext())
		{
			Double size = di.next();
			accum += size;
			it.next();
			if (trigger < accum)
			{
				FlatPoint vecL = new FlatPoint(it.onLeft());
				FlatPoint vecR = new FlatPoint(it.onRight());

				FlatPoint opposite = new FlatPoint(vecL);
				opposite.add(vecR);
				opposite.add(it.one());

				vecL.scale(random.nextDouble());
				vecR.scale(random.nextDouble());

				// add these new vectors to the origin point
				FlatPoint rPoint = new FlatPoint(it.one());
				rPoint.add(vecL);
				rPoint.add(vecR);

				// find angle of chosen point to opposite corners from
				// tiangulation origin
				FlatPoint toPoint = new FlatPoint(it.two());
				toPoint.sub(rPoint);

				// if < 180 then its on the right side already
				if (angleBetween(it.onOtherSide(), toPoint) < PI)
					return rPoint;
				// else subtract from the opposite corner of the parrellologram
				// of the two sides
				opposite.sub(vecL);
				opposite.sub(vecR);

				// check with an assert
				toPoint = new FlatPoint(it.two());
				toPoint.sub(opposite);
				assert (angleBetween(it.onOtherSide(), toPoint) < PI);
				return opposite;
			}
		}
		return null;
	}

	/**
	 * Clockwise angle between two points
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static double angleBetween(Vector2d a, Vector2d b)
	{
		// rounding errors we get (1.0000000000000000002 is annoying!)
		double tmp = a.dot(b) / ((abs(a.length()) * abs(b.length())));
		if (tmp > 1)
			tmp = 1;
		if (tmp < -1)
			tmp = -1;

		if (cross(b, a) > 0)
		{

			return acos(tmp);
		}
		else
		{
			return 2 * PI - acos(tmp);
		}
	}

	public static double angleMe(Vector2d in)
	{
		if (in.y > 0)
		{
			return PI - atan(in.y / in.x);
		}
		else
		{
			return -PI + atan(in.y / in.x);
		}
	}

	/**
	 * interior angle between two vectors, anticlockwise
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static double interiorAngle(Vector2d a, Vector2d b)
	{
		// -10E-15 required here because cross sometime gets rouding errors... 
		if (cross(b, a) >= -10E-15)
		{
			return PI - a.angle(b);
		}
		else
		{
			return 2 * PI - a.angle(b);
		}

		/*
		 * if (abs(cross(b, a)) < 0.000000001) { Vector2d c = new Vector2d(b); b.sub(a); if (a.length() < 0.0000000001) { return 0; } return PI; } if (cross(b, a) >= 0) {
		 * 
		 * System.err.println(">0 case"); return PI - acos(a.dot(b) / ((abs(a.length()) * abs(b.length())))); } else { System.err.println("<0 case"); return 2 * PI - acos(a.dot(b) / ((abs(a.length()) * abs(b.length())))); }
		 */
	}

	/**
	 * as above, but with dots in a line
	 * @param a
	 * @param b
	 * @param c
	 * @return
	 */
	public static double interiorAngleBetween(Tuple2d a, Tuple2d b, Tuple2d c)
	{
		Vector2d left = new Vector2d(b);
		Vector2d right = new Vector2d(c);
		left.sub(a);
		right.sub(b);
		left.normalize();
		right.normalize();
		//System.err.println("zamining "+left+" -- "+right);
		return interiorAngle(left, right);
	}

	/**
	 * Unchecked, find angle between three points
	 * 
	 * @param a
	 * @param b
	 * @param c
	 * @return
	 */
	public static double angleBetween(Tuple2d a, Tuple2d b, Tuple2d c)
	{
		Vector2d left = new Vector2d(b);
		Vector2d right = new Vector2d(c);
		left.sub(a);
		right.sub(b);
		left.normalize();
		right.normalize();
		// System.err.println("zamining "+left+" -- "+right);
		return angleBetween(left, right);
	}

	/**
	 * finds out the angle between the specified line and the point. the Equal ones allow poins lieing on or very close to the line
	 * 
	 * @param origin
	 *            of the line
	 * @param direction
	 *            of the line
	 * @param point
	 *            to test which side of the line it is on
	 * @return
	 */
	public static boolean onRightOf(Tuple2d origin, Vector2d direction, Vector2d point)
	{
		Vector2d angle = new Vector2d(point);
		angle.sub(origin);
		double c = cross(angle, direction);
		// returns true on borderline
		return c >= 0; // = 0.0000000001;
	}

	// BROKEN?
	public static boolean onEqualRightOf(Tuple2d origin, Vector2d direction, Vector2d point)
	{
		Vector2d angle = new Vector2d(point);
		angle.sub(origin);
		double c = angle.dot(direction);
		return c > 0.0000000001;
	}

	public static boolean onLeftOf(Tuple2d origin, Vector2d direction, Vector2d point)
	{
		Vector2d angle = new Vector2d(point);
		angle.sub(origin);
		double c = cross(angle, direction);
		// true on borderline
		return c <= 0;// = -0.0000000001;
	}

	// BROKEN?
	public static boolean onEqualLeftOf(Tuple2d origin, Vector2d direction, Vector2d point)
	{
		Vector2d angle = new Vector2d(point);
		angle.sub(origin);
		double c = angle.dot(direction);
		// zero calibrated to allow intersection with level-ish points
		return c < 0;
	}

	/**
	 * Finds the area of this convex polygon, using the fact that the abs of half the cross product of two vectors is its size
	 * 
	 */
	public static double findArea(Sheaf sheaf)
	{
		double total = 0;

		TriIterator it = new TriIterator(sheaf);

		while (it.hasNext())
		{
			it.next();
			// System.err.println("find Area says "+it.onLeft()+" "+it.onRight());
			total += abs(cross(it.onRight(), it.onLeft())) / 2;
		}

		return total;

		/*
		 * convex code: FlatPoint origin = it.next(); FlatPoint onLeft = it.next(); onLeft.sub(origin); while(it.hasNext()) { FlatPoint onRight = it.next(); onRight.sub(origin); total += abs(cross(onRight,onLeft))/2; onLeft = onRight; } return total;
		 */
	}
	
	public static double findArea(Sheet sheet)
	{
		
		CEFPIterator cit = sheet.iterator();
		
		double sofar = 0;
		if (sheet.size() < 3) return 0;
		
		FlatPoint main = cit.next().thing;
		FlatPoint last = cit.next().thing;
		Vector2d sideTwo = new Vector2d(last);
		sideTwo.sub(main);
				
		while (cit.hasNext())
		{
			FlatPoint current = cit.next().thing;
			Vector2d sideOne = new Vector2d(current);
			sideOne.sub(main);
			
			sofar += cross(sideTwo, sideOne);
			
			sideTwo = sideOne;
			last = current;
		}
		
		return (-sofar)/2;
	}
	
	/**
	 * from http://www.topcoder.com/tc?module=Static&d1=tutorials&d2=geometry1#polygon_area
	 * will work on concave shapes
	 * @param fp
	 * @return
	 */
	public static double findArea(List<FlatPoint> fp)
	{
		double sofar = 0;
		if (fp.size() < 3) return 0;
		
		Iterator<FlatPoint> fi = fp.iterator();
		FlatPoint main = fi.next();
		FlatPoint last = fi.next();
		Vector2d sideTwo = new Vector2d(last);
		sideTwo.sub(main);
				
		while (fi.hasNext())
		{
			FlatPoint current = fi.next();
			Vector2d sideOne = new Vector2d(current);
			sideOne.sub(main);
			
			sofar += cross(sideTwo, sideOne);
			
			sideTwo = sideOne;
			last = current;
		}
		
		return (-sofar)/2;
	}

	/**
	 * Finds the clockwise convex hull of a set of points. If this is taking significant time, this can be replaced by the quickhull procedure!
	 * 
	 * @return
	 */
	public static List<FlatPoint> convexHull(List<FlatPoint> fp)
	{
		List<FlatPoint> out = new Vector<FlatPoint>();

		FlatPoint leftMost = fp.get(0);
		// find the upper most left point
		Iterator<FlatPoint> it = fp.iterator();
		while (it.hasNext())
		{
			FlatPoint f = it.next();
			if (f.x <= leftMost.x)
			{
				// if equal with higher y, or just more left most
				if (f.x < leftMost.x || f.y > leftMost.y)
				{
					leftMost = f;
				}
				else
					continue;
			}
		}

		// System.err.println("left most highest is "+leftMost);

		FlatPoint first = leftMost;
		FlatPoint next = null;
		FlatPoint current = leftMost;
		Vector2d up = new Vector2d(0, 1);
		while (next != first)
		{
			out.add(new FlatPoint(current.x, current.y));
			// System.err.println("adding "+current);
			// find one with lowest polar angle
			double angle = Double.MAX_VALUE;
			double shortestDistance = Double.MAX_VALUE;
			it = fp.iterator();
			while (it.hasNext())
			{
				FlatPoint f = it.next();
				if (f != current)
				{
					Vector2d direction = new Vector2d(f);
					direction.sub(current);
					double thisAngle = angleBetween(up, direction);
					if (abs(thisAngle - 2 * PI) < 0.000000001)
						thisAngle = 0;
					// System.err.println(" angle for "+f+" is "+thisAngle);
					if (thisAngle == angle)
					{
						double d2 = direction.length();
						if (d2 < shortestDistance)
						{
							next = f;
							angle = thisAngle;
							shortestDistance = d2;
						}
					}
					else if (thisAngle < angle)
					{
						next = f;
						angle = thisAngle;
						shortestDistance = direction.length();
					}
				}
			}
			up = new Vector2d(next);
			up.sub(current);

			// System.err.println("I chose "+next);
			current = next;
		}

		return out;
	}

	/**
	 * Finds the intersection of two lines from thei origins and directions modified from: http://astronomy.swin.edu.au/~pbourke/geometry/lineline2d/
	 * 
	 * if lines are co-incident (on top of one another) a point is chosen relative to the sizes of the direction vectors given
	 * 
	 * @param originA
	 * @param originB
	 * @param directionA
	 * @param directionB
	 * @return
	 */
	public static FlatPoint intersect(Tuple2d origA, Tuple2d origB, Vector2d directionA, Vector2d directionB)
	{

		// System.out.println(directionA.length());
		Vector2d scaleA = new Vector2d(directionA);
		Vector2d scaleB = new Vector2d(directionB);

		scaleA.normalize();
		scaleB.normalize();

		Tuple2d destA = new Vector2d(origA);
		destA.add(scaleA);
		Tuple2d destB = new Vector2d(origB);
		destB.add(scaleB);

		double ua = (destB.x - origB.x) * (origA.y - origB.y) - (destB.y - origB.y) * (origA.x - origB.x);
		double ba = (destB.y - origB.y) * (destA.x - origA.x) - (destB.x - origB.x) * (destA.y - origA.y);

		double ub = (destA.x - origA.x) * (origA.y - origB.y) - (destA.y - origA.y) * (origA.x - origB.x);
		double bb = (destB.y - origB.y) * (destA.x - origA.x) - (destB.x - origB.x) * (destA.y - origA.y);

		// lines are parrallel
		if (ba == 0 && bb == 0)
		{
			if (ua < 0.00000001 && ub < 0.00000001)
			{ // lines are coincident-ish
				double aLength = scaleA.length();
				double bLength = scaleB.length();
				FlatPoint outA = new FlatPoint(origA);
				outA.scale(aLength / (aLength + bLength));
				FlatPoint outB = new FlatPoint(origB);
				outB.scale(bLength / (aLength + bLength));
				outA.add(outB);
				return null;// outA;
			}
			// if just parallel
			return null;
		}

		double x = origA.x + (ua / ba) * (destA.x - origA.x);
		double y = origA.y + (ua / ba) * (destA.y - origA.y);

		return new FlatPoint(x, y);
	}

	/**
	 * Uses the above routine to return intersection only if point is in front of both bisectors, null otherwise
	 */
	public static FlatPoint intersectInFront(Tuple2d origA, Tuple2d origB, Vector2d directionA, Vector2d directionB)
	{

		// System.out.println(directionA.length());
		Vector2d scaleA = new Vector2d(directionA);
		Vector2d scaleB = new Vector2d(directionB);

		scaleA.normalize();
		scaleB.normalize();

		Tuple2d destA = new Vector2d(origA);
		destA.add(scaleA);
		Tuple2d destB = new Vector2d(origB);
		destB.add(scaleB);

		double ua = (destB.x - origB.x) * (origA.y - origB.y) - (destB.y - origB.y) * (origA.x - origB.x);
		double ba = (destB.y - origB.y) * (destA.x - origA.x) - (destB.x - origB.x) * (destA.y - origA.y);

		double ub = (destA.x - origA.x) * (origA.y - origB.y) - (destA.y - origA.y) * (origA.x - origB.x);
		double bb = (destB.y - origB.y) * (destA.x - origA.x) - (destB.x - origB.x) * (destA.y - origA.y);

		// intersection before points!
		if (ua / ba <= 0 || ub / bb <= 0)
			return null; // was <0

		// lines are parrallel
		if (ba == 0 && bb == 0)
		{
			if (ua < 0.00000001 && ub < 0.00000001)
			{

				// System.err.println("They're on top"+directionA.angle(directionB));

				Vector2d bDir = new Vector2d(origB);
				bDir.sub(origA);

				// gradients are the same, must be in front
				if (bDir.angle(directionA) < 0.0000000001)
				{
					// System.err.println("b is in front of a");
					// now check gradients of direction
					if (directionB.angle(directionA) < 0.00000000001)
					{
						// System.err.println("same direction");
						// both going in the same direction so no intersect
						return null;
					}
					else
					{
						// different directions with b in front of a, must mean
						// an intersection
						// System.err.println("i predict a collision");
						FlatPoint res = new FlatPoint(origA);
						res.add(origB);
						res.scale(0.5);
						return res;
					}
				}
				else
				// b is behind a, return false;
				{
					// System.err.println("b is behind a");
					return null;
				}
			}
			// if just parallel - find the lines and directions
			// if they are pointing towards each other return the center point
			System.err.println("they're paralled");
			return null;
		}

		double x = origA.x + (ua / ba) * (destA.x - origA.x);
		double y = origA.y + (ua / ba) * (destA.y - origA.y);

		return new FlatPoint(x, y);
	}

	/**
	 * TheFind the intersection point of two lines, between their end poitns and returns a pramaterised 0..1 number saying how far along the lines the intersection point is.
	 * 
	 * @param origA
	 *            start of line 1
	 * @param origB
	 *            start of line 2
	 * @param destA
	 *            end of line 1
	 * @param destB
	 *            end of line 2
	 * @return a triple of (the intersection point, 0..1 diatance along first line, 0..1 distance alonge second line)
	 */
	public static Triple<FlatPoint, Double, Double> intersectBetween(Tuple2d origA, Tuple2d origB, Vector2d destA, Vector2d destB, boolean nullOnOutsideIntersect)
	{

		// System.out.println(directionA.length());
		/*
		 * Vector2d scaleA = new Vector2d(directionA); Vector2d scaleB = new Vector2d(directionB);
		 * 
		 * scaleA.normalize(); scaleB.normalize();
		 * 
		 * Tuple2d destA = new Vector2d(origA); destA.add(scaleA); Tuple2d destB = new Vector2d(origB); destB.add(scaleB);
		 */

		double ua = (destB.x - origB.x) * (origA.y - origB.y) - (destB.y - origB.y) * (origA.x - origB.x);
		double ba = (destB.y - origB.y) * (destA.x - origA.x) - (destB.x - origB.x) * (destA.y - origA.y);

		double ub = (destA.x - origA.x) * (origA.y - origB.y) - (destA.y - origA.y) * (origA.x - origB.x);
		double bb = (destB.y - origB.y) * (destA.x - origA.x) - (destB.x - origB.x) * (destA.y - origA.y);

		// intersection between points!

		// lines are parrallel
		if (ba == 0 && bb == 0)
		{
			if (ua < 0.0000000001 && ub < 0.0000000001)
			{ // lines are coincident-ish
				return null;// new Triple<FlatPoint, Double, Double>(new FlatPoint(origB), 0.5, 0.);
			}
			// if just parallel
			return null;
		}

		double x = origA.x + (ua / ba) * (destA.x - origA.x);
		double y = origA.y + (ua / ba) * (destA.y - origA.y);

		if (nullOnOutsideIntersect)
		{
			if (ua / ba < 0 || ub / bb < 0)
				return null;
			if (ua / ba > 1 || ub / bb > 1)
				return null;
		}

		return new Triple<FlatPoint, Double, Double>(new FlatPoint(x, y), ua / ba, ub / bb);
	}

	/**
	 * Uses the above to find the intersection point
	 * 
	 * @param a1
	 *            start of line 1
	 * @param a2
	 *            end of line 1
	 * @param b1
	 *            start of line 2
	 * @param b2
	 *            end of line 2
	 * @return
	 */
	public static FlatPoint intersectEndPoints(Tuple2d a1, Tuple2d a2, Tuple2d b1, Tuple2d b2)
	{
		Vector2d aDir = new Vector2d(a2);
		aDir.sub(a1);
		Vector2d bDir = new Vector2d(b2);
		bDir.sub(b1);
		return intersect(a1, b1, aDir, bDir);
	}

	/**
	 * calcualte the height that a point is perpendicular above a line. Assumes point is to the right side of the line! or inside a shape with a clockwise perimeter.... If on the outside i reti
	 * 
	 * http://www.topcoder.com/tc?module=Static&d1=tutorials&d2=geometry1
	 * 
	 * @param a
	 *            the first point in the line
	 * @param a
	 *            the second point in the line
	 * @param point
	 *            the point to identify
	 */
	public static double heightPerpendicular(FlatPoint a, FlatPoint b, FlatPoint point)
	{
		FlatPoint A = new FlatPoint(b);
		A.sub(a);
		FlatPoint B = new FlatPoint(point);
		B.sub(a);
		FlatPoint c = new FlatPoint(b);
		c.sub(a);

		return -cross(A, B) / c.length();
	}

	/**
	 * Rather specialised routine to find the direction of a point shot from the corner of mitre'd joint. As ever clocwise order of poitns
	 * 
	 * This is my maths and the vector is calculated to be
	 * 
	 * @param before
	 *            point before A
	 * @param current
	 *            point to mitre B
	 * @param after
	 *            point after C
	 * @param beforeSpeed
	 *            speed of line section AB
	 * @param afterSpeed
	 *            speed of line section BC
	 * @return
	 */
	public static Vector2d shrink_OLD(FlatPoint before, FlatPoint current, FlatPoint after, double beforeSpeed, double afterSpeed)
	{
		// left and right point away from current corner
		Vector2d right = new Vector2d(before);
		assert (current != null);
		right.sub(current);
		Vector2d left = new Vector2d(after);
		left.sub(current);

		// make left and right the same length
		left.normalize();
		right.normalize();

		// System.err.println("left is "+left+" right "+right);

		// tis the clockwise angle, so always external,
		// so points in opposite direction
		// double angle = sin(angleBetween(before, current, after));
		double angle = interiorAngleBetween(before, current, after);
		// System.err.println("angle is "+angleBetween(before, current, after)+"="+angle);
		// if (angle > PI/2) angle = PI-angle; // JUST REMOVED THIS LINE
		// System.err.println("subed angle is "+angle);
		angle = sin(angle);
		// System.err.println("left scaled by "+beforeSpeed/angle);
		// System.err.println("rigth scaled by "+afterSpeed/angle);

		// System.err.println("before "+(beforeSpeed/angle)+" after
		// "+(afterSpeed/angle));

		// multiply by factors
		left.scale(beforeSpeed / angle);
		right.scale(afterSpeed / angle);

		// System.err.println(">> "+left.length()+" "+right.length());

		// add them together
		left.add(right);

		// if we are running parallel, need to hack and take average of speeds
		if (left.length() == 0)
		{
			double zeroLength = (beforeSpeed + afterSpeed) / 2;
			right = new Vector2d(before);
			right.sub(current);
			// rotate right by 90 degrees, normalise and scale by zerolength
			double angleBetween = angleBetween(new Vector2d(0, 1), right);
			// System.err.println("zero length "+angleBetween*360/(PI*2));
			angleBetween -= PI / 2;
			// System.err.println("zero length "+angleBetween*360/(PI*2));
			// construct a vector at anglebetween clockwise from (0,1)
			Vector2d result = new Vector2d(sin(angleBetween), cos(angleBetween));
			// System.err.println("inital "+result);
			result.normalize();
			result.scale(zeroLength);
			// System.err.println("after scaling "+result);
			if (result.length() != 0)
				error("vec2d, shrink parallel called used (use _wisely_) " + result);
			return result;
		}
		return left;
	}

	public static boolean pointBetweenPoints(Tuple2d a, Tuple2d b, Tuple2d x)
	{
		// check that fp is between q and u
		Vector2d direc = new Vector2d(b);
		direc.sub(a);

		Vector2d goal = new Vector2d(x);
		goal.sub(a);
		
		// from q going in newO direction, we get to u in
		double tMax = (direc.x + direc.y) / (direc.x + direc.y);

		double tActual = (goal.x + goal.y) / (direc.x + direc.y);

		if (tActual > tMax || tActual < 0)
		{
			return false;
		}

		return true;
	}
	
	/**
	 * Finds the line between two points. Give the inside point followed by the outside point
	 * for a clockwise bisector :)
	 * @param a first point
	 * @param b second point
	 * @return a pair of the centre point and the direction of the line
	 */
	public static Pair<Tuple2d, Tuple2d> bisectorOfPoints(final Tuple2d a, final Tuple2d b)
	{
		FlatPoint midPoint = new FlatPoint(a);
		midPoint.add(b);
		midPoint.scale(0.5);
		Vector2d bToA = new Vector2d(a);
		bToA.sub(b);
		// lol, we could just flip coords
		Vector2d dir = new Vector2d(-bToA.y, bToA.x);
		dir.normalize();
		
		/* angle rotation
		double angleBetween = angleBetween(new Vector2d(0, 1), bToA);
		angleBetween -= PI / 2;
		Vector2d result = new Vector2d(sin(angleBetween), cos(angleBetween));*/
		
		return new Pair<Tuple2d,Tuple2d>(midPoint, dir);
	}
	
	
	// the parametric tolerance for inclusion in a line // can this go to -10?
	private final static double SMALL_NUMBER = 10E-5;
	private static final boolean DEBUG = false;
	
	/**
	 * Clips the line specified. 
	 * 
	 * @param in
	 * @param against list of corners to clip against
	 * @return
	 */
	public static Pair<FlatPoint,FlatPoint> clip(Pair<Tuple2d, Tuple2d> in, Cell c)
	{
		if (DEBUG) System.err.println ("                                    entering clip");
		if (DEBUG) System.err.println (" bisector "+in);
		List<Wall> walls = c.getWall();
		Tuple2d start = in.first();
		Tuple2d direction = in.second();
		
		// parametric values of line in
		double tMin = -Double.MAX_VALUE;
		double tMax = Double.MAX_VALUE;
		
		Wall startClip = null;
		Wall endClip   = null;
		
		for (Wall w: walls) // next
		{
			FlatPoint start2 = w.getStart(c);
			FlatPoint l = w.getEnd(c);
			FlatPoint direction2 = new FlatPoint(
					l.x-start2.x,
					l.y-start2.y);

			if (DEBUG) System.err.println("first "+start+ " going towards "+direction);
			if (DEBUG) System.err.println("second "+start2+ " going towards "+direction2);
			double top = 
				direction2.x*(start2.y-start.y)
				+direction2.y*(start.x-start2.x);
			double bottom = direction2.x*direction.y-direction2.y*direction.x;
			
			if (bottom == 0) 
			{
				if (DEBUG) System.err.println("parallel!");
				Vector2d AB = new Vector2d(direction);
				//AB.add(direction);
				Vector2d AC = new Vector2d(start2);
				AC.sub(start);
				
				// distance between lines
				double distance = cross(AB,AC)/AB.length();
				double dot = dot(direction,direction2); 
				
				if (
						(dot > 0 && distance < 0) || 
						(dot < 0 && distance > 0))
								{
					// there is no line - ?
					tMin =  Double.MAX_VALUE;
					tMax = -Double.MAX_VALUE;
				}
				continue; //parallel
			}
			
			// check to see where we cross
			double t2 = top/bottom;
			
			double top2 = 
				direction.x*(start.y-start2.y)
				+direction.y*(start2.x-start.x);
			double bottom2 = direction.x*direction2.y-direction.y*direction2.x;
			double t1 = top2/bottom2;
			

			if (DEBUG) System.err.println("t2:"+t2);
			if (DEBUG) System.err.println("t1:"+t1);
			
			if (t1 > 1+SMALL_NUMBER || t1 < 0-SMALL_NUMBER) continue; // outside line length
			if (DEBUG) System.err.println("so good");
			//depending if its to the left or right truncate max or min coord
			if (cross(direction,direction2) > 0)
			{
				if (t2 > tMin) 
					{
						startClip = w;
						tMin = t2;
					}
			}
			else
			{
				if (t2 < tMax) 
					{
						endClip = w;
						tMax = t2;
					}
			}
			
			//System.err.println("intersect at "+(t2*direction.x +start .x)+","+(t2*direction .y+start .y));
			//System.err.println("intersect at "+(t1*direction2.x+start2.x)+","+(t1*direction2.y+start2.y));
			
			if (DEBUG) System.err.println("min "+tMin+" max"+tMax);
		}
		
		if (DEBUG) System.err.println("min "+tMin+" max"+tMax);

		// min and max now contain parallel pairs of start and end poitns
		// if we miss entirely we return Double.maxValue scaled lines so we
		if (tMin ==  Double.MAX_VALUE) return null;
		if (tMax == -Double.MAX_VALUE) return null;

		// clipped out of existance
		if (tMin > tMax) return null;

		// now we know tMin and tMax clip line to those coords
		FlatPoint first = new FlatPoint(direction);
		first.scale(tMin);
		first.add(start);
		FlatPoint second = new FlatPoint(direction);
		second.scale(tMax);
		second.add(start);
		c.setClipOne(startClip);
		c.setClipTwo(endClip);
		
		return new Pair<FlatPoint, FlatPoint>(first, second);
	}
	
	private final static double CONCAVE_SMALL_NUMBER = 10E-5;
	
	/**
	 * Clips the line specified! As above but with added concavey-ness 
	 * 
	 * @param in
	 * @param against list of corners to clip against
	 * @return
	 */
	public static Pair<FlatPoint,FlatPoint> clipConcave(Pair<Tuple2d, Tuple2d> in, Cell c, Cell home)
	{
		FlatPoint newPoint = home.getCentre();
		if (DEBUG) System.err.println ("                                    entering clipConcave");
		if (DEBUG) System.err.println (" bisector "+in);
		List<Wall> walls = c.getWall();
		if (DEBUG) for (Wall w: walls) System.err.println("wall hereo iseo "+w);
		Tuple2d start = in.first();
		Tuple2d direction = in.second();
		
		// parametric values of line in
		double tMin = -Double.MAX_VALUE;
		double tMax = Double.MAX_VALUE;
		
		List<EdgeParam> params = new ArrayList<EdgeParam>();
		
		Wall startClip = null;
		Wall endClip   = null;
		
		for (Wall w: walls) // next
		{
			FlatPoint start2 = w.getStart(c);
			FlatPoint l = w.getEnd(c);
			FlatPoint direction2 = new FlatPoint(
					l.x-start2.x,
					l.y-start2.y);

			if (DEBUG) System.err.println("first "+start+ " going towards "+direction);
			if (DEBUG) System.err.println("second "+start2+ " going towards "+direction2);
			/*double top = 
				direction2.x*(start2.y-start.y)
				+direction2.y*(start.x-start2.x);*/
			
			double top = 
				direction2.x*start2.y-direction2.x*start.y
				+direction2.y*start.x-direction2.y*start2.x;
			
			double bottom = direction2.x*direction.y-direction2.y*direction.x;
			
			if (bottom == 0) 
			{
				if (DEBUG) System.err.println("parallel!");
				Vector2d AB = new Vector2d(direction);
				//AB.add(direction);
				Vector2d AC = new Vector2d(start2);
				AC.sub(start);
				
				// distance between lines
				double distance = cross(AB,AC)/AB.length();
				double dot = dot(direction,direction2); 
				
				if (
						(dot > 0 && distance < 0) || 
						(dot < 0 && distance > 0))
								{
					// there is no line - ?
					tMin =  Double.MAX_VALUE;
					tMax = -Double.MAX_VALUE;
				}
				continue; //parallel
			}
			
			// check to see where we cross
			double t2 = top/bottom;

			/*double top2 = 
				direction.x*(start.y-start2.y)
				+direction.y*(start2.x-start.x);*/

			double top2 = 
				direction.x*start.y-direction.x*start2.y
				+direction.y*start2.x-direction.y*start.x;
			
			double bottom2 = direction.x*direction2.y-direction.y*direction2.x;
			double t1 = top2/bottom2;
			

			if (DEBUG) System.err.println("t2:"+t2);
			if (DEBUG) System.err.println("t1:"+t1);
			
			if (t1 > 1+CONCAVE_SMALL_NUMBER || t1 < 0-CONCAVE_SMALL_NUMBER) continue; // outside line length
			if (DEBUG) System.err.println("so good");
			//depending if its to the left or right truncate max or min coord
			if (cross(direction,direction2) > 0)
			{
				params.add(new EdgeParam(t2,w,EdgeParam.MIN));
				}
			else
			{
				if (DEBUG) System.err.println("adding to max - "+w);
				params.add(new EdgeParam(t2,w, EdgeParam.MAX));
			}
			
			//System.err.println("intersect at "+(t2*direction.x +start .x)+","+(t2*direction .y+start .y));
			//System.err.println("intersect at "+(t1*direction2.x+start2.x)+","+(t1*direction2.y+start2.y));
			
			if (DEBUG) System.err.println("min "+tMin+" max"+tMax);
		}
		
		if (DEBUG) System.err.println("min "+tMin+" max"+tMax);
		if (DEBUG && params.size() == 0) System.err.println("no intersections found"); 
		if (params.size() == 0) return null;
		Collections.sort(params);

		if (DEBUG) System.err.println("points are of size "+params.size());

		//for (EdgeParam e: params)System.err.println(e.getType()+ " params contains "+e.getWall());
		
		ListIterator<EdgeParam> lit = params.listIterator();
		while (lit.hasNext() && lit.next().getType() == EdgeParam.MAX) lit.remove();
		lit= params.listIterator();

		//for (EdgeParam e: params)System.err.println(e.getType()+ " params contains after cleanup "+e.getWall());
		
		while (lit.hasNext())
		{
			EdgeParam minee = lit.next();
			
			assert (minee.getType() == EdgeParam.MIN);
			
			// find the first in a list of mins (min is the next one)
			while (lit.hasNext())
				{
				 EdgeParam tmp = lit.next();
				 if (tmp.getType() == EdgeParam.MIN)
				 {
					 //lit.remove(); dont event need to remove, just skip
				 }
				 else
				 {
					 if (lit.hasPrevious()) lit.previous(); // rewind to max
					 break; //while
				 }
				}


			EdgeParam  maxee = null;
			
			// find the last in a list of maxs
			while (lit.hasNext())
			{
				EdgeParam  tmp = lit.next();
				if (tmp.getType() == EdgeParam.MIN)
				{
					if (lit.hasPrevious()) lit.previous();
					break; //while
				}
				maxee = tmp;
			}
			
			if (maxee == null || minee == null) return null;
			//System.err.println("using min"+minee.getWall());
			//System.err.println("using max"+maxee.getWall());
			//System.err.println("point is "+newPoint);
			if (isInSection(minee, maxee, c, home, newPoint, start, direction))
			{
				c.setClipOne(minee.getWall());
				c.setClipOne(maxee.getWall());
				
				// now we know tMin and tMax clip line to those coords
				FlatPoint first = new FlatPoint(direction);
				first.scale(minee.getValue());
				first.add(start);
				FlatPoint second = new FlatPoint(direction);
				second.scale(maxee.getValue());
				second.add(start);
				c.setClipOne(minee.getWall());
				c.setClipTwo(maxee.getWall());

				return new Pair<FlatPoint, FlatPoint>(first, second);
			}
		}
		assert(false);
		return null;
	}
	
	/**
	 * Used by clipconcave above
	 * @param min
	 * @param max
	 * @param c
	 * @param toFind
	 * @param start
	 * @param direction
	 * @return
	 */
	private static boolean isInSection(EdgeParam min, EdgeParam max, Cell c, Cell home, FlatPoint toFind, Tuple2d start, Tuple2d direction)
	{
		List<FlatPoint> lfp = new ArrayList<FlatPoint>();
		Wall first = min.getWall();
		Wall last  = max.getWall();
		
		FlatPoint biStart = new FlatPoint(direction);
		biStart.scale(min.getValue());
		biStart.add(start);
		FlatPoint biEnd = new FlatPoint(direction);
		biEnd.scale(max.getValue());
		biEnd.add(start);
		
		Iterator<Wall> wallit = c.getWallOn(last).iterator();
		Wall current = wallit.next();
		//System.err.println("looking at edge "+current);
		//System.err.println("  other side is "+current.getOther(c));
		if (current.getOther(c) == home) return true;
		lfp.add(biEnd);
		//System.err.println(" ma home is "+home);
		while (current != first)
		{
			lfp.add(current.getEnd(c));
			current = wallit.next();
			//System.err.println("looking at edge "+current);
			//System.err.println("  other side is "+current.getOther(c));
			if (current.getOther(c) == home) return true;
		}
		lfp.add(biStart);
		
		//System.err.println("isInSection running with "+lfp);
		//System.err.println("isInSection running with "+toFind);
		
		return Vec2d.pointIn(toFind,lfp);
	}
	
	public static double dot(Tuple2d a, Tuple2d b)
	{
		Vector2d va = new Vector2d(a);
		Vector2d vb = new Vector2d(b);
		
		return va.dot(vb);
	}
	
	/**
	 * Distance from line, may be positive or negative....
	 * @param start
	 * @param end
	 * @param point
	 * @return
	 */
	public static double distanceFromLine(Tuple2d start, Tuple2d end, Tuple2d point)
	{
		Vector2d AB = new Vector2d(end);
		end.sub(start);
		Vector2d AC = new Vector2d(point);
		end.sub(start);
		return cross(AB,AC)/AB.length();
	}
	
}
