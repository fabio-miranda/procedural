package geom;

public enum SheetType
{
	WINDOW, DOOR, WALL;
}
