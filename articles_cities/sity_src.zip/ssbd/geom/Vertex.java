package geom;

import java.util.*;

import javax.media.j3d.Transform3D;
import javax.vecmath.*;

public class Vertex extends Vector3d
{
	//private double x,y,z;
	private List<EdgeType> types=new ArrayList <EdgeType>();
	private double speed = 0;
	
	public Vertex(double x, double y, double z)
	{
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	public Vertex(Tuple3d in)
	{
		this.x = in.x;
		this.y = in.y;
		this.z = in.z;
	}
	
	public Vertex(Vertex v)
	{
		x = v.x;
		y = v.y;
		z = v.z;
		this.types = v.getAllTypes();
		this.speed = v.getSpeed();
	}
	
	public double distanceTo(Vertex b)
	{
		double xx = b.x-x;
		double yy = b.y-y;
		double zz = b.z-z;
		return Math.sqrt(xx*xx+yy*yy+zz*zz);
	}
	
	public Iterator<EdgeType> getTypes()
	{
		return types.iterator();
	}
	
	public void addType(EdgeType in)
	{
		types.add(in);
	}

	/** <b>(234,234,234)</b> format string
	 * 
	 */
	public String toString()
	{
		return ("(+"+x+","+y+","+z+")");
	}
	
	/** <b>234 234 234</b> format string for maya
	 * 
	 * @return the string!
	 */
	public String toMELString()
	{
		return (x+" "+y+" "+z);	
	}
	
	/** Multiply this point by the specified transform matrix. Just
	 * uses the java extension libraries
	 * 
	 * @param in the matrix to multiply this point by!
	 */
	public Vertex multiplyBy(Matrix4d in)
	{
		Point3d p3d = new Point3d(x,y,z);
		Transform3D trans = new Transform3D();
		trans.set(in);
		trans.transform(p3d);
		x = p3d.x;
		y = p3d.y;
		z = p3d.z;
		return this;
	}
	
	/** Calculates the vector between two points
	 */
	public Vector3d sub(Vertex in)
	{
		return new Vector3d(x-in.x, y-in.y, z-in.z);
	}
	
	/** Auto generated getters and setters for each coordinate
	 * 
	 * @return
	 */
//	public double getX()
//	{
//		return x;
//	}
//
//	public void setX(double x)
//	{
//		this.x = x;
//	}
//
//	public double getY()
//	{
//		return y;
//	}
//
//	public void setY(double y)
//	{
//		this.y = y;
//	}
//
//	public double getZ()
//	{
//		return z;
//	}
//
//	public void setZ(double z)
//	{
//		this.z = z;
//	}
	
	public List<EdgeType>getAllTypes()
	{
		return types;
	}
	public double getSpeed()
	{
		return speed;
	}
	public void setSpeed(double speed)
	{
		this.speed = speed;
	}
}
