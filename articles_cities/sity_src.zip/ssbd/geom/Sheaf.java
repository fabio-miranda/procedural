package geom;

import static geom.Vec2d.intersectBetween;

import java.util.*;

import static sity.Parameters.*;
import static geom.BooleanTest.*;
import javax.vecmath.*;
import static geom.EdgeType.*;
import static geom.Vec2d.*;

import sity.Parameters;
import util.*;

/**
 * 
 * A Sheaf is a stack of sheets that contains the transform between them and the real world!
 * 
 * @author tomkelly
 * 
 */
public class Sheaf
{
	Matrix4d transform = null;

	private List<Sheet> stack = new Vector<Sheet>();

	/**
	 * creates a sheaf of one sheet with those points specified in
	 * 
	 * @param lfp
	 *            this list
	 * @param trans
	 *            the points lie here in the real world
	 */
	public Sheaf(List<FlatPoint> lfp, Matrix4d trans)
	{
		addSheet(new Sheet(lfp));
		transform = trans;
	}

	/**
	 * Make a sheaf with no sheets, just a transform...
	 * 
	 * @param trans
	 */
	public Sheaf(Matrix4d trans)
	{
		transform = trans;
	}

	/**
	 * creates a sheaf with a null transform for 2d use only
	 * 
	 * @param lfp
	 */
	public Sheaf(List<FlatPoint> lfp)
	{
		addSheet(new Sheet(lfp));
		transform = null;
	}

	public Sheaf(Sheet sheet, Matrix4d trans)
	{
		transform = trans;
		stack.add(sheet);
	}

	public Sheaf(Sheet sheet)
	{
		Matrix4d trans = new Matrix4d();
		trans.setIdentity();
		transform = trans;
		stack.add(sheet);
	}
	
	/**
	 * untested
	 * @param sheaf
	 */
	public Sheaf(Sheaf sheaf)
	{
		transform = new Matrix4d(sheaf.getTransform());
		for (Sheet s: sheaf.getSheets())
		{
			ArrayList<FlatPoint> alfp = new ArrayList<FlatPoint>();
			CEFPIterator cit = new CEFPIterator(s);
			while(cit.hasNext())
			{
				alfp.add(cit.next().thing);
			}
			Sheet sheet = new Sheet(alfp);
			stack.add(sheet);
		}
	}

	public void addSheet(Sheet in)
	{
		stack.add(in);
		in.setSheaf(this);
	}

	public void addSheet(Sheet in, Matrix4d trans)
	{
		stack.add(in);
		if (transform == null)
		{
			transform = trans;
		}
		else
		{
			checkCompatible(trans);
		}

	}

	/**
	 * check matrices are 'compatible' eg: only very small differences between them Checks that we are operating in the same space!
	 * 
	 * @param trans
	 *            other matrix
	 */
	private void checkCompatible(Matrix4d trans)
	{
		// 
		for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++)
			{
				assert (Math.abs(transform.getElement(i, j) - trans.getElement(i, j)) < 0.00000001);
			}
	}

	/**
	 * The transform is from world coordinates the 2D space in X/Z plane; Z is "up"!
	 * 
	 * @return
	 */
	public Matrix4d getTransform()
	{
		return new Matrix4d(transform);
	}
	public void setTransform(Matrix4d in)
	{
		transform = in;
	}

	public Sheet getMain()
	{
		return stack.get(0);
	}

	public List<Sheet> getSheets()
	{
		return stack;
	}
	
	public Sheaf getSheetAsSheaf(int number)
	{
		if (number < 0 || number >= stack.size()) Parameters.fatalErrorSD("never ment to be called with that number !");
		Sheet toUse = stack.get(number); 
		return new Sheaf(toUse, transform); 
	}

	/**
	 * Finds the sum of the lengths of all contained sherets
	 *
	 */
	public double length()
	{
		double total = 0;
		for (Sheet s: stack)
			total+=s.length();
		
		return total;
	}
	
	/**
	 * Finds a point somewhere on the perimiter of this sheaf, if not within
	 * lengtht of first sheet, moves onto the next...etc...
	 */
	public FlatPoint getPointAround(double in)
	{
		double total = 0;
		for (Sheet s: stack)
		{
			double dist = s.length();
			if (in < total+dist)
			{
				return s.getPointAround(in-total);
			}
			total += dist;
		}
		// should never get here!
		assert(false);
		return null;
	}
	
	
	/**
	 * Without moving the points in the world coordinate system. Doesn't change transform!
	 * that has to be done manually after (but could be done here...?);
	 * 
	 * @param in
	 */
	public void convertTo(Sheaf in)
	{
		SheetBuilder.convertTo(this,in);
	}
	
	/**
	 * Converts this sheaf into a face of real world coordinates ready to be rendered :)
	 * 
	 * @return
	 */
	public List<Face> getFace()
	{

		List<Face> output = new Vector<Face>();
		TriIterator ti = new TriIterator(this);
		Matrix4d sheet2World = new Matrix4d(transform);
		sheet2World.invert();

		int count = 0;
		// System.err.println(ti.hasNext());
		while (ti.hasNext() && count < 500)
		{
			count ++; // reliabililty code
			ti.next();
			Face f = new Face();
			Tuple2d one = ti.one();
			Tuple2d two = ti.two();
			Tuple2d three = ti.three();
			//System.err.println("got from triiteratit "+one+two+three);

			f.addVertex(new Vertex(one.x, 0, one.y).multiplyBy(sheet2World));
			f.addVertex(new Vertex(two.x, 0, two.y).multiplyBy(sheet2World));
			f.addVertex(new Vertex(three.x, 0, three.y).multiplyBy(sheet2World));
			output.add(f);
		}

		return output;
	}

	/**
	 * Constructs a new sheaf to be the boolean op of this and that. runs in n^2 time... eeek we could improve here by only checking each sheaf against the other then still n^2 but (n/2)^2. Only if you need the grief tho!
	 * 
	 * could also check end coordinates before doing an all out collision test
	 * 
	 * @param in
	 *            the input sheaf
	 */
	public Sheaf booleanOp(Sheaf in, BooleanType booleanType)
	{
		checkCompatible(in.getTransform());
		List<CEFP> startPoints1 = new Vector<CEFP>();
		List<CEFP> startPoints2 = new Vector<CEFP>();
		// Hashmap of the intersections, they are always stored in pairs one
		// for the first sheaf and one for the second. they are removed once
		// they are visited
		TreeMap<CEFP, CEFP> intersects = new TreeMap<CEFP, CEFP>();

		// copy points from this sheet to the sheet o'mush
		Iterator<Sheet> it = getSheets().iterator();
		while (it.hasNext())
		{
			CEFP ce = it.next().getFirst();
			startPoints1.add(ce.copy());
		}
		// ad the points from the other sheet, if we are subtracting, reverse
		// the points, then continue as intersection!
		it = in.getSheets().iterator();
		while (it.hasNext())
		{
			if (booleanType == BooleanType.SUBTRACT)
			{
				CEFP ce = it.next().getFirst();
				startPoints2.add(ce.ypoc());
				booleanType = BooleanType.INTERSECT;
			}
			else
			{
				CEFP ce = it.next().getFirst();
				startPoints2.add(ce.copy());
			}
		}
		// go through all the lists
		Iterator<CEFP> sit = startPoints1.iterator();
		while (sit.hasNext())
		{
			CEFPIterator cit = new CEFPIterator(sit.next());
			while (cit.hasNext())
			{

				CEFP one = cit.next();
				PriorityQueue<Pair<CEFP, Double>> oneSecs = new PriorityQueue<Pair<CEFP, Double>>(1, new DistanceComparitor(one));
				Iterator<CEFP> sit2 = startPoints2.iterator();

				while (sit2.hasNext())
				{
					CEFPIterator cit2 = new CEFPIterator(sit2.next());
					while (cit2.hasNext())
					{
						CEFP two = cit2.next();
						if (one != two)
						{
							// System.err.print(one.thing+" - "
							// +one.next.thing+"**");
							// System.err.println(two.thing+" = "
							// +two.next.thing);
							// do the lines cross?

							Triple<FlatPoint, Double, Double> intersect = intersectBetween(one.thing, two.thing, one.next.thing, two.next.thing, true);

							// another test for the borderline condition that a
							// two lies on the line between one and one.next
							if (intersect != null && intersect.second()!=1 && intersect.third()!=1)
							{
								 //System.err.println("one "+one+" "+intersect.first());
								 //System.err.println("two "+two);
								// System.err.println("intersect at
								// "+intersect);
								// System.err.println("mmm.... intersecty");
								// create the two intersection points, and
								// copy
								// the
								// attributes across
								CEFP int1;
								CEFP int2;
								if (intersect.second() != 0 && intersect.third() != 0 )
								{
									//System.err.println("dull");
									int1 = new CEFP(new FlatPoint(intersect.first()));
									Iterator<EdgeType> etit1 = one.thing.getType().iterator();
									while (etit1.hasNext())
										int1.thing.addType(etit1.next());
									int1.thing.addType(INTERSECTED);
									int1.next = one.next;
									int1.previous = one;

									oneSecs.add(new Pair<CEFP, Double>(int1, intersect.second()));
									
									int2 = new CEFP(new FlatPoint(intersect.first()));
									Iterator<EdgeType> etit2 = two.thing.getType().iterator();
									while (etit2.hasNext())
										int2.thing.addType(etit2.next());
									int2.thing.addType(INTERSECTED);

									int2.next = two.next;
									int2.previous = two;
									// the intersect with the other line are inserted as we go it can only cross int1 once!
									two.next.previous = int2;
									two.next = int2;

								}
								else if (intersect.second() ==0 && intersect.third() == 0)
								{// intersection happens on top of both points

									//System.err.println("second,third== 0");
									int1 = one;
									int2 = two;
								}
								else if (intersect.third() == 0) // intersection happens on point two
								{ // but not on point one!

									//System.err.println("third== 0");
									int1 = new CEFP(new FlatPoint(intersect.first()));
									Iterator<EdgeType> etit1 = one.thing.getType().iterator();
									while (etit1.hasNext())
										int1.thing.addType(etit1.next());
									int1.thing.addType(INTERSECTED);
									int1.next = one.next;
									int1.previous = one;

									oneSecs.add(new Pair<CEFP, Double>(int1, intersect.second()));
									int2 = two;
								}
								else if (intersect.second() == 0) // intersection happens on point one,
								{ // but not two
									int1 = one;

									//System.err.println("second == 0");
									int2 = new CEFP(new FlatPoint(intersect.first()));
									Iterator<EdgeType> etit2 = two.thing.getType().iterator();
									while (etit2.hasNext())
										int2.thing.addType(etit2.next());
									int2.thing.addType(INTERSECTED);

									int2.next = two.next;
									int2.previous = two;
									// the intersect with the other line are inserted as we go it can only cross int1 once!
									two.next.previous = int2;
									two.next = int2;
								}
								else
								{
									assert(false);
									int1 = null;
									int2 = null;
								}


								assert(int1.thing.distanceTo(int2.thing) < 0.000001);
								
								intersects.put(int1, int2);
								intersects.put(int2, int1);

								// now need to check for intersections
								// between
								// the new line section on
								// one against all line segments on two
								// including the new line...
							}
						}
					}
				}

				// run through the queue in order, taking each in turn and
				// inserting it after one in the linked list
				CEFP previous = one;
				CEFP last = one.next;
				while (oneSecs.size() > 0)
				{
					Pair<CEFP, Double> sec = oneSecs.poll();
					CEFP toAdd = sec.first();

					last.previous = toAdd;
					previous.next = toAdd;
					toAdd.previous = previous;
					toAdd.next = last;

					previous = toAdd;
					// toAdd.next is set upove to point to the original one.next
					// System.err.println("oneSecs " + sec);
				}
			}
		}

		Sheaf sheaf = new Sheaf(transform);
		// now traverse starting from each unvisited intersection point, marking
		// any
		// intersection points passed as visited. When we reach an intersection
		// we choose the path with the maximum interior angle for a union.
		while (intersects.size() > 0)
		{
			//System.err.println("intersections are "+intersects.firstKey().thing+" "+intersects.get(intersects.firstKey()).thing);

			// construct a list for the sheet to be made with
			List<FlatPoint> lfp = new Vector<FlatPoint>();
			// decide which vector to follow
			CEFP start1 = intersects.get(intersects.firstKey());
			CEFP start2 = intersects.firstKey();
			CEFP start = unionChoose(start1, start2, booleanType).previous;
			intersects.remove(start1);
			intersects.remove(start2);

			CEFP previous = start;
			int count = 0;
			boolean go = true;

			//System.err.println("new start..." + start);
			while (go)
			{
				count++;
				if (count > 50)
					assert (false);

				lfp.add(previous.thing);
				//System.err.println("going to " + previous.thing);
				// if we see a point
				if (intersects.containsKey(previous))
				{
					//System.err.print("**");
					CEFP s1 = previous;
					CEFP s2 = intersects.get(previous);

					intersects.remove(s1);
					intersects.remove(s2);

					previous = unionChoose(s1, s2, booleanType);

				}
				else
				{
					previous = previous.next;
				}
				if (previous.thing.equals(start.thing))
					go = false;
			}

			Sheet sheet = new Sheet(lfp);
			sheaf.addSheet(sheet);
		}

		return sheaf;
	}

	public CEFP unionChoose(CEFP start1, CEFP start2, BooleanType bt)
	{
		//System.err.println(start1.thing + "-choosing between");
		//System.err.println(start1.next.thing + " and " + start2.next.thing);

		Vector2d v1 = new Vector2d(start1.next.thing);
		v1.sub(start1.thing);
		Vector2d v2 = new Vector2d(start2.next.thing);
		v2.sub(start2.thing);

		switch (bt)
		{
		case UNION:
			if (cross(v1, v2) > 0)
			{
				return start2.next;
			}
			else
			{
				return start1.next;
			}
		case INTERSECT:
			if (cross(v1, v2) < 0)
			{
				return start2.next;
			}
			else
			{
				return start1.next;
			}
		// SUBTRACT should never get here! should be an intersect by now
		default:
			fatalError("Unimlpemented op in unionChoose " + bt);
			return null;
		}
	}
	
	/**
	 * Finds the rectangle in the input. For now assumes that it is a rectange based at 0,0
	 * going into the first quadrant
	 * 
	 * @param in the sheaf of which the first sheet contains the rectangle
	 * @return a pair of the width and height
	 */
	public static Pair<Double,Double>findRectangle(Sheaf in)
	{
		double xmin =  Double.MAX_VALUE, ymin =  Double.MAX_VALUE;
		double xmax = -Double.MAX_VALUE, ymax = -Double.MAX_VALUE;
		boolean seenOrigin = false;
		
		Sheet s = in.getMain();
		
		CEFPIterator cit = new CEFPIterator(s.first);
		int count = 0;
		while (cit.hasNext())
		{
			count ++;
			FlatPoint f = cit.next().thing;
			if (f.x < xmin) xmin = f.x;
			if (f.y < ymin) ymin = f.y;
			if (f.x > xmax) xmax = f.x;
			if (f.y > ymax) ymax = f.y;
			
			if (f.samePlaceAs(new Vector2d(0,0))) seenOrigin = true;
		}
		if (!seenOrigin)
			fatalErrorSD("findRectangle didnt see the origin point");

		if (xmin != 0 || ymin != 0)
			fatalErrorSD("findRectangle doesnt have rectangle starting at 0"+xmin+" "+ymin);

		if (count != 4)
			fatalErrorSD("findRectangle doesnt see four sides, for four sides should my rectangle have");

		return new Pair<Double,Double>(xmax,ymax);
		
	}
	
	/**
	 * Note too self - descriptive names arnt always good
	 * @param in
	 * @return
	 */
	public CEFP getStartOfFirstEdgeWithTag(EdgeType in)
	{
		Sheet s = getMain();
		
		CEFPIterator cit = new CEFPIterator(s.first);
		while (cit.hasNext())
		{
			CEFP next = cit.next();
			System.err.println("types foudn in here are "+next.thing.getTypes());
			if (next.thing.ofType(in)) return next;
		}
		return null;
	}
	
	public CEFP findLongestEdge()
	{
		CEFP found = null;
		double max = -Double.MAX_VALUE;
		
		Sheet s = getMain();
		
		CEFPIterator cit = new CEFPIterator(s.first);
		while (cit.hasNext())
		{
			CEFP next = cit.next();
			CEFP last = next.previous;
			double dist = next.thing.distanceTo(last.thing);
			if (dist > max)
			{
				max = dist;
				found = last;
			}
		}
		return found;	
	}
	
	public void setAllSpeeds(double in)
	{
		for (Sheet s: stack)
			s.setAllSpeeds(in);
	}
	
	public void addTypeToAll(EdgeType in)
	{
		for (Sheet s: stack)
		{
			CEFPIterator cit = new CEFPIterator(s);
			while (cit.hasNext())
			{
				FlatPoint f = cit.next().thing;
				f.addTypeIfNotAlready(in);
			}
		}
	}
	
	/**
	 * Turns a hole into a positive shape and vice versa!
	 *
	 */
	public void reverse()
	{
		for (Sheet s: stack)
			s.reverse();
	}
	
	/**
	 * Angle processor, will reomve all middle points that have PI rad corners
	 * @return
	 */
	public Sheaf removeStraights()
	{
		Sheaf out = new Sheaf(this);
		for (Sheet s: out.getSheets())
		{
			CEFP start = s.getFirst();
			CEFP current = start;
			
			do
			{
				CEFP ac = current;
				CEFP bc = ac.next;
				CEFP cc = bc.next;
				
				FlatPoint a = ac.thing;
				FlatPoint b = bc.thing;
				FlatPoint c = cc.thing;
				
				if (Vec2d.angleBetween(a,b,c) < 10E-3)
				{ 
					ac.next = cc;
					cc.previous = ac;
					

					if (bc == start)
					{
						s.first = ac;
						break;//do..while
					}
				}
				
				current = current.next;	
			}
			while (current  != start);
		}
		return out;
	}

}
