package geom;

import static sity.Parameters.*;
import junit.framework.TestCase;
import util.*;

public class SheafTest extends TestCase
{
	public void testCreate()
	{
		double data[][] = { { 2.5, 0, 1}, { 0, 0, 1 }, { 0.5, 2, 1 },
				{ 0.75, 1.5 , 1 }, { 1, 2, 1 }, 
				{ 1.25, 1, 1 }, 
				{ 1.5, 2, 1 } 
				,{1.75,1.5,1} ,{2,2,2}};
		
		double data2[][] = { { 0.4,0.6, 1}, {2.3,0.5,1}, {0.5,0.7,1}};
		
		setupParameters();

		SheetBuilder sb = demoSheetBuilder();
		for (int i = 0; i < data.length; i++)
		{
			sb.addPoint(data[i][0],data[i][1], 0);
			sb.setPointSpeed(data[i][2]);
		}

		sb.newSheet();

		for (int i = 0; i < data2.length; i++)
		{
			sb.addPoint(data2[i][0],data2[i][1], 0);
			sb.setPointSpeed(data2[i][2]);
		}

		Sheaf output = sb.makeSheaf();

		int count = 0;
		Sheet first = output.getMain();
		CEFPIterator cit = new CEFPIterator(first.getFirst());
		count = -1;
		
		// check linked list is correct...
		while (cit.hasNext())
		{
			count++;
			CEFP x = cit.next();
			assertTrue(x.thing.x == data[count][0]);
			assertTrue(x.thing.y == data[count][1]);
			assertTrue(x.next.thing.x == data[(count+1)%data.length][0]);
			//System.err.println(x.previous.thing+"  "+   (count-1+data.length)%data.length+"  "
			//		                                +data[(count-1+data.length)%data.length][0]);
			assertTrue        (x.previous.thing.x == data[(count-1+data.length)%data.length][0]);
		}
		
		CEFPIterator c = new CEFPIterator(output.getMain().first);

		count = 0;
		while (c.hasNext()){c.next();count++;}
		assertTrue (count == 9);
		
		//output.getFace();
		anchor.createPolygon(output.getFace());
		
		
		//check linked list still correct!
		cit = new CEFPIterator(first.getFirst());
		count = -1;
		
		// check linked list is correct...
		while (cit.hasNext())
		{
			count++;
			CEFP x = cit.next();
			assertTrue(x.thing.x == data[count][0]);
			assertTrue(x.thing.y == data[count][1]);
			assertTrue(x.next.thing.x == data[(count+1)%data.length][0]);
			assertTrue        (x.previous.thing.x == data[(count-1+data.length)%data.length][0]);
		}
		

	}
	
	public void fftestCreate2()
	{
		double data[][] = { {0,0,1},{0,1,1},{1,1,1},{1,0,1}};
		
		double data2[][] = { { 0.1,0.1,1},{0.8,0.1,1},{0.5,0.7,1}};
		
		//double data[][] = { { 2.5, 0, 1}, { 0, 0, 1 }, { 0.5, 2, 1 },
				
		setupParameters();

		SheetBuilder sb = demoSheetBuilder();
		for (int i = 0; i < data.length; i++)
		{
			sb.addPoint(data[i][0],data[i][1], 0);
			sb.setPointSpeed(data[i][2]);
		}
		sb.newSheet();
		for (int i = 0; i < data2.length; i++)
		{
			sb.addPoint(data2[i][0],data2[i][1], 0);
			sb.setPointSpeed(data2[i][2]);
		}
		
		Sheaf output = sb.makeSheaf();
		CEFPIterator c = new CEFPIterator(output.getMain().first);
		int count = 0;
		

		//output.getFace();
		anchor.createPolygon(output.getFace());
	}
}
