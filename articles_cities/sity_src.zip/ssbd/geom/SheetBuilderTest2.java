package geom;

import java.util.*;

import javax.vecmath.*;

import junit.framework.TestCase;
import sity.Parameters;
import skyHook.*;
import util.CEFPIterator;

public class SheetBuilderTest2 extends TestCase
{

	public void testSheafBuilder()
	{
		Parameters.setupParameters();
		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(4, 0, 0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));
		fp.add(new FlatPoint(1, 1));
		fp.add(new FlatPoint(1, 0)); // sheet is now a unit sqare in the 1st
		Sheaf s1 = new Sheaf(fp, mat);

		Parameters.anchor.createPolygon(s1);
		System.err.println(" s1 matrix is \n"+s1.getTransform());
		
		for (int i = 0; i < 5; i++)
		{
		SheetBuilder sb = new SheetBuilder(s1);
		sb.addPoint(0,0,0);
		//sb.setPointType(EdgeType.REFERENCE);
		sb.addPoint(0,1,0);
		sb.addPoint(1,0.7,1);
		Sheaf s2 = sb.makeSheaf();
		Parameters.anchor.createPolygon(s2);
		s1 = s2;
		}
		
		
		Parameters.anchor.createPolygon(s1);
		
		/*sb = new SheetBuilder(s2);
		sb.addPoint(0,0,1);
		sb.addPoint(0,1,1);
		sb.addPoint(1,0.5,2);
		Sheaf s3 = sb.makeSheaf();*/

		/*Parameters.anchor.createPolygon(s1);
		Parameters.anchor.createPolygon(s2);
		Parameters.anchor.createPolygon(s3);*/
		
	}
	
	public void xxtestSheetAgainAgain()
	{
		Parameters.setupParameters();
		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(-0, 0, -0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));
		fp.add(new FlatPoint(1, 1));
		fp.add(new FlatPoint(1, 0)); // sheet is now a unit sqare in the 1st
		Sheaf s1 = new Sheaf(fp, mat);

		System.err.println("firs tis " + s1.getMain().getFirst().thing);

		for (int i = 0; i < s1.getFace().size(); i++)
		{
			System.err.println("***************");
			Iterator<Vertex> vit = s1.getFace().get(i).getIter();
			while (vit.hasNext())
			{
				System.err.println("translates to " + vit.next());
			}
		}
		
		System.err.println(" s1 matrix is \n"+s1.getTransform());
		
		
		SheetBuilder sb = new SheetBuilder(s1);
		sb.addPoint(0,10,1);
		sb.addPoint(0,11,1);
		sb.addPoint(1,11,1);
		//sb.addPoint(1,10,1);
		//sb.setPointType(EdgeType.REFERENCE);
		
	
		Sheaf s2 = sb.makeSheaf();
		System.err.println(" s2 matrix is \n"+s2.getTransform());
		
		
		showSheaf(s2, "s2");
		
		
		sb = new SheetBuilder(s2);
		sb.addPoint(0,0,0);
		//sb.setPointType(EdgeType.REFERENCE);
		sb.addPoint(0,1,0);
		sb.addPoint(0,1,1);
		Sheaf s3 = sb.makeSheaf();
		System.err.println(" s3 matrix is \n"+s3.getTransform());
		
		showSheaf(s3, "s3");
		
		Parameters.anchor.createPolygon(s1);
		Parameters.anchor.createPolygon(s2);
		Parameters.anchor.createPolygon(s3);

		
	}
	
	private void showSheaf(Sheaf s2, String name)
	{
		for (Sheet s: s2.getSheets())
		{
			CEFPIterator dit = s.iterator();
			while (dit.hasNext()) 
				System.err.println("stred coordinates for "+name+" are "+dit.next().thing);
		}
		System.err.println();
		for (int i = 0; i < s2.getFace().size(); i++)
		{
			//System.err.println("***************");
			Iterator<Vertex> vit = s2.getFace().get(i).getIter();
			while (vit.hasNext())
			{
				System.err.println(name+" translates to " + vit.next());
			}
		}
	}

	public void xxtestSkeletonBroken()
	{
		boolean OUTPUT = true;

		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(0, 0, 0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));
		fp.add(new FlatPoint(1, 1));
		fp.add(new FlatPoint(0, 1)); // sheet is now a unit sqare in the 1st
		// quadrant
		// clockwise manner!
		Sheaf s2 = new Sheaf(fp, mat);

		MayaSkyHook sh = new MayaSkyHook();
		Anchor a = new MayaAnchor(sh);

		double data[][][] = { { { 6.147399295538194, 0.8806303038898822, 0.0 }, { 2.681626655764666, 0.0, 0.0 }, { 2.4861852788619867, 2.4860565617127515, 2.457621431297252 }, { 3.024693423086099, 3.4265735787426426, 2.984170884386353 } },

		{ { 6.80006355343006, 8.035080455842174, 0.0 }, { 6.147399295538194, 0.8806303038898822, 0.0 }, { 3.024693423086099, 3.4265735787426426, 2.984170884386353 }, { 2.929540726476488, 3.7929932181725285, 2.8843836295283194 }, { 3.4814267883901486, 5.199985483442302, 3.0473516654296136 } } };

		SheetBuilder sb;
		Sheaf sheet = s2;
		Sheaf o[] = new Sheaf[2];
		for (int s = 0; s < data.length; s++)
		{
			sb = new SheetBuilder(s2);
			for (int p = 0; p < data[s].length; p++)
			{
				sb.addPoint(data[s][p][0], data[s][p][1], data[s][p][2]);
			}
			// Face f = sb.makeSheet().getFace().get(0);
			// System.err.println("\n"+f);
			// sb.funnyPlane();
			o[s] = sb.makeSheaf();
			a.createPolygon(o[s].getFace());
		}

		// System.err.println(o[0].defref(0)+" \n"+o[1].defref(1)+"\n\n");

		// System.err.println(o[0].defref(3)+" \n"+o[1].defref(2));
	}
}
