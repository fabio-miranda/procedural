package geom;

import java.util.*;

import javax.vecmath.Tuple3d;

/**
 * Dimensional reduction scheme, we remove one variable - but which one?
 * @author people
 *
 */
public class ThreeToTwo
{
	public static final int x = 0;
	public static final int y = 1;
	public static final int z = 2;
	
	private int togo;
	
	/**
	 * We throw away the larget of the parameters (jordan curve stylee)
	 * @param x
	 * @param y
	 * @param z
	 */
	public ThreeToTwo (double x, double y, double z)
	{
		x = Math.abs(x);
		y = Math.abs(y);
		z = Math.abs(z);

		if (x > y && x > z)
			togo = this.x;
		else if (y > z)
			togo = this.y;
		else
			togo = this.z;
	}
	
	public FlatPoint toFlat(Tuple3d in)
	{
		if (togo == x)
		{
			return new FlatPoint(in.y, in.z);
		}
		else if (togo == y)
		{
			return new FlatPoint(in.x, in.z);
		}
		else if (togo == z)
		{
			return new FlatPoint(in.x, in.y);
		}
		return null;
	}
	
	public List<FlatPoint> toFlat(List<Tuple3d> in)
	{
		List<FlatPoint>lfp = new ArrayList<FlatPoint>();
		for (Tuple3d t: in)
			lfp.add(toFlat(t));
		return lfp;
	}
	
	public List<FlatPoint> toFlatVertex(List<Vertex> in)
	{
		List<FlatPoint>lfp = new ArrayList<FlatPoint>();
		for (Tuple3d t: in)
			lfp.add(toFlat(t));
		return lfp;
	}
	
}
