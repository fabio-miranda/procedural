package geom;

public enum BooleanType
{
	UNION, INTERSECT, SUBTRACT
}
