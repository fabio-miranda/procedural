package geom;

import junit.framework.TestCase;
import skeleton.Dot;

public class DotMathTest extends TestCase
{

	// p1 d1 p2 d2 goal
	double[][] data = {
			// simple non parallel
			{ 0, 0, 1, 0, 1, 1, 0, -1, 1, 0 },
			{ 0.5, 0.5, 1, 1, 10.4, 0, 0, 1, 10.4, 10.4},
			// parallel (69 == null)
			{ 0.5, 0.5, 1, 1, 10.4, 0, 1, 1, 69, 69},
			{ 0.5, 0.5, 1, 1, 234, 232, -1, -1, 69, 69},
            // coincident, heading away from each other
			{ 1,1, -0.5, 0.5, -10,-10, 1,-1, 69, 69},
			{ 0,0 ,-100,0, 0,1, 1,0, 69, 69}, 
            // coincident, heading towards from each other
			{ 0,0, 1,0, 10,0, -1,0, 5,0},
			{ 0,0, 2,0, 10,0, -1,0, (2*10./3.),0},
			// coincident, heading in same direction
			{ 0,0, 1.0,0, 1,0, 0.5,0,  2, 0},
			{ 0,1, 0,-1, 0,-1, 0,1,    0,0},
			// against a Bisector with 0 speed
			{ 0,0, 0,0, 1,0, -1,0, 0,0 },
			{ 0,0, 1,1, 10,10, 0,0, 10,10 },
			{ 0,0, 1,1, 1000,1000, 0,0, 1000,1000},
			// two with 0 speed
			{ 0,0, 0,0, 1,1, 0,0, 69, 69 },
			};

	public void testIntersect()
	{
		for (int i = 0; i < data.length; i++)
		{
			//System.err.println("***********************************************"+i);
			double[] row = data[i];

			FlatPoint af = new FlatPoint(row[0], row[1]);
			FlatPoint bf = new FlatPoint(row[4], row[5]);

			Dot a = new Dot(af);
			Dot b = new Dot(bf);

			a.setBisector(row[2], row[3]);
			b.setBisector(row[6], row[7]);
			
			FlatPoint goal = new FlatPoint(row[8],row[9]);

			// check symettry also
			checkLocation(DotMath.intersectDots(a,b),goal,i);
			checkLocation(DotMath.intersectDots(b,a),goal,i);
		}
	}
	
	private void checkLocation(Dot output, FlatPoint goal, int c)
	{
		if (output == null && goal.x == 69)
		{
			// good
		}
		else if (output == null) 
		{
			assertFalse(c+" Target "+output+" was not "+goal, true);	
		}
		else if (goal.x == 69 && output.getPoint().length() > 10E10)
		{
			//good - fine if its a long way away (or very small)
		}
		else if (output.getPoint().distanceTo(goal) < 0.00000001)
		{
			// good
		}
		else
		{
			assertFalse(c+" target "+output+" was not "+goal, true);
		}
	}
}
