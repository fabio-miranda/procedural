package geom;

import static geom.EdgeType.*;

import java.util.ArrayList;
import java.util.List;

import javax.vecmath.Matrix4d;
import javax.vecmath.Tuple4d;
import javax.vecmath.Vector3d;

import junit.framework.TestCase;
import skyHook.Anchor;
import skyHook.MayaAnchor;
import skyHook.MayaSkyHook;


import static geom.Vec3d.*;

public class SheetBuilderTest extends TestCase
{
	public void testCheckHowEnumsWork()
	{
		EdgeType a, b;
		a = EXIT;
		b = STREET;
		assertFalse(a.equals(b));
		a = STREET;
		assertTrue(a.equals(b));
	}

	/**
	 * Error hiding routine for use in rotations where we drop digits
	 * 
	 * @param a
	 * @param b
	 */

	public void closeTo(double a, double b)
	{
		assertTrue(a + " should be " + b, Math.abs(a - b) < 0.00001);
	}

	public void testSheetTranslateOne()
	{
		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(0, -69, 0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));

		FlatPoint fp2 = new FlatPoint(1, 1);
		fp2.addType(REFERENCE);
		fp.add(fp2);
		fp.add(new FlatPoint(0, 1)); // sheet is now a unit sqare in the 1st
		// quadrant
		Sheaf s = new Sheaf(fp, mat);
		SheetBuilder sb = new SheetBuilder(s);
		// now - clockwise when viewed from outside...
		sb.addPoint(0.1, 0.1, 1);
		sb.addPoint(0.1, 0.9, 1);
		sb.addPoint(0.9, 0.9, 1);
		sb.setPointType(REFERENCE);
		sb.addPoint(0.9, 0.1, 1);
		sb.normalisePoints(); // now the points in the sb should be 0.1,70,0.1
		// to
		// 0.1,70,0.9 ...
		List<Vertex> lv = sb.data;
		Double d[][] = { { 0.1, 70., 0.1 }, { 0.1, 70., 0.9 },
				{ 0.9, 70., 0.9 }, { 0.9, 70., 0.1 } };
		for (int i = 0; i < d.length; i++)
		{
			Vertex v = lv.get(i);
			assertTrue(v.getX() + "is X when it should be " + d[i][0],
					v.getX() == d[i][0]);
			assertTrue(v.getY() + "is Y when it should be " + d[i][1],
					v.getY() == d[i][1]);
			assertTrue(v.getZ() + "is Z when it should be " + d[i][2],
					v.getZ() == d[i][2]);
		}
		// now for plane calculation. We want the normal to be straight UP!
		Tuple4d tu = sb.findPlane();
		assertTrue(tu.x + "should be 0", tu.x == 0);
		assertTrue(tu.y + "should be 1", tu.y == 1);
		assertTrue(tu.z + "should be 0", tu.z == 0);
		assertTrue(tu.w + "should be 70", tu.w == 70);
		// now translate so are flat at origin
		sb.flattern(tu); // also
		/*List<FlatPoint> lfp = sb.getFlatPointList(); // *sigh* java Matrix4d partOne
		// =
		// flatPair.second();

		double fg[][] = { { 0.1, 0.1 }, { 0.1, 0.9 }, { 0.9, 0.9 },
				{ 0.9, 0.1 } };
		for (int i = 0; i < fg.length; i++)
		{
			assertTrue(lfp.get(i).x + " should be " + fg[i][0], fg[i][0] == lfp
					.get(i).x);
			assertTrue(lfp.get(i).y + " should be " + fg[i][1], fg[i][1] == lfp
					.get(i).y);
		}
		assertTrue(lfp.get(2).ofType(REFERENCE)); // now rotate so REFERENCE
		// is at
		// base and translate so nicely //
		// positioned in 1st quadrant
		Matrix4d partTwo = sb.normalisePlaneLocation(lfp);
		double fgg[][] = { { 0.0, 0.8 },{ 0.8, 0.8 }, { 0.8, 0.0 },{ 0.0, 0.0 } };
		for (int i = 0; i < fgg.length; i++)
		{
			closeTo(fgg[i][0], lfp.get(i).x);
			closeTo(fgg[i][1], lfp.get(i).y);
		}*/
	}

	/** As above but with a more complicated set of rotations! */

	public void testSheetTranslateTwo()
	{
		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(0, -69, 0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));

		FlatPoint fp2 = new FlatPoint(1, 1);
		fp2.addType(REFERENCE);
		fp.add(fp2);
		fp.add(new FlatPoint(0, 1)); // sheet is now a unit sqare in the 1st
		// quadrant
		// defined in
		// a clockwise manner!
		Sheaf s = new Sheaf(fp, mat);
		SheetBuilder sb = new SheetBuilder(s);
		sb.addPoint(0.1, 0.1, 0);
		sb.addPoint(0.1, 0.9, 0);
		sb.addPoint(0.1, 0.9, 0.9);
		sb.setPointType(REFERENCE);
		sb.addPoint(0.1, 0.1, 0.9);
		sb.normalisePoints(); // now the points in the sb should be
		// List<Vertex>
		List<Vertex> lv = sb.data;
		Double d[][] = { { 0.1, 69., 0.1 }, { 0.1, 69., 0.9 },
				{ 0.1, 69.9, 0.9 }, { 0.1, 69.9, 0.1 } };
		for (int i = 0; i < d.length; i++)
		{
			Vertex v = lv.get(i);
			assertTrue(v.getX() + " is X when it should be " + d[i][0], v
					.getX() == d[i][0]);
			assertTrue(v.getY() + " is Y when it should be " + d[i][1], v
					.getY() == d[i][1]);
			assertTrue(v.getZ() + " is Z when it should be " + d[i][2], v
					.getZ() == d[i][2]);
		} // now for plane calculation. We want the normal to be straight UP!
		Tuple4d tu = sb.findPlane();
		// System.err.println("plane is "+tu);
		assertTrue(tu.x + "should be -1", tu.x == -1);
		assertTrue(tu.y + "should be 0", tu.y == 0);
		assertTrue(tu.z + "should be 0", tu.z == 0);
	}

	public void testThreeTriangesWhole()
	{
		boolean OUTPUT = false;

		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(0, 0, 0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));

		fp.add(new FlatPoint(1, 1));
		fp.add(new FlatPoint(1, 0));
		Sheaf s2 = new Sheaf(fp, mat);

		MayaSkyHook sh = new MayaSkyHook();
		Anchor a = new MayaAnchor(sh);

		SheetBuilder sb;

		Sheaf sheet = s2;
		for (int i = 0; i < 8; i++)
		{
			sb = new SheetBuilder(sheet);
			sb.addPoint(0.0, 0.0, 0.0);
			sb.addPoint(0.0, 2.0, 0.0);
			sb.addPoint(1.0, 0.0, 1.0);

			sheet = sb.makeSheaf();
			//System.err.println(i+" "+sheet.order());
			//Iterator<FlatPoint> it = sheet.getPoints();
			//while (it.hasNext())System.err.println("sheet is "+it.next());
			if (OUTPUT)
				a.createPolygon(sheet.getFace());
		}

		sb = new SheetBuilder(sheet);
		sb.addPoint(0.0, 0.0, 0.0);
		sb.addPoint(0.0, 1.0, 0.0);
		sb.addPoint(1.0, 1.0, 0.0);
		sb.addPoint(1.0, 0.0, 0.0);

		sheet = sb.makeSheaf();

		//Matrix4d result = sheet.getTransform();
		//Matrix4d ident = new Matrix4d();
		//ident.setIdentity();

		// if we rotate 8 times on a unit circle we end up where we started :)
		//assert (result.equals(ident));

		if (OUTPUT)
			a.createPolygon(sheet.getFace());
	}

	/**
	 * Checks that the reference system is consistent
	 * 
	 */
	public void testReference()
	{
		boolean OUTPUT = false;

		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(0, 0, 0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));
		fp.add(new FlatPoint(1, 1));
		fp.add(new FlatPoint(0, 1)); // sheet is now a unit sqare in the 1st
		// quadrant
		// clockwise manner!
		Sheaf s2 = new Sheaf(fp, mat);

		MayaSkyHook sh = new MayaSkyHook();
		Anchor a = new MayaAnchor(sh);

		SheetBuilder sb;
		Sheaf sheet = s2;
		for (int i = 0; i < 50; i++)
		{
			sb = new SheetBuilder(sheet);
			sb.addPoint(0.0, 0.0, 0.1);
			sb.addPoint(0.0, 2.0, 0.1);
			sb.addPoint(2.0, 2.0, 0.1);
			sb.addPoint(2.0, 0.5, 0.1);
			sb.setPointType(REFERENCE);

			sheet = sb.makeSheaf();
			if (OUTPUT)
				a.createPolygon(sheet.getFace());
		}

		sb = new SheetBuilder(sheet);
		sb.addPoint(0.0, 0.0, 0.0);
		sb.addPoint(0.0, 1.0, 0.0);
		sb.addPoint(0.5, 1.5, 0.0);
		sb.addPoint(1.0, 1.0, 0.0);
		sb.addPoint(1.0, 0.0, 0.0);

		sheet = sb.makeSheaf();
		if (OUTPUT)a.createPolygon(sheet.getFace());

		Matrix4d ident = new Matrix4d();
		ident.setIdentity();

		if (OUTPUT)
			a.createPolygon(sheet.getFace());
	}

}
