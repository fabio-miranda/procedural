package geom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


/** A face is an ordered list of vertices. Should probably always be clockwise
 *  list to keep maya happy
 * 
 * @author people
 *
 */
public class Face
{
	private List<Vertex> vertices = new ArrayList<Vertex>();
	private List<EdgeType> type = new ArrayList<EdgeType>();
	
	/** Two cosntructors to create a face
	 * 
	 *
	 */
	public Face()
	{
	}
	
	public Face(List<Vertex> in)
	{
		vertices = in;
	}
	
	public List<Vertex> getVertices()
	{
		return vertices;
	}

	/** Adds a new vertex to the end? of the face
	 * 
	 * @param in
	 */
	public void addVertex(Vertex in)
	{
		vertices.add(in);
	}
	
	public void addVertex(Vertex in, EdgeType et)
	{
		vertices.add(in);
		type.add(et);
	}
	
	/** Returns an iterator of all the points in the face
	 * 
	 * @return
	 */
	public Iterator<Vertex> getIter()
	{
		return vertices.iterator();
	}
	
	public int size()
	{
		return vertices.size();
	}
	
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		Iterator<Vertex>it = getIter();
		while (it.hasNext())
		{
			sb.append(it.next());
			if (it.hasNext()) sb.append(" to \n");
		}
		return sb.toString();
	}
	
}
