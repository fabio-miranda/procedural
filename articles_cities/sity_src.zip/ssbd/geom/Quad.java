package geom;

/** Adapted from ibm.com
 * 
 * @author tomkelly
 *
 * @param <A>
 * @param <B>
 */
class Quad <A,B,C,D> {
  private A element1;
  private B element2;
  private C element3;
  private D element4;
  
  public Quad(A element1, B element2, C element3, D element4){
      this.element1 = element1;
      this.element2 = element2;
      this.element3 = element3;
      this.element4 = element4;
  }
    
  public A first(){
      return element1;
  }
  
  public B second(){
      return element2;
  }
  
  public C third(){
      return element3;
  }
  
  public C fourth(){
      return element3;
  }
  
  public String toString()
  {
	  return "("+element1+","+element2+","+element3+","+element4+")";
  }
}
  