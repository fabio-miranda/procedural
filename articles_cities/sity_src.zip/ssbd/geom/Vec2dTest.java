package geom;

import static geom.Vec2d.*;
import static java.lang.Math.*;
import static sity.Parameters.*;

import java.util.*;

import javax.vecmath.*;

import junit.framework.TestCase;
import cloud.*;

/**
 * Testclass for Vec2d
 * 
 * @author people
 * 
 */
public class Vec2dTest extends TestCase
{
	
	public void testIntersectInFront()
	{
		double data[][] = {{0,0, 1,0, 1,0, -1,0, 0.5,0},
				{0,0, 1,0, 1,0, 1,0, Double.MAX_VALUE, Double.MAX_VALUE},
				{0,0, 1,1, 1,0, -1,0, Double.MAX_VALUE, Double.MAX_VALUE},
				{0,0, 1,0, -1,0, -1,0, Double.MAX_VALUE, Double.MAX_VALUE},
				{0,0, 1,0, -1,0, 1,0, Double.MAX_VALUE, Double.MAX_VALUE}};
		
		for (int i = 0; i < data.length; i++)
		{
			FlatPoint res = intersectInFront(new Vector2d(data[i][0], data[i][1]), new Vector2d(data[i][2], data[i][3]),
					new Vector2d(data[i][4], data[i][5]), new Vector2d(data[i][6], data[i][7]));
			if (res == null) 
				assertTrue("test "+i,data[i][8] == Double.MAX_VALUE);
			else
			{
				closeTo(" test "+i, res, new FlatPoint(data[i][8],data[i][9]));
			}
		}
		
	}
	
	/**
	 * I dont think boundary points count as being in!
	 * 
	 */
	public void testPointIn()
	{
		List<FlatPoint> data = new Vector<FlatPoint>();

		double info[][] = { { 0, 0 }, { 0.0, 0.5 }, { 0.5, 0.5 }, { 0.5, 0.0 } };

		for (int i = 0; i < info.length; i++)
			data.add(new FlatPoint(info[i][0], info[i][1]));

		
		assertTrue(pointIn(new Vector2d(0.01, 0.01), data));
		assertFalse(pointIn(new FlatPoint(-0.1, -0.1), data));
		assertTrue(pointIn(new FlatPoint(0.5, 0.5), data)); // boderline is true
	}
	/**
	 * I dont think boundary points count as being in! (They are now!)
	 * 
	 */
	public void testPointInTwo()
	{
		List<FlatPoint> data = new Vector<FlatPoint>();

		double info[][] = { {0.7071067811865475, 0.5},
				{0.0, 0.0},
				{0.0, 3.0}};

		for (int i = 0; i < info.length; i++)
			data.add(new FlatPoint(info[i][0], info[i][1]));

		assertTrue(pointIn(new FlatPoint(0.03199614210294678, 1.5), data));
		assertFalse(pointIn(new FlatPoint(-0.00000001, 1.5), data));
		assertTrue(pointIn(new FlatPoint(0.00000, 1.5), data));//lol was 0.0001 :)
		assertFalse(pointIn(new FlatPoint(-0.1, -0.1), data));
	}

	/**
	 * Point in a random concave polygon test
	 * 
	 */
	public void testRandomPoint()
	{
		List<FlatPoint> data = new Vector<FlatPoint>();

		double info[][] = { { 0, 0 }, { 0.0, 0.5 }, { 0.5, 0.5 }, { 0.5, 0.0 } };

		setupParameters();
		SheetBuilder sb = demoSheetBuilder();
		
		
		for (int i = 0; i < info.length; i++)
			data.add(new FlatPoint(info[i][0], info[i][1]));
		

		Sheaf f = new Sheaf(data);
		
		Random random = new Random();
		
		for (int i = 0; i < 50; i++)
		{
			FlatPoint output = randomPoint(f, random);
			assertFalse(output == null);
			assertTrue(output.x > 0 && output.x < 0.5);
			assertTrue(output.y > 0 && output.y < 0.5);
			assertTrue(pointIn(output, data));
		}
	}

	public void testInsideAntiAngle()
	{
		double data[][] = { { 0., 1., 1., 1., 3*PI / 4. },
				{ 0., 1., 1 , 0, PI / 2. },
				{ 0., 1., 1., -1., PI / 4. },
				{ 0., 1., -1., 1., 7*PI / 4. },
				{ 1, 1., 1., 1, PI },
				{ -1, 1., -1., 1, PI },
				{ 1, -1., 1., -1, PI },
				{ -1, -1., -1., -1, PI },

				{ -1, -1., 1., 1, 0 },
				{ 1, 1., -1., -1, 0 },
				{ -1, 1., 1., -1, 0 },
				{ 1, -1., -1., 1, 0 },
				{ 0.5, -1., 1., 0, PI*(3./2.)+atan(0.5) },
				//{-0.4926988149835926, -0.8701999067534791,
				//	0.9999999999999999, 1.6814280583727095E-16, 0}
				//	{-0.4926988149835926, -0.8701999067534791,
				//		0.4926988149835927, -0.8701999067534788, 0}
				};

		for (int i = 0; i < data.length; i++)
		{
			Vector2d v1 = new Vector2d(data[i][0], data[i][1]);
			Vector2d v2 = new Vector2d(data[i][2], data[i][3]);

			double a = interiorAngle(v1, v2);
			closeTo(i+") "+v1 + " angle " + v2 + "should be\n " + data[i][4]
					+ " but is " + a, a, data[i][4]);
		}
	}
	
	public void testAngle()
	{
		double data[][] = { { 0., 1., 1., 1., PI / 4. },
				{ 0., 1., 1., 0., PI / 2. },
				{ 0, 1, -1, 1, 7 * PI / 4 },
				{ 1., 1., 0., 1., 7 * PI / 4. }, 
				{ 1, 0., -1., 0., PI },
				{ -1, 0, 1., -1., 5 * PI / 4. }, };

		for (int i = 0; i < data.length; i++)
		{
			Vector2d v1 = new Vector2d(data[i][0], data[i][1]);
			Vector2d v2 = new Vector2d(data[i][2], data[i][3]);
			double a = angleBetween(v1, v2);
			closeTo(v1 + " angle " + v2 + "should be " + data[i][4]
					+ " but is " + a, a, data[i][4]);
		}
	}

	public void closeTo(String msg, double a, double b)
	{
		assertTrue(msg, abs(a - b) < 0.000001);
	}

	public void testConvexHull()
	{
		List<FlatPoint> data = new Vector<FlatPoint>();

		double info[][] = { { 0, 0 }, { 0.5, 1 }, { 2, -1 }, { 0.5, 0.5 },
				{ 0.6, 0.6 }, { 0.5, -1.5 }, { 0.5, -1.6 } };
		// double info[][] = {{0,0},{0.5,1},{0.5,-1.5},{2,-1}};

		for (int i = 0; i < info.length; i++)
			data.add(new FlatPoint(info[i][0], info[i][1]));
		List<FlatPoint> results = convexHull(data);
		for (int i = 0; i < results.size(); i++)
		{
			// System.err.println(">>"+results.get(i));
		}
		assertTrue(results.size() == 4);
		assertTrue(results.get(0).equals(new FlatPoint(0, 0)));
		assertTrue(results.get(3).equals(new FlatPoint(0.5, -1.6)));
	}

	/**
	 * Checks that the nearest point with the same angle is returned...?
	 * 
	 */
	public void testConvexHullStraight()
	{
		List<FlatPoint> data = new Vector<FlatPoint>();

		double info[][] = { { 0, 0 }, { 0, 1 }, { 2, 1 }, { 1, 1 } };
		// double info[][] = {{0,0},{0.5,1},{0.5,-1.5},{2,-1}};

		for (int i = 0; i < info.length; i++)
			data.add(new FlatPoint(info[i][0], info[i][1]));
		List<FlatPoint> results = convexHull(data);
		for (int i = 0; i < results.size(); i++)
		{
			// System.err.println(">>"+results.get(i));
		}
		assertTrue("Missing a linear point?", results.size() == 4);
		for (int i = 0; i < info.length; i++)
		{
			assertTrue(results.contains(new FlatPoint(info[i][0], info[i][1])));
		}
	}

	/**
	 * Test the area finding - only for convexes so far.
	 * 
	 */
	public void testFindArea()
	{
		List<FlatPoint> data = new Vector<FlatPoint>();

		
		double info[][] = { { 0, 0 }, { 0, 1 }, { 2, 1 }, { 2, 0 } };
		for (int i = 0; i < info.length; i++)
			data.add(new FlatPoint(info[i][0], info[i][1]));
		
		Sheaf f = new Sheaf(data);
		
		assertTrue("2x1 rectangle area", findArea(f) == 2);

		double info2[][] = { { 0, 0 }, { 10, 20 }, { 10, 0 } };
		
		
		data = new Vector<FlatPoint>();
		for (int i = 0; i < info2.length; i++)
			data.add(new FlatPoint(info2[i][0], info2[i][1]));
		
		f = new Sheaf(data);
		
		assertTrue("10 x 20 triangle area " +  findArea(f), findArea(f) == 100);
	}

	/**
	 * line intersections
	 * 
	 */
	public void testIntersect()
	{
		FlatPoint res = intersect(new FlatPoint(0, 0), new FlatPoint(0, 1),
				new Vector2d(1, 1), new Vector2d(1, -1));
		assertTrue(res.equals(new FlatPoint(0.5, 0.5)));

		res = intersect(new FlatPoint(0, 0), new FlatPoint(0, 1), new Vector2d(
				-1, 1), new Vector2d(-1, -1));
		assertTrue(res.equals(new FlatPoint(-0.5, 0.5)));

		res = intersect(new FlatPoint(0, 0), new FlatPoint(0, 1), new Vector2d(
				1, 0), new Vector2d(1, 0));
		assertTrue(res == null);

		res = intersect(new FlatPoint(0, 0), new FlatPoint(1, 0), new Vector2d(
				0, -1), new Vector2d(-1, -1));
		closeTo("intersect" + res, res.y, -1);
		assertTrue(res.x == 0);

		res = intersect(new FlatPoint(1.0, 0.0), new FlatPoint(
				0.5000000000000001, 2.5), new Vector2d(-0.7071067811865476,
				0.7071067811865476), new Vector2d(-6.53197946192731E-17, -1.0));
		closeTo(" is " + res, res, new FlatPoint(0.5, 0.5));

		res = intersect(new FlatPoint(1.0, 0.0), new FlatPoint(0.5, 2.5),
				new Vector2d(-1, 1), new Vector2d(0, -1.0));
		assertTrue(res.equals(new FlatPoint(0.5, 0.5)));

	}

	/**
	 * perpendicualr height
	 */
	public void testPerpHeight()
	{
		double res;
		for (double i = -10; i < 10; i++)
		{
			res = heightPerpendicular(new FlatPoint(0, 0), new FlatPoint(1, 0),
					new FlatPoint(i, 1));
			assertTrue(res == -1);
			res = heightPerpendicular(new FlatPoint(0, 0), new FlatPoint(1, 0),
					new FlatPoint(i, -1));
			assertTrue(res == 1);
		}
		res = heightPerpendicular(new FlatPoint(1, 1), new FlatPoint(0, 0),
				new FlatPoint(0, 1));
		closeTo(" � ", sqrt(2) / 2, res);
	}

	private void closeTo(String msg, Tuple2d a, Tuple2d b)
	{
		assertTrue(msg, abs(a.x - b.x) < 0.0000001);
		assertTrue(msg, abs(a.y - b.y) < 0.0000001);
	}

	/**
	 * Straigh skeleton shrunk point
	 */
	public void testShrunk()
	{
		Vector2d res;

		double data[][] = { { 0, 1, 0, 0, 1, 0, 1, 1, -1, -1 },
				{ 0, 1, 0, 0, 1, 0, -1, -1, 1, 1 },
				{ 1, 0, 0, 0, 0, 1, 1, 0, 0, 1 },
				{ 0, 1, 0, 0, -1, 1, 1, 1, -1, sqrt(2) + 1 },
				{ 1, 0, 0, 0, -1, 0, 1, 1, 0, 1 },
				{ 0, 1, 0, 0, 0, -1, 1, 1, -1, 0 },
				{ 0, 1, 0, 0, 0, -1, -1, -1, 1, 0 },
				{ 0, -1, 0, 0, 0, 1, 1, 1, 1, 0 },
				{ 0, -1, 0, 0, 0, 1, -1, -1, -1, 0 },
				{ 0, 0, 1, 0.25, 0, 0.5, 1, 1, 1, 0 },
				{ 0, 0.5, 1, 0.25, 0, 0, 1, 1, -1, 0 }
				};

		for (int i = 0; i < data.length; i++)
		{
			Vector2d goal = new Vector2d(data[i][8], data[i][9]);
			res = shrink_OLD(new FlatPoint(data[i][0], data[i][1]), new FlatPoint(
					data[i][2], data[i][3]), new FlatPoint(data[i][4],
					data[i][5]), data[i][6], data[i][7]);
			goal.normalize();
			res.normalize();
			closeTo("run " + i + " gave " + res, goal, res);
		}
	}

	public void tesShrunkk2()
	{
		Vector2d res;
		Random random = new Random();

		for (int i = 0; i < 10; i++)
		{
			FlatPoint a = new FlatPoint(random.nextDouble(), random
					.nextDouble());
			FlatPoint b = new FlatPoint(random.nextDouble(), random
					.nextDouble());
			FlatPoint c = new FlatPoint(random.nextDouble(), random
					.nextDouble());
			a.normalize();
			b.normalize();
			c.normalize();
			res = shrink_OLD(a, b, c, 1, 1);
			res.add(b);
			closeTo("vecor ", angleBetween(a, b, res), angleBetween(res, b, c));
		}
	}

	public void testOnRight()
	{
		double t = 1;
		double f = 0;

		double data[][] = { { 0,0, 0,1, 1,0, t },
				 { 0,0, 0,1, 0.0001,1, t },
				 { 0,0, 0,1, -0.0001,0, f },
				 { 1,1, -1,-1, -0.5,-0.4, t },
				 { 1,1, -1,-1, -0.5,-0.6, f },
				 { 0,0, 1,0, -100,-0.001, t },
		};

		for (int i = 0; i < data.length; i++)
		{
			Vector2d p = new Vector2d(data[i][4], data[i][5]);
			boolean res = onRightOf(new Vector2d(data[i][0], data[i][1]),
					new Vector2d(data[i][2], data[i][3]), p);
			assertTrue("fail on "+i,res == (data[i][6] == 1));
			assertTrue((p.x == data[i][4]) && (p.y == data[i][5]));
		}
	}
	
	public void testDumIntersect()
	{
		double data[][] = {
				{1.185187983608741,7.639384128914511},
				{6.124996132955945,0.9842890447703867},
				{7.111843926599199,1.6654174856908088},
		};
		
		int pairs[][] = {
				{0,1},
				{0,2},
				{1,2},
		};
		
		int count = 0;
		ArrayList<Pair<Tuple2d, Tuple2d>> lines = new ArrayList<Pair<Tuple2d, Tuple2d>>();
		for (int[] d: pairs)
		{
			int f= d[0];
			int s= d[1];
			Pair<Tuple2d, Tuple2d> res = bisectorOfPoints(
				new Vector2d(data[f][0],data[f][1]),
				new Vector2d(data[s][0],data[s][1]));
			lines.add(res);
			count++;
		}
		
		ArrayList<FlatPoint> sects = new ArrayList<FlatPoint>();
		
		// now over each line defined
		for (int[] d: pairs)
		{
			Pair<Tuple2d, Tuple2d> one = lines.get(d[0]);
			Pair<Tuple2d, Tuple2d> two = lines.get(d[1]);
			Vector2d dirO = new Vector2d(one.second().x,one.second().y);
			Vector2d dirS = new Vector2d(two.second().x,two.second().y);
			sects.add(intersect(one.first(), two.first(), dirO, dirS));
			//System.err.println("intersect at "+intersect(one.first(), two.first(), dirO, dirS));
		}
		
		for (FlatPoint f: sects)
		{
			for (FlatPoint F: sects)
			{
				assertTrue (f.distanceTo(F) < 10E-15);
			}
		}
		
	}
	
	
	public void testDumClipIntersect()
	{
		double data[][] = {
				{1.185187983608741,7.639384128914511},
				{6.124996132955945,0.9842890447703867},
				{7.111843926599199,1.6654174856908088},
		};
		
		int pairs[][] = {
				{0,1},
				{0,2},
				{1,2},
		};
		
		int count = 0;
		ArrayList<Pair<FlatPoint, FlatPoint>> lines = new ArrayList<Pair<FlatPoint, FlatPoint>>();
		for (int[] d: pairs)
		{
			int f= d[0];
			int s= d[1];
			
			Vector2d ptO = new Vector2d(data[f][0],data[f][1]);
			Vector2d ptT = new Vector2d(data[s][0],data[s][1]);
			

			
			PointCloud pc = new PointCloud(10.,10.,0, new Random());
			Cell me = new Cell(pc, new FlatPoint(ptO.x, ptO.y));
			pc.setFirstCell(me);
			pc.addCell(me);
			
			Cell other = new Cell(new FlatPoint(ptT.x, ptT.y));
			pc.addCell(other);
			
			Pair<Tuple2d, Tuple2d> res = bisectorOfPoints(
					ptT, ptO);
			Pair<FlatPoint,FlatPoint> clipped = clipConcave(res, me, other);
			
			lines.add(clipped);
			
			System.err.println("results are "+clipped);
			
			
			count++;
		}
		ArrayList<FlatPoint> sects = new ArrayList<FlatPoint>();
		for (int[] d: pairs)
		{
			Pair<FlatPoint, FlatPoint> one = lines.get(d[0]);
			Pair<FlatPoint, FlatPoint> two = lines.get(d[1]);
			sects.add(intersectEndPoints(one.first(), one.second(), two.first(), two.second()));
			System.err.println("intersect at "+intersectEndPoints(one.first(), one.second(), two.first(), two.second()));
		}
		
		for (FlatPoint f: sects)
		{
			for (FlatPoint F: sects)
			{
				// intersects at intersect at {4.2513271919515XX,4.7543978327731XX}
				assertTrue (f.distanceTo(F) < 10E-15);
			}
		}
		
	}
	
}
