package geom;

import java.util.*;

import javax.media.j3d.Transform3D;
import javax.vecmath.*;

/**
 * A 2D point. Complication is because of Maya's y-up coordinate system the 2D
 * points are really on the XZ plane, but we dont think about that too hard
 * here!
 * 
 * The types carry metaData about the previous edge, whether it is on the floor
 * or neightbours another house etc.. May also contain information about the
 * type of point it is eg: SMOOTH, SHARP, TJUNCTION, OBTUSE, REFLEX etc...?
 * 
 * @author tomkelly
 * 
 */
public class FlatPoint extends Vector2d
{

	private static final long serialVersionUID = 5348825898265673L;
	private double speed = 0;
	//double x = 0, y = 0;
	List <EdgeType> type = new ArrayList<EdgeType>(1);
	/** Constructs a 2 d point with no type
	 * 
	 * @param a
	 * @param b
	 */
	public FlatPoint(double a, double b)
	{
		x = a;
		y = b;
	}
	
	/**
	 * Makes a duplicate flatpoint!
	 */
	public FlatPoint clone()
	{
		FlatPoint out = new FlatPoint(x,y);
		out.setSpeed(speed);
		Iterator<EdgeType> it = type.iterator();
		while (it.hasNext()) out.addType(it.next());
		return out;
	}
	
	public double distanceTo(Tuple2d in)
	{
		double xx = in.x-x;
		double yy = in.y-y;
		return Math.sqrt(xx*xx+yy*yy);
	}
	
	public List<EdgeType> getType()
	{
		return type;
	}
	
	/**
	 * Returns a vector representing this flatpoint, at a set y-coord in 3 space
	 * @return
	 */
	public Vector3d get3d()
	{
		return get3d(0);
	}
	public Vector3d get3d(double height)
	{
		return new Vector3d(x, height, y);
	}
	
	/**
	 * Constructs a flatpoint from the an existing tuples (which may be a FlatPoint!) 
	 * @param in the tuple 2d to construct from
	 */
	public FlatPoint(Tuple2d in)
	{
		x = in.x;
		y = in.y;
	}

	
	public FlatPoint(double a, double b, EdgeType et)
	{
		type.add(et);
		x = a;
		y = b;
	}

	/**
	 *  Adds a type to the this point. It references either this
	 *  point, or if a line attribute the line from the previous 
	 *  point to here.
	 * @param in
	 */
	public void addType(EdgeType in)
	{
		type.add(in);
	}
	
	public void addTypeIfNotAlready(EdgeType in)
	{
		if (!type.contains(in)) type.add(in);
	}
	
	public void removeType(EdgeType in)
	{
		while (type.contains(in)) type.remove(in);
	}
	
	public boolean ofType(EdgeType in)
	{
		return (type.contains(in));
	}
	
	public List<EdgeType> getTypes()
	{
		return type;
	}

	/**
	 * Converts the point to a coordinnate in 3 space. We assume that it lies on
	 * the XZ grid, with the Y value being 0.
	 * 
	 * @param m3d
	 *            The transform from absolute coordinate space to local
	 *            coordinate space
	 */
	public Vertex multiplyByInverseOf(Matrix4d m3d)
	{
		Matrix4d mat = new Matrix4d(m3d);
		mat.invert();
		Point3d p3d = new Point3d(x, 0, y);
		Transform3D trans = new Transform3D();
		trans.set(mat);
		trans.transform(p3d);
		return new Vertex(p3d.x,p3d.y,p3d.z);
	}

	public Vertex multiplyBy(Matrix4d mat)
	{
		Point3d p3d = new Point3d(x, 0, y);
		Transform3D trans = new Transform3D();
		trans.set(mat);
		trans.transform(p3d);
		return new Vertex(p3d.x,p3d.y,p3d.z);
	}

	public double getSpeed()
	{
		return speed;
	}

	public void setSpeed(double speed)
	{
		this.speed = speed;
	}
	
	/**
	 * Is this in the same place in 2d space as another tuple
	 * @param in
	 * @return
	 */
	public boolean samePlaceAs(Tuple2d in)
	{
		return (in.x == x && in.y == y);
	}
	
	public String toString()
	{
		return "{"+x+","+y+"}";
	}
	
	public boolean equals(FlatPoint f)
	{
		return (f.x == x && f.y == y);
	}
	
}
