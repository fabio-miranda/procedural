package geom;

import static java.lang.Math.abs;

import java.util.*;

import javax.vecmath.*;

/**
 * 3D math library
 * @author people
 *
 */
public class Vec3d
{
	public static double distanceTo(Tuple3d a, Tuple3d b)
	{
		double x = a.x-b.x;
		double y = a.y-b.y;
		double z = a.z-b.z;
		
		return Math.sqrt(x*x+y*y+z*z);
	}
	public static double dot(Tuple3d a, Tuple3d b)
	{
		return (a.x*b.x+
				a.y*b.y+
				a.z*b.z);
	}
	
	// dot product at which lines are not considered for finding the planes
	private static final double STRAIGHT = 10E-15;

	public static Tuple4d findPlane(List<Vertex> data)
	{
		return findPlane(data, false);
	}
	
	public static Tuple4d findPlane(List<Vertex> data, boolean flipNormal)
	{
		assert(data.size() >= 3);
		Iterator<Vertex> it = data.iterator();
		Vertex one = data.get(data.size()-2);//it.next();
		Vertex two = data.get(data.size()-1);//it.next();
		double oneTwo = one.distanceTo(two);
		Vertex t1 = null, t2 = null, t3 = null;
		double best = -Double.MAX_VALUE;
		while (it.hasNext())
		{
			Vertex three = it.next();

			double twoThree = two.distanceTo(three);
			// angle factor - low for 180 degrees or 0 degrees, high for 90 deg
			// all angle stuff here is new 12th july
			Vector3d oneToTwo = new Vector3d(two);
			oneToTwo.sub(one);
			Vector3d twoToThree= new Vector3d(three);
			twoToThree.sub(two);
			double angle = oneToTwo.angle(twoToThree);		
			
			if ((oneTwo + twoThree) > best && angle > STRAIGHT)
			{
				t1 = one;
				t2 = two;
				t3 = three;
				best = (oneTwo + twoThree);
			}

			one = two;
			two = three;
			oneTwo = twoThree;
		}

		if (t1 == null || t2 == null || t3 == null)
			return null;
		if (!flipNormal)
			return findPlane(data, t3.sub(t2), t2.sub(t1));
		Vector3d t2t = new Vector3d(t2);
		t2t.sub(t1);
		return findPlane(data, t2t, t3.sub(t2));
		
	}

	public static Tuple4d findPlane(List<Vertex> data, Vector3d u, Vector3d v)
	{
		v.normalize();
		u.normalize();

	
		u.cross(v, u); // was this one!
		
		u.normalize();
		Vertex a = data.get(0);
		
		if (Double.isNaN(u.length()))
		{
			/*u = data.get(2).sub(data.get(1));
			System.err.println(u);
			v = data.get(1).sub(data.get(0));
			System.err.println(v);
			u.cross(u, v);
			System.err.println(u);
			System.err.println("v "+v);
			System.err.println("u "+u);
			Thread.dumpStack();*/
			return null;
		}
		//assert abs(u.length() - 1.0) < 0.0000001 : u.length();
		double offset = -(
				a.getX() * u.x + 
				a.getY() * u.y + 
				a.getZ() * u.z);
		Tuple4d out = new Point4d(u.x, u.y, u.z, offset);
		return out;
	}
}
