package geom;

import static geom.Vec2d.*;

import java.util.*;

import javax.vecmath.*;

import junit.framework.TestCase;

public class Vec2dTest2 extends TestCase
{
	
	public void testLineInPoly() throws Exception
	{
		double[][] shape = {{0,10},{9,10},{15,5},{10,0},{0,0},};
		List<FlatPoint> sh = new ArrayList<FlatPoint>();
		for (double[] s : shape)
			sh.add(new FlatPoint(s[0],s[1]));
		
		double[][] test = {
				{-1,1,1,0, 0,1, 11, 1},
				{5,20, 0, -1, 5,10, 5, 0},
				{5,20, -1, 0, 69,69, 69, 69},
				{-100, 5, 1, 0, 0, 5, 15, 5},
				{100, 5, -1, 0, 15, 5, 0, 5, },
				{-1, 11, 1, -1, 0, 10, 10, 0},
				{13, 11, 0, -1, 13, 20./3., 13, 3},
				// borderline cases = true
				{0, 11, 0, -1, 0, 10, 0, 0},
				{-1, 10, 1, 0, 0, 10, 9, 10},
				{0, 0, 1, 0, 0, 0, 10, 0},
				// behind us case
				{5, 11, 0, 1, 5, 0, 5, 10},
				// outside totally
				{5, 11, 1, 0, 69, 69, 69, 69},
				{-1, 1, 0, 1, 69, 69, 69, 69},
				{15, 0, 0, 1, 15,5, 15, 5},
				{15.01, 0, 0, 1, 69, 69, 69, 69},
		};
		
		Pair<FlatPoint,FlatPoint> res ;
		int count = -1;
		for (double[] t: test)
		{
			count++;
			res = null;/*clip(new Pair<Tuple2d, Tuple2d>(
					new FlatPoint(t[0],t[1]),
					new FlatPoint(t[2],t[3])),
					sh);*/
			
			if (res != null)
			{
				//System.err.println("result is "+res.first()+" to "+res.second());
				//assertTrue(count+") first point "+res.first(),notFarFrom(res.first(),new Vector2d(t[4],t[5])));
				//assertTrue(count+") second point "+res.second(),notFarFrom(res.second(),new Vector2d(t[6],t[7])));

			}
			else
			{
				//assertTrue(count+" ) null when it shouldn't be",t[4] == 69);
				//System.err.println(count+") result is null");
			}
		}
	}
	
	double[][] dataBisec =
	{
			{0,0, 1,0, 0.5,0, 0,-1},
			{1,0, 0,0, 0.5,0, 0,1},
			{0,0, 1,1, 0.5,0.5,  Math.sqrt(2)/2,-Math.sqrt(2)/2},
			{1,1, 0,0, 0.5,0.5, -Math.sqrt(2)/2, Math.sqrt(2)/2},
			{100,100, 100,110, 100,105, 1,0},
			};
	
	public void testBisectorOfPoints()
	{
		int count = 0;
		for (double[] d: dataBisec)
		{
			Pair<Tuple2d, Tuple2d> res = bisectorOfPoints(new Vector2d(d[0],d[1]), new Vector2d(d[2],d[3]));
			assertTrue(count+" location wrong " + res.first (), notFarFrom(res.first(), new Vector2d(d[4],d[5])));
			assertTrue(count+" angle    wrong " + res.second(), notFarFrom(res.second(), new Vector2d(d[6],d[7])));
			count++;
		}
	}
	
	private boolean notFarFrom(Tuple2d a, Tuple2d b)
	{
		if (a == null && b.x == 69) return true;
		if (b == null && a.x == 69) return true;
		
		double x = a.x - b.x;
		double y = a.y - b.y;
		double dist = Math.sqrt(x*x+y*y);
		if (dist < 0.00000001) return true;
		return false;
	}
	
	public void testPointBetweenPoints()
	{
		Vector2d a = new Vector2d(10,10);
		Vector2d b = new Vector2d(0,0);
		Vector2d c = new Vector2d(-1,-1);
		Vector2d d = new Vector2d(5,5);
		Vector2d e = new Vector2d(100,100);
		
		assertTrue(pointBetweenPoints(b,a,d));
		assertTrue(pointBetweenPoints(a,b,d));
		assertTrue(pointBetweenPoints(c,e,b));
		assertTrue(pointBetweenPoints(c,e,a));
		assertTrue(pointBetweenPoints(e,c,b));
		assertFalse(pointBetweenPoints(b,a,c));
		assertFalse(pointBetweenPoints(b,a,e));
		// include end points
		assertTrue(pointBetweenPoints(b,a,b));
		assertTrue(pointBetweenPoints(b,a,a));
		// point lines
		assertTrue(pointBetweenPoints(a,a,a));
		assertFalse(pointBetweenPoints(e,e,d));
	}
	
	public void testPointIn()
	{
		List<FlatPoint> data = new Vector<FlatPoint>();

		double info[][] = { { 0, 0 }, { 0.0, 0.5 }, { 0.5, 0.5 }, { 0.5, 0.0 } };

		for (int i = 0; i < info.length; i++)
			data.add(new FlatPoint(info[i][0], info[i][1]));

		
		assertTrue(pointIn(new FlatPoint(0.01, 0.01), data));
		assertFalse(pointIn(new FlatPoint(-0.1, -0.1), data));
		assertFalse(pointIn(new FlatPoint(1, 1), data));
		assertFalse(pointIn(new FlatPoint(-1, 1), data));
		assertFalse(pointIn(new FlatPoint(1, -1), data));
		// borderlines are true!
		assertTrue(pointIn(new FlatPoint(0.25, 0.5 ), data)); 
		assertTrue(pointIn(new FlatPoint(0.25, 0.0 ), data));
		assertTrue(pointIn(new FlatPoint(0.0 , 0.25), data));
		assertTrue(pointIn(new FlatPoint(0.5 , 0.25), data));
		// corners are true!
		assertTrue(pointIn(new FlatPoint(0.5, 0.5 ), data));
		assertTrue(pointIn(new FlatPoint(0.0, 0.5 ), data));
		assertTrue(pointIn(new FlatPoint(0.5, 0.0 ), data));
		assertTrue(pointIn(new FlatPoint(0.0, 0.0 ), data));
	}

	/**
	 * Castle turrets shape
	 *
	 */
	public void testPointInThree()
	{
		List<FlatPoint> data = new Vector<FlatPoint>();

		double info[][] = { { 0, 0 }, { 0.0, 0.5 }, { 0.2, 0.5 }, { 0.2, 0.2 }
		 ,{0.4,0.2},{0.4,0.5},{0.6,0.5},{0.6,0}};

		for (int i = 0; i < info.length; i++)
			data.add(new FlatPoint(info[i][0], info[i][1]));

		assertTrue(pointIn(new FlatPoint(0.1, 0.5), data));
		assertFalse(pointIn(new FlatPoint(0.3, 0.5), data));
		assertTrue(pointIn(new FlatPoint(0.5, 0.5), data));
	}
	
	public void testPointInTwo()
	{
		List<FlatPoint> data = new Vector<FlatPoint>();

		double info[][] = { {0.7071067811865475, 0.5},
				{0.0, 0.0},
				{0.0, 3.0}};

		for (int i = 0; i < info.length; i++)
			data.add(new FlatPoint(info[i][0], info[i][1]));

		assertTrue(pointIn(new FlatPoint(0.03199614210294678, 1.5), data));
		assertFalse(pointIn(new FlatPoint(-0.000001, 1.5), data));
		assertTrue(pointIn(new FlatPoint(0.000001, 1.5), data));
		//assertFalse(pointIn(new FlatPoint(-0.1, -0.1), data));
		//assertFalse(pointIn(new FlatPoint(0.5, 0.5), data)); // boderline ==
																// flase?
	}
	
	public void testPointInFour()
	{
		List<FlatPoint> data = new Vector<FlatPoint>();

		double info[][] = { 
				{2.5662309739306535, -4.440892098500626E-16}, 
				{0.0, 0.0}, 
				{5.551115123125783E-17, 6.040475085026688}, 
				{5.234407980001, 6.4897019912968705}};

		for (int i = 0; i < info.length; i++)
			data.add(new FlatPoint(info[i][0], info[i][1]));

		assertFalse(pointIn(new FlatPoint(8.51204780803927, 6.995097354851259), data));
	}
	
	public void testOnLeft()
	{
		Vector2d o = new Vector2d (0,0);
		Vector2d f = new Vector2d(0,1);
		assertTrue (onLeftOf(o,f,new Vector2d(-1,1)));
		assertTrue (onLeftOf(o,f,new Vector2d( 0,1)));
		assertFalse(onLeftOf(o,f,new Vector2d( 1,1)));
		
		assertTrue (onRightOf(o,f,new Vector2d( 1,1)));
		assertTrue (onRightOf(o,f,new Vector2d( 0,1)));
		assertFalse(onRightOf(o,f,new Vector2d(-1,1)));
		
		o = new Vector2d (0,0);
		f = new Vector2d(-1,0);
		assertFalse (onLeftOf(o,f,new Vector2d(-1,1)));
		assertFalse (onRightOf(o,f,new Vector2d(-1,-1)));
		
		o = new Vector2d (0,0);
		f = new Vector2d (1,0);
		assertFalse (onLeftOf (o,f,new Vector2d( 1,-1)));
		assertFalse (onRightOf(o,f,new Vector2d( 1, 1)));
	}
	
	/**
	 * The concave area finding function
	 *
	 */
	public void testNewArea()
	{
		double[][] data = {
				{1,0},
				{1,2},
				{0,2},
				{0,3},
				{3,3},
				{3,2},
				{2,2},
				{2,0}
		};
		List<FlatPoint> l = new ArrayList<FlatPoint>();
		for (double[] d: data)
			l.add(new FlatPoint(d[0],d[1]));
		double res = Vec2d.findArea(l);
		assertTrue(Math.abs(res-5) < 10E-10);
	}

	public void testNewArea2()
	{
		double[][] data = {
				{3,3},
				{3,2},
				{2,2},
				{2,1},
				{3,1},
				{3,0},
				{0,0},
				{0,3},
		};
		List<FlatPoint> l = new ArrayList<FlatPoint>();
		for (double[] d: data)
			l.add(new FlatPoint(d[0],d[1]));
		double res = Vec2d.findArea(l);
		assertTrue(Math.abs(res-8) < 10E-10);
	}
}
