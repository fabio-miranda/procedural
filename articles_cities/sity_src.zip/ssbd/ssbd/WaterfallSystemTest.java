package ssbd;

import static sity.Parameters.setupParameters;
import geom.FlatPoint;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.vecmath.Matrix4d;
import javax.vecmath.Vector3d;

import junit.framework.TestCase;

public class WaterfallSystemTest extends TestCase
{
	public void testMakeHouse()
	{
		setupParameters();
		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(0, 0, 0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));
		fp.add(new FlatPoint(1, 1));
		fp.add(new FlatPoint(0, 1)); 
		// sheet is now a unit sqare in the 1st quadrant clockwise manner!
		//Sheaf s2 = new Sheaf(fp, mat);
		
		Root root = new Root(null);
		
		Plot plot= new Plot(root);
		root.cityPlanner.addWaterfall(plot,1.00);

		FloorPlan floorPlan = new FloorPlan(plot);
		plot.floorPlan.addWaterfall(floorPlan,1.0);

/*		SimpleRoof roof = new SimpleRoof(floorPlan);
		floorPlan.roof.addWaterfall(roof,1.0);
		roof.nextRoof.addWaterfall(roof,1.0);
		
		WallsFromFloor wff = new WallsFromFloor(floorPlan);
		floorPlan.wallMaker.addWaterfall(wff);
		
		Wall wall = new Wall(wff);
		wff.wall.addWaterfall(wall);*/
		
		// freeze from the root 8)
		FREEZER_Root.bigFreeze(root, new Random());
	}
}
