package ssbd;

import sity.*;
import util.*;

public class Doodow extends Waterfall
{
	public ProbDouble VAR_topHeight = new ProbDouble(0,Double.MAX_VALUE,0,1);
	public String       DEF_topHeight = "proportional size of the top section";
	
	public ProbDouble VAR_middleHeight = new ProbDouble(0,Double.MAX_VALUE,0.5,1);
	public String       DEF_middleHeight = "proportional size of the middle section";
	
	public ProbDouble VAR_bottomHeight = new ProbDouble(0,Double.MAX_VALUE,0,0.2);
	public String       DEF_bottomHeight = "proportional size of the bottom section";
	
	public ProbDouble VAR_ratio = new ProbDouble(0.01,100,2,3);
	public String       DEF_ratio= "how tall this whole section is";
	
	public ProbBoolean  VAR_flatTop   = new ProbBoolean(0);
	public String       DEF_flatTop   = "Does the roof terminate in a flat area";

	public SluiceManual topShape = new SluiceManual(NOISE_Line.class,"window shape at top, leave empty for straight",this);
	public SluiceManual bottomShape = new SluiceManual(NOISE_Line.class,"window shape at base, leave empty for straight",this);
	
	public Doodow(Waterfall parent)
	{	
		super(parent);
	}
}
