package ssbd;

import sity.*;
import util.*;

public class DotGrid extends Waterfall
{
	public MyChoice VAR_dotStyle = new MyChoice("regular", "random");
	public String DEF_dotStyle = "distribution style of the points";
	
	public ProbInt VAR_width = new ProbInt(1, 1000, 2, 20);
	public String DEF_width = "number of dots in row";
	
	public ProbInt VAR_height = new ProbInt(1, 1000, 2, 10);
	public String DEF_height = "number of dots in column";
	
	public DotGrid(Waterfall parent)
	{
		super(parent);
	}
}
