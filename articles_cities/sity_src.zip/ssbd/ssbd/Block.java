package ssbd;

import sity.*;
import util.*;

public class Block extends Waterfall
{
	public ProbDouble VAR_minBuildingArea = new ProbDouble(0,Double.MAX_VALUE,10,20);
	public String DEF_minBuildingArea = "how small, small plots must be before being merged into neighbouring plots?";
	
	//public SluiceManual points = new SluiceManual(NOISE_Subdiv.class,"block layout",this);
	public SluiceManual plot = new SluiceManual(NOISE_Plot.class,"plot",this);
	public SluiceManual streets = new SluiceManual(NOISE_Street.class,"Street Generator",this);
	
	public Block(Waterfall parent)
	{
		super(parent);
	}
}
