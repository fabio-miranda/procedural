package ssbd;

import sity.*;
import util.ProbDouble;

public class OverHang extends Waterfall
{
	public ProbDouble VAR_hangFront= new ProbDouble(0.01,Double.MAX_VALUE,0.1,0.1);
	public String     DEF_hangFront = "How much roof overhang at the front";
	
	public ProbDouble VAR_hangSides= new ProbDouble(0.01,Double.MAX_VALUE,0.1,0.1);
	public String     DEF_hangSides = "How much roof overhang at the side";
	
	public ProbDouble VAR_hangBack = new ProbDouble(0.01,Double.MAX_VALUE,0.1,0.1);
	public String     DEF_hangBack = "How much roof overhang at the back";
	
	public ProbDouble VAR_hangDown = new ProbDouble(0.00,Double.MAX_VALUE,0.1,0.1);
	public String     DEF_hangDown = "How far the roof is dropped down around the house - use with caution!";
	
	
	public SluiceManual gables = new SluiceManual(NOISE_Panel.class,"What is used on gabled roof sections",this);
	public SluiceManual other = new SluiceManual(NOISE_Panel.class,"What is used on non-gabled roof secitons",this);
	//public SluiceManual roof = new SluiceManual(NOISE_SheafChange.class,"What goes on top",this);
	
	public OverHang(Waterfall parent)
	{
		super(parent);
	}
}
