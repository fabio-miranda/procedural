package ssbd;

import sity.*;
import util.*;

public class Plot extends Waterfall
{
	public ProbDouble VAR_streetFrontage = new ProbDouble(0.5, Double.MAX_VALUE, 2,10);
	public String DEF_streetFrontage = "How much space each house would like on the street!";

	public ProbDouble VAR_spaceOnStreet = new ProbDouble(0.0, Double.MAX_VALUE, 0.3,1);
	public String DEF_spaceOnStreet = "how much space a house is given on sides next to the street";
	
	public ProbDouble VAR_spaceAtFront = new ProbDouble(0.0, Double.MAX_VALUE, 0.0,0);
	public String DEF_spaceAtFront = "How much extra space to add only on the one front of the house";
	
	public ProbDouble VAR_borderSize = new ProbDouble(0.0, Double.MAX_VALUE, 0.0,0.0);
	public String DEF_borderSize = "How much space at sides and back of house?";
	
	public ProbDouble VAR_houseDepth = new ProbDouble(0.1, Double.MAX_VALUE, 1,5);
	public String DEF_houseDepth = "How Deep is the house (rest is 'garden')?";

	// walls really should have their own freezer, but for now....
	public ProbBoolean VAR_sideBackWall = new ProbBoolean(1.0);
	public String DEF_sideBackWall = "chance of a wall at sides and back of house";

	public ProbBoolean VAR_frontWall = new ProbBoolean(1.0);
	public String DEF_frontWall = "Chance of a wall at the front of the house";
		
	public ProbDouble VAR_wallWidth = new ProbDouble(0.01, Double.MAX_VALUE, 0.1,0.2);
	public String DEF_wallWidth = "What is the depth of the garden wall?";

	public ProbDouble VAR_wallGap = new ProbDouble(0.1, Double.MAX_VALUE, 0.2,1);
	public String DEF_wallGap = "How big a gap to leave for front door?";
	
	public SluiceManual floorPlan = new SluiceManual(NOISE_Subdiv.class,"Floor Plan",this);
	public SluiceManual sideFence  = new SluiceManual(NOISE_Subdiv.class,"Side and Back Fence",this);
	public SluiceManual frontFence = new SluiceManual(NOISE_Subdiv.class,"Front Fence",this);
	
	public Plot(Waterfall parent)
	{
		super(parent);
	}
}
