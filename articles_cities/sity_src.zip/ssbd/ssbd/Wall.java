package ssbd;

import sity.*;

/** This is a simple wall!
 * 
 * @author people
 *
 */

public class Wall extends Waterfall
{
	public Wall(Waterfall parent)
	{
		super(parent);
	}
}
