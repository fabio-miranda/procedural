package ssbd;

/** This is the superinterface of all nosies. Noises determine the type of
 *  waterfall chaining that is permitted. Eg: a noise is the type of the
 *  output plug.
 * 
 * @author tomkelly
 *
 */
public interface NOISE_Core
{

}
