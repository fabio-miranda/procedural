package ssbd;

import sity.*;
import util.*;

public class FlatRoof extends Waterfall
{
	public ProbBoolean VAR_wall= new ProbBoolean(0.5);
	public String      DEF_wall = "chance of having a wall";
	
	public ProbDouble VAR_wallDepth = new ProbDouble(0.01,1000,0.1,0.1);
	public String     DEF_wallDepth = "how deep is the wall";
	
	//public SluiceManual nextTop = new SluiceManual(NOISE_Subdiv.class,"What goes on top?",this);
	public SluiceManual topWall = new SluiceManual(NOISE_Subdiv.class,"Wall on Roof",this);
	
	public FlatRoof(Waterfall parent)
	{
		super(parent);
	}
}
