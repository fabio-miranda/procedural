package ssbd;

import sity.*;
import util.*;
import util.ProbDouble;

/**
 * creates walls from a specified wallplan
 * @author people
 *
 */
public class Fence extends Waterfall
{
	public ProbDouble VAR_fenceHeight = new ProbDouble(0.01, Double.MAX_VALUE, 0.5,1.5);
	public String DEF_fenceHeight = "How tall is the fence?";
	
	// not implemented yet:
	/*public ProbBoolean VAR_pointTop = new ProbBoolean(0.0);
	public String DEF_pointTop = "Chance of the wall having a pointed top";
	
	public ProbDouble VAR_pointAngle= new ProbDouble(0.1, 100, 2,1);
	public String DEF_pointAngle = "It we have a pointy top to this fence, how pointy is it?";
	*/
	public Fence(Waterfall parent)
	{
		super(parent);
	}
}
