package ssbd;

import sity.*;
import util.*;

/**
 * This is a line segment that is just a traingle
 * @author people
 *
 */
public class TriangleLine extends Waterfall
{
	private String[] names = {"straight line","triangular","I-shaped"};
	private double[] probs = {1,1,1};
	public ProbChoiceInt VAR_lineType = new ProbChoiceInt(names, probs);
	public String  DEF_lineType = "type of line specified";
	
	public TriangleLine(Waterfall parent)
	{	
		super(parent);
	}
}
