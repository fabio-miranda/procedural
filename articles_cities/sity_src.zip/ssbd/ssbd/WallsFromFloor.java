package ssbd;

import sity.*;

/**
 * creates walls from a specified wallplan
 * @author people
 *
 */
public class WallsFromFloor extends Waterfall
{
	
	public SluiceManual wall = new SluiceManual(NOISE_Core.class,"Wall",this);

	public WallsFromFloor(Waterfall parent)
	{
		super(parent);
	}
}
