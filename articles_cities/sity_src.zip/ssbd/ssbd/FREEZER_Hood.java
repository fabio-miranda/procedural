package ssbd;


import static sity.Parameters.*;
import geom.Sheaf;

import java.util.*;


public class FREEZER_Hood extends FREEZER<Hood> implements NOISE_Hood
{
	Sheaf sheaf;
	public FREEZER_Hood(Hood w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		sheaf= in;
	}
	
	public String getName()
	{
		return basicName+" neightbourhood generator ";
	}
	
	/**
	 * Returns a set of points remresenting the voronoi centres of
	 * the blocks of houses
	 */
	public NOISE_Dot getBlockGenerator()
	{
		return (NOISE_Dot)stochoFreeze(waterfall.points,sheaf);
	}

	List<NOISE_Block> blocks = new ArrayList<NOISE_Block>();
	
	/**
	 * We assume that this is called one for each block
	 */
	public NOISE_Block getNextBlock()
	{
		NOISE_Block block = (NOISE_Block) stochoFreeze(waterfall.block,NULL_SHEAF);
		blocks.add(block);
		return block;
	}
	

	public NOISE_Block getNextBlock(NOISE_Street street)
	{
		NOISE_Block b = getNextBlock();
		b.setStreet(street);
		return b;
	}

	/**
	 * This is then called that same number of times as getNextStreet, 
	 * *in the same order* to specify the shrunk shape of the block
	 */
	public void setNextBlock(Sheaf in)
	{
		// TODO Auto-generated method stub
		
	}
}
