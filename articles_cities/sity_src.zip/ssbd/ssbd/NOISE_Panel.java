package ssbd;

import geom.FlatPoint;
import woof.*;

/**For a panel that is assiated with a wall/roof surface in a house
 * 
 * @author tomkelly
 *
 */
public interface NOISE_Panel extends NOISE_Core
{
	// a description of a woof, and height variables
	public WoofPanel getWoofPanel(double height, int storyCount, FlatPoint point, double storyHeight, WoofBuilder wb);
	public WoofPanel addToWoofPanel(double height, int storyCount, FlatPoint point, double storyHeight, WoofBuilder wb, WoofPanel wp);
}
