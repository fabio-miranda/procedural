package ssbd;

import geom.Sheaf;

public interface NOISE_Plot extends NOISE_Core
{
	public double getFrontage();
	public void setPlot(Sheaf in);
}
