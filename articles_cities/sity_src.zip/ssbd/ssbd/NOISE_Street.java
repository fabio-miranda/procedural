package ssbd;

public interface NOISE_Street extends NOISE_Core
{
	// the width of the street on this side of the road
	public double getWidth();
}
