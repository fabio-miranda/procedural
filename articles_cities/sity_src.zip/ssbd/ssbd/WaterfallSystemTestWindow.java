package ssbd;

import static sity.Parameters.*;
import geom.FlatPoint;

import java.util.*;

import javax.vecmath.*;

import ssbd.*;
import util.ProbInt;

import junit.framework.TestCase;

public class WaterfallSystemTestWindow extends TestCase
{
	public void testMakeHouse()
	{
		setupParameters();
		Matrix4d mat = new Matrix4d();
		mat.setIdentity();
		mat.setTranslation(new Vector3d(0, 0, 0));
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		fp.add(new FlatPoint(0, 0));
		fp.add(new FlatPoint(0, 1));
		fp.add(new FlatPoint(1, 1));
		fp.add(new FlatPoint(0, 1)); 
		// sheet is now a unit sqare in the 1st quadrant clockwise manner!
		//Sheaf s2 = new Sheaf(fp, mat);
		
		Root root = new Root(null);
		
		Doodow dd = new Doodow(root);
		root.cityPlanner.addWaterfall(dd,1.00);
		
		TriangleLine tl = new TriangleLine(dd);
		dd.topShape.addWaterfall(tl,1);
		CurveLine tl2 = new CurveLine(dd);
		dd.topShape.addWaterfall(tl2,1);
		
		// freeze from the root 8)
		FREEZER_Root.bigFreeze(root, new Random());
	}
}
