package ssbd;

import static geom.Sheet.lineBetween01;
import static java.lang.Math.abs;
import static sity.Parameters.*;
import geom.*;

import java.util.*;

public class FREEZER_Doodow extends FREEZER<Doodow> implements NOISE_Core
{
	public FREEZER_Doodow(Doodow w, Random r)
	{
		super(w,r);
	}

	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// height over width ratio
		double desiredRatio = gDouble("ratio");
		Pair<Double,Double> inDimensions = Sheaf.findRectangle(in);

		//System.err.println("found a rectangle"+inDimensions+" ratio "+desiredRatio);
		double realRatio = inDimensions.first() / inDimensions.second();
		double xmin,ymin,xmax,ymax;
		if (desiredRatio == Double.MIN_VALUE || realRatio == desiredRatio)
		{
			// we werent specified a ratio - take it form the incomming sheet.
			xmin = ymin = 0;
			xmax = inDimensions.first();
			ymax = inDimensions.second();
		}
		else
		{
			// we will create this frame in the middle of the area we are given,
			// but first we will shrink our area to the ratio specified to us
			if (realRatio < desiredRatio)
			{
				
				// shrink in sides to desired ratio
				ymin = 0;
				ymax = inDimensions.second();
				double xdist = (ymax - ymin) / desiredRatio;
				xmin = (inDimensions.first()-xdist)/2;
				xmax = inDimensions.first()-(inDimensions.first()-xdist)/2;
			}
			else // realRatio > desiredRatio
			{
				// shrink in top and bottom
				xmin = 0;
				xmax = inDimensions.first();
				
				double ydist = (xmax - xmin) * desiredRatio;
				ymin = (inDimensions.second()-ydist)/2;
				ymax = inDimensions.second()-(inDimensions.second()-ydist)/2;
			}
		}
		//System.err.println("using "+xmin+" "+xmax+" "+ymin+" "+ymax);
		double desiredWidth = xmax - xmin;
		
		// now we create a new sheet by adding points from each of the sides offset by a suitable
		// amount
		NOISE_Line topLine = (NOISE_Line)freezeThis(getNextToFreeze(waterfall.topShape),in);
		NOISE_Line bottomLine = (NOISE_Line)freezeThis(getNextToFreeze(waterfall.bottomShape),in);
		
		// the two dividing heights for feature distinction, others are 0 at bottom and ymax-ymin at top
		double topHeight = gDouble("topHeight");
		double middleHeight = gDouble("middleHeight");
		double bottomHeight =  gDouble("bottomHeight");
		// we only use the figures as cumulative measures over their total
		double totalHeight = topHeight+middleHeight+bottomHeight;
		// check for the height being 0- top mid and bot == 0
		if (totalHeight == 0) 
			{
				middleHeight = 1;
				totalHeight = topHeight+middleHeight+bottomHeight;
			}
		
		double bH =(bottomHeight/totalHeight)*(ymax-ymin)+ymin;
		double tH =((bottomHeight+middleHeight)/totalHeight)*(ymax-ymin)+ymin;
		
		Sheet top    = topLine    == null ? lineBetween01() : 
			topLine   .getLine(xmax-xmin,(ymax-ymin)*topHeight/totalHeight); 
		Sheet bottom = bottomLine == null ? lineBetween01() : 
			bottomLine.getLine(xmax-xmin,(ymax-ymin)*bottomHeight/totalHeight);
		
		double topLineY = top.getMaxY()- top.getMinY();
		double topLineX = top.getMaxX()- top.getMinX();
		double botLineY = bottom.getMaxY()- bottom.getMinY();
		double botLineX = bottom.getMaxX()- bottom.getMinX();
		
		// recalculate ratios if we are given a flat shape
		if (abs(topLineY) < 0.0000000001) topHeight = 0;
		if (abs(botLineY) < 0.0000000001) bottomHeight = 0;
		totalHeight = topHeight+middleHeight+bottomHeight;
		bH =(bottomHeight/totalHeight)*(ymax-ymin)+ymin;
		tH =((bottomHeight+middleHeight)/totalHeight)*(ymax-ymin)+ymin;
		
		//System.err.println("top height is"+topHeight+" bh: "+bH);
		//System.err.println("middle height is"+middleHeight+" th "+tH);
		//System.err.println("bot height is"+bottomHeight);
		
		double topYScale = (topHeight*(ymax-ymin)/totalHeight)/topLineY; 
		if (Double.isNaN(topYScale)) topYScale = 1;
		double botYScale = bottomHeight*(ymax-ymin)/totalHeight*botLineY;
		if (Double.isNaN(botYScale)) botYScale = 1;

		//System.err.println("top scale y"+topYScale);
		//System.err.println("bot scale y"+botYScale);
		
		// to find x scale we find the scale factor for the largest (top or bottom
		// then apply it to both
		double topXScale = desiredWidth/topLineX;
		double botXScale = desiredWidth/botLineX;
		
		//System.err.println("topbot scale x"+topXScale+" "+botXScale);
		
		double topXOffset;
		double botXOffset;

		if (topXScale < botXScale) 
		{
			// the top one is bigger scale bottom by this
			botXScale = topXScale;
			topXOffset = (-top.getMinX())*topXScale;
			botXOffset = (-top.getMinX())*topXScale;
		}
		else
		{
			// bottom one is bigger
			topXScale = botXScale;
			topXOffset = (-bottom.getMinX())*botXScale;
			botXOffset = (-bottom.getMinX())*botXScale;
		}
		
		//System.err.println("top scalex is "+topXScale);
		//System.err.println("    scaley is "+topYScale);

		
		//now scale the two lines, noting to scale the bottom by a negative amount in Y
		top   .scale(topXScale,  topYScale);
		bottom.scale(botXScale, -botYScale);
		
		// now move the top and bottom to their respective location
		top.move(xmin+topXOffset, tH);
		bottom.move(xmin+botXOffset, bH);

		// finally we join the top and the bottom together into a new sheet
		List<FlatPoint> fp = new Vector<FlatPoint>(4);
		top.addPointsTo(fp, EdgeType.TOP);
		bottom.addPointsBackwardsTo(fp, EdgeType.BOTTOM);
		
		/*
		System.err.println("spewing out "+fp.size()+" points");
		Iterator<FlatPoint>fir = fp.iterator();
		while (fir.hasNext())
			System.err.println(">>>=="+fir.next());
			*/
		
		Sheaf out = new Sheaf(fp,in.getTransform());
		anchor.createPolygon(out.getFace());
	}
	

	public String getName()
	{
		return basicName+" Outline of a hole - a door or window";
	}
}
