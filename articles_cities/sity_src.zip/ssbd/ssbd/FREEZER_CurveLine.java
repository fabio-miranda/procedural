package ssbd;

import geom.Circle;
import geom.FlatPoint;
import geom.Sheaf;
import geom.Sheet;

import java.util.List;
import java.util.Random;


public class FREEZER_CurveLine extends FREEZER<CurveLine> implements NOISE_Line
{
	public FREEZER_CurveLine(CurveLine w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// do nothing!
	}
	
	/**
	 * returns a line curved as specified
	 */
	public Sheet getLine(double width, double h2)
	{
		// base must be 0..1 along x, so scale y accordingly
		double height = h2/width;
		double size = gDouble("featureSize");
		double line = gDouble("lineResolution");
		Sheet output= null;
		FlatPoint a,b,c;
		System.err.println("line type is"+gInt("lineType"));
		switch(gInt("lineType"))
		{
		case 0:
		{
			a = new FlatPoint(0,0);
			c = new FlatPoint(1,0);
			b = new FlatPoint(0.5, size*3);
			if (size == 0)
		    b = new FlatPoint(0.5, size*3+0.1);
			Circle ci = new Circle(a,b,c);
			output = new Sheet(ci.getClockwiseBetween(a,c,line,true));
			break;
		}
		case 1:
		{
			a = new FlatPoint(0,0);
			c = new FlatPoint(0.5,height);
			b = new FlatPoint(0,height/20);
			Circle ci = new Circle(a,b,c);
			List<FlatPoint> lfp = ci.getClockwiseBetween(a,c,line,false);
			a = new FlatPoint(0.5,height);
			c = new FlatPoint(1,0);
			b = new FlatPoint(1,height/20);
			ci = new Circle(a,b,c);
			lfp.addAll(ci.getClockwiseBetween(a,c,line,true));
			output = new Sheet(lfp);
			break;
		}
		case 2:
		{
			a = new FlatPoint(0,0);
			c = new FlatPoint(0.5,height);
			b = new FlatPoint(-size+0.5,size);
			Circle ci = new Circle(a,b,c);
			List<FlatPoint> lfp = ci.getClockwiseBetween(a,c,line,false);
			a = new FlatPoint(0.5,height);
			c = new FlatPoint(1,0);
			b = new FlatPoint(size+0.5,size);
			ci = new Circle(a,b,c);
			lfp.addAll(ci.getClockwiseBetween(a,c,line,true));
			output = new Sheet(lfp);
			break;
		}
		}
		return output;
	}
	
	public String getName()
	{
		return basicName+"Its me, curve line!";
	}
}
