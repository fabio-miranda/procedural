package ssbd;

import sity.*;
import util.*;

public class CityPlanner extends Waterfall
{
	public MyDouble VAR_mergeSmallBlocks = new MyDouble(10.);
	public String DEF_mergeSmallBlocks = "area at which blocks are merged into adjoining blocks";
	
	public ProbDouble VAR_bombed = new ProbDouble(0,1,0.5,0.1);
	public String DEF_bombed = "probability of blocks being merged together, citywide";
	
	public SluiceManual hood = new SluiceManual(NOISE_Hood.class,"Neighbour-hood generators",this);
	public SluiceManual points = new SluiceManual(NOISE_Dot.class,"Neighbourhood space generators",this);	
		
	public CityPlanner(Waterfall parent)
	{
		super(parent);
	}
}
