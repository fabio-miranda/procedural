package ssbd;

import static sity.Parameters.anchor;
import geom.*;

import java.util.*;

import util.*;

/**
 * wall of the house!
 * @author people
 *
 */
public class FREEZER_WallsFromFloor extends FREEZER<WallsFromFloor> implements NOISE_Core
{
	public FREEZER_WallsFromFloor(WallsFromFloor w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		double height = gInt("numberStories")*gDouble("story");
		Iterator<Sheet> it = in.getSheets().iterator();
		while (it.hasNext())
		{
			CEFPIterator ce = new CEFPIterator(it.next().getFirst());
			
			while (ce.hasNext())
			{
				CEFP c = ce.next();
				FlatPoint start = c.thing;
				FlatPoint end   = c.next.thing;
				SheetBuilder sb = new SheetBuilder(in);
				sb.addPoint(start.x,start.y,0);
				sb.addPoint(end.x,end.y,0);
				sb.addPoint(end.x,end.y,height);
				sb.addPoint(start.x,start.y,height);
				Sheaf out = sb.makeSheaf();
				stochoFreeze(waterfall.wall, sb.makeSheaf());
			}
			
		}
		//floor ?
		//anchor.createPolygon(in.getFace());
	}
	
	public String getName()
	{
		return basicName+"I am a wall";
	}
}
