package ssbd;

import sity.*;
import sity.Waterfall;
import util.*;

/** This is a simple wall!
 * 
 * @author people
 *
 */

public class SlopeInRoof extends Waterfall
{
	public ProbDouble VAR_steepnessOne = new ProbDouble(0.1,100,0,1);
	public String     DEF_steepnessOne = "how steep is first gradient section of roof";
	
	public ProbDouble VAR_steepnessTwo = new ProbDouble(-100,100,0.0,2);
	public String     DEF_steepnessTwo = "how steep is second gradient section of roof";
	
	public ProbDouble VAR_height = new ProbDouble(0.1,100,0,2);
	public String     DEF_height = "how high before transition to next gradient";

	public MyDouble VAR_steepnessOneMin = new MyDouble (0.1);
	public String   DEF_steepnessOneMin = "min Steepness of first allowable";
	
	public MyDouble VAR_steepnessTwoMin = new MyDouble (0.0);
	public String   DEF_steepnessTwoMin = "min Steepness of second allowable";
	
	public SlopeInRoof(Waterfall parent)
	{
		super(parent);
	}
}
