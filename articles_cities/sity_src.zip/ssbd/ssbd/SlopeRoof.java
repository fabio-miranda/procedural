package ssbd;

import sity.*;
import sity.Waterfall;
import util.*;

/** This is a simple wall!
 * 
 * @author people
 *
 */

public class SlopeRoof extends Waterfall
{
	public ProbDouble VAR_steepness = new ProbDouble(0.1,100,0.2,0);
	public String     DEF_steepness = "how steep is roof";

	public MyDouble VAR_steepnessMin = new MyDouble (0.4);
	public String   DEF_steepnessMin = "min Steepness allowable";
	
	public SlopeRoof(Waterfall parent)
	{
		super(parent);
	}
}
