package ssbd;

import static java.lang.Math.*;
import geom.*;

import java.util.*;

import sity.Parameters;
import skyHook.AnchorStatics;
import util.CEFPIterator;


public class FREEZER_DotGrid extends FREEZER<DotGrid> implements NOISE_Dot
{
	Sheaf sheaf = null;
	private static final boolean DEBUG = false;
	
	public FREEZER_DotGrid(DotGrid w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		sheaf = in;
	}
	
	public int dotStyle;
	public int width, height;
	
	public List<FlatPoint> getPoint()
	{
		// find the rectuangular bounds of the input sheaf
		findBounds();
		switch (dotStyle)
		{
		// spiral
		case 0:
			return regular();
		// circular
		case 1:
			return random();
		}
		
		return null;
	}
	
	private List<FlatPoint> random()
	{
			int count = 0;
			int tries = 0;
			List<FlatPoint> out = new ArrayList<FlatPoint>();
			while (count < (width * height) && tries < 1000)
			{
				Double x = minX+random.nextDouble()*maxX-minX;
				Double y = minY+random.nextDouble()*maxY-minY;
				FlatPoint f = new FlatPoint(x,y);
				if (isInRectangle(f) && isInSheaf(f))
				{
					out.add(f);
					tries = 0;
				}
				else
				{
					tries ++;
				}
				count++;
			}
			if (DEBUG) FREEZER_Dot.dumpPoints(out);
			return out;
	}
	
	private List<FlatPoint> regular()
	{
		int count = 0;
		List<FlatPoint> out = new ArrayList<FlatPoint>();
		
		// +1 for an airgap!
		double resX = (maxX-minX)/(width+1);
		double resY = (maxY-minY)/(height+1);
		
		for (double x = minX; x < maxX; x+= resX)
		{
			for (double y = minY; y < maxY; y+= resY)
			{
				FlatPoint f = new FlatPoint(x,y);
				if (isInRectangle(f) && isInSheaf(f))
					out.add(f);
			}	
		}
		
		if (DEBUG) FREEZER_Dot.dumpPoints(out);	
		return out;
	}
	
	double minX, minY;
	double maxX, maxY;
	double diagonal;
	
	/**
	 * round the given sheet to a rectangle... lazy tom
	 *
	 */
	private void findBounds()
	{
		minX =  Double.MAX_VALUE;
		minY =  Double.MAX_VALUE;
		maxX = -Double.MAX_VALUE;
		maxY = -Double.MAX_VALUE;
		
		for (Sheet s: sheaf.getSheets())
		{
			CEFPIterator cit = s.iterator();
			while (cit.hasNext())
			{
				FlatPoint f = cit.next().thing;
				if (f.x < minX) minX = f.x; 
				if (f.y < minY) minY = f.y;
				if (f.x > maxX) maxX = f.x;
				if (f.y > maxY) maxY = f.y;
			}
		}
		//System.err.println("goin in");
		assert(
				minX !=  Double.MAX_VALUE && 
				minY !=  Double.MAX_VALUE && 
				maxX != -Double.MAX_VALUE && 
				maxY != -Double.MAX_VALUE);
		double xdist = maxX-minX;
		double ydist = maxY-minY;
		diagonal = Math.sqrt(xdist*xdist+ydist*ydist);
	}
	
	/**
	 * Is this point in the rectangle defined by findbounds?
	 */
	private boolean isInRectangle(FlatPoint f)
	{
		if (f.x < minX) return false;
		if (f.y < minY) return false;
		if (f.x > maxX) return false;
		if (f.y > maxY) return false;
		return true;
	}
	
	/**
	 * Returns true of the specified point is really in the sheaf
	 * @param f
	 * @return
	 */
	private boolean isInSheaf(FlatPoint f)
	{
		if (sheaf.getSheets().size() > 1) Parameters.fatalErrorSD("dot not working on shapes with holes!");
		List<FlatPoint> lfp= new ArrayList<FlatPoint>();
		CEFPIterator cit = sheaf.getMain().iterator();
		while(cit.hasNext()) lfp.add(cit.next().thing);
		return Vec2d.pointIn(f, lfp);
	}
}
