package ssbd;

import geom.*;

import java.util.*;

import sity.Parameters;

import woof.*;

public class FREEZER_SlopeRoof extends FREEZER<SlopeRoof> implements NOISE_Panel
{
	public double steepness;

	public double steepnessMin;
	
	public FREEZER_SlopeRoof(SlopeRoof w, Random r)
	{
		super(w, r);
	}

	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// nothing to do here, just get created!
	}

	public String getName()
	{
		return basicName + " I am a very simple roof";
	}

	// approximations of horizontal....
	private final static double small = 10E-3;

	public WoofPanel getWoofPanel(double startHeight, int storyCount, FlatPoint point, double storyHeight, WoofBuilder wb)
	{
		WoofPanel dw = new DullRoof(wb, point, Math.max(steepness, steepnessMin),startHeight);
		return addToWoofPanel(startHeight, storyCount, point, storyHeight, wb, dw);
	}

	public WoofPanel addToWoofPanel(double startHeight, int storyCount, FlatPoint point, double storyHeight, WoofBuilder wb, WoofPanel dw)
	{
	    // no carry on, so nothing to do...
		return dw;
	}

}
