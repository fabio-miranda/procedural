package ssbd;

import static geom.Sheet.lineBetween01;
import static java.lang.Math.abs;
import static sity.Parameters.*;
import geom.*;

import java.util.*;

/**
 * Some simple linear constructs for the top of a window or door
 * @author people
 *
 */
public class FREEZER_TriangleLine extends FREEZER<TriangleLine> implements NOISE_Line
{
	public FREEZER_TriangleLine(TriangleLine w, Random r)
	{
		super(w, r);
	}

	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// do nothing
	}
	// definintions of structure
	double[][][] data = {
			{{0,0},{1,0}}, // line
			{{0,0},{0.5,1},{1,0}}, // triangle
			{{0,0},{-0.5,0},{-0.5,1},{1.5,1},{1.5,0},{1,0}}}; // archery slit thing
	
	public Sheet getLine(double x, double y)
	{
		List<FlatPoint> fp = new Vector<FlatPoint>();
		int toUse = gInt("lineType");
		for (int i = 0; i < data[toUse].length; i++)
			fp.add(new FlatPoint(data[toUse][i][0],data[toUse][i][1]));
		
		return new Sheet(fp);
	}
	

	public String getName()
	{
		return basicName+" ";
	}
}
