package ssbd;

import geom.Sheaf;


public interface NOISE_Block extends NOISE_Core
{
	public NOISE_Street getStreet();
	public void setSheaf(Sheaf in, boolean concave);
	// if we need to create a block and assign a street this is how we do it
	public void setStreet(NOISE_Street street);
}
