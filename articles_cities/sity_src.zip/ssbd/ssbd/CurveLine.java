package ssbd;

import sity.*;
import util.*;

/**
 * This silly named class represents the top of a doodow that is curved in 
 * a circle in a way specified here
 * @author people
 *
 */
public class CurveLine extends Waterfall
{
	private String[] names = {"domed / circular","arched","bulging"};
	private double[] probs = {1,1,1};

	public ProbChoiceInt VAR_lineType = new ProbChoiceInt(names, probs);
	public String  DEF_lineType = "type of curve specified";

	public Double  VAR_lineResolution = 0.1;
	public String  DEF_lineResolution = "The length of a straight line segment pretending to be a curve";
	
	public ProbDouble VAR_featureSize = new ProbDouble(-1,1, 1, 0);
	public String     DEF_featureSize = "Size of the above selected feature, has no effect on arched";
	
	
	public CurveLine(Waterfall parent)
	{	
		super(parent);
	}
}
