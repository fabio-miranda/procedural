package ssbd;

import sity.*;
import sity.Waterfall;
import util.*;

/** This is a simple wall!
 * 
 * @author people
 *
 */

public class HangWall extends Waterfall
{
	public ProbDouble VAR_depth = new ProbDouble(-1000,1000,0.5,1);
	public String       DEF_depth = "big is the overhang (+ve/-ve)";
	
	public ProbBoolean VAR_everyStory = new ProbBoolean(0.5);
	public String DEF_everyStory = "is there a hang every story (true), or just once after the first story(false)?";

	public ProbDouble VAR_steepness = new ProbDouble(-1000,1000,0.2,0);
	public String       DEF_steepness = "how steep is twall";
	
	public SluiceManual nextMod = new SluiceManual(NOISE_Panel.class,"Optional additional modification to this wall!",this);
	
	public HangWall(Waterfall parent)
	{
		super(parent);
	}
}
