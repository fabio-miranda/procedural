package ssbd;

import sity.*;
import util.*;

public class Dot extends Waterfall
{
	public MyChoice VAR_dotStyle = new MyChoice("spiral", "circular", "square");
	public String DEF_dotStyle = "distribution of the points";
	
	public ProbDouble VAR_width = new ProbDouble(0.5, 1000, 1, 20);
	public String DEF_width = "distance between dots in rows";
	
	public ProbDouble VAR_height = new ProbDouble(0.5, 1000, 1, 5);
	public String DEF_height = "distance between dots in columns (or loop circle/spiral)";
	
	public ProbDouble VAR_chaos = new ProbDouble(0.0, 100, 0, 0);
	public String DEF_chaos = "how much noise is added to the points";
	
	public Dot(Waterfall parent)
	{
		super(parent);
	}
}
