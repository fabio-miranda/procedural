package ssbd;

import geom.*;

import java.util.*;

import cloud.*;


public class FREEZER_PlotFromBlock extends FREEZER<PlotFromBlock> implements NOISE_Subdiv
{
	public FREEZER_PlotFromBlock(PlotFromBlock w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		stochoFreeze(waterfall.plot,in);
	}
	
	public String getName()
	{
		return basicName+" plot generator ";
	}
}
