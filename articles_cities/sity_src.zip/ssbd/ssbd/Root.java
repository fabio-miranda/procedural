package ssbd;

import sity.*;
import util.*;


public class Root extends Waterfall
{
	public MyInt VAR_random_seed = new MyInt(-1695742530);
	//public MyInt VAR_random_seed = new MyInt(-1583897846);
	public String DEF_random_seed = "random seed used to generate model";
	//public ProbInt VAR_scatter = new ProbInt(0,10,5,3);
	//public String DEF_scatter = "changes the root level scattering";
	//public ProbThreeVector VAR_up = new ProbThreeVector(new Vector3d(0,1,0));
	//public String DEF_up = "Definition of up for the system";
	
	public MyDouble VAR_width = new MyDouble(100);
	public String DEF_width   = "how wide is this city east to west?";
	public MyDouble VAR_height= new MyDouble(100);
	public String DEF_height  = "how wide is this city north to south?";
	
	public SluiceManual cityPlanner = new SluiceManual(NOISE_Subdiv.class,"City layout unit",this);
	
	public Root(Waterfall parent)
	{
		super(parent);
	}
}
