package ssbd;

import static sity.Parameters.*;
import geom.*;

import java.util.*;

import cloud.*;


public class FREEZER_Street extends FREEZER<Street> implements NOISE_Street
{
	public double width;
	
	public FREEZER_Street(Street w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		if (in != NULL_SHEAF)
			anchor.createPolygon(in.getFace());
	}

	public double getWidth()
	{
		return width;
	}
	
	public String getName()
	{
		return basicName;
	}
}
