package ssbd;

import sity.Waterfall;

/** This is a simple wall!
 * 
 * @author people
 *
 */

/** The final wall in a wall chain, makes no changes to the speeds!
 * 
 */
public class NullWall extends Waterfall
{

	public NullWall(Waterfall parent)
	{
		super(parent);
	}
}
