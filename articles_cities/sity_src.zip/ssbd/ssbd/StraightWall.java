package ssbd;

import sity.Waterfall;

/** This is a simple wall!
 * 
 * @author people
 *
 */

public class StraightWall extends Waterfall
{
	public StraightWall(Waterfall parent)
	{
		super(parent);
	}
}
