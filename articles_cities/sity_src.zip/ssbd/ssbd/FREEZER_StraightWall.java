package ssbd;

import geom.*;

import java.util.*;

import woof.*;

public class FREEZER_StraightWall extends FREEZER<StraightWall> implements NOISE_Panel
{
	public FREEZER_StraightWall(StraightWall w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// nothing to do here, just get created!
	}
	
	public String getName()
	{
		return basicName+" I am a very simple wall";
	}

	public WoofPanel getWoofPanel(double startHeight,int storyCount, FlatPoint point, double storyHeight, WoofBuilder wb)
	{
		WoofPanel wp = new DullWall(wb,point,storyCount, storyHeight,0);
		return wp;
	}
	
	public WoofPanel addToWoofPanel(
			double startHeight,
			int storyCount, 
			FlatPoint point, 
			double storyHeight, 
			WoofBuilder wb, 
			WoofPanel dw)
	{
		return dw; // we are a flat wall, but not alowed to set inital speed!
	}

}
