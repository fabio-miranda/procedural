package ssbd;

import static sity.Parameters.anchor;
import geom.*;

import java.util.*;

import javax.vecmath.*;

import skeleton.*;
import util.*;

/**
 * wall of the house!
 * @author people
 *
 */
public class FREEZER_Fence extends FREEZER<Fence> implements NOISE_Subdiv
{
	public double  fenceHeight;
	public boolean pointTop;
	public double  pointAngle;
	
	public FREEZER_Fence(Fence w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		Iterator<Sheet> it = in.getSheets().iterator();
		while (it.hasNext())
		{
			CEFPIterator ce = new CEFPIterator(it.next().getFirst());
			
			while (ce.hasNext())
			{
				CEFP c = ce.next();
				FlatPoint start = c.thing;
				FlatPoint end   = c.next.thing;
				SheetBuilder sb = new SheetBuilder(in);
				sb.addPoint(start.x,start.y,0);
				sb.addPoint(end.x,end.y,0);
				sb.addPoint(end.x,end.y,fenceHeight);
				sb.addPoint(start.x,start.y,fenceHeight);
				Sheaf out = sb.makeSheaf();
				anchor.createPolygon(out);
				start.setSpeed(pointAngle);
				//stochoFreeze(waterfall.wall, sb.makeSheaf());
			}
		}
		
		
		Vector3d up = new Vector3d(0,1,0);//Vector3d.class.cast(gOther("up")));
		up.normalize();
		up.scale(fenceHeight);
		Matrix4d m = new Matrix4d(in.getTransform());
		FREEZER_FloorPlan.add(up,m);
		// does this screw in's transform for good?
		in.setTransform(m);
		if (pointTop && false)
		{
			try
			{
				Bones b = new Bones(in, 1.0, false);
				List<Sheaf> sheafses = b.getWoof();
				for (Sheaf s: sheafses) anchor.createPolygon(s);
			}
			catch (BonesSaysNoException e)
			{
				anchor.createPolygon(in);
			}
		}
		else
		{
			anchor.createPolygon(in);
		}
	}
	
	public String getName()
	{
		return basicName+"I am a wall";
	}
}
