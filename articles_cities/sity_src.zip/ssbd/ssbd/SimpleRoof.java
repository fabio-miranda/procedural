package ssbd;

import sity.*;
import util.*;

public class SimpleRoof extends Waterfall
{
	public ProbDouble VAR_steepness = new ProbDouble(0.0001,Double.MAX_VALUE,0.7,1);
	public String       DEF_steepness = "how steep is the roof edge?";
	public ProbBoolean  VAR_flatTop   = new ProbBoolean(0.9);
	public String       DEF_flatTop   = "Does the roof terminate in a flat area";
	public ProbDouble VAR_distToFlat = new ProbDouble(0.1,Double.MAX_VALUE,2,3);
	
	public ProbDouble VAR_areaFlat = new ProbDouble(0,Double.MAX_VALUE,0,2);

	public SluiceManual nextRoof= new SluiceManual(NOISE_Core.class,"Roof to go on this roof",this);
	
	public SimpleRoof(Waterfall parent)
	{
		super(parent);
	}
}
