package ssbd;

import sity.*;
import util.*;


public class FloorPlan extends Waterfall
{
	public ProbDouble VAR_storyHeight = new ProbDouble(0.1,100,0.5,2);
	public String     DEF_storyHeight = "how tall is one story";
	
	public ProbInt VAR_numberStories = new ProbInt(1,Integer.MAX_VALUE, 2, 4);
	public String  DEF_numberStories = "number of stories above this floorplan";
	
	
	public SluiceManual front = new SluiceManual(NOISE_Panel.class,"Front of house appearance", this);
	public SluiceManual side = new SluiceManual(NOISE_Panel.class,"Side of house appearance", this);
	public SluiceManual back = new SluiceManual(NOISE_Panel.class,"Back of house appearance", this);
	
	public SluiceManual onTop = new SluiceManual(NOISE_SheafChange.class,"Roof or shape change of floor plan",this);
	
	public FloorPlan(Waterfall parent)
	{
		super(parent);
	}
}
