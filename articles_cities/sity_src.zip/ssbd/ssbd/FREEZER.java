package ssbd;

import static sity.Parameters.error;
import static sity.Parameters.fatalError;
import static sity.Parameters.fatalErrorSD;
import geom.Sheaf;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Vector;

import sity.FallState;
import sity.SluiceManual;
import sity.Waterfall;
import util.FreezeBoolean;
import util.FreezeDouble;
import util.FreezeInt;
import util.FreezeThreeVector;
import util.LookUp;

/**
 * A lock is a gnerator - it defines the generator used for the next section of the waterfall
 * 
 * @author people
 * 
 */
public abstract class FREEZER<E extends Waterfall> implements NOISE_Core
{
	protected E waterfall;

	protected String basicName = "undefined";

	protected static final Map<Class, Integer> counts = new Hashtable<Class, Integer>();

	protected List<FREEZER> freezes = null;

	private static Waterfall runTimeFreezer = null;

	protected Random random;

	/**
	 * When overridding this, the type taken (E) should be the type of the waterfall that specifies this freezer!
	 * 
	 * @param data
	 */
	public FREEZER(E data, Random r)
	{
		waterfall = data;
		random = r;
		makeUpName();
		instanceVariables();
		setLocalFields();
	}

	/**
	 * Keyboard wear and tear saving method
	 * 
	 * @param in
	 * @return
	 */
	protected Waterfall getNextToFreeze(SluiceManual in)
	{
		return in.getNextToFreeze(random);
	}

	protected static Waterfall egGoal = null;

	protected static FallState fallState = null;

	/**
	 * This is only protected for debugging! it shouldnt really be used
	 * 
	 * @param in
	 *            the shee
	 * @param parents
	 */
	protected NOISE_Core freeze(Sheaf in, List<FREEZER> parents)
	{
		freezes = parents;
		// keep track of whats running now, so we know who makes what output!
		Waterfall tmpFreezer = runTimeFreezer;
		runTimeFreezer = waterfall;
		if (egGoal == waterfall && fallState == null)
		{
			fallState = new FallState(in, parents, waterfall, random, this);
			return null;
		}
		else if (fallState != null)
		{
			return null;
		}
		// do the real hard work!
		doFreeze(in, parents);
		// set output back to parent, in case they make more output!
		runTimeFreezer = tmpFreezer;
		return this;
	}

	/**
	 * keyboard saving function that stochastically freezes one of the choices in sm
	 * 
	 * @param sm
	 * @param sheet
	 * @return
	 */
	public NOISE_Core stochoFreeze(SluiceManual sm, Sheaf sheet)
	{
		Waterfall w = sm.getNextToFreeze(random);
		return freezeThis(w, sheet);
	}

	/**
	 * Freezes another waterfall (probably a sluice from this waterfall!) specifying the given sheet coordinates.
	 * 
	 * @param water
	 *            the Waterfall to instance
	 * @param sheet
	 *            the space that the frozen waterwall is to occupy (an ice-sheet if you will)
	 */
	public NOISE_Core freezeThis(Waterfall water, Sheaf sheet)
	{
		// allows the sluice to return null :)
		if (water == null)
			return null;

		int numParents = 1;
		List<FREEZER> newParents;
		if (freezes != null)
		{
			numParents = freezes.size() + 1;
			newParents = new Vector<FREEZER>(numParents);
			Iterator<FREEZER> it = freezes.iterator();
			while (it.hasNext())
				newParents.add(it.next());
		}
		else
			newParents = new Vector<FREEZER>(numParents);

		newParents.add(this);

		return fallToFreezer(water, random).freeze(sheet, newParents);

	}

	/**
	 * target is the
	 * 
	 * @param target
	 * @return
	 */
	public static FREEZER<? extends Waterfall> fallToFreezer(Waterfall water, Random random)
	{
		Class target = water.getFreezer();
		Object[] args = new Object[] { water, new Random(random.nextLong()) };
		Class[] argTypes = new Class[] { water.getClass(), Random.class };
		Constructor toMake;
		FREEZER<? extends Waterfall> output = null;
		try
		{
			toMake = target.getConstructor(argTypes);
			output = (FREEZER<? extends Waterfall>) createObject(toMake, args);
		}
		catch (NoSuchMethodException e)
		{
			System.err.println("NSME " + e.toString());
			fatalErrorSD("Cant instance " + target.getSimpleName());
			e.printStackTrace();
		}
		catch (Exception e)
		{
			error(e.toString());
			fatalErrorSD("Cant instance " + target.getSimpleName());
		}

		return output;
	}

	/**
	 * Starts the freezing process
	 * 
	 * @param in
	 * @param in
	 */
	public static void freezeSource(Waterfall in)
	{
	}

	/**
	 * Uses the parameters to instantainise this waterfall into a frozen waterfall. Takes a list of parent Freezers for parameters they may require.
	 */
	public abstract void doFreeze(Sheaf in, List<FREEZER> parent);

	/**
	 * Debugging routine that returns the unique name of this frozen part
	 * 
	 * @return
	 */
	public String getName()
	{
		return basicName;
	}

	/**
	 * Assigns to basic name a new name consisting of the name of the class followed by the number of instances this class has
	 */
	private void makeUpName()
	{
		int count = -1;
		if (counts.containsKey(this.getClass()))
		{
			count = counts.get(this.getClass());
			counts.put(this.getClass(), count + 1);
		}
		else
		{
			counts.put(this.getClass(), 0);
			count = 0;
		}
		basicName = this.getClass().getSimpleName() + " # " + count;
	}

	LookUp<Integer> LUInt = new LookUp<Integer>();

	LookUp<Double> LUDouble = new LookUp<Double>();

	LookUp<Boolean> LUBoolean = new LookUp<Boolean>();

	LookUp<Object> LURest = new LookUp<Object>();

	/**
	 * Collects the names of the variables from Waterfall & instances them for this freezer. Uses a lot of ugly casting and reflection code
	 */
	private void instanceVariables()
	{
		// find all variables in the Waterfall
		Class c = waterfall.getClass();
		Field[] publicFields = c.getFields();
		for (int i = 0; i < publicFields.length; i++)
		{
			String fieldName = publicFields[i].getName();
			if (fieldName.startsWith("VAR_"))
			{
				Class typeClass = publicFields[i].getType();
				String name = fieldName.substring(4, fieldName.length());
				try
				{
					if (typeClass == Integer.TYPE || typeClass == Integer.class) // Integer types
					{
						LUInt.add(name, (Integer) publicFields[i].get(waterfall));
					}
					else if (FreezeInt.class.isAssignableFrom(typeClass))
					{
						FreezeInt f = (FreezeInt) publicFields[i].get(waterfall);
						LUInt.add(name, f.freeze(random));
					}
					else if (typeClass == Double.TYPE || typeClass == Double.class) // Double types
					{
						LUDouble.add(name, (Double) publicFields[i].get(waterfall));
					}
					else if (FreezeDouble.class.isAssignableFrom(typeClass))
					{
						FreezeDouble f = (FreezeDouble) publicFields[i].get(waterfall);
						LUDouble.add(name, f.freeze(random));
					}
					else if (typeClass == boolean.class) // Boolean types
					{
						LUBoolean.add(name, (Boolean) publicFields[i].get(waterfall));
					}
					else if (FreezeBoolean.class.isAssignableFrom(typeClass))
					{
						FreezeBoolean f = (FreezeBoolean) publicFields[i].get(waterfall);
						LUBoolean.add(name, f.freeze(random));
					}
					else if (FreezeThreeVector.class.isAssignableFrom(typeClass)) // Rest types
					{
						FreezeThreeVector f = (FreezeThreeVector) publicFields[i].get(waterfall);
						LURest.add(name, f.freeze(random));
					}
					else
					{
						fatalError("FREEZER doesnt know how to deal with a " + typeClass.getSimpleName());
					}
				}
				catch (java.lang.IllegalAccessException e)
				{
					fatalError("Error trying to acess " + typeClass.getSimpleName() + "\n" + e);
				}
			}
		}
	}

	/**
	 * Runs through the hash sets of accumulated values and set sets the local fields in the FREEZER_
	 * 
	 */
	private void setLocalFields()
	{
		try
		{
			Field[] myFields = getClass().getFields();

			LookUp lookup[] = { LUInt, LUDouble, LUBoolean, LURest };
			for (LookUp look : lookup)
				for (Field f : myFields)
				{
					Object l = look.find(f.getName());
					if (l != null)
					{
						f.set(this, l);
					}
				}
		}
		catch (IllegalAccessException e)
		{
			sity.Parameters.fatalErrorSD("which setLocalFields " + e.toString());
		}
	}

	private FREEZER getParent()
	{
		return freezes.get(freezes.size() - 1);
	}

	/**
	 * Returns the parameter with the specified name from the most recently returned freezer.
	 * 
	 * @param name
	 * @return
	 */
	public double gDouble(String name)
	{
		if (!LUDouble.has(name))
		{
			if (freezes.size() != 0)
				return getParent().gDouble(name);
			fatalErrorSD("Requested variable " + name + " not found");
		}
		return LUDouble.find(name);
	}

	/**
	 * Similarly
	 * 
	 * @param name
	 * @return
	 */
	public int gInt(String name)
	{
		if (!LUInt.has(name))
		{
			if (freezes.size() != 0)
				return getParent().gInt(name);
			fatalErrorSD("Requested variable " + name + " not found");
		}
		return LUInt.find(name);
	}

	/**
	 * Similarly
	 * 
	 * @param name
	 * @return
	 */
	public Object gOther(String name)
	{
		if (!LURest.has(name))
		{
			if (freezes.size() != 0)
				return getParent().gOther(name);
			fatalErrorSD("Requested variable " + name + " not found");
		}
		return LURest.find(name);
	}

	/**
	 * Similarly
	 * 
	 * @param name
	 * @return
	 */
	public boolean gBoolean(String name)
	{
		if (!LUBoolean.has(name))
		{
			if (freezes.size() != 0)
				return getParent().gBoolean(name);
			fatalErrorSD("Requested variable " + name + " not found");
		}
		if (!LUBoolean.has(name))
			fatalErrorSD("Requested variable " + name + " not found");
		return LUBoolean.find(name);
	}

	/**
	 * Creates a new object, modified from java.sun tutorial
	 * 
	 * @param constructor
	 * @param arguments
	 * @return
	 */
	public static Object createObject(Constructor constructor, Object[] arguments)
	{
		Object object = null;

		try
		{
			object = constructor.newInstance(arguments);
			return object;
		}
		catch (InvocationTargetException e)
		{
			System.err.println("argulements were "+arguments);
			for (Object o: arguments) System.err.println(">>"+o);
			System.err.println("cunstructor is "+constructor.getName());
			e.getCause().printStackTrace();
			e.printStackTrace();
			fatalErrorSD("error instancing object " );
			/*
			 * for (int i = 0; i < st.length; i++) { System.err.println(" "+st[i].toString()); }
			 */
		}
		catch (Exception e)
		{
			fatalError("unkown error instanceing object: " + e);
		}

		return object;
	}

	/**
	 * 
	 * @return the runTimeFreezer that is currentlyRunning!
	 */
	public static Waterfall getRunTimeFreezer()
	{
		return runTimeFreezer;
	}
}
