package ssbd;

import geom.Sheaf;

import java.util.*;

import woof.*;

public class FREEZER_FlatRoof extends FREEZER<FlatRoof> implements NOISE_SheafChange, DoRoofWall
{

	public boolean wall;
	public double wallDepth;
	
	public FREEZER_FlatRoof(FlatRoof w, Random r)
	{
		super(w,r);
	}
	
	public void markGables(Sheaf in)
	{
		// do nothing... no gables on a flat roof
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// nothing to do here, just instance variables!
	}
	
	public String getName()
	{
		return basicName+" I am a very simple flat roof";
	}

	/**
	 * return the generator for the wall...
	 */
	public WoofFloor getWoofFloor(int storyCount, double storyHeight, WoofBuilder wb)
	{
		double wd = 0;
		if (wall) wd = wallDepth;
		return new woof.FlatRoof(wb, storyHeight*storyCount, wd,this);
	}
	
	public void doRoofWall(Sheaf in)
	{
		stochoFreeze(waterfall.topWall,in);
	}
	
}
