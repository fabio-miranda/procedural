package ssbd;

import geom.Sheet;

/**
 * A Things that represent a line between 0,0 and 1,0
 * @author people
 *
 */
public interface NOISE_Line extends NOISE_Core
{
	public Sheet getLine(double width, double height);
}
