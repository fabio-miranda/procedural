package ssbd;

import sity.*;
import util.*;

public class PlotFromBlock extends Waterfall
{
	public SluiceManual plot = new SluiceManual(NOISE_Subdiv.class,"Plot layout manager goes here",this);
	
	public PlotFromBlock(Waterfall parent)
	{
		super(parent);
	}
}
