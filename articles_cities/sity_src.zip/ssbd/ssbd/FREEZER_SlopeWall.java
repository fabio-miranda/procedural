package ssbd;

import geom.*;

import java.util.*;

import sity.Parameters;

import woof.*;

public class FREEZER_SlopeWall extends FREEZER<SlopeWall> implements NOISE_Panel
{
	public double steepness;
	public boolean lump;
	public double lumpHeight;
	public double lumpWidth;
	
	public FREEZER_SlopeWall(SlopeWall w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// nothing to do here, just get created!
	}
	
	public String getName()
	{
		return basicName+" I am a very simple wall";
	}

	// approximations of horizontal....
	private final static double small = 10E-3;
	
	public WoofPanel getWoofPanel(double startHeight,int storyCount, FlatPoint point, double storyHeight, WoofBuilder wb)
	{
		WoofPanel dw = new DullWall(wb,point,storyCount, storyHeight, steepness);
		return addToWoofPanel(startHeight, storyCount, point, storyHeight, wb,dw);
	}
	
	public WoofPanel addToWoofPanel(
			double startHeight,
			int storyCount, 
			FlatPoint point, 
			double storyHeight, 
			WoofBuilder wb, 
			WoofPanel dw)
	{
		if (lump) // add a lump at every sotry
		{
			for (int i = 1; i <= storyCount; i++)
			{
				// the -100* is a bit arbitrary but seems to work...
				dw.setSpeedAt(i*storyHeight-lumpHeight+startHeight, -100*lumpWidth);
				dw.setSpeedAt(i*storyHeight-(99*lumpHeight/100)+startHeight, steepness);
				// the -small here stops it clashing with overhangs at the same height!
				dw.setSpeedAt(i*storyHeight-(lumpHeight/100)-small+startHeight, 100*lumpWidth);
				dw.setSpeedAt(i*storyHeight-small+startHeight, steepness);
				
			}
		}
		NOISE_Panel np = (NOISE_Panel) stochoFreeze(waterfall.nextMod,Parameters.NULL_SHEAF);
		
		if (np != null)
		{
			np.addToWoofPanel(startHeight, storyCount, point, storyHeight, wb, dw);
		}
		
		return dw;	
	}

}
