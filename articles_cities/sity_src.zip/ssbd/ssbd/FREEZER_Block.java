package ssbd;

import static sity.Parameters.*;
import geom.*;

import java.util.*;

import sity.Parameters;
import skeleton.*;

import cloud.*;


public class FREEZER_Block extends FREEZER<Block> implements NOISE_Block
{

	private NOISE_Street street = null;
	
	public FREEZER_Block(Block w, Random r)
	{
		super(w,r);
		street = (NOISE_Street)stochoFreeze(waterfall.streets, NULL_SHEAF);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		//stochoFreeze(waterfall.plot, in);
	}
	
	public String getName()
	{
		return basicName+" plan generator ";
	}
	
	public NOISE_Street getStreet()
	{
		return street;
	}
	
	public void setStreet(NOISE_Street s)
	{
		street = s;
	}
	
	// how much each house gets as the front of their plot
	public double streetFrontage; 
	public double minBuildingArea;
	
	private List<NOISE_Plot> plots = new ArrayList<NOISE_Plot>();
	private List<Double> plotFrontage = new ArrayList<Double>();
	
	/**
	 * Where the hard work is done, this is called with the sheaf when its time
	 * to do some work.
	 */
	public void setSheaf(Sheaf in, boolean concave)
	{
		//in.getMain().dump();
		assert(in.getSheets().size() == 1);

		// find the inner sheet(s)
		in.getMain().setAllSpeeds(0.1);
		Sheaf shrunk;
		try
		{
			Bones s = new Bones(in, 1., true);
			shrunk = s.getFlatTop();
		}
		catch (BonesSaysNoException e)
		{
			cantMakeBlock(in);
			return;
		}
		
		
		if (shrunk == null) 
		{
			cantMakeBlock(in);
			return;
		}
		// change coordinate system back to original....
		shrunk.convertTo(in);
		double total = shrunk.length();		
		
		double sofar = 0;
		while (sofar < total)
		{
			NOISE_Plot p = (NOISE_Plot) stochoFreeze(waterfall.plot, sity.Parameters.NULL_SHEAF);
			sofar += p.getFrontage();
			plots.add(p);
			plotFrontage.add(p.getFrontage());
		}
		
		assert(plots.size() == plotFrontage.size());

		// now find scale factor to turn sofar into totla
		double scale = total/sofar;
		
		// points used for voronoi
		List<FlatPoint> fp = new ArrayList<FlatPoint>();
		
		// create an array of points on perimiter for each house
		Iterator<Double> id = plotFrontage.iterator();
		double circ = 0;
		while (id.hasNext())
		{
			double front = id.next()*scale;
			circ+= front/2;
			FlatPoint p = shrunk.getPointAround(circ);
			//System.err.println("point added at "+p);
			fp.add(p);
			circ+= front/2;
		}

		PointCloud pc = new PointCloud(fp,in);
		try
		{
			Lightning l = new Lightning(pc,concave);
			// this causes lots of parallel edges to upset bones!:
		    //SilverLining.mergeSmallTillNoMore(pc, minBuildingArea, random);
			// set up who owns which wall
			pc.setUpWalls(random);
		}
		catch (CloudSaysNoException e)
		{
			// cant tesselate - just create the 'park'
			cantMakeBlock(in);
			return;
		}
		// since we've merged some plots this may be less than number of plots...  no way to reconcile yet
		Iterator<Cell> ic = pc.getCells().iterator();  
		Iterator<NOISE_Plot> ip = plots.iterator();
		while (ic.hasNext())
		{
			assert(ip.hasNext());
			NOISE_Plot plot = ip.next();
			plot.setPlot(ic.next().getSheaf(in));
		}
		
		// what we are doing here is splitting the block up into points
		anchor.createPolygon(in.getFace());
		stochoFreeze(waterfall.plot, in);
	}
	
	public void cantMakeBlock(Sheaf in)
	{
		assert(false);
		anchor.createPolygon(in);
	}
}
