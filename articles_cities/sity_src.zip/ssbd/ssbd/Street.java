package ssbd;

import sity.*;
import util.*;

public class Street extends Waterfall
{
	public ProbDouble VAR_width = new ProbDouble(0.5, 20, 0.1, 1.2);
	public String DEF_width   = "how wide is the street on this side of this block?";

	public Street(Waterfall parent)
	{
		super(parent);
	}
}
