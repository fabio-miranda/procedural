package ssbd;

import geom.*;

import java.util.*;

import cloud.*;

import skeleton.*;
import util.*;

public class FREEZER_Plot extends FREEZER<Plot> implements NOISE_Plot
{
	public double streetFrontage;

	public double spaceAtFront;

	public double spaceOnStreet;

	public double borderSize;

	public double houseDepth;

	public boolean sideBackWall;

	public boolean frontWall;

	public double wallWidth;

	public FREEZER_Plot(Plot w, Random r)
	{
		super(w, r);
	}

	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// nothing, dummy method... in will be Parameters.NullSheet
	}

	public double getFrontage()
	{
		return streetFrontage;
	}

	public String getName()
	{
		return basicName + "Its me, plot!";
	}

	public double wallGap;

	public void doFrontWall(Sheaf in)
	{
		// in.getMain().dump();
		assert (in.getSheets().size() == 1);

		// find the inner sheet(s)
		in.getMain().setAllSpeeds(0.001);
		Sheaf shrunk;
		try
		{
			Bones s = new Bones(in, 1., true);
			shrunk = s.getFlatTop();
		}
		catch (BonesSaysNoException e)
		{
			stochoFreeze(waterfall.frontFence, in);
			return;
		}

		if (shrunk == null)
		{
			stochoFreeze(waterfall.frontFence, in);
			return;
		}

		// change coordinate system back to original....
		shrunk.convertTo(in);

		CEFP startCEFP = shrunk.findLongestEdge();
		FlatPoint start = startCEFP.thing;
		FlatPoint end = startCEFP.next.thing;

		double distance = start.distanceTo(end);
		int dotsToUse = new Long(Math.round(Math.ceil(distance / wallGap))).intValue();

		// points used for voronoi
		List<FlatPoint> fp = new ArrayList<FlatPoint>();

		for (int i = 0; i < dotsToUse; i++)
		{
			double param = (double) i / (double) dotsToUse;
			FlatPoint f = new FlatPoint(start);
			f.scale(param);
			FlatPoint g = new FlatPoint(end);
			g.scale(1 - param);
			f.add(g);
			fp.add(f);
			// System.err.println("just added "+f);
		}

		PointCloud pc = new PointCloud(fp, in);
		try
		{
			Lightning l = new Lightning(pc, true);
			// this causes lots of parallel edges to upset bones!:
			WoofUnion union = new WoofUnion();

			int count = 0;
			int holeAt = random.nextInt(pc.getCells().size());
			for (Cell c : pc.getCells())
			{
				if (count != holeAt)
					union.addCell(c);
				count++;
			}
			Sheaf res = union.getSheaf(in);
			if (res != null)
				stochoFreeze(waterfall.frontFence, res);
			else
				throw new CloudSaysNoException();
		}
		catch (CloudSaysNoException e)
		{
			// cant tesselate - just create the 'park'
			stochoFreeze(waterfall.frontFence, in);
			return;
		}
	}

	private void doGarden(Sheaf in)
	{
		if (in == null)
			return; // may have no walls!
		//System.err.println("setting off on garden!");
		Sheet main = in.getMain();
		CEFPIterator cit;
		// first up if there is a border, try to make a wall in it

		cit = main.iterator();
		// first set all the speeds
		while (cit.hasNext())
		{
			FlatPoint next = cit.next().thing;
			if (next.ofType(EdgeType.MY_WALL) && !next.ofType(EdgeType.FRONT))
			{
				next.setSpeed(wallWidth);
			}
			else
			{
				next.setSpeed(0.0);
			}
		}

		try
		{
			Bones b = new Bones(in, 1.0, true);
			cit = main.iterator();
			// set speeds for wall
			while (cit.hasNext())
			{
				FlatPoint next = cit.next().thing;
				if (next.ofType(EdgeType.MY_WALL) &&  !next.ofType(EdgeType.FRONT))
				{
					//System.err.println("found one we like");
					next.addType(EdgeType.GUTTER);
				}
				else
				{
					//System.err.println("there wasn't one here!");
					next.removeType(EdgeType.GUTTER);
				}
			}

			Sheaf sideWall = b.getGutter();
			if (sideWall != null)
				stochoFreeze(waterfall.sideFence, sideWall);
			//else
			//	System.err.println("sideWallWasNull");
		}
		catch (BonesSaysNoException e)
		{
			// continue.... no consequence!
		}
	}

	private Sheaf doWalls(Sheaf in)
	{
		if (in == null)
			return null; // may have no walls!
		Sheet main = in.getMain();
		CEFPIterator cit;
		// first up if there is a border, try to make a wall in it
		if (frontWall || (sideBackWall && borderSize > 0))
		{
			cit = main.iterator();
			// first set all the speeds
			while (cit.hasNext())
			{
				FlatPoint next = cit.next().thing;
				if (next.ofType(EdgeType.MY_WALL) || next.ofType(EdgeType.FRONT))
					next.setSpeed(wallWidth);
				else
					next.setSpeed(wallWidth);
			}

			try
			{

				Bones b = new Bones(in, 1.0, true);

				cit = main.iterator();
				// set speeds for wall
				if (sideBackWall && borderSize > 0)
				{
					while (cit.hasNext())
					{
						FlatPoint next = cit.next().thing;
						if (next.ofType(EdgeType.MY_WALL) && !next.ofType(EdgeType.STREET))
							next.addType(EdgeType.GUTTER);
						else
							next.removeType(EdgeType.GUTTER);
					}

					Sheaf sideWall = b.getGutter();
					if (sideWall != null)
						stochoFreeze(waterfall.sideFence, sideWall);
				}

				// now create a wall on the street
				if (frontWall)
				{
					cit = main.iterator();
					while (cit.hasNext())
					{
						FlatPoint next = cit.next().thing;
						if (next.ofType(EdgeType.STREET) && (!next.ofType(EdgeType.FRONT)))
						{
							// System.err.println("adding gutter to "+next.getType());
							next.addType(EdgeType.GUTTER);
						}
						else
						{
							// System.err.println("not adding gutter to "+next.getType());
							next.removeType(EdgeType.GUTTER);
						}
					}
					Sheaf streetWall = b.getGutter();
					if (streetWall != null)
						stochoFreeze(waterfall.frontFence, streetWall);
				}

				// now create a wall at the front
				if (frontWall)
				{
					cit = main.iterator();
					while (cit.hasNext())
					{
						FlatPoint next = cit.next().thing;
						if (next.ofType(EdgeType.FRONT))
							next.addType(EdgeType.GUTTER);
						else
							next.removeType(EdgeType.GUTTER);
					}
					Sheaf frontWall = b.getGutter();
					if (frontWall != null)
						doFrontWall(frontWall);
				}

				return b.getFlatTop(); // new starting locaiton!

			}
			catch (BonesSaysNoException e)
			{
				// continue.... _in_ should be untouched!
			}
		}
		return null;
	}

	/**
	 * This is where the real work is done
	 */
	public void setPlot(Sheaf in)
	{
		if (in == null)
			return; // no room for a house here!
		Sheaf oldIn = in;
		Sheet main = in.getMain();
		CEFPIterator cit;
		// now onto border

		// find the front of the house
		cit = main.iterator();
		double maxLength = -Double.MAX_VALUE;
		CEFP longest = null;// main.getFirst().thing;
		// find longest street...
		while (cit.hasNext())
		{
			CEFP c = cit.next();
			FlatPoint a = c.thing;
			FlatPoint b = c.next.thing;
			double dist = a.distanceTo(b);
			if (a.ofType(EdgeType.STREET))
			{
				if (dist > maxLength)
				{
					maxLength = dist;
					longest = c; // point at end of line!?
				}
				// elif just street, size is
				a.setSpeed(spaceOnStreet);
			}
			else
				a.setSpeed(borderSize); // defaultSpeed
		}
		// if we found a street on the road, let it have a front garden
		if (longest != null)
		{
			// System.err.println("found a longest");
			longest.thing.setSpeed(spaceAtFront + spaceOnStreet);
			longest.thing.addType(EdgeType.FRONT);
		}

		// create walls if we have a border
		if (borderSize > 0 && (sideBackWall || frontWall))
		{
			in = doWalls(in);
			if (in == null)
				in = oldIn;
			main = in.getMain();
		}

		// set the speeds again
		cit = main.iterator();
		// find longest street...
		while (cit.hasNext())
		{
			CEFP c = cit.next();
			FlatPoint a = c.thing;
			FlatPoint b = c.next.thing;
			if (a.ofType(EdgeType.STREET))
			{
				a.setSpeed(spaceOnStreet);
			}
			else
				a.setSpeed(borderSize); // defaultSpeed
			if (longest.thing == a)
			{

				longest.thing.setSpeed(spaceAtFront + spaceOnStreet);
			}
		}

		// now shrink in that amount...

		Sheaf partOne = null;

		try
		{
			Bones b = new Bones(in, 1., true);
			partOne = b.getFlatTop();
		}
		catch (BonesSaysNoException e)
		{
			// "vacant lot"
			sity.Parameters.anchor.createPolygon(in);
			return;
		}

		// if street line doesn't exist after shrinking then dont bother
		if (partOne == null)
		{
			sity.Parameters.anchor.createPolygon(in);
			return;
		}

		// here comes the science! concentrate!
		for (Sheet sheet : partOne.getSheets())
		{
			// set all sides to zero speed
			cit = sheet.iterator();
			while (cit.hasNext())
			{
				CEFP c = cit.next();
				c.thing.setSpeed(0);
				// find if one edge still has FRONT tag
				if (c.thing.ofType(EdgeType.FRONT))
				{
					c.thing.setSpeed(houseDepth);
				}
			}

			// shrink in again, bevel at 1, distance will be == speed
			Sheaf partTwo = null;
			try
			{
				Bones b = new Bones(partOne, 1., true);
				List<Sheaf> woof = b.getWoof(true); // flat roof!
				for (Sheaf f : woof)
				{
					// got to search for the roof section that was on the front
					cit = f.getMain().iterator();
					while (cit.hasNext())
					{
						FlatPoint n = cit.next().thing;
						if (n.ofType(EdgeType.FRONT))
						{
							// System.err.println("found it");
							partTwo = f;
							// label those sides that arn't top and arn't front as sides
						}
						else if (!n.ofType(EdgeType.BEVELTOP))
						{
							// tag all other sides as side of the house (if not front and not back)
							n.addType(EdgeType.SIDE);
						}
							
					}
				}
				// now the garden for those that didnt get it before
				if (borderSize == 0 && sideBackWall)
				{
					Sheaf garden = b.getFlatTop();
					doGarden(garden); // does return a Sheaf if we want a tree later!
				}
			}
			catch (BonesSaysNoException e)
			{
				// go with part one
				freezeThis(getNextToFreeze(waterfall.floorPlan), partOne);
				return;
			}
			if (partTwo == null)
			{
				// shrinking removed building, go with part one again
				// System.err.println("didnt find front!");
				freezeThis(getNextToFreeze(waterfall.floorPlan), partOne);
				return;
			}
			freezeThis(getNextToFreeze(waterfall.floorPlan), partTwo);
		}

		// Waterfall plan = waterfall.floorPlan.getNextToFreeze();
	}
}
