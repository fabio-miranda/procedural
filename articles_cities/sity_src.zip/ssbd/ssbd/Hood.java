package ssbd;

import sity.*;

public class Hood extends Waterfall
{
	public SluiceManual points = new SluiceManual(NOISE_Dot.class,"Block layout",this);
	public SluiceManual block = new SluiceManual(NOISE_Block.class,"Block generator",this);
	
	public Hood(Waterfall parent)
	{
		super(parent);
	}
}
