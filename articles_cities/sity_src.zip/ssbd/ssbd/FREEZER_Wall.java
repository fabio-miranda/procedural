package ssbd;

import static sity.Parameters.anchor;
import geom.Sheaf;

import java.util.List;
import java.util.Random;

/**
 * wall of the house!
 * @author people
 *
 */
public class FREEZER_Wall extends FREEZER<Wall> implements NOISE_Core
{
	public FREEZER_Wall(Wall w, Random r)
	{
		super(w, r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		anchor.createPolygon(in);
	}
	
	public String getName()
	{
		return basicName+"I am a wall";
	}
}
