package ssbd;

import geom.*;

import java.util.*;

import sity.Parameters;
import util.*;
import woof.*;

public class FREEZER_OverHang extends FREEZER<OverHang> implements NOISE_SheafChange, SetupPanel
{
	public double hangFront;
	
	public double hangSides;
	
	public double hangBack;
		
	public double hangDown; 
	
	private double hangAt;
	
	public FREEZER_OverHang(OverHang w, Random r)
	{
		super(w,r);
	}
	
	/**
	 * Starting from the shortest edge, mark
	 */
	public void markGables(Sheaf in)
	{
		for (Sheet s: in.getSheets())
		{
			CEFP shortest = s.findShortest();
			CEFPIterator cit = new CEFPIterator(shortest);
			while (cit.hasNext())
			{
				CEFP n = cit.next();
				CEFP p = n.previous;
				FlatPoint one   = n.previous.thing;
				FlatPoint two   = n.thing;
				FlatPoint three = n.next.thing;
				FlatPoint four  = n.next.next.thing;
				
				if (one.ofType(EdgeType.GABLED) || three.ofType(EdgeType.GABLED))
				{
					// nothing to do, already gabled.
					two.removeType(EdgeType.GABLED);
				}
				else
				{
					if (Vec2d.interiorAngleBetween(one, two, three) < Math.PI)
						if (Vec2d.interiorAngleBetween(two,three,four) < Math.PI)
						{
							two.addType(EdgeType.GABLED);
						}
						else
						{
							two.removeType(EdgeType.GABLED);
						}
				}
				
			}
		}
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// nothing to do here, just get created!
	}
	
	public String getName()
	{
		return basicName+" I am a very simple roof";
	}

	/**
	 * return the generator for the wall...
	 */
	public WoofFloor getWoofFloor(int storyCount, double storyHeight, WoofBuilder wb)
	{	
		hangAt = storyHeight*storyCount;
		woof.OverHang overhang = new woof.OverHang(wb,hangAt,hangFront, hangSides, hangBack, hangDown, this);
		return overhang;
	}

	public Map<FlatPoint, WoofPanel> getPanel(Sheaf in, WoofBuilder wb)
	{
		Map<FlatPoint, WoofPanel> map = new LinkedHashMap<FlatPoint, WoofPanel>();
		if (in == null) return map;
		for (Sheet s: in.getSheets())
		{
			CEFPIterator cit = new CEFPIterator(s);
			while (cit.hasNext())
			{
				FlatPoint f = cit.next().thing;
				NOISE_Panel panel;
				if (f.ofType(EdgeType.GABLED))
					panel = (NOISE_Panel) stochoFreeze(waterfall.gables,Parameters.NULL_SHEAF);
				else
					panel = (NOISE_Panel) stochoFreeze(waterfall.other,Parameters.NULL_SHEAF);
				map.put(f,panel.getWoofPanel(hangAt,0,f,0,wb));//dr);
			}
		}
		return map;
	}
}
