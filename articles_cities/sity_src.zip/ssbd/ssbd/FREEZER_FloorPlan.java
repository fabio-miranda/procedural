package ssbd;

import geom.*;

import java.util.*;

import javax.vecmath.*;

import sity.Parameters;
import skeleton.BonesSaysNoException;
import util.*;
import woof.*;

public class FREEZER_FloorPlan extends FREEZER<FloorPlan> implements NOISE_Subdiv
{
	public boolean gableSides;
	public boolean gableFront;
	
	public double storyHeight;
	public int numberStories;
	
	
	public NOISE_SheafChange roof;
	
	public FREEZER_FloorPlan(FloorPlan w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		if (in != null && Vec2d.findArea(in) < 0) in.reverse(); // reliability code
		
		
		roof = (NOISE_SheafChange)stochoFreeze(waterfall.onTop,Parameters.NULL_SHEAF);
		roof.markGables(in);

		WoofBuilder wb = new WoofBuilder();
		wb.addBigEvent(roof.getWoofFloor(numberStories,storyHeight,wb));
		
		// our settings for each wall
		Map<FlatPoint,WoofPanel> walls = new LinkedHashMap<FlatPoint,WoofPanel>();
		
		// now go through all walls in the sheaf setting the relevant wall shape creator
		for (Sheet s: in.getSheets())
		{
			CEFPIterator cit = new CEFPIterator(s);
			while(cit.hasNext())
			{
				FlatPoint f = cit.next().thing;
				NOISE_Panel gen; 
				if (f.ofType(EdgeType.FRONT))
					gen = (NOISE_Panel)stochoFreeze(waterfall.front, Parameters.NULL_SHEAF);
				else if (f.ofType(EdgeType.BEVELTOP)) // back of house
					gen = (NOISE_Panel)stochoFreeze(waterfall.back, Parameters.NULL_SHEAF);
				else if (f.ofType(EdgeType.SIDE))
					gen = (NOISE_Panel)stochoFreeze(waterfall.side, Parameters.NULL_SHEAF);
				else  // shoudn't happen!... but caus I'm lazy....
					gen = (NOISE_Panel)stochoFreeze(waterfall.side, Parameters.NULL_SHEAF);
				
				assert(gen != null);
				walls.put(f,gen.getWoofPanel(0.,numberStories,f, storyHeight, wb));
			}
		}
		
		try
		{
			wb.go(in, walls);
		}
		catch (BonesSaysNoException e)
		{
			System.err.println("creating a vacant lot....");
			// just create a vacant lot!
			Parameters.anchor.createPolygon(in);
		}
		
		/*System.err.println("****************************************");
		for (Sheet s: in.getSheets())
		{
			CEFPIterator cit = new CEFPIterator(s);
			while (cit.hasNext())
			{
				System.err.println("input to floorplan contains "+cit.next().thing.getTypes());
			}
		}*/
	}

	public static void add(Vector3d in, Matrix4d m)
	{
		m.m03-=in.x;
		m.m13-=in.y;
		m.m23-=in.z;
	}

	public String getName()
	{
		return basicName + "Floor plan generator";
	}
}
