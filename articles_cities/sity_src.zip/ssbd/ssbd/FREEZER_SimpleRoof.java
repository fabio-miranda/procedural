package ssbd;

import static sity.Parameters.anchor;
import geom.*;

import java.util.*;

import junk.Skeleton;
import skeleton.*;
import util.CEFPIterator;

public class FREEZER_SimpleRoof extends FREEZER<SimpleRoof> implements NOISE_Core
{
	public FREEZER_SimpleRoof(SimpleRoof w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		/*double doFlat = Double.MAX_VALUE;
		//List<Double> speeds = new Vector<Double>();
		//for (int i = 0; i < in.getMain().size(); i++) speeds.add(new Double(random.nextDouble()));
		
		Iterator<Sheet> it = in.getSheets().iterator();
		while (it.hasNext())
		{
			it.next().reverse();
		}
		
		//System.err.println("inital transform "+in.getTransform());
		
		Skeleton eves = new Skeleton(in,0.2);
		Iterator<Sheaf> shit = eves.makeSideSheets(in,-0.5).iterator();//gDouble("steepness")).iterator();
		while (shit.hasNext()) anchor.createPolygon(shit.next().getFace());
		List<Sheaf> ls = eves.findFlatTop(in,-0.1);
		
		if (ls.size() == 0) return;
		Sheaf main = ls.get(0);
		
		
		//System.err.println("eves transform "+main.getTransform());
		
		//main.getMain().reverse();
		double bevel = Double.MAX_VALUE;
		
		if (gBoolean("flatTop"))
		{
			bevel = gDouble("distToFlat");
		}
				
		Bones roof = new Bones(main,bevel);
		shit = roof.makeSideSheets(main,1).iterator();
		while (shit.hasNext()) anchor.createPolygon(shit.next().getFace());
		
		if (gBoolean("flatTop"))
		{
			ls = roof.findFlatTop(main,bevel);
			if (ls.size()==0) return;
			Sheaf nextRoof = ls.get(0);
			nextRoof.getMain().reverse();
			stochoFreeze(waterfall.nextRoof, nextRoof);	
		}*/
		
		Iterator<Sheet> it = in.getSheets().iterator();
		while (it.hasNext())
		{
			CEFPIterator cit = it.next().iterator();
			while (cit.hasNext())
			{
				cit.next().thing.setSpeed(1);
			}
		}
		
		try
		{
			Bones roof = new Bones(in, false);
			//System.err.println("going into getWoof");
			List<Sheaf> s = roof.getWoof();
			//System.err.println("getWoofisDone "+s.size());
			int count = 0;
			for (Sheaf sheaf : s)
			{
				count++;
				//System.err.println("on now thank youuu "+count);
				Sheet de = sheaf.getMain();
				///CEFPIterator cit = de.iterator();
				//while (cit.hasNext()) System.err.println("point to triaingulate is "+cit.next());
				anchor.createPolygon(sheaf);
				//System.err.println("done thank youuu "+count);
			}
			//System.err.println("leaving sim[ple woof");
		}
		catch (BonesSaysNoException e)
		{
			// dont really care
		}
	}
	
	public String getName()
	{
		return basicName+" I am a very simple roof";
	}
}
