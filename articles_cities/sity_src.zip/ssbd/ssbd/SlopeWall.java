package ssbd;

import sity.*;
import sity.Waterfall;
import util.*;

/** This is a simple wall!
 * 
 * @author people
 *
 */

public class SlopeWall extends Waterfall
{
	public ProbDouble VAR_steepness = new ProbDouble(-1000,1000,0.2,0);
	public String       DEF_steepness = "how steep is twall";
	
	public ProbDouble VAR_lumpHeight = new ProbDouble(0.001,100, 0.1,0.2);
	public String DEF_lumpHeight = "Height of the lump between stories";
	
	public ProbDouble VAR_lumpWidth = new ProbDouble(0.001,100, 0.1,0.2);
	public String DEF_lumpWidth = "outwards width/depth of step between stories";
	
	public ProbBoolean VAR_lump = new ProbBoolean(0.5);
	public String DEF_lump = "is there a step between stories?";
	
	public boolean lump;
	public double lumpHeight;
	public double lumpWidth;
	
	public SluiceManual nextMod = new SluiceManual(NOISE_Panel.class,"Optional additional modification to this wall!",this);
	
	public SlopeWall(Waterfall parent)
	{
		super(parent);
	}
}
