package ssbd;

import static java.lang.Math.*;
import geom.*;

import java.util.*;

import sity.Parameters;
import skyHook.AnchorStatics;
import util.CEFPIterator;


public class FREEZER_Dot extends FREEZER<Dot> implements NOISE_Dot
{
	Sheaf sheaf = null;
	private static final boolean DEBUG = false;
	
	public FREEZER_Dot(Dot w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		sheaf = in;
	}
	
	public int dotStyle;
	public double width, height;
	public double chaos;
	
	public List<FlatPoint> getPoint()
	{
		// find the rectuangular bounds of the input sheaf
		findBounds();

		//System.err.println("dot style is "+random.nextLong());
		
		CEFPIterator cit = sheaf.getMain().iterator();
		//while (cit.hasNext()) System.err.print(">>>"+cit.next().thing);
		//System.err.println();
		
		switch (dotStyle)
		{
		// spiral
		case 0:
			return spiral();
		// circular
		case 1:
			return circular();
		// square
		case 2:
			return rectangular();
		}
		System.err.println("oops, returning null");
		
		return null;
	}
	
	private List<FlatPoint> spiral()
	{
		List<FlatPoint> out = new ArrayList<FlatPoint>();
		//find a random point in the middle of the shape
		double rangeX = maxX-minX;
		double rangeY = maxY-minY;
		
		double cenX = random.nextDouble()*rangeX+minX;
		double cenY = random.nextDouble()*rangeY+minY;
		
		// add a point at the centre
		FlatPoint cen = new FlatPoint(cenX, cenY);
		noiseFilter(cen);
		out.add(cen);
		
		// find the longest distance to one of the corners of the rectangle.
		double maxSize = longestDistanceToCorner(cenX,cenY);

		// scaling factors - bit a bit of a ephemeral random constant malarkey here
		double b = height/300;
		// apply parametic form of spiral equation until
		double t = 1;
		double xPos = cenX;
		double yPos = cenY;
		if (DEBUG)System.err.println("cenX "+cenX+" ceny"+cenY);

		while (dist(xPos,yPos,cenX,cenY) < maxSize)
		{
			xPos = 10*cos(t)*pow(E,b*t)+cenX;
			yPos = 10*sin(t)*pow(E,b*t)+cenY;
			FlatPoint f = new FlatPoint(xPos, yPos);
			if (DEBUG)System.err.println("new point at "+f);
			noiseFilter(f);
			if (isInRectangle(f) && isInSheaf(f)) out.add(f);
			t+=width/20;
		}
		if (DEBUG)dumpPoints(out);
		
		return out;
	}
	
	private List<FlatPoint> circular()
	{
		List<FlatPoint> out = new ArrayList<FlatPoint>();
		//find a random point in the middle of the shape
		double rangeX = maxX-minX;
		double rangeY = maxY-minY;
		
		double cenX = random.nextDouble()*rangeX+minX;
		double cenY = random.nextDouble()*rangeY+minY;
		
		// find the longest distance to one of the corners of the rectangle.
		double maxSize = longestDistanceToCorner(cenX,cenY);
		
		// add a point at the centre
		FlatPoint cen = new FlatPoint(cenX, cenY);
		noiseFilter(cen);
		out.add(cen);
				
		// now
		for (double y = 1; y < maxSize; y+=height)
		{
			if (DEBUG) System.err.println(" y is "+y);
			double circum = PI*y; // y/2 is radius
			// split circum into width size bits
			int div = (new Long(round(floor(circum/width)))).intValue();
			double length = circum/div;
			// prevent strange offset patterns
			double offset = random.nextDouble() * PI*2;
			for (int i = 0; i < div; i++)
			{
				if (DEBUG) System.err.println(" i is "+i);
				double angle = ((double)i)/(div)*PI*2+offset;
				// now add point at angle angle and distance y from (cenX,cenY)
				double yPos = cenY+sin(angle)*y;
				double xPos = cenX+cos(angle)*y;
				FlatPoint f= new FlatPoint(xPos,yPos);
				if (DEBUG) System.err.println("output point is at"+ yPos+" and "+xPos);
				noiseFilter(f);
				if (isInRectangle(f) && isInSheaf(f)) out.add(f);
			}
		}
		
		if (DEBUG)dumpPoints(out);
		
		return out;
	}
	
	/**
	 * returns the longest distance to the corner of a rectangle
	 * @param x
	 * @param y
	 * @return
	 */
	private double longestDistanceToCorner(double x, double y)
	{
		double t1 = dist(x,y,minX,minY);
		double t2 = dist(x,y,minX,maxY);
		double t3 = dist(x,y,maxX,maxY);
		double t4 = dist(x,y,maxX,minY);
		// should really write max that takes an argument list...
		return max(max(max(t1,t2),t3),t4);
	}
	
	private double dist(double x1, double y1, double x2, double y2)
	{
		double a = y2-y1;
		double b = x2-x1;
		return sqrt(a*a+b*b);
	}
	
	/**
	 * Width and height between each dot, clipped to the inside of sheaf, chaos length
	 * random walk away from specified locaiton
	 * 
	 * O- find square boundary of sheaf 
	 * 
	 * @return
	 */
	private List<FlatPoint> rectangular()
	{
		if (DEBUG)
		{System.err.println("x range f rom "+minX+" to "+maxX);
		System.err.println("y range f rom "+minY+" to "+maxY);
		System.err.println("diagonal is "+diagonal+" height is "+height);}
		
		// how far around shall we rotate the points
		double rotate = random.nextDouble()*Math.PI;
		if (rotate > Math.PI/2)
		{
			rotate -= Math.PI/2;
			double tmp = width;
			width = height;
			height = tmp;
		}
		List<FlatPoint> out = new ArrayList<FlatPoint>();
		
		for (double xPos = 0; xPos < diagonal; xPos += height)
		{
			if (DEBUG)System.err.println("yPos is "+xPos);
			double yPos= 0;
			//do forwards
			for (yPos = -diagonal; yPos < diagonal; yPos += width)
			{
				findPoint(xPos,yPos,out, rotate);
			}
		}
		if (DEBUG)dumpPoints(out);
		return out;
	}
	
	/**
	 * Rectangle utility fn - find rotated locaiton of point and returns true if inside
	 * shape
	 * @param xPos
	 * @param yPos
	 * @param out
	 * @param angle
	 * @return
	 */
	public boolean findPoint(double xPos, double yPos, List<FlatPoint> out, double angle)
	{
		boolean wasInRec;
		// rotate points and add
		double newX = minX + (Math.cos(angle)*xPos - Math.sin(angle)*yPos);
		double newY = minY + (Math.cos(angle)*yPos + Math.sin(angle)*xPos);
		FlatPoint f = new FlatPoint (newX, newY);
		
		if (DEBUG)
		{
			System.err.println("input location is at "+xPos+","+yPos);
			System.err.println("new suggested point is at"+newX+" ::: "+ newY);
		}
		
		wasInRec = isInRectangle(f);
		// mess it up a bit
		noiseFilter(f);
		// go lazy java go! 
		if (wasInRec && isInSheaf(f))
			out.add(f);
		return wasInRec;
	}
	
	/**
	 * Is this point in the rectangle defined by findbounds?
	 */
	private boolean isInRectangle(FlatPoint f)
	{
		if (f.x < minX) return false;
		if (f.y < minY) return false;
		if (f.x > maxX) return false;
		if (f.y > maxY) return false;
		return true;
	}
	
	/**
	 * Returns true of the specified point is really in the sheaf
	 * @param f
	 * @return
	 */
	private boolean isInSheaf(FlatPoint f)
	{
		if (sheaf.getSheets().size() > 1) Parameters.fatalErrorSD("dot not working on shapes with holes!");
		List<FlatPoint> lfp= new ArrayList<FlatPoint>();
		CEFPIterator cit = sheaf.getMain().iterator();
		while(cit.hasNext()) lfp.add(cit.next().thing);
		return Vec2d.pointIn(f, lfp);
	}
	
	/**
	 * adds noise, decided by chaos to the 
	 * @param in given flatpoitns
	 */
	private void noiseFilter(FlatPoint in)
	{
		double distx = random.nextDouble()*chaos*2 - chaos;
		double disty = random.nextDouble()*chaos*2 - chaos;
		in.x += distx;
		in.y += distx;
	}
	
	double minX, minY;
	double maxX, maxY;
	double diagonal;
	
	/**
	 * round the given sheet to a rectangle... lazy tom
	 *
	 */
	private void findBounds()
	{
		minX =  Double.MAX_VALUE;
		minY =  Double.MAX_VALUE;
		maxX = -Double.MAX_VALUE;
		maxY = -Double.MAX_VALUE;
		
		for (Sheet s: sheaf.getSheets())
		{
			CEFPIterator cit = s.iterator();
			while (cit.hasNext())
			{
				FlatPoint f = cit.next().thing;
				if (f.x < minX) minX = f.x; 
				if (f.y < minY) minY = f.y;
				if (f.x > maxX) maxX = f.x;
				if (f.y > maxY) maxY = f.y;
			}
		}
		//System.err.println("goin in");
		assert(
				minX !=  Double.MAX_VALUE && 
				minY !=  Double.MAX_VALUE && 
				maxX != -Double.MAX_VALUE && 
				maxY != -Double.MAX_VALUE);
		double xdist = maxX-minX;
		double ydist = maxY-minY;
		diagonal = Math.sqrt(xdist*xdist+ydist*ydist);
	}
	
	public static void dumpPoints(List<FlatPoint> in)
	{
		System.err.println("point count is "+in.size());
		for 
		(FlatPoint f : in)
		{
			AnchorStatics.createCube(f, 2);
		}
	}
	
	public String getName()
	{
		return basicName+" plan generator ";
	}
}
