package ssbd;

import static sity.Parameters.anchor;
import geom.FlatPoint;
import geom.Sheaf;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import javax.vecmath.Matrix4d;

import sity.FallState;
import sity.Parameters;
import sity.Waterfall;
import skyHook.Anchor;
import skyHook.DoNothingAnchor;

/**
 * The only freezer not to have to implement a root, but it does so
 * we know what colour it should be!
 * @author people
 *
 */
public class FREEZER_Root extends FREEZER<Root> implements NOISE_Core
{
	public FREEZER_Root(Root w, Random r)
	{
		super(w,r);
	}
	
	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		/** root never renders! just ask the next section to set up nicely */
		if (in == null)
		{
			List<FlatPoint> lfp = new ArrayList<FlatPoint>();
			double width  = gDouble("width");
			double height = gDouble("height");
			lfp.add(new FlatPoint(0,0));
			lfp.add(new FlatPoint(0,height));
			lfp.add(new FlatPoint(width,height));
			lfp.add(new FlatPoint(width,0));
			Matrix4d ident = new Matrix4d();
			ident.setIdentity();
			in = new Sheaf(lfp,ident);
		}
		freezeThis(getNextToFreeze(waterfall.cityPlanner),in);
	}
	
	/**
	 *  Static method that initiates the freeze cascade
	 * @param rootWaterfall the root waterfall.
	 * @param random the random source for this construction
	 */
	public static void bigFreeze(Root rootWaterfall, Random random)
	{
		FREEZER_Root fr = new FREEZER_Root(rootWaterfall, random);
		fr.doFreeze(null, new Vector<FREEZER>(0));
		anchor.allDone();
	}
	
	public static void bigFreeze(Root rootFall)
	{
		bigFreeze(rootFall, new Random(rootFall.VAR_random_seed.value));
	}
	
	public String getName()
	{
		return basicName+"Its me, plot!";
	}
	
	public static FallState findFallState(Waterfall in, Root root)
	{
		egGoal = in;
		Anchor tmpAnchor = Parameters.anchor;
		Parameters.anchor = new DoNothingAnchor();
		//search for our waterfall
		bigFreeze(root);
		// remember what we learnt
		FallState output = fallState;
		//put it back how it was!
		Parameters.anchor = tmpAnchor;
		egGoal = null;
		fallState = null;
		return output;
	}
	
	public static void freezeFromState(FallState in)
	{
		// should state contain the freezer? or new instance from waterfall, set random
		// then call freezeThis on it! probably best
		FREEZER<? extends Waterfall > res = FREEZER.fallToFreezer(in.getWaterfall(), in.getRandom());
		res.freeze(in.getSheaf(), in.getParents());
	}
}
