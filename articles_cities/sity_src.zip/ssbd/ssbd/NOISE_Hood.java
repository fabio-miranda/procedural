package ssbd;

import geom.Sheaf;

/** This is the superinterface of all nosies. Noises determine the type of
 *  waterfall chaining that is permitted. Eg: a noise is the type of the
 *  output plug.
 * 
 * @author tomkelly
 *
 */
public interface NOISE_Hood extends NOISE_Core
{
	// the generator for the blocks in this hood
	public NOISE_Dot getBlockGenerator();
	// returns the next block in the hood, created on the fly, called an unknown number of tmes!
	public NOISE_Block getNextBlock();
	// creates another block with street as its street!
	public NOISE_Block getNextBlock(NOISE_Street street);

}
