package ssbd;

import java.util.*;

import junit.framework.TestCase;
import util.*;

public class FREEZERInstanceVariablesTest extends TestCase
{
	Random r = new Random();
	public void testinstanceVariables()
	{
		Plot w = new Plot(null);
		w.VAR_streetFrontage = new ProbDouble(0,20,0,10);
		FREEZER_Plot f = new FREEZER_Plot(w,r);
		assertTrue ("value is "+f.gInt("frontGarden"),f.gInt("frontGarden")==10);
		assertTrue ("value is "+f.gInt("frontGarden"),f.gInt("frontGarden")==10);
	}
	/*
	public void testRange()
	{
		Plot w = new Plot(null);
		w.VAR_streetFrontage = ProbDouble(0,20,0,10);
		w.VAR_frontGarden.mean = -100;
		w.VAR_frontGarden.SD = 1;
		
		FREEZER_Plot f = new FREEZER_Plot(w,r);
		int i = f.gInt("frontGarden");
		assertTrue ("value is "+f.gInt("frontGarden"), i >-104 && i < -96);
	}
	
	public void testParentChaining()
	{
		Plot w = new Plot(null);
		Root w2 = new Root(null);
		w.VAR_frontGarden = new NYProbInt(0,100);
		//w2.VAR_scatter = 4;
		FREEZER_Plot f = new FREEZER_Plot(w,r);
		FREEZER_Root f2 = new FREEZER_Root(w2,r);
		ArrayList<FREEZER> al = new ArrayList<FREEZER>(0);
		al.add(f2);
		f.freeze(null,al);
		f2.freeze(null,new ArrayList<FREEZER>(0));
		int i = f.gInt("frontGarden");
		assertTrue ("value is "+f.gInt("frontGarden"), i==10);
		assertTrue ("value is "+f.gInt("scatter"), f.gInt("scatter") == 4);
		// dumps stack! int a = f.gInt("Not exist");
*/
}
