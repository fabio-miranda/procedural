package ssbd;

import geom.*;

import java.util.*;

import javax.swing.*;

import sity.Parameters;
import util.CEFPIterator;

import cloud.*;

public class FREEZER_CityPlanner extends FREEZER<CityPlanner> implements NOISE_Subdiv
{

	public double mergeSmallBlocks, bombed;

	public FREEZER_CityPlanner(CityPlanner w, Random r)
	{
		super(w, r);
	}

	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		NOISE_Dot pointGen = (NOISE_Dot) stochoFreeze(waterfall.points, in);
		if (pointGen == null)
		{
			sity.Parameters.message("you probably want to give city planner a point generator, or you wont see much...");
			return;
		}

		List<FlatPoint> points = pointGen.getPoint();
		// find the voronoi tesselation of the points offered
		PointCloud pc = new PointCloud(points, in);

		Lightning l = null;
		try
		{
			l = new Lightning(pc);
		}
		catch (CloudSaysNoException e)
		{
			Parameters.error("error tesselating hood layout");
			return;
		}

		Set<Sheaf> sh = l.getCellsAsSheets(in);
		List<FlatPoint> allBlocks = new ArrayList<FlatPoint>();
		List<NOISE_Hood> allHoods = new ArrayList<NOISE_Hood>();
		// once for all hoods - find out where they position their blocks

		for (Sheaf s : sh)
		{
			NOISE_Hood h = (NOISE_Hood) stochoFreeze(waterfall.hood, s);
			NOISE_Dot d = (NOISE_Dot) h.getBlockGenerator();
			List<FlatPoint> lfp = d.getPoint();
			// CEFPIterator cit = s.getMain().iterator();
			// while (cit.hasNext()) System.err.println("corner is "+cit.next());

			for (FlatPoint f : lfp)
			{
				allBlocks.add(f);
				allHoods.add(h);
			}
			// Parameters.anchor.createPolygon(s.getFace());
		}
		
		// check that there are > 1 points!
		if (allBlocks.size() == 0) 
		{
			allBlocks.add(new FlatPoint(Double.MIN_VALUE, Double.MIN_VALUE));
			allHoods.add((NOISE_Hood)stochoFreeze(waterfall.hood, in));
		}
		
		// debugging line
		// FREEZER_Dot.dumpPoints(allBlocks);
		// perform voronoi tesselation on all points
		PointCloud blocks = new PointCloud(allBlocks, in);
		try
		{
			l = new Lightning(blocks);
		}
		catch (CloudSaysNoException e)
		{
			Parameters.error("error tesselating the sity");
			return;
		}

		// now all over all hoods find how much to shrink each road
		assert (allBlocks.size() == blocks.getCells().size());
		assert (allBlocks.size() == allHoods.size());

		// clean up small blocks and add some chaos
		//SilverLining.mergeSmallTillNoMore(blocks, mergeSmallBlocks, random);
		// 984904962
		//SilverLining.mergeRandom(blocks, bombed, random);
		ListIterator<NOISE_Hood> lit = allHoods.listIterator();

		int count = 0;
		for (Cell c : blocks.getCells())
		{
			count++;

			Parameters.error(count + " from " + blocks.getCells().size() + " done so far....");
			NOISE_Hood h = lit.next();
			NOISE_Block block = h.getNextBlock();
			if (block == null) continue;
			NOISE_Street s = block.getStreet();

			// store the street width parameter
			c.setStreet(s);

			Sheaf blockSize = c.shrink(in, s.getWidth());

			
            if (false) Parameters.anchor.createPolygon(blockSize); // for dumping block layouts
            
			/*if (count == -69)
			{
				System.err.println("number of sheets is " + blockSize.getSheets().size());
				CEFPIterator cit = new CEFPIterator(blockSize.getMain().getFirst());
				while (cit.hasNext())
				{
					FlatPoint f = cit.next().thing;
					System.err.println(f + ",");// +f.getSpeed());
				}
			}*/

			if (blockSize != null)
				// blockSize may consist of two or more blocks due to shrinking shenagoats.
				for (int i = 0; i < blockSize.getSheets().size(); i++)
				{
					if (i >= 1)
						block = h.getNextBlock(s);
										
					block.setSheaf(blockSize.getSheetAsSheaf(i), c.isMerged()); // merge = concave
				}
		}

		// loop over all roads and call the appropriate street calculator on them!
	}

	public String getName()
	{
		return basicName + " plan generator ";
	}
}
