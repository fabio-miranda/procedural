package ssbd;

import geom.FlatPoint;

import java.util.List;

public interface NOISE_Dot extends NOISE_Core
{
	public List<FlatPoint> getPoint();
}
