package ssbd;

import geom.*;

import java.util.*;

import sity.Parameters;

import woof.*;

public class FREEZER_SlopeInRoof extends FREEZER<SlopeInRoof> implements NOISE_Panel
{
	public double steepnessOne, steepnessTwo;
	public double steepnessOneMin, steepnessTwoMin;

	public double height;
	
	public FREEZER_SlopeInRoof(SlopeInRoof w, Random r)
	{
		super(w, r);
	}

	public void doFreeze(Sheaf in, List<FREEZER> parent)
	{
		// nothing to do here, just get created!
	}

	public String getName()
	{
		return basicName + " I am a roof with a twist - two differing gradients";
	}

	public WoofPanel getWoofPanel(double startHeight, int storyCount, FlatPoint point, double storyHeight, WoofBuilder wb)
	{
		steepnessOne = Math.max(steepnessOneMin,steepnessOne);
		steepnessTwo = Math.max(steepnessTwoMin,steepnessTwo);
		
		DullRoof dw = new DullRoof(wb, point, steepnessOne ,startHeight);
		dw.setSpeedAt(height +startHeight, steepnessTwo);
		//System.err.println("heightOne "+startHeight+" height Two "+(height +startHeight));
		return addToWoofPanel(startHeight, storyCount, point, storyHeight, wb, dw);
	}

	public WoofPanel addToWoofPanel(double startHeight, int storyCount, FlatPoint point, double storyHeight, WoofBuilder wb, WoofPanel dw)
	{
		// no chaining, noting to do here
		return dw;
	}

}
