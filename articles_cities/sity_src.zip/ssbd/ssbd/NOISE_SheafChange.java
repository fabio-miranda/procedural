package ssbd;

import geom.Sheaf;
import woof.*;

/**For a panel that is assiated with a sheaf change for an overhand or a roof...
 * 
 * @author tomkelly
 *
 */
public interface NOISE_SheafChange extends NOISE_Core
{
	// a description of a woof, and height variables
	public WoofFloor getWoofFloor(int storyCount, double storyHeight, WoofBuilder wb);
	public void markGables(Sheaf in);
}
