package woof;

import geom.Sheaf;

public interface DoRoofWall {
 public void doRoofWall(Sheaf in);
}
