package woof;

import geom.FlatPoint;

public class DullRoof extends WoofPanel
{
	public DullRoof(WoofBuilder wb, FlatPoint init, double slope, double startHeight)
	{
		super(wb,init);
		setSpeedAt(startHeight, slope);
	}
}
