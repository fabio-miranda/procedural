package woof;

public enum Direction
{
	/**
	 * Whether we need to add a no additional sheet, one pointing down, one
	 * pointing up or in both directions - eg is this an overhang or a contraction?
	 */
	UP,DOWN,NONE, BOTH
}
