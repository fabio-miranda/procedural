package woof;

import static woof.Hvent.*;

import java.util.*;
import java.util.PriorityQueue;

import skeleton.Bones;

import geom.*;
import geom.Sheaf;

/**
 * Utility class, basically for simple transforms an extending class just registers a set of distances
 * 
 * @author people
 * 
 */
public abstract class WoofPanel extends Hvent
{

	protected PriorityQueue<PanelTransition> q = new PriorityQueue<PanelTransition>();

	protected FlatPoint point = null;

	public WoofPanel(WoofBuilder wb, FlatPoint initial)
	{
		super(wb);
		point = initial;
	}

	/**
	 * 
	 * @param in
	 * @return do we keep this point in the supporting roofbuilder?
	 */
	public boolean update(Bones in)
	{
		boolean out = true;
		// only if this isnt a big event!
		if (point != null)
		{
			Map<FlatPoint, FlatPoint> map = in.getIO();
			// for (FlatPoint f: map.keySet())
			// System.err.println("map contains " +f+" to "+map.get(f));
			FlatPoint n = map.get(point);
			// no longer - not in new flatTop
			if (n == null)
			{
				out = false;
				//System.err.println("I'm not in the output map "+this.getClass().getSimpleName());
			}
			// System.err.println("next pointeo is "+n);
			point = n;
		}
		return out;
	}

	public Sheaf makeChanges(Sheaf in)
	{
		if (point != null) // another on the same layer may have emptied the sheaf
		{
			PanelTransition pt = q.poll();
			// System.err.println("makeChanges called"+point);
			assert (point != null);
			point.setSpeed(pt.getSpeed());
			return in;
		}
		//else
		//{
		//	System.err.println("a point is null");
		//}
		return in;
	}

	public void setNextHeight()
	{
		PanelTransition pt = q.peek();
		if (pt != null && point != null)
		{
			nextHeight = pt.getHeight();
		}
		else
		{
			nextHeight = Hvent.ALLDONE;
		}
	}

	public double getInitialSpeed()
	{
		// System.err.println("getInital speed called");
		PanelTransition pt = q.peek();
		if (pt == null || pt.getHeight() == ALLDONE)
			return 0; // defult is straight up!
		// if theres one at zero, return it, and remove it from the queue
		if (pt.getHeight() == 0)
			return q.poll().getSpeed();
		// otherwise....I guess we go with the defualt of 0;
		return 0;
	}

	public void setSpeedAt(double height, double speed)
	{
		// intitial speed
		q.add(new PanelTransition(height, speed));
	}

}
