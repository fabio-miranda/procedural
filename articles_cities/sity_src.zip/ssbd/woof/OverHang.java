package woof;

import geom.*;

import java.util.*;

import javax.vecmath.*;

import sity.Parameters;
import skeleton.*;
import ssbd.FREEZER_FloorPlan;
import util.CEFPIterator;

public class OverHang extends WoofFloor
{
	double front;
	double back;
	double sides;
	double drop;
	SetupPanel setup;

	// speeds of in cache...
	private Map<FlatPoint, Double> speed = new LinkedHashMap<FlatPoint,Double>();
	
	public OverHang(WoofBuilder wb, double height, double front, double sides, double back, double drop, SetupPanel sPanel)
	{
		super(wb);
		this.front = front;
		this.back = back;
		this.sides = sides;
		this.drop = drop;
		setup = sPanel;
		nextHeight = height;
	}
	
	public Sheaf makeChanges(Sheaf in)
	{
		cacheSpeeds(in);
		Sheaf out = null;
		
		try
		{
			woofBuilder.deleteAllEvents();
			Sheaf next = new Sheaf(in);
			for (Sheet s: in.getSheets())
			{
				CEFPIterator cit = new CEFPIterator(s);
				while (cit.hasNext())
				{
					FlatPoint f= cit.next().thing;
					if (f.ofType(EdgeType.FRONT))
					{
						f.setSpeed(-front);
					}
					else if (f.ofType(EdgeType.BEVELTOP))
					{
						f.setSpeed(-back);
					}
					else if (f.ofType(EdgeType.SIDE))
					{
						f.setSpeed(-sides);
					}
				}
			}
			Bones b = new Bones(next, 1., -drop);
			
			// create the top - the shape we want
			out = b.getFlatTop();
			
			//Parameters.anchor.createPolygon(out);
			
			// create side panels to fill in gap
			for (Sheaf f: b.getWoof(-drop))
				Parameters.anchor.createPolygon(f);
			
			// now we gotta set up this new panel with the woof builder...
			// now create a new woof builder
			woofBuilder.addSheaf(out,setup.getPanel(out, woofBuilder));
			return out;
		}
		catch (BonesSaysNoException e)
		{
			// argh, only sensible thing to do!:
			Parameters.error("error in overhang");
			Parameters.anchor.createPolygon(in);
			if (out != null) return out;
			restoreSpeeds(in);
			return in;
		}
	}

	/**
	 * have to set and reset speeds - is there an argument for letting the points
	 * have a pushable/popable stack of speeds and types for different circumstanes?
	 */
	private void cacheSpeeds(Sheaf in)
	{
		for (Sheet s : in.getSheets())
		{
			CEFPIterator cit = new CEFPIterator(s);
			while (cit.hasNext())
			{
				FlatPoint f = cit.next().thing;
				speed.put(f,f.getSpeed());
			}
		}
	}
	
	private void restoreSpeeds(Sheaf in)
	{
		for (Sheet s : in.getSheets())
		{
			CEFPIterator cit = new CEFPIterator(s);
			while (cit.hasNext())
			{
				FlatPoint f= cit.next().thing;
				Double d = speed.get(f);
				if (d != null)
				{
					//System.err.println("restoring speed of "+f+" to "+d);
					f.setSpeed(d);
				}
			}
		}
	}

	public Sheaf getWall()
	{
		return null;
	}

	public void setNextHeight()
	{
		nextHeight = ALLDONE;
	}
}
