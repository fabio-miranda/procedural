package woof;

import geom.*;

import java.util.*;

import junit.framework.TestCase;
import sity.Parameters;
import skeleton.BonesSaysNoException;
import util.*;

public class WoofBuilderTest extends TestCase
{
	public void testWoofBuilder() throws Exception
	{
		Parameters.setupParameters();
		
		Map<FlatPoint,WoofPanel> map = new LinkedHashMap<FlatPoint,WoofPanel>();
		
		SheetStaticBuilder sb = new SheetStaticBuilder();
		sb.addPoint(0.0, 0.0);
		sb.addPoint(0.0, 10.0);
		sb.addPoint(10.0, 10.0);
		sb.addPoint(10.0, 0.0);

		Sheaf start = sb.makeSheaf();
		
		Sheet main = start.getMain();
		CEFPIterator cit = new CEFPIterator(main);

		WoofBuilder wb = new WoofBuilder();
		
		while (cit.hasNext())
		{
			CEFP c = cit.next();
			FlatPoint f= c.thing;
			// mark all points as being very dull walls
			map.put(f,new DullWall(wb,f,2,1.0,0));
		}
		// add in a roof
		wb.addBigEvent(new SlopeRoof(wb,3, 3, 1, 1));
		
		// let it rip on the currently defined anchor!
		try
		{
			System.err.println("start size is "+start.getMain().size());
			wb.go(start, map);
		}
		catch (BonesSaysNoException e)
		{
			System.err.println("bones said no!");
		}
	}
}
