package woof;

import geom.Sheaf;

public abstract class WoofFloor extends Hvent
{
	public WoofFloor(WoofBuilder wb)
	{
		super(wb);
	}

	public Sheaf makeChanges(Sheaf in)
	{
		return null;
	}
	
	public void setNextHeight()
	{
		
	}
}
