package woof;

public interface Decorator
{

}
