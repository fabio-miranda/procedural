package woof;

import geom.*;
import geom.Sheaf;
import sity.Parameters;
import skeleton.*;
import ssbd.NOISE_Subdiv;
import util.CEFPIterator;

public class FlatRoof extends WoofFloor
{
	private double wall;

	private DoRoofWall fence;

	public FlatRoof(WoofBuilder wb, double height, double wall, DoRoofWall fence)
	{
		super(wb);
		this.wall = wall;
		nextHeight = height;
		this.fence = fence;
	}

	public Sheaf makeChanges(Sheaf in)
	{
		// if we've got a wall, shrink in and make that wall

		if (wall > 0)
		{
			Sheet main = in.getMain();
			CEFPIterator cit;
			// first up if there is a border, try to make a wall in it

			cit = main.iterator();
			// first set all the speeds
			while (cit.hasNext())
				cit.next().thing.setSpeed(wall);
			try
			{
				Bones b = new Bones(in, 1.0, true);
				cit = main.iterator();
				while (cit.hasNext())
				{
					FlatPoint next = cit.next().thing;
					next.addType(EdgeType.GUTTER);
				}

				Sheaf topWall = b.getGutter();
				if (topWall != null)
					fence.doRoofWall(topWall);
				Sheaf middle = b.getFlatTop();
				// should pass middle somewhere?
				Parameters.anchor.createPolygon(middle);
			}
			catch (BonesSaysNoException e)
			{
				// just make the roof
				Parameters.anchor.createPolygon(in);
			}
		}
		else
		{
			Parameters.anchor.createPolygon(in);			
		}
		// there is nothing to return!
		return null;
	}

	public Sheaf getWall()
	{
		return null;
	}

	public void setNextHeight()
	{
		nextHeight = ALLDONE;
	}
}
