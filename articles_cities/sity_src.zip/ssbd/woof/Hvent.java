package woof;

import geom.Sheaf;
import sity.Parameters;

/**
 * Height event, basically a modification of a Sheaf that is triggered at a given height
 * 
 * @author people
 * 
 */
public abstract class Hvent implements Comparable
{
	// taf for no more events!
	public final static double ALLDONE = -Double.MAX_VALUE;

	protected double nextHeight = ALLDONE;

	// this is the last flatpoint operated apon, and is updated to the next layer
	// after each HVent, if null we are not associated with a point, rather we operate
	// on the whole sheaf, eg a roof change!

	protected WoofBuilder woofBuilder;

	public Hvent(WoofBuilder wb)
	{
		woofBuilder = wb;
	}

	
	/**
	 * This can return null to say it is finished
	 * 
	 * responsiblity to retain the same points in the output sheaf if you want them to act the
	 * same!
	 * 
	 * @param in
	 * @return
	 */
	public final Sheaf doIt(Sheaf in)
	{
		Sheaf out = makeChanges(in);
		setNextHeight();
		return out;
	}

	/**
	 * inform that we need to add a sheet going in up directions
	 */
	protected void setUp()
	{
		woofBuilder.setUp();
	}

	/**
	 * inform that we need to add a sheet going in up directions
	 */
	protected void setDown()
	{
		woofBuilder.setDown();
	}

	public abstract Sheaf makeChanges(Sheaf in);

	public abstract void setNextHeight();

	public int compareTo(Object arg0)
	{
		if (arg0 instanceof Hvent)
		{
			Hvent other = Hvent.class.cast(arg0);
			if (other.getNextHeight() < nextHeight)
			{
				return 1;
			}
			else if (other.getNextHeight() > nextHeight)
			{
				return -1;
			}
			else
				if (arg0 instanceof WoofPanel && this instanceof WoofFloor)
				{
					return -1;
				}
				else if (arg0 instanceof WoofFloor && this instanceof WoofPanel)
				{
					return 1;
				} // otherwise both are same...!
				else return 0;
		}
		else
		{
			Parameters.fatalErrorSD("trying to compare wiht non-Hvent!");
			return 0;
		}
		// TODO Auto-generated method stub
	}

	public double getNextHeight()
	{
		return nextHeight;
	}

	public void setNextHeight(double nextHeight)
	{
		this.nextHeight = nextHeight;
	}

}
