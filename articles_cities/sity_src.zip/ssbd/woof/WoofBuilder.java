package woof;

import static woof.Direction.*;
import static woof.Hvent.ALLDONE;
import static sity.Parameters.*;
import geom.*;

import java.util.*;

import sity.Parameters;
import skeleton.*;
import util.*;

public class WoofBuilder
{
	private PriorityQueue<Hvent> q;

	//private Sheaf start;

	// after running
	private Direction direction = NONE;

	
	public WoofBuilder()
	{
		q = new PriorityQueue<Hvent>();
	}

	public void addSheaf(Sheaf start, Map<FlatPoint, WoofPanel> panels)
	{
		for (Sheet s : start.getSheets())
		{
			CEFPIterator cit = new CEFPIterator(s.getFirst());
			while (cit.hasNext())
			{
				CEFP c = cit.next();
				WoofPanel wp = panels.get(c.thing);
				if (wp != null)
				{
					double initSpeed = wp.getInitialSpeed();
					c.thing.setSpeed(initSpeed);
					wp.setNextHeight();
					q.add(wp);
				}
				else
					Parameters.error("point not in initial hash in WoofBuilder");

			}
		}		
	}
	
	/**
	 * Perform operations to construct whatever geometry has been created. Adds output direct to the anchor...returns whatever is left at the end, or nul
	 * 
	 * @return the resulting sheaf, if any
	 * 
	 */
	public Sheaf go(Sheaf start, Map<FlatPoint, WoofPanel> panels) throws BonesSaysNoException
	{
		// set up data
		addSheaf(start, panels);

		// for (Hvent h : q)
		// {
		// System.err.println("there is an event at "+h.getNextHeight());
		// }

		// now work through the items in the queue...
		Sheaf current = start;
		double oldHeight = 0, height = 0;
		
		boolean done = false;
		Hvent tmp = q.peek();

		// ditch any unwated events
		while (!done)
		{
			if (tmp.getNextHeight() == ALLDONE)
			{
				q.poll();
				tmp = q.peek();
				done = false;
			}
			else done = true;
		}
		
		while (q.size() > 0 && current != null)
		{

			Hvent next = q.peek();
			height = next.getNextHeight();
			fixUp(current);
			// now all operations have been performed, extend the skeleton up to the next level
			Bones b = new Bones(current, height - oldHeight, false);
			current = b.getFlatTop();
			
			// output that last set of bones
			List<Sheaf> woof = b.getWoof();
			for (Sheaf s : woof)
				anchor.createPolygon(s);

			// now update using bones structure so all point point to current location
			Set<Hvent> remove = new LinkedHashSet<Hvent>();
			for (Hvent h : q)
				if (h instanceof WoofPanel)
				{
					boolean keep = WoofPanel.class.cast(h).update(b);
					if (!keep)
						remove.add(h);
				}
			for (Hvent h : remove)
				q.remove(h);

			//System.err.println("q aize is " + q.size());

			// now grow at current speeds to this level
			//direction = NONE;

			// for all those with the same height
			while (current != null && next != null && next.getNextHeight() == height && q.size() > 0)
			{

				Hvent h = q.poll();
				height = h.getNextHeight();
				if (height != ALLDONE)
				{
					//System.err.println("another event at " + h.getNextHeight()+" q size "+q.size());
					// perform changes to sheaf and set new height
					current = h.doIt(current);
				}
				
				// if there is another event, add it back in
				if (h.getNextHeight() != ALLDONE)
					q.add(h);
				
				
				next = q.peek();
			}

			oldHeight = height;
		}
		
		
		
		// just check nothing else going on...
		if (current != null)
		{
			fixUp(current);
			Bones b = new Bones(current, Double.MAX_VALUE, false);
			// output that last set of bones
			List<Sheaf> woof = b.getWoof();
			for (Sheaf s : woof)
				anchor.createPolygon(s);
		}
		else
		{
			System.err.println("output was null at some stage");
		}
		// assume output is nothing for now: ie: roof is complete
		return null;
	}

	protected void deleteAllEvents()
	{
		while (q.size() != 0) q.poll();
	}
	
	/**
	 * inform that we need to add a sheet going in up directions
	 */
	protected void setUp()
	{
		if (direction == NONE)
			direction = UP;
		if (direction == DOWN)
			direction = BOTH;
	}

	/**
	 * inform that we need to add a sheet going in up directions
	 */
	protected void setDown()
	{
		if (direction == NONE)
			direction = DOWN;
		if (direction == UP)
			direction = BOTH;
	}

	/**
	 * ensures all speeds are set and are not too negative
	 * @param in
	 */
	private void fixUp(Sheaf in)
	{
		
		
		for (Sheet s: in.getSheets())
		{
			
			if (Vec2d.findArea(s) < 0) s.reverse(); // reliability code
			
			CEFPIterator cit = s.iterator();
			while (cit.hasNext())
			{
				FlatPoint f = cit.next().thing;
				//if (f.getSpeed() < -1) f.setSpeed(0.1);
			}
		}
	}
	
	/**
	 * Add a large event, such as changing to a roof... should eventually add to just a specific group of edges?
	 * 
	 * @param in
	 */
	public void addBigEvent(Hvent in)
	{
		q.add(in);
	}

	public PriorityQueue<Hvent> getQ()
	{
		return q;
	}
}
