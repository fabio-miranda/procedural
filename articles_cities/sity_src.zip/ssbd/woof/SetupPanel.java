package woof;

import geom.*;

import java.util.Map;

public interface SetupPanel
{
	public Map<FlatPoint,WoofPanel> getPanel(Sheaf in, WoofBuilder wb);
}
