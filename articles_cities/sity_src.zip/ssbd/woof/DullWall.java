package woof;

import geom.FlatPoint;

public class DullWall extends WoofPanel
{
	public DullWall(WoofBuilder wb, FlatPoint init, int storyCount, double storyHeight, double initalSpeed)
	{
		super(wb,init);
		if (initalSpeed != Hvent.ALLDONE) setSpeedAt(0,initalSpeed);
	}
}
