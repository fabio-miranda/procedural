package woof;


public class PanelTransition implements Comparable
{
	private double height;
	private double speed;
	public PanelTransition(double height, double speed)
	{
		super();
		// TODO Auto-generated constructor stub
		this.height = height;
		this.speed = speed;
	}
	
	/**
	 * sorted by minimum value!
	 * 
	 * @param arg0
	 * @return
	 */
	public int compareTo(Object arg0)
	{
		if (arg0 instanceof PanelTransition)
		{
			PanelTransition other = PanelTransition.class.cast(arg0);
			if (other.getHeight() < height)
				return  1;
			if (other.getHeight() > height)
				return -1;
			return 0;
		}
		return 0;
	}
	public double getHeight()
	{
		return height;
	}
	public void setHeight(double height)
	{
		this.height = height;
	}
	public double getSpeed()
	{
		return speed;
	}
	public void setSpeed(double speed)
	{
		this.speed = speed;
	}
	
}
