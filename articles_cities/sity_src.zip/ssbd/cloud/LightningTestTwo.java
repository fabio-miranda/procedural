package cloud;

import static sity.Parameters.setupParameters;
import geom.FlatPoint;

import java.util.*;

import junit.framework.TestCase;

public class LightningTestTwo extends TestCase
{
//	 regular octagon	
	final static double l = 1.0/(Math.sqrt(2))+0.5; 
	double data[][] = {{-0.5,l,1},{0.5,l,1},{l,0.5,1},{l,-0.5,1},{0.5,-l,1},{-0.5,-l,1},{-l,-0.5,1},{-l,0.5,1}};
	
	public void cctestOctagon() throws Exception
	{
		setupParameters();
		FlatPoint[] border = new FlatPoint[data.length];
		for (int c  = 0; c < data.length; c++)
			border[c] = new FlatPoint(data[c][0],data[c][1]);
		
		FlatPoint[] points = {new FlatPoint(-0.1,0),new FlatPoint(0.1,0)};
		List<FlatPoint> p2 = new ArrayList<FlatPoint>();
		for (FlatPoint f: points) p2.add(f);
		
		PointCloud pc = new PointCloud(p2, border);
		Lightning l = new Lightning(pc);
		l.show();
		
		
		assertTrue("size of cell count should be 2, but is "+pc.getCells().size() ,pc.getCells().size() == 2);
		
		FlatPoint[] points4 = {new FlatPoint(-0.1,0),new FlatPoint(0.1,0),new FlatPoint(0, 0.1),new FlatPoint(0,-0.1)};
		p2 = new ArrayList<FlatPoint>();
		for (FlatPoint f: points4) p2.add(f);
		pc = new PointCloud(p2, border);
		l = new Lightning(pc);
		assertTrue("size of cell count should be 4, but is "+pc.getCells().size() ,pc.getCells().size() == 4);
		
	}
	
	public void cctestOctCentre() throws Exception
	{
		setupParameters();
		FlatPoint[] border = new FlatPoint[data.length];
		for (int c  = 0; c < data.length; c++)
			border[c] = new FlatPoint(data[c][0],data[c][1]);
		//FlatPoint[] points = {new FlatPoint(-0.5,0),new FlatPoint(0,-0.5), new FlatPoint(0,0)};
		FlatPoint[] points = {new FlatPoint(-0.5,0),new FlatPoint(0.5,0),new FlatPoint(0, 0.5),new FlatPoint(0,-0.5), new FlatPoint(0,0)};
		List<FlatPoint> p2 = new ArrayList<FlatPoint>();	
		for (FlatPoint f: points) p2.add(f);
		PointCloud pc = new PointCloud(p2, border);
		Lightning l = new Lightning(pc);

		assertTrue("size of cell count should be 2, but is "+pc.getCells().size() ,pc.getCells().size() == points.length);
		l.show();
	}
	
	double square[][] = {{0,0},{0,10},{10,10},{10,0}};
	
	public void testregularTest()
	{
		setupParameters();
		FlatPoint[] border = new FlatPoint[square.length];
		for (int c  = 0; c < square.length; c++)
			border[c] = new FlatPoint(square[c][0],square[c][1]);
		//FlatPoint[] points = {new FlatPoint(-0.5,0),new FlatPoint(0,-0.5), new FlatPoint(0,0)};
		
		Lightning.DEBUG = true;

		int s = 3;
		FlatPoint[] points = new FlatPoint[s*s];
		for (int i = 0; i < s; i++)
		{
			for (int j = 0; j < s; j++)
			{
				points[i+j*s] = new FlatPoint(i+1,j+1);
			}
		}
		List<FlatPoint> p2 = new ArrayList<FlatPoint>();	
		for (FlatPoint f: points) p2.add(f);
		
		PointCloud pc = new PointCloud(p2, border);
		try
		{
		Lightning l = new Lightning(pc);

		assertTrue("size of cell count should be 2, but is "+pc.getCells().size() ,pc.getCells().size() == points.length);
		l.show();
		}
		catch (CloudSaysNoException e)
		{
			assertFalse(true);
		}


	}
}
