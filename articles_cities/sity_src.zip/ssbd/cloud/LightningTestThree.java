package cloud;

import static sity.Parameters.setupParameters;
import geom.FlatPoint;

import java.util.*;

import junit.framework.TestCase;

public class LightningTestThree extends TestCase
{
	// regular octagon
	final static double l = 1.0 / (Math.sqrt(2)) + 0.5;

	double data[][] = { { -0.5, l, 1 }, { 0.5, l, 1 }, { l, 0.5, 1 }, { l, -0.5, 1 }, { 0.5, -l, 1 }, { -0.5, -l, 1 }, { -l, -0.5, 1 }, { -l, 0.5, 1 } };

	public void xxtestOctagon() throws Exception
	{
		setupParameters();
		FlatPoint[] border = new FlatPoint[data.length];
		for (int c = 0; c < data.length; c++)
			border[c] = new FlatPoint(data[c][0], data[c][1]);

		FlatPoint[] points = { new FlatPoint(-0.1, 0), new FlatPoint(0.1, 0) };
		List<FlatPoint> p2 = new ArrayList<FlatPoint>();
		for (FlatPoint f : points)
			p2.add(f);

		// PointCloud pc = new PointCloud(p2, border);
		// Lightning l = new Lightning(pc);
		// l.show();

		// assertTrue("size of cell count should be 2, but is "+pc.getCells().size() ,pc.getCells().size() == 2);
		double d = 0.1;

		FlatPoint[] points4 = { new FlatPoint(-d, 0), new FlatPoint(d, 0), new FlatPoint(0, d), new FlatPoint(0, -d) };
		p2 = new ArrayList<FlatPoint>();
		for (FlatPoint f : points4)
			p2.add(f);

		PointCloud pc = new PointCloud(p2, border);
		Lightning l = new Lightning(pc);
		l.show();
		assertTrue("size of cell count should be 4, but is " + pc.getCells().size(), pc.getCells().size() == 4);

		// check that we are merging 180 degree line sections to one
		for (Cell c : pc.getCells())
		{
			assertTrue("failed merging line segments ", c.getWall().size() == 5);
		}
	}

	public void cctestOctCentre() throws Exception
	{
		setupParameters();
		FlatPoint[] border = new FlatPoint[data.length];
		for (int c = 0; c < data.length; c++)
			border[c] = new FlatPoint(data[c][0], data[c][1]);
		// FlatPoint[] points = {new FlatPoint(-0.5,0),new FlatPoint(0,-0.5), new FlatPoint(0,0)};
		FlatPoint[] points = { new FlatPoint(-0.5, 0), new FlatPoint(0.5, 0), new FlatPoint(0, 0.5), new FlatPoint(0, -0.5), new FlatPoint(0, 0) };
		List<FlatPoint> p2 = new ArrayList<FlatPoint>();
		for (FlatPoint f : points)
			p2.add(f);
		PointCloud pc = new PointCloud(p2, border);
		Lightning l = new Lightning(pc);

		assertTrue("size of cell count should be 2, but is " + pc.getCells().size(), pc.getCells().size() == points.length);
		l.show();
	}

	double square[][] = { { 0, 0 }, { 0, 10 }, { 10, 10 }, { 10, 0 } };

	public void xxtestregularTest()
	{
		setupParameters();
		FlatPoint[] border = new FlatPoint[square.length];
		for (int c = 0; c < square.length; c++)
			border[c] = new FlatPoint(square[c][0], square[c][1]);
		// FlatPoint[] points = {new FlatPoint(-0.5,0),new FlatPoint(0,-0.5), new FlatPoint(0,0)};

		Lightning.DEBUG = false;

		long count  = 0;
		
		while (true)
		{
			count++;
			int s = 9;
			FlatPoint[] points = new FlatPoint[s * s];
			List<FlatPoint> p3 = new ArrayList<FlatPoint>();

			for (int i = 0; i < s; i++)
			{
				for (int j = 0; j < s; j++)
				{
					// points[i+j*s] = new FlatPoint(i+1,j+1);
					p3.add(new FlatPoint(i + 1, j + 1));
				}
			}

			//Collections.shuffle(p3, new Random(5540l));
			Collections.shuffle(p3, new Random(count));
			for (int i = 0; i < p3.size(); i++)
				points[i] = p3.get(i);

			List<FlatPoint> p2 = new ArrayList<FlatPoint>();
			for (FlatPoint f : points)
				p2.add(f);

			Lightning.DEBUG = false;
			//Lightning.DEBUG = true;
			System.err.println("*****************************))))))))))))))))))))))))))))))))"+count);
			PointCloud pc = new PointCloud(p2, border);
			try
			{
			Lightning l = new Lightning(pc);
			}
			catch  (CloudSaysNoException e){}
			
			assertTrue("size of cell count should be 2, but is " + pc.getCells().size(), pc.getCells().size() == points.length);
			 //l.show();
		}

	}
}
