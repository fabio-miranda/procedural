package cloud;

import geom.FlatPoint;

/**
 * a wall segment to be added at a later date to the shape we are currently carving
 * @author people
 *
 */
public class WallSegment
{
	private Wall wall;
	private Cell nextCell;
	private FlatPoint nextPoint;
	
	public WallSegment(Wall wall, Cell nextCell, FlatPoint nextPoint)
	{
		this.wall = wall;
		this.nextCell = nextCell;
		this.nextPoint = nextPoint;
	}
	
	public String toString()
	{
		FlatPoint start = wall.getStart(wall.getOne());
		return "wallSeg from "+ start+"("+start.hashCode()+") to "+ wall.getEnd(wall.getOne());
	}
	
	public Cell getNextCell()
	{
		return nextCell;
	}
	public void setNextCell(Cell nextCell)
	{
		this.nextCell = nextCell;
	}
	public FlatPoint getNextPoint()
	{
		return nextPoint;
	}
	public void setNextPoint(FlatPoint nextPoint)
	{
		this.nextPoint = nextPoint;
	}
	public Wall getWall()
	{
		return wall;
	}
	public void setWall(Wall wall)
	{
		this.wall = wall;
	}
}
