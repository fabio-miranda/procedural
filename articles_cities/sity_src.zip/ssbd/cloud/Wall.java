package cloud;

import static sity.Parameters.anchor;
import static skyHook.AnchorStatics.createArrow;
import geom.FlatPoint;

import java.awt.Color;

import javax.vecmath.Vector3d;

import sity.Parameters;
/**
 * A cell boundary
 * 
 * @author people
 * 
 */
public class Wall implements Comparable
{
	private Cell one, two;

	private FlatPoint start, end;

	private double speed;

	private PointCloud pointCloud;
	
	private Cell ownsWall = null;
	
	public Wall(Cell one, Cell two, FlatPoint start, FlatPoint end, double speed, PointCloud pointCloud)
	{
		this.one = one;
		this.two = two;
		this.start = end;
		this.end = start;
		this.speed = speed;
		this.pointCloud = pointCloud;
	}
	public Wall(Cell one, Cell two, FlatPoint start, FlatPoint end, PointCloud pc)
	{
		// not so dum constructor...
		this(one, two, start, end, 1.0, pc);
	}

	public String toString()
	{
		return "[from "+end+" to "+start+"]";
	}
	
	public void show(Cell c, double height)
	{
		anchor.setColor(Color.blue);
		Vector3d a = new Vector3d(getStart(c).x, 0, getStart(c).y);
		Vector3d b = new Vector3d(getEnd  (c).x, 0, getEnd  (c).y);
		createArrow(a,b,height+0.,height+1);
		
		a.add(b);
		a.scale(0.5);
		anchor.setColor(Color.red);
		
		if (one != null)
		{
			Vector3d o1 = new Vector3d(one.getCentre().x, 0, one.getCentre().y);
			createArrow(a,o1,height, height+0.5);
		}
		if (two!= null)
		{
			Vector3d o2 = new Vector3d(two.getCentre().x, 0, two.getCentre().y);
			createArrow(a,o2,height, height+0.5);
		}
	}
	
	public boolean hasCell (Cell in)
	{
		return one == in || two == in;
	}
	
	public Cell getOther(Cell a)
	{
		if (a==one) return two;
		if (a==two) return one;
		Parameters.fatalErrorSD("Shouldn't get to here in wall");
		return null;
	}
	
	public FlatPoint getOtherEnd(FlatPoint a)
	{
		if (a == start) return end;
		if (a == end) return start;
		Parameters.fatalErrorSD("getOtherEnd doesn't find another end");
		return null;
	}
	
	/**
	 * Replaces all ownership of cell a to cell b, 
	 * @param a
	 * @param b
	 */
	public void change(Cell a, Cell b)
	{
		if (one == a) one = b;
		if (two == a) two = b;
	}
	
	public FlatPoint getEnd(Cell s)
	{
		if (s == one)
			return end;
		return start;
	}

	public Cell getOne()
	{
		return one;
	}

	public void setOne(Cell one)
	{
		this.one = one;
	}

	public double getSpeed()
	{
		return speed;
	}

	public void setSpeed(double speed)
	{
		this.speed = speed;
	}

	public FlatPoint getStart(Cell s)
	{
		if (s == one)
			return start;
		return end;
	}

	public void setEnd(FlatPoint end, Cell relative)
	{
		boolean inSkin = false;
		if (pointCloud.getSkin().containsKey(this)) inSkin = true;
		if (inSkin) pointCloud.removeFromSkin(this);
		if (relative == one)
			this.end = end;
		else if (relative == two)
			this.start = end;
		else Parameters.fatalErrorSD("cell rlative invalid");
		if (inSkin) pointCloud.addToSkin(this);
	}
	
	public void setStart(FlatPoint start, Cell relative)
	{
		boolean inSkin = false;
		if (pointCloud.inSkin(this)) 
			{
				inSkin = true;
				pointCloud.removeFromSkin(this);
			}
		if (relative == one)
			this.start = start;
		else if (relative == two)
			this.end = start;
		else Parameters.fatalErrorSD("cell rlative invalid");
		
		if (inSkin) pointCloud.addToSkin(this);
	}

	public void swapCells()
	{
		Cell tmp = one;
		one = two;
		two = tmp;
	}
	
	/**
	 * reverses ends and cells. should be unnecessary?
	 *
	 */
	public void swapEnds()
	{
		Cell tmp = one;
		one = two;
		two = tmp;
		
		FlatPoint tp = start;
		start = end;
		end = tp;
	}
	
	public Cell getTwo()
	{
		return two;
	}

	public void setTwo(Cell two)
	{
		this.two = two;
	}
	public int compareTo(Object arg0)
	{
		return arg0.hashCode() - this.hashCode();
	}
	public Cell getOwnsWall()
	{
		return ownsWall;
	}
	public void setOwnsWall(Cell ownsWall)
	{
		this.ownsWall = ownsWall;
	}
	
}
