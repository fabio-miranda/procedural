package cloud;

import geom.FlatPoint;

import java.util.*;

public class DistanceFromComparitor implements Comparator
{
	private List<Cell> list = new ArrayList<Cell>();
	
	public DistanceFromComparitor (Set<Cell>set , FlatPoint f)
	{
		for (Cell c: set)
		{
			c.tmpDist = f.distanceTo(c.getCentre());
			list.add(c);
		}
		
		Collections.sort(list, this);
	}
	
	public List<Cell> getList()
	{
		return list;
	}

	public int compare(Object arg0, Object arg1)
	{
		assert(arg0 instanceof Cell);
		assert(arg1 instanceof Cell);
		Cell a = Cell.class.cast(arg0);
		Cell b = Cell.class.cast(arg1);
		if (a.tmpDist < b.tmpDist) return -1;
		if (a.tmpDist > b.tmpDist) return 1;
		return 0;
	}

}
