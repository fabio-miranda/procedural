package cloud;

import static sity.Parameters.setupParameters;

import java.util.*;

import geom.FlatPoint;
import junit.framework.TestCase;

public class CellTest extends TestCase
{
	final static double l = 1.0/(Math.sqrt(2))+0.5; 
	double data[][] = {{-0.5,l,1},{0.5,l,1},{l,0.5,1},{l,-0.5,1},{0.5,-l,1},{-0.5,-l,1},{-l,-0.5,1},{-l,0.5,1}};
	
	public void xxtestCellMerge() throws Exception
	{
		//double data1[][] = { { 0, 0 }, { 0, 1 }, { 2, 1 }, { 2, 0 } };
		//double data2[][] = { { 2, 0 }, { 2, 1 }, { 2, 2 }, { 3, 2 }, { 3, 0 }, };

		setupParameters();
		FlatPoint[] border = new FlatPoint[data.length];
		for (int c  = 0; c < data.length; c++)
			border[c] = new FlatPoint(data[c][0],data[c][1]);
		
		FlatPoint[] points = {new FlatPoint(-1,0),new FlatPoint(1,0),new FlatPoint(0,1)};
		List<FlatPoint> p2 = new ArrayList<FlatPoint>();
		for (FlatPoint f: points) p2.add(f);
		
		PointCloud pc = new PointCloud(p2, border);
		Lightning l = new Lightning(pc);
		l.show();
		Iterator<Cell> cit = pc.getCells().iterator();
		Cell a= cit.next();
		Cell b=cit.next();
		a.merge(b,pc);
		l.show();	
	}
	
	public void xxtestCellMergeRandom() throws Exception
	{
		setupParameters();
		FlatPoint[] border = new FlatPoint[data.length];
		for (int c  = 0; c < data.length; c++)
			border[c] = new FlatPoint(data[c][0],data[c][1]);
		
		FlatPoint[] points = {new FlatPoint(-1,0),new FlatPoint(1,0),new FlatPoint(0,1),new FlatPoint(0,-1)};
		List<FlatPoint> p2 = new ArrayList<FlatPoint>();
		for (FlatPoint f: points) p2.add(f);
		
		PointCloud pc = new PointCloud(p2, border);
		Lightning l = new Lightning(pc);
		l.show();
		SilverLining.mergeRandom(pc,0.5,new Random());
		l.show();	
	}
	
	
	public void xxtestCellMergeSmall() throws Exception
	{
		setupParameters();
		FlatPoint[] border = new FlatPoint[data.length];
		for (int c  = 0; c < data.length; c++)
			border[c] = new FlatPoint(data[c][0],data[c][1]);
		
		FlatPoint[] points = {new FlatPoint(-0.2,0),new FlatPoint(0.2,0),new FlatPoint(0,0.2),new FlatPoint(0,-0.2),new FlatPoint(0,0)};
		List<FlatPoint> p2 = new ArrayList<FlatPoint>();
		for (FlatPoint f: points) p2.add(f);
		
		PointCloud pc = new PointCloud(p2, border);
		Lightning l = new Lightning(pc);
		l.show();
		//SilverLining.mergeSmall(pc,0.2*0.25, new Random());
		SilverLining.mergeSmallTillNoMore(pc,0.2*0.25, new Random());
		l.show();	
	}
	
	public void testCellMergeTwoSided() throws Exception
	{
		//double data1[][] = { { 0, 0 }, { 0, 1 }, { 2, 1 }, { 2, 0 } };
		//double data2[][] = { { 2, 0 }, { 2, 1 }, { 2, 2 }, { 3, 2 }, { 3, 0 }, };

		setupParameters();
		FlatPoint[] border = new FlatPoint[data.length];
		for (int c  = 0; c < data.length; c++)
			border[c] = new FlatPoint(data[c][0],data[c][1]);
		
		FlatPoint[] points = {new FlatPoint(-1,0),new FlatPoint(1,0),new FlatPoint(0,1),new FlatPoint(0,-1)};
		List<FlatPoint> p2 = new ArrayList<FlatPoint>();
		for (FlatPoint f: points) p2.add(f);
		
		PointCloud pc = new PointCloud(p2, border);
		Lightning l = new Lightning(pc);
		l.show();
		Iterator<Cell> cit = pc.getCells().iterator();
		cit.next();
		Cell a= cit.next();
		Cell b=cit.next();
		System.err.println("merging cells with centres "+a.getCentre()+" and "+b.getCentre());
		a.merge(b,pc);
		
		l.show();
		
		cit = pc.getCells().iterator();
		a= cit.next();
		cit.next();
		b=cit.next();
		System.err.println("merging cells with centres "+a.getCentre()+" and "+b.getCentre());
		System.err.println("starting second merge");
		a.merge(b,pc);
		System.err.println("done");
		pc.removeCell(b);
		
		l.show();	
		
		cit = pc.getCells().iterator();
		a= cit.next();
		b=cit.next();
		System.err.println("merging cells with centres "+a.getCentre()+" and "+b.getCentre());
		System.err.println("starting second merge");
		a.merge(b,pc);
		System.err.println("done");
		pc.removeCell(b);
		
		l.show();	
		
	}
	
}
