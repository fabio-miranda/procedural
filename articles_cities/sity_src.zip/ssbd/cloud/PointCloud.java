package cloud;

import static sity.Parameters.anchor;
import static skyHook.AnchorStatics.createCube;
import geom.*;

import java.util.*;

import java.awt.Color;

import javax.vecmath.Vector2d;

import skyHook.AnchorStatics;
import util.CEFPIterator;

public class PointCloud
{
	double width, height;

	int count;

	List<FlatPoint> points = new ArrayList<FlatPoint>();

	// in order traversal! woo! & constant time lookup
	private Set<Cell> cells = new LinkedHashSet<Cell>();

	// outer boundary markers
	private Map<FlatPoint, List<Wall>> skin = new LinkedHashMap<FlatPoint, List<Wall>>();

	Cell firstCell = null;

	/**
	 * Points from a list of points
	 * @param fp list of points
	 */
	public PointCloud(FlatPoint ... fp)
	{
		assert(fp.length > 0);
		this.count = fp.length;
		for (FlatPoint f: fp)
			points.add(f);
		// root cell cdefining boundart
		firstCell = new Cell(this, fp[0]);
		addCell(firstCell);
	}
	
	public PointCloud(List<FlatPoint> fp, Sheaf in)
	{
		assert (in.getSheets().size() == 1);
		Sheet sheet = in.getMain();
		CEFPIterator cit = sheet.iterator();
		FlatPoint [] border = new FlatPoint[sheet.size()];
		int count = 0;
		while (cit.hasNext())
		{
			FlatPoint f = cit.next().thing;
			assert Vec2d.pointIn(f,in) :"suggested point ouside shape "+fp ;
			border[count] = f; 
			count++;
		}
		setup(fp,border);
	}
	
	/**
	 * 
	 * @param fp the flatpoints in the cloud
	 * @param border the exterior voder of this tesselation
	 */
	public PointCloud(List<FlatPoint> fp, FlatPoint ... border)
	{
		setup(fp, border);
	}
	
	private void setup(List<FlatPoint> fp, FlatPoint ... border)
	{
		this.count = fp.size();
		for (FlatPoint f: fp)
			points.add(f);
		firstCell = new Cell(this, fp.get(0), border);
		addCell(firstCell);
	}
	
	/**
	 * creates a point cloud in the first quadrant
	 * 
	 * @param width
	 * @param height
	 * @param count
	 *            number of points (not <=0)
	 */
	public PointCloud(double width, double height, int count, Random r)
	{
		this.count = count;
		this.width = width;
		this.height = height;
		FlatPoint first = null;
		for (int i = 0; i < count; i++)
		{
			if (first == null)
			{
				first = new FlatPoint(r.nextDouble() * width, r.nextDouble() * height);
				points.add(first);
			}
			else
			{
				points.add(new FlatPoint(r.nextDouble() * width, r.nextDouble() * height));
			}

		}
		
		if (count > 0)
		{
			// root cell - assign it first point
			firstCell = new Cell(this, first);
			addCell(firstCell);
		}
	}

	public List<FlatPoint> getPoints()
	{
		return points;
	}

	public List<FlatPoint> getPointsClone()
	{
		ArrayList<FlatPoint> out = new ArrayList<FlatPoint>();
		for (FlatPoint f : points)
			out.add(f);
		return out;
	}

	public void show()
	{
		anchor.setColor(Color.green);
		for (Vector2d p : points)
		{
			createCube(p, 0.05);
		}
		for (FlatPoint q : skin.keySet())
		{
			List<Wall> l = skin.get(q);
			if (l != null)
				for (Wall w : l)
				{
					anchor.setColor(Color.white);
					AnchorStatics.createArrow(w.getEnd(w.getOne()).get3d(), w.getStart(w.getOne()).get3d(), -2, -1);
					{
						/*FlatPoint one;
						if (w.getOne() != null)
							one = w.getOne().getCentre();
						else
						{
							one = new FlatPoint(-1, -1);
						}*/

						FlatPoint oneStart = new FlatPoint(w.getStart(w.getOne()));
						oneStart.add(w.getEnd(w.getOne()));
						oneStart.scale(1. / 2.);

						//anchor.setColor(Color.cyan);
						//AnchorStatics.createArrow(oneStart.get3d(), one.get3d(), -1, -1.2);
					}
					{
						/*FlatPoint two;
						if (w.getTwo() != null)
							two = w.getTwo().getCentre();
						else
						{
							two = new FlatPoint(11, 11);
						}

						FlatPoint twoStart = new FlatPoint(w.getStart(w.getOne()));
						twoStart.add(w.getEnd(w.getOne()));
						twoStart.scale(1. / 2.);*/

						//anchor.setColor(Color.magenta);
						//AnchorStatics.createArrow(twoStart.get3d(), two.get3d(), -1, -1.2);
					}
				}
		}
	}

	public int getCount()
	{
		return count;
	}

	public double getHeight()
	{
		return height;
	}

	public double getWidth()
	{
		return width;
	}

	public void addCell(Cell in)
	{
		cells.add(in);
	}

	public Set<Cell> getCells()
	{
		return cells;
	}

	/**
	 * used to remove cells from pointcloud when merging cells
	 * @param in
	 */
	public void removeCell(Cell in)
	{
		cells.remove(in);
	}
	
	public Cell getFirstCell()
	{
		return firstCell;
	}

	private void intoSkin(FlatPoint f, Wall w)
	{
		List<Wall> l = skin.get(f);
		if (l == null)
		{
			l = new Vector<Wall>();
			skin.put(f, l);
		}
		l.add(w);
		assert (l.size() == 1); // should always be 1
	}

	public void addToSkin(Wall in)
	{
		intoSkin(in.getEnd(in.getOne()), in);
	}

	public void showSkin()
	{
		for (FlatPoint f : skin.keySet())
		{
			System.err.println(f + " -> " + skin.get(f));
		}
	}

	public void removeFromSkin(Wall w)
	{
		// List<Wall> l = skin.get(w.getStart(w.getOne()));
		// assert(l != null);
		// l.remove(w);
		List<Wall> l = skin.get(w.getEnd(w.getOne()));
		assert (l != null);
		boolean r = l.remove(w);
		assert (r);
	}

	public Map<FlatPoint, List<Wall>> getSkin()
	{
		return skin;
	}

	public boolean inSkin(Wall w)
	{
		List<Wall> l = skin.get(w.getEnd(w.getOne()));
		//if (l == null)
		//	System.err.println(" no entry for that flatpoint " + w.getEnd(w.getOne()));
		if (l == null)
			return false;
		if (l.contains(w))
		{
			// assert skin.get(w.getEnd(w.getOne())).contains(w);
			return true;
		}
		//System.err.println(" inSkin says not same as " + l.get(0) + " is " + w);
		return false;
	}

	public void setFirstCell(Cell firstCell)
	{
		this.firstCell = firstCell;
	}
	
	/**
	 * This sets the ownsWall variable in each wall to one or other cell
	 * Assumes the ownWall variable in each wall is null!
	 */
	public void setUpWalls(Random random)
	{
		List<Cell> mix = new ArrayList<Cell>();
		mix.addAll(cells);
		Collections.shuffle(mix, random);
		for (Cell c: mix)
			for (Wall w:c.getWall())
				//if (w.getOwnsWall() == null) just grab all!
					w.setOwnsWall(c);
	}
}
