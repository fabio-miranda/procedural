package cloud;

import static sity.Parameters.setupParameters;
import geom.FlatPoint;

import java.util.Random;

import junit.framework.TestCase;

public class PointCloudTest extends TestCase
{
	// problem cases! 7667857139018510383l is the problem one!
	long[] data = { -6087675723061440040l,7496245132672882365l, 
			-8428166723642615976l,3530224227840081414l,71456303455695365l, 4996311864528089143l,
			7667857139018510383l,4970965185449721667l,13651496787889899l,3376019405970382029l};
	long[] datad ={3376019405970382029l};

	/**
	 * Cases that have failed in the past
	 */
	public void testPedanticTest() throws Exception
	{
		setupParameters();
		//Lightning.DEBUG = true;
		for (long ll : data)
		{
			long random = ll;
			Random r2 = new Random(random);
			System.err.println("************************+" + random + "l+*********************");
			System.err.println("******************************************************************");
			PointCloud pc = new PointCloud(10., 10., 5, r2);
			// if (i == 1) Lightning.DEBUG = true;
			Lightning l = new Lightning(pc, true);
			r2 = new Random(random);
			System.err.println(">>>>>>>>>>>>>>>>>>>>>>>and using concave version");
			pc = new PointCloud(10., 10., 5, r2);
			l = new Lightning(pc);
		}
	}
	
	public void cctestShowOutput() throws Exception
	{
		setupParameters();
		if (false)
		{
			// Random r = new Random(327);
			Lightning.DEBUG = false;
			Random r = new Random(659);
			// for (int i = 0; i < 100; i++)
			// {
			// System.err.println(">>>>>>>>>>>>>>" + i);
			int count = 0;
			while (true)
			{
				count++;
				long random = r.nextLong();
				Random r2 = new Random(random);
				System.err.println("***************************" + count + "**********************************");
				System.err.println("************************+" + random + "l+*********************");
				System.err.println("******************************************************************");
				PointCloud pc = new PointCloud(10., 10., 5, r2);
				// if (i == 1) Lightning.DEBUG = true;
				Lightning l = new Lightning(pc);
			}
			// }
		}
		else
		{
			Lightning.DEBUG = true;
			// l.show();
			// pc.show();
			Random r = new Random(data[data.length-1]);
			PointCloud pc = new PointCloud(10., 10., 20, r);
			// if (i == 1) Lightning.DEBUG = true;
			Lightning l = new Lightning(pc, true);
			l.show();
			l.nextCell = l.nextCell;
		}
	}
}
