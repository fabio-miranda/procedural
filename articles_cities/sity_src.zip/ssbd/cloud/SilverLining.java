package cloud;

import geom.FlatPoint;

import java.util.*;

/**
 * operations that run on a point cloud, that arn't really voronoi related.
 * 
 * @author people
 * 
 */
public class SilverLining
{
	public static boolean mergeSmall(PointCloud in, double minSize, Random r)
	{
		boolean change = false;
		Set<Cell> togo = new LinkedHashSet<Cell>();
		togo.addAll(in.getCells());

		while (togo.size() > 0)
		{
			Cell c = togo.iterator().next();
			togo.remove(c);
			if (c.getSize() < minSize)
			{
				Cell f = c.getRandomNeightbour(r);
				if (f != null)
				{
					change = true;
					try
					{
						c.merge(f, in);
					}
					catch (CloudSaysNoException e)
					{
						togo.remove(c);
						continue;
					}
					// in.removeCell(f);
					togo.remove(f);
				}
				else
					sity.Parameters.errorSD("tiny boundry cases not anticipated here");
			}
		}
		return change;
	}

	/**
	 * merges out all small cells
	 * 
	 * @param in
	 * @param minSize
	 * @param r
	 */
	public static void mergeSmallTillNoMore(PointCloud in, double minSize, Random r)
	{
		boolean res = true;
		while (res && in.getCells().size() > 1)
		{
			res = mergeSmall(in, minSize, r);
		}
	}

	/**
	 * Merges together random cells to add some interest to teh streets
	 * 
	 * @param in
	 * @param prob
	 *            the chance of any one cell will be merged with a neightbour
	 * @param r
	 */
	public static void mergeRandom(PointCloud in, double prob, Random r)
	{
		Set<Cell> togo = new LinkedHashSet<Cell>();
		togo.addAll(in.getCells());

		while (togo.size() != 0)
		{
			Cell c = togo.iterator().next();
			togo.remove(c);
			if (r.nextDouble() < prob)
			{
				Cell f = c.getRandomNeightbour(r);
				if (f != null)
				{
					togo.remove(f);

					int size = c.getWall().size();
					try
					{
						c.merge(f, in);
					}
					catch (CloudSaysNoException e)
					{
						continue;
					}
				}
			}
		}
	}

}
