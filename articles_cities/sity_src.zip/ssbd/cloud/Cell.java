package cloud;

import static sity.Parameters.anchor;
import geom.*;

import java.util.*;

import java.awt.Color;

import sity.Parameters;
import skeleton.*;
import skyHook.AnchorStatics;
import ssbd.NOISE_Street;

public class Cell
{
	private List<Wall> wall = new ArrayList<Wall>();

	private FlatPoint centre = null;

	// when we clip a line these two hold where the walls the clip took place against
	private Wall clipOne, clipTwo;

	// for constructing roads - really the width of the road
	private NOISE_Street street;

	protected double tmpDist;
	
	/**
	 * Sets inital size to the entire cell
	 * 
	 */
	public Cell(PointCloud pc, FlatPoint a)
	{
		if (a == null)
			a = pc.getPoints().iterator().next();
		FlatPoint o1 = new FlatPoint(0, 0);
		FlatPoint o2 = new FlatPoint(0, pc.getHeight());
		FlatPoint o3 = new FlatPoint(pc.getWidth(), pc.getHeight());
		FlatPoint o4 = new FlatPoint(pc.getWidth(), 0);

		FlatPoint lt[] = { o1, o2, o3, o4 };
		FlatPoint l = lt[lt.length - 1];

		for (FlatPoint n : lt)
		{
			Wall b = new Wall(null, this, l, n, pc);
			wall.add(b);
			pc.addToSkin(b);
			l = n;
		}
		centre = a;
	}

	public Cell(PointCloud pc, FlatPoint a, FlatPoint... border)
	{
		if (a == null)
			Parameters.fatalErrorSD("a, first flatpoint may not be null");
		FlatPoint l = border[border.length - 1];

		for (FlatPoint n : border)
		{
			Wall b = new Wall(null, this, l, n, pc);
			wall.add(b);
			pc.addToSkin(b);
			l = n;
		}

		centre = a;
	}

	public Cell(FlatPoint centre)
	{
		this.centre = centre;
	}

	public void show(double height)
	{
		if (wall != null)
		{
			if (wall.size() == 0)
				return;
			Wall last = wall.get(wall.size() - 1);
			for (Wall t : wall)
			{
				t.show(this, height);
				// draw a line from the middle of the last wall to the middle of the next
				Parameters.anchor.setColor(Color.green);

				FlatPoint start = new FlatPoint(last.getEnd(this));
				start.add(last.getStart(this));
				start.scale(0.5);

				FlatPoint end = new FlatPoint(t.getEnd(this));
				end.add(t.getStart(this));
				end.scale(0.5);

				AnchorStatics.createArrow(start.get3d(), end.get3d(), height, height + 0.5);
				last = t;
			}
		}
	}

	public List<FlatPoint> getCorners()
	{
		List<FlatPoint> out = new ArrayList<FlatPoint>();
		for (Wall w : wall)
			out.add(w.getStart(this));
		return out;
	}

	public FlatPoint getCentre()
	{
		return centre;
	}

	public void setCentre(FlatPoint centre)
	{
		this.centre = centre;
	}

	public List<Wall> getWall()
	{
		return wall;
	}

	public void removeWall(Wall in)
	{
		assert (wall.contains(in));
		wall.remove(in);
	}

	/**
	 * re-orders the list so that
	 * 
	 * @param in
	 *            is the first element
	 * @return
	 */
	public List<Wall> getWallOn(Wall in)
	{
		if (!wall.contains(in))
			return null;

		Wall current = wall.get(0);
		while (current != in)
		{
			// remove first wall and add back in at end
			Wall tmp = wall.remove(0);
			wall.add(tmp);
			current = wall.get(0);
		}
		return wall;
	}

	// returns the next wall in the loop
	public Wall getWallAfter(Wall in)
	{
		if (!wall.contains(in))
			return null;

		int loc = wall.indexOf(in);
		if (loc + 1 == wall.size())
			return wall.get(0);
		return wall.get(loc + 1);
	}

	// returns the previous wall in the loop
	public Wall getWallBefore(Wall in)
	{
		if (!wall.contains(in))
			return null;

		int loc = wall.indexOf(in);
		if (loc - 1 == -1)
			return wall.get(wall.size() - 1);
		return wall.get(loc - 1);
	}

	/**
	 * Adds a wall before or after a specified node
	 * 
	 * @param add
	 * @param after
	 */
	public void addWallAfter(Wall add, Wall after) throws CloudSaysNoException
	{
		if (!wall.contains(after))
			throw new CloudSaysNoException();
		int index = wall.indexOf(after);
		wall.add(index + 1, add);
	}

	/**
	 * 
	 * @param add
	 *            the wall to add
	 * @param before
	 *            the wall before that we are too add after!
	 * @return true if an error has occured
	 */
	public boolean addWallBefore(Wall add, Wall before)
	{
		if (!wall.contains(before))
		{
			Parameters.errorSD("before not in wall" + before);
			return true;
		}
		int index = wall.indexOf(before);
		wall.add(index, add);
		return false;
	}

	public Wall getClipOne()
	{
		return clipOne;
	}

	public void setClipOne(Wall clipOne)
	{
		this.clipOne = clipOne;
	}

	public Wall getClipTwo()
	{
		return clipTwo;
	}

	public void setClipTwo(Wall clipTwo)
	{
		this.clipTwo = clipTwo;
	}

	public NOISE_Street getStreet()
	{
		return street;
	}

	public void setStreet(NOISE_Street street)
	{
		this.street = street;
	}

	/**
	 * Constructs s sheaf from this cell
	 * @param ref
	 * @return
	 */
	public Sheaf getSheaf(Sheaf ref)
	{
		// create a sheaf from the wall points, relative to ref
		SheetStaticBuilder sb = new SheetStaticBuilder();
		for (Wall w : wall)
		{
			FlatPoint f = new FlatPoint(w.getStart(this).x, w.getStart(this).y);
			sb.addPoint(f);
			if (w.getOther(this) == null) sb.addType(EdgeType.STREET);
			if (w.getOwnsWall() == this) sb.addType(EdgeType.MY_WALL);
		}

		Sheaf sheaf = new Sheaf(sb.makeSheet(), ref.getTransform());
		return sheaf;
	}
	
	/**
	 * Shrinks this cell using bones, then returns the shrunk sheaf
	 * @param ref
	 * @param speed
	 * @return
	 */
	public Sheaf shrink(Sheaf ref, double speed)
	{
		// create a sheaf from the wall points, relative to ref
		SheetStaticBuilder sb = new SheetStaticBuilder();
		for (Wall w : wall)
		{
			FlatPoint f = new FlatPoint(w.getStart(this).x, w.getStart(this).y);
			// all pts are same speed
			f.setSpeed(speed);
			sb.addPoint(f);
		}

		Sheaf sheaf = new Sheaf(sb.makeSheet(), ref.getTransform());
		
		// System.err.println("first point before bones is "+sheaf.getMain().getFirst().thing);
		// System.err.println("matrix before bones is "+sheaf.getTransform());

		// set all speeds to
		try
		{
			Bones s = new Bones(sheaf, speed, true);
			Sheaf out = s.getFlatTop();
			return out;
		}
		catch (BonesSaysNoException e)
		{
			Parameters.fatalErrorSD("cant shrink that");
			return null;
		}
	}

	public double getSize()
	{
		List<FlatPoint> l = new ArrayList<FlatPoint>();
		for (Wall w : wall)
			l.add(w.getStart(this));
		return geom.Vec2d.findArea(l);
	}

	/**
	 * returns a random neighbour, if it exists, otherwise null (iff nthere are no neighbours, eg boundary all way around);
	 * 
	 * @param r
	 * @return
	 */
	public Cell getRandomNeightbour(Random r)
	{
		List<Cell> neigh = new ArrayList<Cell>();
		for (Wall w : wall)
			if (w.getOther(this) != null)
				neigh.add(w.getOther(this));

		if (neigh.size() > 0)
			return neigh.get(r.nextInt(neigh.size()));

		return null; // no neightbour - all null
	}

	// debug var;
	static boolean first = true;
	
	private boolean merged = false;
	
	/**
	 * Merges this cell with the specified ccell. Not tested on non-simple polygons. does not remove the other cell from whatever pointcloud it was part of
	 */
	public void merge(Cell other, PointCloud in) throws CloudSaysNoException
	{
		merged = true;
		other.merged = true; // just in case...
		Wall otherShouldExist = null;
		for (Wall w: other.getWall()) if (w.getOther(other) != this) otherShouldExist = w;
		
		
		SortedSet<Wall> todo = new TreeSet<Wall>();
		todo.addAll(wall);
		boolean done = false;

		// System.err.println("me size "+wall.size()+" other size "+other.getWall().size());
		// for (Wall w: wall) System.err.println(" pppooooopp "+w.getOther(this));

		while (todo.size() > 0)
		{
			Wall meNow = todo.first();
			todo.remove(meNow);
			if (meNow.getOther(this) == other) // shared wall
			{
				done = true;
				Wall next = getWallBefore(meNow);
				wall.remove(meNow);
				assert (next != null);

				// System.err.println("next " + next + "\n next.getOther " + next.getOther(this) + "\n other " + other);
				while (next.getOther(this) == other)
				{
					meNow = next;
					todo.remove(meNow);
					next = getWallBefore(meNow);
					wall.remove(meNow);
				}

				// meNow is now first wall in a sequence of bordering walls with other
				Iterator<Wall> iw = other.getWallOn(meNow).iterator();
				Wall t = iw.next(); // skip the current shared wall
				while (iw.hasNext())
				{
					Wall otherNow = iw.next();
					// System.err.println("tracking thro "+otherNow);

					if (otherNow.getOther(other) == this)
					{
						// end = otherNow;
						break;
					}
					// add into ourlist
					addWallAfter(otherNow, next);
					// change ownership
					otherNow.change(other, this);
					next = otherNow;
				}
			}
		}
		in.removeCell(other);
		assert(wall.contains(otherShouldExist));
		assert (done);
		first = false;
	}

	public boolean isMerged()
	{
		return merged;
	}
}
