package cloud;

import static geom.Vec2d.*;
import geom.*;

import java.util.*;

import javax.vecmath.*;

import sity.Parameters;

/**
 * Voronoi Tesselation from points class.
 * 
 * @author people
 * 
 */
public class Lightning
{
	PointCloud pointCloud = null;

	boolean concave = false;
	
	
	
	public Lightning(PointCloud in)  throws CloudSaysNoException
	{
		pointCloud = in;
		setup();
	}
	
	/**
	 * Performs a voronoi tesselation on the specified pointcloud
	 * @param in the pointcloud to operate on
	 * @param c true if this is a concave shape, false otherwise
	 */
	public Lightning(PointCloud in, boolean c)  throws CloudSaysNoException
	{
		pointCloud = in;
		this.concave = c;
		setup();
	}

	// current location in our traversal of one cell
	protected Cell nextCell;

	private Cell startCell = null;

	protected FlatPoint nextPoint;

	protected FlatPoint start;

	private Wall startBisector;

	// debugging output
	private boolean output = false;

	// debug count
	private int count = 0;

	public static boolean DEBUG = false;

	private static final FlatPoint DUMMY = new FlatPoint(99, 99);

	private Map<FlatPoint, WallSegment> wallSegments;

	public void setup() throws CloudSaysNoException
	{
		// grab the first cell
		Cell c = pointCloud.getFirstCell();
		checkCell(c);

		List<FlatPoint> pointsToAdd = pointCloud.getPointsClone();
		pointsToAdd.remove(c.getCentre());

		showMaybe();
		// for each point in the cloud add it to the network
		for (FlatPoint f : pointsToAdd)
		{
			count++;
			if (DEBUG)
				System.err.println(">>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\nadding point " + f);
			// reset the pointer to the start of the circuit
			start = null;
			nextPoint = null;
			nextCell = null;
			startBisector = null;

			// lastCell is (*will be*..?) used to break ambiguous borderline cases
			Cell lastCell = null;
			Cell currentCell = null;
			c = null;
			// first up find the cell that its in
			for (Cell cell : (new DistanceFromComparitor(pointCloud.getCells(), f)).getList())
			{
				if (geom.Vec2d.pointIn(f, cell.getCorners()))
				{
					c = cell;
					break;
				}
			}
			if (c == null)
			{
				
				System.err.println("There is nomatching cell for " + f);
				//throw new CloudSaysNoException();
				System.exit(4);
				show();
				Parameters.fatalErrorSD("There is nomatching cell for " + f);
			}

			startCell = c;
			Cell me = new Cell(f); // the cell we are generating boundries for

			pointCloud.addCell(me);
			// list of cells we have already split
			Set<Cell> visited = new LinkedHashSet<Cell>();
			nextCell = c;
			visited.add(me);

			 output = false;

			start = DUMMY;

			wallSegments = new LinkedHashMap<FlatPoint, WallSegment>();

			// if we have just followed an edge, need to patch between entering shape and bisector start
			boolean afterEdgeFollow = false;
			boolean moved = false; // opening flag :(
			
			showMaybe();

			while (true)
			{
				if (DEBUG)
				{
					System.err.println("*********************************\nnextCell is  " + nextCell);
					if (nextCell != null ) System.err.println(" cemt "+ nextCell.getCentre());
				}
				if (DEBUG)
					System.err.println("nextPoint is " + nextPoint+" count is "+count);
				if (DEBUG)
					System.err.println("start  " + start);
				if (DEBUG)
					System.err.println("start  cell : " + startCell + " :: " + startCell.getCentre());

				lastCell = currentCell;
				currentCell = nextCell;

				// System.err.println(" moved tis "+(nextPoint==start)+" moved is "+moved+" trigger is "+(start == nextPoint && moved));
				// else if (visited.contains(nextCell) || nextCell == me)
				if (start == nextPoint && moved)
				{
					// break?
					break;
				}
				else if (nextCell == null)
				{
					// we are on an edge, work around to the next unvisited cell
					nextCellIsNull(me, visited, moved);
					moved = true; // allow futher moves
					afterEdgeFollow = true;
				}
				else
				// new cell!
				{
					visited.add(nextCell);
					gogo(me, nextCell, afterEdgeFollow, lastCell, visited);
					afterEdgeFollow = false;
				}
			}
			if (DEBUG)
				for (Cell cc : pointCloud.getCells())
					checkCell(cc);
			
			showMaybe();
		}

		// merge small edges and straight lines!
		cleanOutput();
	}

	/**
	 * set nextCell and nextPoint given that nextCell is null
	 * 
	 */
	private void nextCellIsNull(Cell me, Set<Cell> visited, boolean moved) throws CloudSaysNoException
	{
		while ((nextCell == null || visited.contains(nextCell)) && (nextPoint != start || (!moved)))
		{
			WallSegment ws = wallSegments.get(nextPoint);
			if (DEBUG)
				for (FlatPoint fp : wallSegments.keySet())
					System.err.println(fp + "::::::" + wallSegments.get(fp));
			if (ws != null) // TODO
			{ // theres a matching wall setment , lets follow that!
				me.getWall().add(ws.getWall());
				// we may set nextCell to a cell that's already processed!
				nextCell = ws.getNextCell();
				// if so, we assume there's a line to follow next time
				if (visited.contains(nextCell))
				{
					if (DEBUG)
						System.err.println(" seen next cell before twas " + nextCell + " cet: " + nextCell.getCentre());
					// if the next cell is home, we're done
					nextCell = null;
				}
				if (nextCell != null && DEBUG)
				{
					System.err.println("next cell is " + nextCell + " centre being " + nextCell.getCentre());
				}
				else if (DEBUG)
					System.err.println("next cell in NULL ");
				// remove that segment from map
				wallSegments.put(nextPoint, null);
				nextPoint = ws.getNextPoint();
				showMaybe();

				
				return;
			}
			else
			{ // no wall segments, so try following an edge
				Map<FlatPoint, List<Wall>> map = pointCloud.getSkin();
				assert (nextPoint != null);
				if (DEBUG)
					System.err.println("looking up " + nextPoint + " (" + nextPoint.hashCode() + ")");
				List<Wall> l = map.get(nextPoint);
				assert (l != null);
				if (l == null) throw new CloudSaysNoException();
				assert (l.size() == 1);
				Wall w = l.get(0);
				// set w to be one of me's edges
				assert (w.getOne() == null || w.getTwo() == null);
				assert (w.getOne() != null || w.getTwo() != null);

				if (!visited.contains(w.getOther(null)))
				{
					// We have bisected a shape onto an edge, at the start of an unseen shape
					// nextPoint stays as it is, nextCell is set to the new cell
					nextCell = w.getOther(null);
					if (DEBUG) System.err.println("skipping out, seen before");
					continue;
				}

				// else
				nextPoint = w.getOtherEnd(nextPoint);

				w.change(w.getOther(null), me);
				// add in w to our list
				me.getWall().add(w);
				assert (w.getOne() == null || w.getTwo() == null);
				// if there is a bisector leaving this point, we want to do that rather than follow outer wall
				if (wallSegments.get(nextPoint) != null) continue;
				// now find nextCell
				l = map.get(nextPoint);
				assert (l != null);
				assert (l.size() == 1) : "l size not one, but " + l.size();
				w = l.get(0);
				nextCell = w.getOther(null);
				if (DEBUG) System.err.println("settin nextCell to "+nextCell.getCentre());
				showMaybe();
			}
			moved = true;
		}
	}

	/**
	 * debug function that ensures that the start and end points of each wall over an entire cell are consistant
	 */
	private void checkCell(Cell in)
	{
		// FlatPoint
		Wall last = in.getWall().get(in.getWall().size() - 1);
		for (Wall w : in.getWall())
		{
			if (last.getEnd(in) != w.getStart(in))
			{
				for (Wall q : in.getWall())
					System.err.println(" q is : " + q);
				assert (last.getEnd(in) == w.getStart(in)) : "" + last.getEnd(in) + "not equal to" + w.getStart(in);
			}
			last = w;
		}
	}

	public void show()
	{
		double height = 1;
		for (Cell cc : pointCloud.getCells())
		{
			cc.show(height++);
		}
		pointCloud.show();
		//Parameters.anchor.nextFrame();
	}

	/**
	 * only shows if output
	 * 
	 */
	protected void showMaybe()
	{
		if (output && DEBUG)
		{
			show();
		}
	}

	// tolerance, smaller than this and we will merge two vertices into a singular vertex
	private static final double MERGE_VERTEX = 10E-10;

	/**
	 * inner function that inserts the bisector of me and other into the correct places
	 * 
	 * @param me
	 * @param other
	 * @param fromEdge -
	 *            did we get here from folling an outer edge?
	 */
	protected void gogo(Cell me, Cell other, boolean fromEdge, Cell lastCell, Set<Cell> visited) throws CloudSaysNoException
	{
		// find bisector of current centre and new point
		Pair<Tuple2d, Tuple2d> res = bisectorOfPoints(me.getCentre(), other.getCentre());
		// System.err.println("bisector is at" + res.first() + " angle " + res.second());
		Pair<FlatPoint, FlatPoint> clipped; 
		
		if (!concave)
			clipped= clip(res, other);
		else
			clipped= clipConcave(res, other, me);
		
		if (clipped == null)
		{
			System.err.println("bisector centre at " + res.first() + " bisector second at " + res.second());
			System.err.println("other dump" + other.getWall());
			assert false: "failed to clip where i expected to clip" ;
			throw (new CloudSaysNoException());
		}

		// the edges that we bisect against on entering (one) and leaving (two), relative to me
		Wall bisectorOne = other.getClipOne();
		Wall bisectorTwo = other.getClipTwo();

		// gloabal pointer to the next cell to process
		if (DEBUG)
			System.err.println("b1: " + bisectorOne + " b2: " + bisectorTwo);
		if (DEBUG)
			System.err.println(" bisector s/e : " + clipped.first() + " ::::: " + clipped.second());
		if (bisectorTwo == null)
		{
			// if it stops here,your problem may be a too low tolerance in Vec2d.clip
			if (DEBUG)
				show();
			System.err.println("bisector centre at " + res.first() + " bisector second at " + res.second());
			for (Wall w : other.getWall())
			{
				System.err.println("odp:" + w);
			}
		}
		assert (bisectorOne != null);
		assert (bisectorTwo != null);

		// next cell is always null as we just pack up and follow pointers next
		nextCell = null;

		// we dont know if the
		boolean mergeFirst = false;
		boolean mergeSecond = false;

		// are we inside the new shape (me) or outside - toggles on bisectorOne/Two
		boolean inShape = true;

		// convention here is that the bisectorOne/Two point to the edge where the *first point relative to other*
		// is in the shared edge
		// do we merge the start of the bisector with an already existing vertex
		
		if (DEBUG)
		{
			System.err.println("distance to first end   "+clipped.first().distanceTo(bisectorOne.getEnd(other)));
			System.err.println("distance to first start "+clipped.first().distanceTo(bisectorOne.getStart(other)));
			System.err.println("distance to second end  "+clipped.second().distanceTo(bisectorTwo.getEnd(other)));
			System.err.println("distance to second start"+clipped.second().distanceTo(bisectorTwo.getStart(other)));
		}
		
		if (clipped.first().distanceTo(bisectorOne.getEnd(other)) < MERGE_VERTEX)
		{
			if (DEBUG)
				System.err.println("first end");
			mergeFirst = true;
			clipped.setFirst(bisectorOne.getEnd(other));
			bisectorOne = other.getWallAfter(bisectorOne);
		}
		else if (clipped.first().distanceTo(bisectorOne.getStart(other)) < MERGE_VERTEX)
		{
			if (DEBUG)
				System.err.println("first start");
			mergeFirst = true;
			clipped.setFirst(bisectorOne.getStart(other));
			// bisectorOne already in correct locaiton - after merged point
		}


		//Cell oldOtherSideOfBisectorTwo = bisectorTwo.getOther(other);
		
		// do we merge the end of the bisector with an already existing vertex
		if (clipped.second().distanceTo(bisectorTwo.getEnd(other)) < MERGE_VERTEX)
		{
			if (DEBUG)
				System.err.println("second end, & bisec");
			mergeSecond = true;
			clipped.setSecond(bisectorTwo.getEnd(other));
			// move bisector two up one
			bisectorTwo = other.getWallAfter(bisectorTwo);
		}
		else if (clipped.second().distanceTo(bisectorTwo.getStart(other)) < MERGE_VERTEX)
		{
			if (DEBUG)
				System.err.println("second end");
			mergeSecond = true;
			clipped.setSecond(bisectorTwo.getStart(other));
			// bisectorTwo already in correct location - after merged point
		}

		// default next after this split is as found before being merged
		//Cell otherSideOfBisectorTwo = oldOtherSideOfBisectorTwo;
		// if other side is null, we're on an edge, so use old value
		// otherwise we use new value so we always choose the inner cell next after following a bisector
		//if (otherSideOfBisectorTwo == null) otherSideOfBisectorTwo = bisectorTwo.getOther(other);
		
		if (DEBUG)
		{
			System.err.println("after clippin b1: " + bisectorOne + "\n        b2: " + bisectorTwo);
			System.err.println(" start is " + clipped.first() + " ::: ti :::: " + clipped.second());
		}

		if (mergeFirst && mergeSecond && DEBUG)
		{
			for (Wall ww : other.getWall())
				System.err.println("****" + ww);
			System.err.println("first && second");
		}

		// some linear math rounding differences got us!
		if (bisectorOne == bisectorTwo)
		{ // TODO something intellegent to go here!
			// if this edge borders the start, need to choose before or after edge to continue on
			// we use the previous cell, try to locate it and choose t other.
			Wall n = other.getWallAfter(bisectorOne);
			// nextCell
			//if (DEBUG) System.err.println("last cell is " + lastCell + " to " + lastCell.getCentre());
		}

		// if we are back at the start, make the lines join exactley.... iff not on an edge
		//if ((oldBisectorTwo.getOther(other) == startCell || oldBisectorTwo.getOther(other) == me) && !pointCloud.getSkin().containsKey(clipped.second()))
		// if ((bisectorTwo.getOther(other) == me) && !pointCloud.getSkin().containsKey(clipped.second()))
		//{
			/*if (DEBUG)
				System.err.println("back at start so setting end of bisector to start point");
			double distanceToEnd = clipped.second().distanceTo(startBisector.getEnd(me));
			double distanceToStart = clipped.second().distanceTo(startBisector.getStart(me));

			if (distanceToEnd < distanceToStart)
			{
				System.err.println("end");
				clipped.setSecond(startBisector.getEnd(me));
			}
			else
			{
				System.err.println("start");
				clipped.setSecond(startBisector.getStart(me));
			}

			mergeSecond = true;*/
		//}
		/*
		 * else if (visited.contains(bisectorTwo.getOther(other)) && false) { if (DEBUG) System.err.println("SHANANAGOATS"+bisectorTwo.getOther(other).getCentre()); // check, if due to a degernate case error we are being redirected back into a cell we've already been to Wall t = null; if (!visited.contains(other.getWallBefore(bisectorTwo))) t = other.getWallBefore(bisectorTwo); //if (!visited.contains(other.getWallAfter(bisectorTwo))) // t = other.getWallAfter(bisectorTwo);
		 * 
		 * if (t != null) { System.err.println("so settint next to "+t); // if we split then the next cell will be something else oldBisectorSecond = t.getOther(other); } }
		 */

		// if start is null then we have started a new insertion, and we set the flatpoint to return too!
		if (start == DUMMY)
			start = clipped.first();

		Wall sharedWall = new Wall(other, me, clipped.first(), clipped.second(), pointCloud);
		if (startBisector == null)
			startBisector = sharedWall;

		Wall firstWall = null;
		if (nextPoint == null)
		{
			// first run for this point
			firstWall = bisectorOne;
			nextPoint = sharedWall.getStart(me);
		}
		else
		{
			// fromEdge = true; - why was that there?
			// search all
			for (Wall w : other.getWall())
				if (w.getStart(other) == nextPoint)
				{
					firstWall = w;
					break;
				}
		}
		assert (firstWall != null);
		// find wall to start at
		ListIterator<Wall> lit = other.getWallOn(firstWall).listIterator();
		while (lit.hasNext())
		{
			Wall current = lit.next();
			//System.err.println("looking at "+current+" inShape: "+inShape);
			if (current == bisectorOne)
			{
				if (!mergeFirst)
				{
					FlatPoint oldStart = current.getStart(other);
					current.setStart(clipped.first(), other);

					if (current.getOther(other) == null)
					{
						Wall restOf = new Wall(null, me, oldStart, clipped.first(), pointCloud);
						pointCloud.addToSkin(restOf);
					}
					else
					{
						// we need to add in a line to keep the opposite shape complete for line collisions
						Cell overLine = current.getOther(other);
						Wall restOf = new Wall(overLine, me, oldStart, clipped.first(), pointCloud);
						if (DEBUG)
						{
							showMaybe();
							System.err.println("clipped.first i s" + clipped.first());
							System.err.println("now adding wall after " + restOf + " ::: " + current + ".." + current.hashCode());
							// for (Wall q: overLine.getWall()) System.err.println("(((((("+q+"--"+q.hashCode());
						}
						overLine.addWallAfter(restOf, current);
					}
				}
				// add shared wall in at correct location on loop
				lit.previous();
				lit.add(sharedWall);
				lit.next();
				/*if (otherSideOfBisectorTwo!=null)
					System.err.println("split added has at end of it cell with middle "+otherSideOfBisectorTwo.getCentre());
				else
					System.err.println("split added has at end of nullll");*/
				// add shared wall to list directions, otherSideOfBisectorTwo is so that if mergedSecond other bisection isnt null
				wallSegments.put(sharedWall.getStart(me), new WallSegment(sharedWall,bisectorTwo.getOther(other), sharedWall.getEnd(me)));

				inShape = false;
			}
			else if (current == bisectorTwo) // end of bisector
			{
				if (!mergeSecond)
				{
					FlatPoint oldEnd = current.getEnd(other);
					current.setEnd(clipped.second(), other);
					if (current.getOther(other) == null)
					{
						Wall restOf = new Wall(null, me, clipped.second(), oldEnd, pointCloud);
						pointCloud.addToSkin(restOf);
					}
					else
					{
						// untested~2lines:
						Cell overLine = current.getOther(other);
						Wall restOf = new Wall(overLine, me, clipped.second(), oldEnd, pointCloud);
						if (overLine != me)
						{
							boolean debug = overLine.addWallBefore(restOf, current);
							if (debug)
							{
								System.err.println("me centre " + me.getCentre() + " other centre " + other.getCentre());
								System.err.println("current line " + current.getStart(other) + " to " + current.getEnd(other));
								System.err.println("current.getOther" + current.getOther(other));
								System.err.println("other is " + other);
								showMaybe();
								assert (false);
							}
						}
					}
				}
				else
				{
					// this should now be an edge in me's shape. We keep it
					current.change(other, me); // this just added
					lit.remove();
				}
				inShape = true;
			}
			else if (inShape)
			{
				lit.remove();
				// assign new half to belong to new shape
				current.change(other, me);
			}
			else
			{
				// keep in other
			}
			showMaybe();
		}
	}
	
	public Set<Sheaf> getCellsAsSheets(Sheaf ref)
	{
		Set<Sheaf> out = new LinkedHashSet<Sheaf>();
		for (Cell c:pointCloud.getCells())
		{
			SheetStaticBuilder sb = new SheetStaticBuilder();
			for (Wall w: c.getWall())
			{
				FlatPoint f = w.getStart(c);
				sb.addPoint(f.x, f.y);//, 0);
			}
			out.add(new Sheaf(sb.makeSheet()));
		}
		return out;
	}
	
	/**
	 * Merge small edges and straight lines
	 *
	 */
	private void cleanOutput()
	{
		// search for straight lines with same cell ownership
		// note - we examine all the edges twice!
		for (Cell c: pointCloud.getCells())
		{
			Wall last = c.getWall().get(c.getWall().size()-1);
			ListIterator<Wall> nowi = c.getWall().listIterator();
			while (nowi.hasNext())
			{
				Wall now = nowi.next();
				if (mergable (last, now, c))
				{
					assert((now.getOne() == last.getOne() && now.getTwo() == last.getTwo()) || (now.getOne() == last.getTwo() && now.getTwo() == last.getOne()));
					Cell other = now.getOther(c);
					// remove current wall from c
					
					if (DEBUG)
					{
						System.err.println("****************************\n now is "+now);
						System.err.println(" now is "+now.getOne());
						System.err.println(" now is "+now.getTwo());
					}
					
					if (other != null) // if we are not on an edge
						other.removeWall(now);
					
					nowi.remove();
					// move last wall to cover for current
					last.setEnd(now.getEnd(c),c);
				}
				else
				{ // only move on last if not merged!
					last = now;
				}
			}
		}
	}
	
	/**
	 * Decides if two consectutive walls are mergable, if they are
	 * able to be combined. We just check fro 180 corners. Process is
	 * to check how far the midpoint of the lines is from the line made from
	 * the start to the end!
	 * @param before
	 * @param after
	 * @param r before, after relative to this cell
	 * @return
	 */
	private boolean mergable (Wall before, Wall after, Cell r)
	{
		Cell a = before.getOne();
		Cell b = before.getTwo();
		// cells may be in either order in either wall
		if (!after.hasCell(a)) return false;
		if (after.getOther(a) != b) return false;
		assert(before.getEnd(r)== after.getStart(r));
		// now we know they have the same cell, distance of shared point (before.second)
		// from line before.first, after.second
		Vector2d AB = new Vector2d(before.getEnd(r));
		AB.sub(before.getStart(r));
		Vector2d AC = new Vector2d(after.getEnd(r));
		AC.sub(before.getEnd(r));
		double dist = Vec2d.cross(AB,AC)/AB.length();
		if (Math.abs(dist) < 10E-12) return true;
		return false;
	}
}
