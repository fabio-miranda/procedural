package cloud;

public class CloudSaysNoException extends Exception
{
	public CloudSaysNoException()
	{
		
	}
}
