package cloud;

import static sity.Parameters.setupParameters;
import geom.FlatPoint;

import java.util.*;

import junit.framework.TestCase;

public class ConcaveCellTest extends TestCase
{

	final static double l = 1.0/(Math.sqrt(2))+0.5;
	// split Shape
	double data[][] = {
			{0,0},
			{0,3},
			{3,3},
			{3,2},
			{2,2},
			{2,1},
			{3,1},
			{3,0},
	};
	
	// large cross
	double data2[][] = {
			{4,0},
			{4,4},
			{0,4},
			{0,5},
			{4,5},
			{4,9},
			{5,9},
			{5,5},
			{9,5},
			{9,4},
			{5,4},
			{5,0},
	};
	
	// large e
	double data3[][] = {
			{4,0},
			{0,0},
			{0,1},
			{4,1},
			{4,4},
			{0,4},
			{0,5},
			{4,5},
			{4,8},
			{0,8},
			{0,9},
			{5,9},
			{5,0},
	};
	
	public void cctestConcaveOne() throws Exception
	{
			Lightning.DEBUG = false;
			setupParameters();
			FlatPoint[] border = new FlatPoint[data.length];
			for (int c  = 0; c < data.length; c++)
				border[c] = new FlatPoint(data[c][0],data[c][1]);
			
			FlatPoint[] points = {new FlatPoint(1.5,0.5),new FlatPoint(2.5,0.5)};
			//FlatPoint[] points = {new FlatPoint(1.5,2.5),new FlatPoint(2.5,2.5)};
			List<FlatPoint> p2 = new ArrayList<FlatPoint>();
			for (FlatPoint f: points) p2.add(f);
			
			PointCloud pc = new PointCloud(p2, border);
			Lightning l = new Lightning(pc, true);
			l.show();
	}
	
	
	public void cctestConcaveTwo() throws Exception
	{
			Lightning.DEBUG = false;
			setupParameters();
			FlatPoint[] border = new FlatPoint[data.length];
			for (int c  = 0; c < data.length; c++)
				border[c] = new FlatPoint(data[c][0],data[c][1]);
			
			FlatPoint[] points = {new FlatPoint(0.6,2.1),new FlatPoint(2.5,0.5)};
			List<FlatPoint> p2 = new ArrayList<FlatPoint>();
			for (FlatPoint f: points) p2.add(f);
			
			PointCloud pc = new PointCloud(p2, border);
			Lightning l = new Lightning(pc, true);
			l.show();
	}
	
	
	public void cctestConcaveThree() throws Exception
	{
			Lightning.DEBUG = false;
			setupParameters();
			FlatPoint[] border = new FlatPoint[data2.length];
			for (int c  = 0; c < data2.length; c++)
				border[c] = new FlatPoint(data2[c][0],data2[c][1]);
			
			FlatPoint[] points = {new FlatPoint(4.5,0.5),new FlatPoint(4.5,8.5),new FlatPoint(0.5,4.5),new FlatPoint(8.5,4.5)};
			List<FlatPoint> p2 = new ArrayList<FlatPoint>();
			for (FlatPoint f: points) p2.add(f);
			
			PointCloud pc = new PointCloud(p2, border);
			pc.show();
			sity.Parameters.anchor.nextFrame();
			Lightning l = new Lightning(pc, true);
			l.show();
	}
	
	public void cctestConcaveFour() throws Exception
	{
			Lightning.DEBUG = false;
			setupParameters();
			FlatPoint[] border = new FlatPoint[data3.length];
			for (int c  = 0; c < data3.length; c++)
				border[c] = new FlatPoint(data3[c][0],data3[c][1]);
			
			FlatPoint[] points = {new FlatPoint(0.5,0.5),new FlatPoint(0.5,4.5),new FlatPoint(0.5,8.5),new FlatPoint(4.5,4.5)};
			List<FlatPoint> p2 = new ArrayList<FlatPoint>();
			for (FlatPoint f: points) p2.add(f);
			
			PointCloud pc = new PointCloud(p2, border);
			Lightning l = new Lightning(pc, true);
			l.show();
	}
	
	public void cctestConcaveFive() throws Exception
	{
			//Lightning.DEBUG = true;
			setupParameters();
			FlatPoint[] border = new FlatPoint[data.length];
			for (int c  = 0; c < data.length; c++)
				border[c] = new FlatPoint(data[c][0],data[c][1]);
			
			FlatPoint[] points = new FlatPoint[data.length];
			for (int c  = 0; c < data.length; c++)
				points[c] = new FlatPoint(data[c][0],data[c][1]);
			
			List<FlatPoint> p2 = new ArrayList<FlatPoint>();
			for (FlatPoint f: points) p2.add(f);
			
			PointCloud pc = new PointCloud(p2, border);
			Lightning l = new Lightning(pc, true);
			l.show();
	}
	
	public void testConcaveSix() throws Exception
	{
			Lightning.DEBUG = false;
			setupParameters();
			FlatPoint[] border = new FlatPoint[data3.length];
			for (int c  = 0; c < data3.length; c++)
				border[c] = new FlatPoint(data3[c][0],data3[c][1]);
			
			FlatPoint[] points = new FlatPoint[data3.length];
			for (int c  = 0; c < data3.length; c++)
				points[c] = new FlatPoint(data3[c][0],data3[c][1]);
			
			List<FlatPoint> p2 = new ArrayList<FlatPoint>();
			for (FlatPoint f: points) p2.add(f);
			
			PointCloud pc = new PointCloud(p2, border);
			Lightning l = new Lightning(pc, true);
			l.show();
	}
	
}
