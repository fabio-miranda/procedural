package util;

/**
 * Mutable boolean wrapper
 */
public class Toggle
{
	private boolean value;

	public Toggle(boolean value)
	{
		this.value = value;
	}

	public boolean get()
	{
		return value;
	}

	public void set(boolean value)
	{
		this.value = value;
	}
}
