package util;

public interface Stringable
{
	public String stringitise(String in);
	public void deStringitise();
}
