package util;

import java.util.Random;

/**
 * lol, display wrapper for an integer! woot!
 * @author tomkelly
 *
 */
public class MyInt extends FreezeInt
{
	public int value;
	public MyInt(int value)
	{
		this.value = value;
	}

	public int doFreeze(Random r)
	{
		return value;
	}
}
