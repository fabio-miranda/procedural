package util;

import static geom.Vec2d.pointIn;
import static sity.Parameters.*;
import geom.*;

import java.util.*;
import static geom.Vec2d.*;
import javax.vecmath.Vector2d;

/**
 * This is the hole happy replacement for the concave replacement for the triangulator
 * 
 * @author people
 * 
 */
public class TriIterator
{
	// last points returned by next();
	private Triple<FlatPoint, FlatPoint, FlatPoint> cache = new Triple<FlatPoint, FlatPoint, FlatPoint>(
			null, null, null);

	CircularList<FlatPoint> cl;
	
	public PriorityQueue<CEFP> q = new PriorityQueue<CEFP>(3, new LeftnessComparitor());
	
	/**
	 * Creates a triangulator for the specified sheaf
	 * @param in
	 */
	public TriIterator(Sheaf in)
	{
		//run through all points copying them and adding them to 
		// a list ordered by x coord
		Iterator<Sheet>it = in.getSheets().iterator();
		while (it.hasNext())
		{
			CEFP ce = it.next().getFirst();
			CEFP newCE = ce.copy();
			CEFPIterator c = new CEFPIterator(newCE);
			while (c.hasNext())
			{
				CEFP n = c.next();
				q.add(n);
			}
		}
		CEFPIterator c = new CEFPIterator(q.peek());
	}

	
	private void dumpQ()
	{
		System.err.println("++++++++++++++++++++++++++++++++++++++");
		PriorityQueue<CEFP> w = new PriorityQueue<CEFP>(3, new LeftnessComparitor());
		Iterator<CEFP>it = q.iterator();
		while (it.hasNext())
		{
			w.add(it.next());
		}
		while (w.size() > 0)
		{
			System.err.println("dq: "+w.poll());
		}
		
	}
	
	//int count2 = 0;
	
	/**
	 * Are there anymore triangles to come in this triangulation
	 */
	public boolean hasNext()
	{
		return q.size() > 2;
	}

	int count = 0;
	public Triple<FlatPoint, FlatPoint, FlatPoint> next()
	{
		count = 0;
	 return next2();
	}
	/**
	 * Returns the next triangle in the triangluation of the convex shape :)
	 * Routine used is thus:
	 *  take left most point from the queue, if it is an ear return it
	 *  else take the list of all points that are inside the bounds between
	 *  the point, its next and previous and find that furthest from the 3rd side of
	 *  the ear, lets call it bob.
	 *  
	 *  Duplicate bob and the left most point, and insert them into the lists so
	 *  they become a break in the chain, start over!
	 */
	public Triple<FlatPoint, FlatPoint, FlatPoint> next2()
	{
		CEFP current = q.peek();
		CEFP previous = current.previous;
		CEFP next = current.next;
		
		//System.err.println("*************"+count+" q size is "+q.size());
		//System.err.println("vertices are "+current.thing+" "+previous.thing+" "+next.thing);
		//for (CEFP c: q)System.err.println("q itemsz "+c.thing);
		count++;
		if (count > 100) return cache;
		
		
		// now check all points to see if they are in the ear
		// WE CAN OPTIMISE MASSIVLEY HERE! only need to check points in a certain x range...
		Iterator<CEFP> it = q.iterator();
		boolean suitable = true;
		double minDist = -Double.MAX_VALUE;
		CEFP minPoint = null;
		
		List<FlatPoint> tmp = new Vector<FlatPoint>(3);
		tmp.add(current.thing);
		tmp.add(previous.thing);
		tmp.add(next.thing);


		//dumpQ();
		while (it.hasNext())
		{
			CEFP cefp = it.next();
			if (
					   !cefp.thing.equals(current.thing) 
					&& !cefp.thing.equals(next.thing) 
					&& !cefp.thing.equals(previous.thing) 
					&& pointIn(cefp.thing, tmp))
			{
				// if dist is 0, it doesnt really count....
				double dist = heightPerpendicular(next.thing, previous.thing, cefp.thing);
				if (dist != 0)
				{
				suitable = false;
				if (dist > minDist)
				{
					minDist = dist;
					minPoint = cefp; 
				}
				}
			}
		}

		/*System.err.println("prespli ");
		CEFPIterator a = new CEFPIterator(current);
		while(a.hasNext())
		{
			a.next();
			System.err.println("split scan:" +a.current.thing);
			assert(a.current.previous.next == a.current);
			assert(a.current.next.previous == a.current);
		}
		System.err.println("results of prisplit end");*/
		
		if (suitable)
		{
			cache = new Triple<FlatPoint, FlatPoint, FlatPoint>(
					previous.thing,current.thing,next.thing);
			q.remove(current); // remove top item
			if (next.next == previous)
			{
				
				q.remove(previous); // remove other two as it is the last
				q.remove(next);
				//System.err.println("returning last triangle in set"+cache);
				return cache;
			}

			//System.err.println("Returnin "+cache);
			current.previous.next = current.next;
			current.next.previous = current.previous;
			return cache;
		}

		//System.err.println(suitable+ " "+minDist+" "+minPoint);
		
		//System.err.println("Splitting out "+minPoint); 
		// we take our point and make a copy
		CEFP leftMostCopy = current.clone();
		q.add(leftMostCopy); 
		//leftMostCopy.thing.setSpeed(random.nextDouble());
		// also copy the opposite point
		CEFP diagonalCopy = minPoint.clone();
		q.add(diagonalCopy);
		//diagonalCopy.thing.setSpeed(random.nextDouble());
		
		//assert(leftMostCopy.thing == current.thing);
		//assert(leftMostCopy != current);
		
		// set up pointers!
		leftMostCopy.next = diagonalCopy;
		leftMostCopy.previous.next = leftMostCopy;
		diagonalCopy.previous = leftMostCopy;
		diagonalCopy.next.previous = diagonalCopy;

		// we set the points into position in the loops
		current.previous = minPoint;
		minPoint.next = current;

		/*
		System.err.println("results of split LMC");
		a = new CEFPIterator(leftMostCopy);
		while(a.hasNext())
		{
			a.next();
			System.err.println("split scan:" +a.current.thing);
			assert(a.current.previous.next == a.current);
			assert(a.current.next.previous == a.current);
		}
		System.err.println("results of split LMC end");*/
		
		
		// recurse in!
		return next2();
	}

	/**
	 * Set of convience function to get around the generics bit
	 */
	public FlatPoint one()
	{
		return cache.first();
	}

	public FlatPoint two()
	{
		return cache.second();
	}

	public FlatPoint three()
	{
		return cache.third();
	}

	/**
	 * Returns the two major vecors using the above routine
	 * 
	 * @return
	 */
	public Pair<Vector2d, Vector2d> nextV()
	{
		Triple<FlatPoint, FlatPoint, FlatPoint> next = next();
		Vector2d one = new Vector2d(next.second());
		one.sub(next.first());
		Vector2d two = new Vector2d(next.third());
		one.sub(next.first());
		Pair<Vector2d, Vector2d> output = new Pair<Vector2d, Vector2d>(one, two);
		return (output);
	}

	/**
	 * These three return vectors of the two sides adjoining the origin point,
	 * pointing toward the point?
	 * 
	 * @return
	 */
	public Vector2d onLeft()
	{
		Vector2d one = new Vector2d(two());
		one.sub(one());
		return (one);
	}

	public Vector2d onRight()
	{
		Vector2d two = new Vector2d(three());
		two.sub(one());
		return (two);
	}

	public Vector2d onOtherSide()
	{
		Vector2d three = new Vector2d(two());
		three.sub(three());
		return (three);
	}

	public void remove()
	{
		error("Functionality not implemented");
	}
}
