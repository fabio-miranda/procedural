package util;

import static geom.EdgeType.REFERENCE;
import static geom.Vec2d.angleBetween;
import static java.lang.Math.abs;
import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static sity.Parameters.*;

import geom.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.vecmath.AxisAngle4d;
import javax.vecmath.Matrix4d;
import javax.vecmath.Point4d;
import javax.vecmath.Tuple4d;
import javax.vecmath.Vector2d;
import javax.vecmath.Vector3d;

/**
 * A sheet is a 2D plane together with a transform that specifies its location
 * in 3 space.
 * 
 * @author tomkelly
 * 
 */
public class NewSheetBuilder
{

	protected Matrix4d transform = null;

	protected List<Vertex> data = new ArrayList<Vertex>(3);

	private Vertex lastPoint = null;

	/**
	 * A new sheet is constructed fromthe sheet higher up the hierarchy, and a
	 * list of points <b> in the coordinate space of the upstream node </b>
	 * 
	 * @param in
	 *            the upstream Sheet, or null to assume an empty transform
	 * @param points
	 *            the points specified in <i>the sheetsin's</i> coordinate
	 *            space.
	 */
	public NewSheetBuilder(Sheaf in)
	{
		if (in == null)
		{ // set to a 'null' transform matrix
			transform = new Matrix4d();
			transform.setIdentity();
		} else
		{
			transform = in.getTransform();
		}
	}

	/**
	 * After creation of the sheet use this method to add vertices. The
	 * coordinate here is to be noted. I consider the 'across' first(X) followed
	 * by up(Z/Y?!) then finally out (away from the previous sheet)
	 * 
	 * @param x
	 *            accross
	 * @param y
	 *            up
	 * @param z
	 *            out
	 */
	// the list of flatpoints so far
	List<FlatPoint> lfp = null;
	// the transforrm to convert from world space to the coords of the points being entered
	Matrix4d partOne = null;
	// the equation of the plane for the current points being entered
	Tuple4d abcd;
	public void addPoint(double x, double y, double z)
	{
		if (data == null)
		{
			error("The makeSheet command has already been called, you can't add any more coordinates!");
		}
		lastPoint = new Vertex(x, z, y); // y is out of the system!
		data.add(lastPoint);
		double size = data.size();
		if (size == 3)
		{
//			 convert the specified points to the global coord system
			normalisePoints();
			// find the plane of the incomming points global coord system
			abcd = findPlane();
			//System.err.println("Plane is "+abcd+" data size "+data.size());
			lfp = new ArrayList<FlatPoint>();
			flattern(abcd); // also
		}
		else if (size > 3)
		{
			flattenPoints(lastPoint, partOne);
		}
	}
	
	public List<FlatPoint>getFlatPointList()
	{
		return lfp;
	}

	/**
	 * Adds a type to the last specified
	 * 
	 * @param in
	 *            the type to add to the last addPoint() point!
	 */
	public void setPointType(EdgeType in)
	{
		lastPoint.addType(in);
	}

	/**
	 * Once the sheet is constructed calling this routine will do the math to
	 * create the sheet object
	 * 
	 * @return The sheet that has just been built.
	 */
	public Sheaf makeSheet()
	{
		if (data.size() < 3)
			error("There are only " + data.size() + " points specified!");
		
		// transform in 2D so in 1st quadrant & has an edge market as BOTTOM
		// at the bottom!
		Matrix4d partTwo = normalisePlaneLocation(lfp);
		// combine the matrices
		Matrix4d finalMatrix = new Matrix4d(partTwo); // is this right?
		finalMatrix.mul(partOne);
		// ensure no more data can be added once the transform is set.
		data = null;
		transform = null;
		//System.err.println("part one is \n"+partOne);
		//partOne.setIdentity();
		//System.err.println("part one is now\n"+partOne);
		return new Sheaf(lfp, finalMatrix);
	}

	/**
	 * Apply the inverse transfrom to the points to move them into the absolute /
	 * normalised coordinate system.
	 * 
	 */
	protected void normalisePoints()
	{
		Iterator<Vertex> it = data.iterator();
		Matrix4d mat = new Matrix4d(transform);
	    mat.invert();
		while (it.hasNext())
		{
			Vertex v = it.next();
			v.multiplyBy(mat);
		}
	}

	/**
	 * Finds the cross product between the first three points int the data set
	 * and returns the ABC & D values :)
	 * 
	 * @param points
	 * @return
	 */
	protected Tuple4d funnyPlane()
	{
		Tuple4d t = findPlane(data.get(2).sub(data.get(1)),data.get(1).sub(data.get(0)));
		Tuple4d f = findPlane(data.get(3).sub(data.get(2)),data.get(2).sub(data.get(1)));
		//Tuple4d g = findPlane(data.get(2).sub(data.get(1)),data.get(1).sub(data.get(0)));
		
		return t;
	}
	
	
	public Tuple4d findPlane()
	{
		Iterator<Vertex> it = data.iterator();
		Vertex one = it.next();
		Vertex two = it.next();
		double oneTwo = one.distanceTo(two);
		Vertex t1 = null,t2= null,t3= null;
		double best = -Double.MAX_VALUE;
		while (it.hasNext())
		{
			Vertex three = it.next();
			
			double twoThree = two.distanceTo(three);
			
			if (oneTwo+twoThree > best)
			{
				t1 = one; t2 = two; t3 = three;
				best = oneTwo+twoThree;
				System.err.println(best);
			}
			
			one = two;
			two = three;
			oneTwo = twoThree;
		}
		Vertex three = data.get(0);
		double twoThree = two.distanceTo(three);
		if (oneTwo+twoThree > best)
		{
			t1 = one; t2 = two; t3 = three;
			best = oneTwo+twoThree;
			System.err.println(best);
		}
		one = two;
		two = three;
		oneTwo = twoThree;
		three = data.get(1);
		twoThree = two.distanceTo(three);
		if (oneTwo+twoThree > best)
		{
			t1 = one; t2 = two; t3 = three;
			best = oneTwo+twoThree;
			System.err.println(best);
		}
		one = two;
		two = three;
		oneTwo = twoThree;
		
		
		
		//System.err.println(t1+" "+t2+" "+t3);
		
		// return findPlane(t3.sub(t2),t2.sub(t1));
		//return findPlane(data.get(3).sub(data.get(2)),data.get(2).sub(data.get(1)));
		return findPlane(data.get(2).sub(data.get(1)),data.get(1).sub(data.get(0)));
	}
			
	public Tuple4d findPlane(Vector3d u, Vector3d v)
	{
		v.normalize();
		u.normalize();
	
		u.cross(v,u);
		Vertex a = data.get(0);
		u.normalize();
		if (Double.isNaN(u.length()))
		{
			u = data.get(2).sub(data.get(1));
			System.err.println(u);
			v = data.get(1).sub(data.get(0));
			System.err.println(v);
			u.cross(u,v);
			System.err.println(u);
			Thread.dumpStack();
			System.exit(2);
		}
		assert abs(u.length()-1.0) < 0.0000001 : u.length();
		double offset = (a.getX() * u.x + a.getY() * u.y + a.getZ() * u.z);
		Tuple4d out = new Point4d(u.x,u.y,u.z,offset);
		return out;
	}

	/**
	 * Creates a transform to rotate the specified plane to lie on the XZ
	 * axes and applies it to the points and return a list of the 2D points represented
	 * 
	 * @param in
	 *            the normalised plane equation
	 * @return a pair of the new flat points and the 3D transform that was used
	 *         on them
	 */
	protected Matrix4d flattern(Tuple4d in)
	{
		Matrix4d trans = new Matrix4d();
		trans.setIdentity();
		List<FlatPoint> flat = new ArrayList<FlatPoint>();

		Vector3d current = new Vector3d(in.x,in.y,in.z);
		Vector3d goal = new Vector3d(0,1,0);
		current.normalize(); goal.normalize();
		
		Vector3d axis = new Vector3d();
		axis.cross(current,goal);

		// find the angle between the two vectors
		double angle;
		// are parallel
		if (axis.x == 0 && axis.y == 0 && axis.z == 0)
		{
			// shoddy solution to finding unique axis, direction irrelevant
			if (current.x > 0)
			{
				axis.set(-1,0,0);
			}
			else 
			{
				axis.set(1,0,0);
			}
			// parallel axis! eep. Find out whether the same or opposite...
			// they are normalised so this works
			if (current.x == goal.x && current.y == goal.y && current.z == goal.z)
			{
				// same direction no rotation necessary
				angle = 0;
			}
			else
			{
				// must be exactley opposite
				angle = Math.PI;
			}
		}
		else
		{
			Vector3d diff = new Vector3d(goal);
			diff.sub(current); // is this the wrong way around?
			angle = Math.acos((2-(diff.lengthSquared()))/2);
		}
		//System.err.println("rotation is around " +axis +" by "+angle);
		
		// perform the rotation
		Matrix4d rot = new Matrix4d();
		rot.setIdentity();
		rot.setRotation(new AxisAngle4d(axis,angle));
		
		trans.setTranslation(new Vector3d(0,-in.w,0));
		trans.mul(rot);
		partOne=trans;
		//System.err.println(trans);
		
		Iterator<Vertex> dp = data.iterator();
		while (dp.hasNext())
		{
			Vertex v = dp.next();
			flattenPoints(v,partOne);
		}
		
		//Pair<List<FlatPoint>, Matrix4d> pair = new Pair<List<FlatPoint>, Matrix4d>(
		//		flat, trans);
		return trans;
	}

	/**
	 * Flattens the vertex using the specified transform, also adds it to the global list of 
	 * vertices
	 * @param v
	 * @param trans
	 * @return
	 */
	public void flattenPoints(Vertex v, Matrix4d trans)
	{
		v.multiplyBy(trans);
		// check all the points are planar!
		//System.err.println("height is "+v.getY());
		if (Math.abs(v.getY()) > 0.001)
		{
			//fatalErrorSD("Non planar vertex ("+v+") submitted for sheet "+Math.abs(v.getY()));
		}
		FlatPoint togo = new FlatPoint(v.getX(), v.getZ());
		// add the properties from the 3d to the 2d version
		Iterator<EdgeType> it = v.getTypes();
		while (it.hasNext()){togo.addType(it.next());}
		lfp.add(togo);
	}
	
	
	/**
	 * Takes the plane in 2D space and constructs a 3D transform to move it into
	 * the 2D first quadrent, with a sensible up direction. This is tricky
	 * stuff! Assume that they are in the XZ 3D space and that 'up' is Z.
	 * 
	 */
	protected Matrix4d normalisePlaneLocation(List<FlatPoint> points)
	{
		// first deal with rotation. Locate bottom edge vector.
		Iterator<FlatPoint> it = points.iterator();
		Vector2d toStraighten = null;
		while (it.hasNext())
		{
			FlatPoint fp = it.next();
			//System.err.println(fp);
			if (fp.ofType(REFERENCE))
			{
				if (toStraighten != null)
				{
					fatalErrorSD("More than one vertex with REFERENCE tags!");
				}
				// if not the final vertex
				if (it.hasNext())
				{
					FlatPoint next = it.next();
					toStraighten = new Vector2d(fp);
					//System.err.println(">>>"+next);
					toStraighten.sub(next);
					//System.err.println("from "+next+" to "+fp);
					if (next.ofType(REFERENCE))
					{
						fatalErrorSD("More than one vertex with REFERENCE tags!!");
					}
				}
				else // final vertex, connects to first
				{
					toStraighten = new Vector2d(fp);
					toStraighten.sub(points.get(0));
				}
			}
		}
		/*
		trying to ground (0.0, -2.0)
		2D Angle is 1.5707963267948966 now rotating
		trying to ground null
		2D Angle is 0.0 now rotating
		*/
		//System.err.println("trying to ground "+toStraighten);

		Matrix4d rot = new Matrix4d();
		rot.setIdentity();
		double angle;
		 
		// if there was a reference do a rotation, otherwise leave it as is!
		if (toStraighten != null)
		{
			//toStraighten.normalize();
			angle = -angleBetween(new Vector2d(1,0), toStraighten);
			//angle = angle; // sign change for rotates - they're counterclockwise
			rot.rotY(angle);
		}
		else // no preference for a rotation so ignore it
		{
			angle = 0;
		}
		// find min value of each point in Z,X directions

		double minX = Double.MAX_VALUE;
		double minY = Double.MAX_VALUE;
		//System.err.println("2D Angle is "+ angle +" now rotating");
		
		it = points.iterator();
		// find min at same time as applying rotation!
		while (it.hasNext())
		{
			FlatPoint fp = it.next();
			double tmpX = fp.x* cos(angle)+fp.y*sin(angle); // this bit here needs to rotate!
			double tmpY =-fp.x* sin(angle)+fp.y*cos(angle); //counterclockwise!
			fp.x = tmpX; fp.y = tmpY;
			///System.err.println("****"+fp);
			if (fp.x < minX) minX = fp.x;
			if (fp.y < minY) minY = fp.y;
		}
		// apply translation to ensure all are just positive
		Matrix4d trans= new Matrix4d();
		trans.setIdentity();
		trans.setTranslation(new Vector3d(-minX,0,-minY));
		trans.mul(rot);
		//System.err.println("After relocation it is");
		it = points.iterator();		
		while (it.hasNext())
		{
			FlatPoint fp = it.next();
			fp.x = fp.x-minX;
			fp.y = fp.y-minY;
			//System.err.println(">>>"+fp);
		}
		// return completed matrix - still untested!
		return trans;
	}
}

