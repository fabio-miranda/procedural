package util;


/**
 * renamed from circular element to save keyboard wear and tear... 
 * <b> circular element</b><br> 
 * 
 * Represents an ordered circular list element0
 * @author people
 *
 */
public class CE <E>
{
	public CE<E> next = null;
	public CE<E> previous = null;
	
	public E thing = null;
	
	public CE(E in)
	{
		thing = in;
		// added, circle of one:
		next = this;
		previous = this;
	}
	
	public CE(CE<E> in)
	{
		this.next = in.next;
		this.previous = in.previous;
	}

	public E get()
	{
		return thing;
	}
	
	public CE<E> clone()
	{
		CE<E> c = new CE<E>(thing);
		c.next = next;
		c.previous = previous;
		return c;
	}
	
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		sb.append("CE: "+thing.toString());
		if (true)
		{
		if (next == null) sb.append("\n  next is null");
		else sb.append("next is "+next.thing.toString());
		if (previous == null) sb.append("\n  previous is null");
		else sb.append("  previous is "+previous.thing.toString());
		}
		return sb.toString();
	}
	
	public CE<E> findElement(E in)
	{
		CircularIterator ci = new CircularIterator(this);
		while (ci.hasNext())
		{
			ci.next();
			if (ci.current.thing == in)
			{
				return ci.current;
			}
		}
		//element not found...
		return null;
	}
	
	/**
	 * Depending on what data you have, none, either or bother may be applicable
	 * UNTESTED
	 * @param in
	 */
	public void addAfterMe(CE<E> in)
	{
		in.next= next;
		in.previous = this;
		next.previous = in;
		next = in;
	}
	public void addBeforeMe(CE<E> in)
	{
		in.previous = previous;
		in.next = this;
		previous.next = in;
		previous = in;
	}
	
}
