package util;

public class ObjectWrapper
{
	private Object object;

	public ObjectWrapper(Object object)
	{
		super();
		this.object = object;
	}

	public Object getObject()
	{
		return object;
	}

	public void setObject(Object object)
	{
		this.object = object;
	}
	
}
