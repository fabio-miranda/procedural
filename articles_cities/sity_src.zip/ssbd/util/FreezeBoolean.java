package util;

import java.util.Random;

import java.io.Serializable;

public abstract class FreezeBoolean implements Serializable
{
	public abstract boolean freeze(Random r);
}
