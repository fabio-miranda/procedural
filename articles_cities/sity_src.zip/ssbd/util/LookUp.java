package util;

import java.util.Hashtable;
import java.util.Map;

/** Generic hashtable from string to the specified type
 * 
 * @author tomkelly
 *
 * @param <E>
 */
public class LookUp<E>
{
	
	Map<String,E> map = new Hashtable<String,E>();
	
	public boolean has (String in)
	{
		return map.containsKey(in);
	}
	
	public void add(String name, E thing)
	{
		map.put(name, thing);
	}
	
	public E find(String in)
	{
		return map.get(in);
	}
}
