package util;

import java.util.Random;

import java.io.Serializable;

import javax.vecmath.Vector3d;

public abstract class FreezeThreeVector  implements Serializable
{
	public abstract Vector3d doFreeze(Random r);
	
	public Vector3d freeze(Random r)
	{
		return doFreeze(r);
	}
}
