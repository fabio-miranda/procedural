package util;

import static sity.Parameters.*;

import geom.*;

import java.util.ListIterator;

import javax.vecmath.Vector2d;

/**
 * At the moment this is an iterator over the points from a convex shape!
 * in the future perhaps it will be over concave too.../.
 * @author people
 *
 */
public class TriIteratorConvex
{
	ListIterator<FlatPoint> it;

	FlatPoint origin;
	FlatPoint onLeft;
	// last points returned by nexT();
	private Triple<FlatPoint, FlatPoint, FlatPoint> cache 
	= new Triple<FlatPoint, FlatPoint, FlatPoint>(null,null,null);
	
	public TriIteratorConvex(ListIterator<FlatPoint> in)
	{
		it = in;
		origin = it.next();		
		onLeft = it.next();
	}
	
	/**
	 * Are there anymore triangles to come in this triangulation
	 */
	public boolean hasNext()
	{
		return it.hasNext();
	}
	
	/**
	 * Returns the next triangle in the triangluation of the convex
	 * shape :)
	 */
	public Triple<FlatPoint, FlatPoint, FlatPoint>next()
	{
		FlatPoint onRight = it.next();
		Triple<FlatPoint, FlatPoint, FlatPoint> output 
		= new Triple<FlatPoint, FlatPoint, FlatPoint>
		(origin, onLeft, onRight);
		cache = output;
		onLeft = onRight;
		return (output); 
	}
	/**
	 * Set of convience function to get around the generics bit
	 */
	public FlatPoint one  (){return cache.first ();} 
	public FlatPoint two  (){return cache.second();} 
	public FlatPoint three(){return cache.third ();} 
	
	/**
	 * Returns the two major vecors using the above routine
	 * @return
	 */
	public Pair<Vector2d,Vector2d>nextV()
	{
		Triple<FlatPoint, FlatPoint, FlatPoint>next = next();
		Vector2d one = new Vector2d(next.second());
		one.sub(next.first());
		Vector2d two = new Vector2d(next.third());
		one.sub(next.first());
		Pair<Vector2d, Vector2d> output 
		= new Pair<Vector2d, Vector2d>(one,two);
		return (output); 
	}
	
	/**
	 * These three return vectors of the two sides adjoining the origin point, 
	 * pointing toward the point?
	 * @return
	 */
	public Vector2d onLeft()
	{
		Vector2d one = new Vector2d(two());
		one.sub(one());
		return (one); 
	}
	
	public Vector2d onRight()
	{
		Vector2d two = new Vector2d(three());
		two.sub(one());
		return (two); 
	}
	public Vector2d onOtherSide()
	{
		Vector2d three = new Vector2d(two());
		three.sub(three());
		return (three); 
	}
	
	
	public void remove()
	{
		error("Functionality not implemented");
	}
}
