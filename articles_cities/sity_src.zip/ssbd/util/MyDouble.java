package util;

import java.util.Random;

/**
 * lol, display wrapper for an integer! woot!
 * @author tomkelly
 *
 */
public class MyDouble extends FreezeDouble
{
	public double value;
	public MyDouble(double value)
	{
		this.value = value;
	}

	public double doFreeze(Random r)
	{
		return value;
	}
}
