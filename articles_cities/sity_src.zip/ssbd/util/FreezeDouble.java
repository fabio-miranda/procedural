package util;

import java.util.Random;

import java.io.Serializable;

public abstract class FreezeDouble  implements Serializable
{
	protected double min = -Double.MAX_VALUE;

	protected double max = Double.MAX_VALUE;

	public abstract double doFreeze(Random in);

	public double freeze(Random r)
	{
		double result = doFreeze(r);
		if (result < min)
			return min;
		if (result > max)
			return max;
		return result;
	}

	public double getMin()
	{
		return min;
	}

	public double getMax()
	{
		return max;
	}

	public String toString()
	{
		return min + " to " + max + " output range";
	}
}
