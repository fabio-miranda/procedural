package util;

import java.util.Random;

import java.awt.List;

/**
 * lol, display wrapper for an integer! woot!
 * @author tomkelly
 *
 */
public class MyChoice extends FreezeInt
{
	public List choices;
	
	public MyChoice(String...strings)
	{
		choices = new List();
		for (String s: strings)
			choices.add(s);
		choices.select(0);
		// set max and min, for the user info more than anything else!
		min = 0;
		max = strings.length-1;
	}

	public int doFreeze(Random r)
	{
		return choices.getSelectedIndex();
	}
}
