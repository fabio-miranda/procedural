package util;

import static sity.Parameters.*;

import java.util.*;

/**
 * Data structure: linked list with forward and backwards links
 * 
 * @author people
 * 
 * @param <E>
 */
public class CircularList<E>
{
	public CE<E> current = null;

	private int size;
	
	public CircularList(Collection<E> in)
	{
		size = in.size();
		assert (size >= 2);
		Iterator<E> it = in.iterator();
		CE<E> first = new CE<E>(it.next());
		CE<E> prev = first;

		while (it.hasNext())
		{
			CE<E> ce = new CE<E>(it.next());
			ce.previous = prev;
			prev.next = ce;
			prev = ce;
		}

		CE<E> last = prev;

		last.next = first;
		first.previous = last;
		current = first;
	}

	/**
	 * Remove the current element from the list
	 */
	public void remove()
	{
		size--;
		if (oneBig())
		{
			error("attempt to remove last element in a circularlist");
			current = null;
		}
		else
		{
		current.next.previous = current.previous;
		current.previous.next = current.next;
		current = current.next;
		}
	}
	
	/**
	 * makes current point to the specified value
	 * @param in an element in the circle - it had better be there!
	 */
	public void select(CE<E> in)
	{
		current = in;
	}
	
	/**
	 * Replaces the current element with the specified one
	 *
	 */
	public void replace(CE<E> in)
	{
		current.next.previous = in;
		current.previous.next = in;
		in.next = current.next;
		in.previous = current.previous;
		current = in;
	}
	
	/**
	 * Number of remaining elements in the list
	 * @return
	 */
	public int size()
	{
		return size;
	}
	
	/**
	 * Returns if we are down to one element
	 * @return
	 */
	public boolean oneBig()
	{
		return current.previous == current;
	}
	
	/**
	 *  Returns next elements, previosu element and curernt element
	 * @return
	 */
	public E next()
	{
		current = current.next;
		return current.get();
	}

	public E prev()
	{
		current = current.previous;
		return current.get();
	}
	
	public E current()
	{
		return current.get();
	}

	public CircularIterator<E> iterator()
	{
		return new CircularIterator <E>(this);
	}
	
}
