package util;

import static sity.Parameters.*;

import java.util.Iterator;

public class CircularIterator<E> implements Iterator<E>
{
	CircularList<E> circle;
	
	CE<E> current;
	CE<E> first;
	
	public CircularIterator(CircularList<E> in)
	{
		circle = in;
		current = circle.current;
		first = null;
	}
	
	public CircularIterator(CE<E> in)
	{
		circle = null;
		current = in;
		first = null;
	}
	
	public boolean hasNext()
	{
		return current != first;
	}

	
	
	/**
	 * Two method to iterate over hte list by what is in the list, or by the
	 * list element itself (useful if you need to know whats before and after... )
	 * @return
	 */
	public CE<E> nextCircular()
	{
		if (hasNext())
		{
			if (first == null) first = current;
			CE<E> togo = current;
			current = current.next;
			return togo;
		}
		else // back at start
		{
			return null;
		}		
	}
	
	public E next()
	{
		if (hasNext())
		{
			if (first == null) first = current;
			CE<E> togo = current;
			current = current.next;
			return togo.thing;
		}
		else // back at start
		{
			return null;
		}
	}

	public void remove()
	{
		if (circle == null)
			fatalErrorSD("you must have used the CircularList constructor to remove an element");
		circle.current = current.previous;
		circle.remove();
		//fatalErrorSD("Call to unimplemented CircularListIterator.remove()");
	}

	public CE<E> getCurrent()
	{
		return current;
	}

}
