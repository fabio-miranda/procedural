package util;

import java.util.Random;

/** Class that represents a choice between yes or no for a feature. If yes then it also has a probability
 *  distribution
 * 
 * @author people
 *
 */
public class NYProbInt extends FreezeInt
{
	
	public boolean NY;
	public double mean;
	public double SD;
	
	/** constructor representing false for this feature
	 * 
	 *
	 */
	public NYProbInt()
	{
		NY = false;
	}
	
	/** Constructure meaning affirmative for this feature, with the specified mean and sd
	 * 
	 * @param mean the mean
	 * @param sd the standard deviation of the distribution
	 */
	public NYProbInt(int i, int a)
	{
		NY = true;
		min = i;
		max = a;
	}
	
	/** Applies a gaussian distribution function to freeze this value
	 *  around the specified parameters, 
	 */
	public int doFreeze(Random random)
	{	
		if (!NY) return Integer.MIN_VALUE;
		double out = random.nextGaussian() * SD;
		out += mean;
		return new Long(Math.round(out)).intValue();
	}
}
