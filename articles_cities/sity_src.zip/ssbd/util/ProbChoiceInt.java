package util;

import static sity.Parameters.error;

import java.util.Random;

/** Class that represents a probability based choice between different integers
 * 
 * @author people
 *
 */
public class ProbChoiceInt extends FreezeInt
{
	// default values
	public String[] names;
	public double[] probs;
	
	/** 
	 * 
	 * @param names array of the option names
	 * @param prob the prob of each name
	 */
	public ProbChoiceInt(String[] names, double[] probs)
	{
		this.names = names;
		this.probs = probs;
		
		if (names.length != probs.length)
		{
			if (names.length > 0)
				error("ProbChoiceInt starting with "+names[0]+" not same length as probabilities array");
			else
				error("ProbChoiceInt not same length as probabilities array");
		}
		
		if (names.length == 0)
			if (names.length > 0)
				error("ProbChoiceInt starting with "+names[0]+" given 0 length of options!");
			else
				error("ProbChoiceInt given zero length of options!");		
	}
	
	/** Uses a cumulatative probability to determine which choice is chosen!
	 */
	public int doFreeze(Random random)
	{	
		double totalProb = 0;
		for (int i = 0; i < probs.length; i++)
				totalProb += probs[i];
		
		double out = random.nextDouble()*totalProb;
		
		double accum = 0;
		for (int i = 0; i < probs.length; i++)
		{
			accum += probs[i];
			if (accum > out) return i;
		}
		error("something wrong in probchoiceint");
		return 0;
	}
}
