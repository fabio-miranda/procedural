package util;

import static sity.Parameters.*;

import java.util.Iterator;

public class CEFPBackwardsIterator implements Iterator<CEFP>
{
	CEFP current;
	CEFP first;
	
	public CEFPBackwardsIterator(CEFP in)
	{
		current = in.previous; // check this!
		first = null;
	}
	
	public boolean hasNext()
	{
		return current != first;
	}

	/**
	 * Two method to iterate over hte list by what is in the list, or by the
	 * list element itself (useful if you need to know whats before and after... )
	 * @return
	 */
	public CEFP nextCircular()
	{
		if (hasNext())
		{
			if (first == null) first = current;
			CEFP togo = current;
			current = current.previous;
			return togo;
		}
		else // back at start
		{
			return null;
		}		
	}
	
	public CEFP next()
	{
		if (hasNext())
		{
			if (first == null) first = current;
			CEFP togo = current;
			current = current.previous;
			return togo;
		}
		else // back at start
		{
			return null;
		}
	}
	
	public void remove()
	{
		fatalErrorSD("Call to unimplemented CircularListIterator.remove()");
	}

}
