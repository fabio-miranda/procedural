package util;

import java.lang.reflect.Field;

import java.awt.Component;
import java.awt.event.*;
import java.beans.*;
import java.text.NumberFormat;

import javax.swing.*;
import javax.swing.event.*;

import sity.Parameters;

public class boolean_GUI implements ChangeListener
{
	private boolean v;

	Object object;

	Field field;

	// names for true/false
	String[] names = { "yes", "no" };

	public boolean_GUI(Boolean value, ObjectWrapper source, Field field)
	{
		v = value;
		this.object = source.getObject();
		this.field = field;
	}

	public Component makeGUI()
	{
		JPanel p = new JPanel();
		ButtonGroup bg = new ButtonGroup();
		JRadioButton t = new JRadioButton(names[0]);
		JRadioButton f = new JRadioButton(names[1]);

		bg.add(t);
		bg.add(f);
		p.add(f);
		p.add(t);
		
		if (v)
			t.setSelected(true);
		else
			f.setSelected(true);

		t.addChangeListener(this);
		f.addChangeListener(this);

		return p;
	}

	public void stateChanged(ChangeEvent arg0)
	{
		JRadioButton b = (JRadioButton) arg0.getSource();
		if (b.getText().compareTo(names[0]) == 0)
		{
			v = true;
		}
		else
		{
			v = false;
		}
		Mojo.set(field, object, (Boolean)v);
	}
}
