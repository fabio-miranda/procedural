package util;

import java.util.Random;

import java.io.Serializable;

/** Class that represents a choice between yes or no for a feature. If yes then it also has a probability
 *  distribution
 * 
 * @author people
 *
 */
public class ProbDouble extends FreezeDouble
{
	public double mean;
	public double SD;

	/** Constructure meaning affirmative for this feature, with the specified mean and sd
	 * 
	 * @param mean the mean
	 * @param sd the standard deviation of the distribution
	 */
	public ProbDouble(double i, double a)
	{
		min = i;
		max = a;
	}
	
	public ProbDouble(double i, double a, double SD, double mean)
	{
		min = i;
		max = a;
		this.SD = SD;
		this.mean = mean;
	}
	
	/** Applies a gaussian distribution function to freeze this value
	 *  around the specified parameters, 
	 */
	public double doFreeze(Random random)
	{	
		double out = random.nextGaussian() * SD;
		out += mean;
		return out;
	}
}
