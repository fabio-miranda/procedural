package util;

import java.lang.reflect.Field;

import java.awt.Component;
import java.beans.*;
import java.text.NumberFormat;

import javax.swing.*;

import sity.Parameters;

public class double_GUI implements PropertyChangeListener
{
	private double v;
	Object object;
	Field field;
	public double_GUI(Double value, ObjectWrapper source, Field field)
	{
		v = value;
		this.object = source.getObject();
		this.field = field;
	}
	
	public Component makeGUI()
	{
		JPanel out = new JPanel();
		JFormattedTextField amountField = new JFormattedTextField(NumberFormat.getNumberInstance());
		amountField.setValue(v);
		amountField.setColumns(10);
        amountField.addPropertyChangeListener("value", this);
		out.add(amountField);
		return out;
	}

	public void propertyChange(PropertyChangeEvent arg0)
	{
		//System.err.println("Change to "+arg0.getNewValue().getClass().getSimpleName());
		Object o = arg0.getNewValue();
		double d;
		if (o instanceof Long)
		{
			d = Double.parseDouble(((Long)o).toString());
		}
		else if (o instanceof Double)
		{
			d = (Double)o;
		}
		else 
		{
			d = -1;
			Parameters.fatalErrorSD("Property change events returned something strange");
		}
		Mojo.set(field, object, (Double)d);
	}
}
