package util;

import java.util.List;
import java.util.Vector;

import junit.framework.TestCase;

public class CircularListTest extends TestCase
{
	public void testCircularList()
	{
		Double data[] = {1.,2.,3.,4.};
		List<Double>l = new Vector<Double>();
		for (int i = 0; i < data.length; i++) l.add(data[i]);
		
		CircularList<Double> cl = new CircularList<Double>(l);
		for (int i = 0; i < 10; i++)
		{
			assertTrue(cl.next()== 2);
			assertTrue(cl.next()== 3);
			assertTrue(cl.next()== 4);
			assertTrue(cl.next()== 1);
			
		}
		assertTrue(cl.prev() == 4);
		assertTrue(cl.prev() == 3);
		cl.remove();
		for (int i = 0; i < 10; i++)
		{
			assertTrue(cl.next()== 1);
			assertTrue(cl.next()== 2);
			assertTrue(cl.next()== 4);
		}
		assertTrue(cl.prev()== 2);
		assertTrue(cl.prev()== 1);
		assertTrue(cl.prev()== 4);
		assertTrue(cl.prev()== 2);
		
		cl.replace(new CE<Double>(new Double(10)));
		assertTrue(cl.current()== 10);
		for (int i = 0; i < 10; i++)
		{
			assertTrue(cl.next()== 4);
			assertTrue(cl.next()== 1);
			assertTrue(cl.next()== 10);
		}
	}
}
