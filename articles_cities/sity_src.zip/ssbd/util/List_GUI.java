package util;

import java.lang.reflect.Field;

import java.awt.*;
import java.beans.*;

/**
 * This is a list where people may select only one thing at present UNTESTEd
 * @author people
 *
 */
public class List_GUI implements PropertyChangeListener
{
	private List v;
	Object object;
	Field field;
	public List_GUI(List value, ObjectWrapper source, Field field)
	{
		v = value;
		this.object = source.getObject();
		this.field = field;
		//default value
	}
	
	public Component makeGUI()
	{
		//List out = List.class.cast(object);
		return v;
	}

	public void propertyChange(PropertyChangeEvent arg0)
	{
		/*System.err.println("Change to "+arg0.getNewValue().getClass().getSimpleName());
		Object o = arg0.getNewValue();
		int d;
		if (o instanceof Long)
		{
			d = ((Long)o).intValue();
		}
		else if (o instanceof Double)
		{
			d = (new Long(Math.round((Double)o))).intValue();
		}
		else 
		{
			d = -1;
			Parameters.fatalErrorSD("Property change events returned something strange");
		}
		Mojo.set(field, object, (Integer)d);*/
	}
}
