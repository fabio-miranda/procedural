package util;

import java.util.Random;

import java.io.Serializable;

public abstract class FreezeInt  implements Serializable
{
	protected int min = Integer.MIN_VALUE;
	protected int max = Integer.MAX_VALUE;
	public abstract int doFreeze(Random r);
	
	public int freeze(Random r)
	{
		int result = doFreeze(r);
		if (result < min) return min;
		if (result > max) return max;
		return result;
	}
	
	public int getMin()
	{
		return min;
	}
	
	public int getMax()
	{
		return max;
	}
	
	public String toString()
	{
		return min +" to "+ max +" output range";
	}
}
