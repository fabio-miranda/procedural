package util;

import static sity.Parameters.*;

import static geom.Vec2d.*;
import static java.lang.Math.*;
import geom.*;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import javax.vecmath.Vector2d;

/**
 * This is the concave replacement for the triangulator
 * 
 * @author people
 * 
 */
public class TriIteratorConcaveNoHoles
{
	List<FlatPoint> data;

	FlatPoint origin;

	FlatPoint onLeft;

	// last points returned by nexT();
	private Triple<FlatPoint, FlatPoint, FlatPoint> cache = new Triple<FlatPoint, FlatPoint, FlatPoint>(
			null, null, null);

	List<FlatPoint> convex = new Vector<FlatPoint>();

	CircularList<FlatPoint> cl;

	public TriIteratorConcaveNoHoles(ListIterator<FlatPoint> in)
	{
		data = new Vector<FlatPoint>();
		while (in.hasNext())
			data.add(in.next());

		cl = new CircularList<FlatPoint>(data);

		// set up circular list and list of convex joints
		CE<FlatPoint> start = cl.current;
		CE<FlatPoint> next = null;
		while (next != start)
		{	
			//System.err.println(">>triit>> "+cl.current.thing);
			if (angleBetween(cl.current.previous.thing, cl.current.thing,
					cl.current.next.thing) > PI)
			{
				convex.add(cl.current.thing);
			}
			cl.next();
			next = cl.current;
		}

	}

	/**
	 * Are there anymore triangles to come in this triangulation
	 */
	public boolean hasNext()
	{
		return cl.size() > 2;
	}

	/**
	 * Checks the current point in cl to see if its convex
	 * 
	 */
	public void checkConvex()
	{
		if (convex.contains(cl.current()))
		{
			if (angleBetween(cl.current.previous.thing, cl.current.thing,
					cl.current.next.thing) <= PI)
			{
				convex.remove(cl.current);
			}
		}
	}

	/**
	 * Returns the next triangle in the triangluation of the convex shape :)
	 */
	public Triple<FlatPoint, FlatPoint, FlatPoint> next()
	{
		int count = 0;
		while (!cl.oneBig())
		{
			count++;
			if (count > 190)
				assert(false);
			
			/*System.err.println("cl size "+cl.size());
			System.err.println(" >> "+angleBetween(cl.current.previous.thing, cl.current.thing,
					cl.current.next.thing));
			System.err.println("cley "+cl.current.previous.thing+" "+ cl.current.thing+" "+
					cl.current.next.thing);
					*/
			if (angleBetween(cl.current.previous.thing, cl.current.thing,
					cl.current.next.thing) < PI)
			{
				boolean good = true;
				Iterator<FlatPoint> it = cl.iterator(); // should be convex,
				// but dont need speed right now
				List<FlatPoint> triangle = new Vector<FlatPoint>(3);
				triangle.add(cl.current.previous.thing);
				triangle.add(cl.current.thing);
				triangle.add(cl.current.next.thing);

				/*System.err.println("  *************");
				System.err.println(triangle.get(0));
				System.err.println(triangle.get(1));
				System.err.println(triangle.get(2));
				System.err.println("<<*************>>");*/


				while (it.hasNext())
				{
					FlatPoint nfp = it.next();
					//System.err.println(">>" + nfp);
					if (pointIn(nfp, triangle) && !triangle.contains(nfp))
					{
						good = false;
						//System.err.println("not good");
						break;
					}
				}
				if (good)
				{
					cache = new Triple<FlatPoint, FlatPoint, FlatPoint>(
							cl.current.previous.thing, cl.current.thing,
							cl.current.next.thing);
					//System.err.println("removing " + cl.current());
					cl.remove();
					checkConvex();
					cl.prev();
					checkConvex();
					cl.next();
					//System.err.println("returning " + cache);
					return cache;
				}
			}
			cl.next();
		}
		assert(false);
		return null;
	}

	/**
	 * Set of convience function to get around the generics bit
	 */
	public FlatPoint one()
	{
		return cache.first();
	}

	public FlatPoint two()
	{
		return cache.second();
	}

	public FlatPoint three()
	{
		return cache.third();
	}

	/**
	 * Returns the two major vecors using the above routine
	 * 
	 * @return
	 */
	public Pair<Vector2d, Vector2d> nextV()
	{
		Triple<FlatPoint, FlatPoint, FlatPoint> next = next();
		Vector2d one = new Vector2d(next.second());
		one.sub(next.first());
		Vector2d two = new Vector2d(next.third());
		one.sub(next.first());
		Pair<Vector2d, Vector2d> output = new Pair<Vector2d, Vector2d>(one, two);
		return (output);
	}

	/**
	 * These three return vectors of the two sides adjoining the origin point,
	 * pointing toward the point?
	 * 
	 * @return
	 */
	public Vector2d onLeft()
	{
		Vector2d one = new Vector2d(two());
		one.sub(one());
		return (one);
	}

	public Vector2d onRight()
	{
		Vector2d two = new Vector2d(three());
		two.sub(one());
		return (two);
	}

	public Vector2d onOtherSide()
	{
		Vector2d three = new Vector2d(two());
		three.sub(three());
		return (three);
	}

	public void remove()
	{
		error("Functionality not implemented");
	}
}
