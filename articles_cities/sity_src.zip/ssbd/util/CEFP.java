package util;

import geom.FlatPoint;


/**
 * Represents an ordered circular list element of FlatPoints to save on
 * keyboard ware and tear due to endles <<>><><>>>>><!
 * @author people
 *
 */
public class CEFP implements Comparable
{
	public CEFP next = null;
	public CEFP previous = null;
	
	public FlatPoint thing = null;
	
	public CEFP(FlatPoint in)
	{
		thing = in;
	}

	public FlatPoint get()
	{
		return thing;
	}
	
	public String toString()
	{
		return " thing: "+thing.toString()+
		" prev "+previous.thing+
		" next "+next.thing;
	}

	public int compareTo(Object in)
	{
		if (in instanceof CEFP)
		{
			CEFP other = CEFP.class.cast(in);
			double red = other.thing.x - thing.x;
			if (red < 0) return -1;
			if (red > 0) return 1;
			return hashCode() - other.hashCode();
		}
		else
		{
			return 0;
		}
	}
	
	/**
	 * Copies all the points UNTESTED!
	 * @return
	 */
	public CEFP copy()
	{
		CEFPIterator it = new CEFPIterator(this);
		CEFP previous = new CEFP(it.next().thing.clone());
		CEFP first = previous;
		while (it.hasNext())
		{
			CEFP now = new CEFP(it.next().thing.clone());
			//System.err.println(now);
			previous.next = now;
			now.previous = previous;
			previous = now;
		}
		first.previous = previous;
		previous.next = first;
		return first;
	}
	
	/**
	 * Copies all the points but reverses thir pointers!
	 * @return
	 */
	public CEFP ypoc()
	{
		CEFPIterator it = new CEFPIterator(this);
		CEFP previous = new CEFP(it.next().thing.clone());
		CEFP first = previous;
		while (it.hasNext())
		{
			CEFP now = new CEFP(it.next().thing.clone());
			//System.err.println(now);
			previous.previous = now;
			now.next = previous;
			previous = now;
		}
		first.next = previous;
		previous.previous = first;
		return first;
	}
	
	/**
	 * Just copy this point, keeping the same pointers and flatpoint
	 * we point to THE SAME flatpoint after...
	 */
	public CEFP clone()
	{
		CEFP output = new CEFP(new FlatPoint(this.thing));
		output.next = next;
		output.previous = previous;
		return output;
	}
}
