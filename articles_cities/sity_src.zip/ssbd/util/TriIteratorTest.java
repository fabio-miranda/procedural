package util;

import geom.*;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import static sity.Parameters.*;

import javax.vecmath.Tuple2d;

import junit.framework.TestCase;

/**
 * Triangulates a polygon using an ear cutting method to cut of the next convec
 * triangle 
 * @author people
 *
 */
public class TriIteratorTest extends TestCase
{
	public void testTri()
	{
		List<FlatPoint> lfp = new ArrayList<FlatPoint>();
		double[][] data = { { 0, 0 }, { 0.5, 1.0 }, { 1.5, 1.0 }, { 0.5, 0 } };
		for (int i = 0; i < data.length; i++)
			lfp.add(new FlatPoint(data[i][0], data[i][1]));
		ListIterator<FlatPoint> lit = lfp.listIterator();

		TriIterator it = new TriIterator(new Sheaf(lfp));

		assertTrue("should be null and it is " + it.one(), it.one() == null);

		/*while (it.hasNext())
		{
			System.err.println(it.next());
		}*/
		
		it.next();
		//System.err.println("oppp"+it.one()+it.two()+it.three());
		assertTrue (it.one().equals(new FlatPoint(0.5, 0)));
		assertTrue (it.two().equals(new FlatPoint(0.0, 0.0)));
		assertTrue (it.three().equals(new FlatPoint(0.5, 1.0)));

		it.next();
		//System.err.println("2ppp"+it.one()+it.two()+it.three());
		assertTrue (it.one().equals(new FlatPoint(1.5, 1)));
		assertTrue (it.two().equals(new FlatPoint(0.5, 0.0)));
		assertTrue (it.three().equals(new FlatPoint(0.5, 1.0)));
		assertFalse(it.hasNext());
	}
	public void testConvex()
	{
		List<FlatPoint> lfp = new ArrayList<FlatPoint>();
		double[][] data = { { 0, 1 }, { 1., 1.2 }, { 2, 1 }, { 1.2, 0.8 }, {1,-1},{0.8,0.8} };
		for (int i = 0; i < data.length; i++)
			lfp.add(new FlatPoint(data[i][0], data[i][1]));
		ListIterator<FlatPoint> lit = lfp.listIterator();

		TriIterator ti = new TriIterator(new Sheaf(lfp));

		assertTrue("should be null and it is " + ti.one(), ti.one() == null);

		List<Face> out = new Vector<Face>();
		
		while (ti.hasNext())
		{
				ti.next();
				Face f = new Face();
				Tuple2d one   = ti.one();
				Tuple2d two   = ti.two();
				Tuple2d three = ti.three();
				f.addVertex(new Vertex(one.x,0,one.y));
				f.addVertex(new Vertex(two.x,0,two.y));
				f.addVertex(new Vertex(three.x,0,three.y));

				out.add(f);
		}
		//setupParameters();
		//anchor.createPolygon(out);
	}

	public void testReal()
	{
		List<FlatPoint> lfp = new ArrayList<FlatPoint>();
		double[][] data = { 	{25.19181710785074,17.583952365341723},
				{25.19181710785074,0.0},
				{0.0,1.0533626141106822},
				{0.7371764184265714,18.68339168524956},
				{1.5511864645286266,38.150944388047655},
				{2.247554861113656,54.8050244279652},
				{25.19181710785074,57.722133100114085},
				{25.19181710785074,37.085541824853415}, };
		for (int i = 0; i < data.length; i++)
			lfp.add(new FlatPoint(data[i][0], data[i][1]));
		ListIterator<FlatPoint> lit = lfp.listIterator();

		System.err.println("creating iterator");
		
		TriIterator ti = new TriIterator(new Sheaf(lfp));

		assertTrue("should be null and it is " + ti.one(), ti.one() == null);

		List<Face> out = new Vector<Face>();
		
		int count = 0;
		while (ti.hasNext())
		{
			count ++;
			System.err.println("count" + count);
				ti.next();
				Face f = new Face();
				Tuple2d one   = ti.one();
				Tuple2d two   = ti.two();
				Tuple2d three = ti.three();
				f.addVertex(new Vertex(one.x,0,one.y));
				f.addVertex(new Vertex(two.x,0,two.y));
				f.addVertex(new Vertex(three.x,0,three.y));
				
				System.err.println("here it is "+ti.one()+ti.two()+ti.three());

				out.add(f);
				if (count > 10) break;
		}
		//assertTrue  (count == data.length-1);
		//setupParameters();
		//anchor.createPolygon(out);
	}
	
}
