package util;

import java.util.Random;

/** Class that represents a choice between yes or no for a feature. If yes then it also has a probability
 *  distribution
 * 
 * @author people
 *
 */
public class ProbInt extends FreezeInt
{
	// default values
	public double mean = 10;
	public double SD = 5;
	
	/** Constructure meaning affirmative for this feature, with the specified mean and sd
	 * 
	 * @param mean the mean
	 * @param sd the standard deviation of the distribution
	 */
	public ProbInt(int i, int a)
	{
		min = i;
		max = a;
	}
	
	public ProbInt(int i, int a, double SD, double mean)
	{
		min = i;
		max = a;
		this.mean = mean;
		this.SD = SD;
	}
	
	/** Applies a gaussian distribution function to freeze this value
	 *  around the specified parameters, 
	 */
	public int doFreeze(Random random)
	{	
		double out = random.nextGaussian() * SD;
		out += mean;
		int result = new Long(Math.round(out)).intValue();
		return result;
	}
}
