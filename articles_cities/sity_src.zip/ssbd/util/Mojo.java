package util;

import java.lang.reflect.*;
import static sity.Parameters.*;
import com.jme.math.Rectangle;

/**
 * Wrapper for reflection, mostly from http://java.sun.com/docs/books/tutorial/reflect/object/invoke.html
 * 
 * @author people
 * 
 * @param <T>
 */
public class Mojo<T>
{
	public static void main(String[] args)
	{

		Rectangle rectangle;
		Class rectangleDefinition;
		Class[] intArgsClass = new Class[] { int.class, int.class };
		Integer height = new Integer(12);
		Integer width = new Integer(34);
		Object[] intArgs = new Object[] { height, width };
		Constructor intArgsConstructor;

		try
		{
			rectangleDefinition = Class.forName("java.awt.Rectangle");
			intArgsConstructor = rectangleDefinition.getConstructor(intArgsClass);
			rectangle = (Rectangle) createObject(intArgsConstructor, intArgs);
		}
		catch (ClassNotFoundException e)
		{
			fatalErrorSD(e.toString());
		}
		catch (NoSuchMethodException e)
		{
			fatalErrorSD(e.toString());
		}
	}

	T o = null;

	public Mojo(Class c, Object... arguments)
	{
		setup(c, arguments);
	}

	public Mojo(String s, Object... arguments) throws ClassNotFoundException
	{
		Class c = Class.forName(s);
		setup(c, arguments);
	}

	private void setup(Class c, Object... arguments)
	{

		try
		{
			Class[] ca = new Class[arguments.length];
			for (int i = 0; i < arguments.length; i++)
				ca[i] = arguments[i].getClass();
			Constructor constructor = c.getConstructor(ca);
			o = (T) createObject(constructor, arguments);
		}
		catch (NoSuchMethodException e)
		{
			fatalErrorSD(e.toString());
		}
	}

	public T get()
	{
		return o;
	}

	public Object run(String name, Object... arguments)
	{
		Class c = String.class;

		Class[] ca = new Class[arguments.length];
		for (int i = 0; i < arguments.length; i++)
			ca[i] = arguments[i].getClass();

		Class[] parameterTypes = new Class[] { String.class };
		Method method;
		try
		{
			method = o.getClass().getMethod(name, ca);
			return method.invoke(o, arguments);
		}
		catch (NoSuchMethodException e)
		{
			fatalErrorSD(e.toString());
		}
		catch (IllegalAccessException e)
		{
			fatalErrorSD(e.toString());
		}
		catch (InvocationTargetException e)
		{
			e.getTargetException().printStackTrace();
			fatalErrorSD(e.toString());
		}
		return null;
	}

	public static Object createObject(Constructor constructor, Object[] arguments)
	{
		Object object = null;

		try
		{
			object = constructor.newInstance(arguments);
			return object;
		}
		catch (InstantiationException e)
		{
			fatalErrorSD(e.toString());
		}
		catch (IllegalAccessException e)
		{
			fatalErrorSD(e.toString());
		}
		catch (IllegalArgumentException e)
		{
			fatalErrorSD(e.toString());
		}
		catch (InvocationTargetException e)
		{
			fatalErrorSD(e.toString());
		}
		return object;
	}

	public static void set(Field f, Object source, Object value)
	{
		try
		{
			f.set(source, value);
			// } catch (NoSuchFieldException e) {
			// System.out.println(e);
		}
		catch (IllegalAccessException e)
		{
			fatalErrorSD(e.toString());
		}
	}

}
