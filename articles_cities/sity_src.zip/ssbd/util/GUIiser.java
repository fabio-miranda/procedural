package util;

import java.util.Formatter;

import java.lang.reflect.Field;

import java.awt.*;
import java.text.NumberFormat;

import javax.swing.*;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.border.BevelBorder;

/**
 * Reflection based class that creates an editor for another class (that has only elemental fields) for some definition of elemental
 * 
 * @author people
 * 
 */
public class GUIiser
{

	Object object;
	String desc;
	
	/**
	 * Object we are operating on and its description
	 * @param in
	 * @param d
	 */
	public GUIiser(Object in, String d)
	{
		object = in;
		desc = d;
	}

	/**
	 * does the hard work
	 * 
	 * @return
	 */
	public Component getGUI()
	{
		JPanel out = new JPanel();
		out.setToolTipText(desc);
		out.setLayout(new BoxLayout(out,BoxLayout.PAGE_AXIS));
		out.setBorder(new BevelBorder(BevelBorder.LOWERED));
		Field[] fields = object.getClass().getFields();

		JLabel jl = new JLabel(desc);
		out.setToolTipText(desc);
		jl.setToolTipText(desc);
		out.add(new JLabel(desc));
		out.add(new JLabel(object.toString()));

		for (Field f : fields)
		{
			String s = desc;
			s = s.concat(object.toString());
			out.add(getComponent(f, object, desc));
			out.add(Box.createHorizontalGlue());
		}
		return out;
	}

	private void setVar(String in, String value)
	{
		try
		{
			Field f = getClass().getField(in);
			if (f.getDeclaringClass() == Integer.TYPE)
			{
				Integer i = new Integer(value);
				f.set(this, i);
			}
			else if (f.getDeclaringClass() == Double.TYPE)
			{
				Double d = new Double(value);
				f.set(this, d);
			}
		}
		catch (IllegalAccessException e)
		{
			sity.Parameters.fatalErrorSD("couldn't set field " + in + " to " + value);
		}
		catch (NoSuchFieldException e)
		{
			sity.Parameters.fatalErrorSD("couldn't find the field " + in);
		}
	}
	
	/**
	 * A 'switch' statment of primitive types that returns a gui editor for that type
	 * @param f
	 * @param toUse
	 * @return
	 */
	private Component getComponent(Field f, Object toUse, String desc)
	{
		JPanel out = new JPanel();
		out.add(new JLabel(f.getName()));

		try
		{
			Object val = f.get(toUse);
			try
			{
				//System.err.println("looking for >"+f.getType().getSimpleName()+"_GUI<");
				Mojo m = new Mojo("util."+f.getType().getSimpleName()+"_GUI", val, new ObjectWrapper(toUse), f);
				out.add((Component)m.run("makeGUI"));
			}
			catch (ClassNotFoundException e)
			{
				out.add(new JLabel(" Field type " + f.getType().getSimpleName() + " not editable yet!"));
			}
		}
		catch (IllegalAccessException e)
		{
			sity.Parameters.fatalErrorSD("trying to set field " + f.getName());
		}
		return out;
	}

}
