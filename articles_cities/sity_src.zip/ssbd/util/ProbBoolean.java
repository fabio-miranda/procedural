package util;

import java.util.Random;

/**
 * Class that represents a probability of something being true or false.
 * 
 * @author people
 * 
 */
 // was implements freeszeBoolean!
public class ProbBoolean extends FreezeBoolean
{
	public double chance = 0; // probability of this happening

	/**
	 * Constructure meaning affirmative for this feature, with the specified
	 * mean and sd
	 * 
	 * @param chance
	 *            the probability (0..1) of this being true
	 */
	public ProbBoolean(double chance)
	{
		this.chance = chance;
	}

	/**
	 * Applies a gaussian distribution function to freeze this value around the
	 * specified parameters,
	 */
	public boolean freeze(Random random)
	{
		double out = random.nextDouble();
		if (out < chance)
		{
			return true;
		} else
		{
			return false;
		}
	}
	
	public String toString()
	{
		return "yes/no output";
	}
}
