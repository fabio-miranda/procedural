package util;

import java.util.Random;

import javax.vecmath.Vector3d;

/** Class that represents a choice between yes or no for a feature. If yes then it also has a probability
 *  distribution NOT A JME VECTOR3D!!
 * 
 * @author people
 *
 */
public class ProbThreeVector extends FreezeThreeVector
{
	public double x,y,z;

	/** Constructure meaning affirmative for this feature, with the specified mean and sd
	 * 
	 * @param mean the mean
	 * @param sd the standard deviation of the distribution
	 */
	public ProbThreeVector(Vector3d in)
	{
		x = in.x;
		y = in.y;
		z = in.z;
	}
	
	/** Applies a gaussian distribution function to freeze this value
	 *  around the specified parameters, 
	 */
	public Vector3d doFreeze(Random random)
	{	
		return new Vector3d(x,y,z);
	}
}
