These files are part of the AntTweakBar library.
http://www.antisphere.com/Wiki/tools:anttweakbar

AntTweakBar is a free software released under the zlib license.
For conditions of distribution and use, see ../License.txt

Note for Linux users: depending on your system, you may need to rebuild
the library. To do so, type make in the src directory.
